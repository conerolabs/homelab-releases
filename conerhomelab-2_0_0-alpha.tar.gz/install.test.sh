#!/bin/bash
set -eo pipefail
VM_NAME="armbian"
VM_CLEAN_SNAPSHOT="clean-installation-20260816"
SSH_KEY="$HOME/.ssh/$VM_NAME"
INSTALL_SCRIPT_URL="https://raw.githubusercontent.com/conerolabs/homelab-releases/test/install.sh"

echo "Starting a clean $VM_NAME VM..."
if [[ $(virsh domstate "$VM_NAME") != "running" ]]; then
    echo "VM is not running, starting..."
    virsh start "$VM_NAME"
fi

# wait VM to boot up
echo "Waiting for VM to boot up and become available via ssh..."
# Loop until SSH is available on port 22
# Get the IP address of the VM
VM_IP=$(virsh domifaddr "$VM_NAME" --source agent | grep 'ipv4' | awk '{print $NF}' | grep '192.' | cut -d/ -f1)

# Wait for SSH to be available
while ! nc -z "$VM_IP" 22; do
    sleep 1
    echo -n "."
done

echo "VM is running, reverting to clean snapshot..."
virsh snapshot-revert "$VM_NAME" "$VM_CLEAN_SNAPSHOT"


# wait VM to boot up
echo "Waiting for VM to boot up and become available via ssh..."
# Loop until SSH is available on port 22
# Get the IP address of the VM
VM_IP=$(virsh domifaddr "$VM_NAME" | grep 'ipv4' | awk '{print $NF}' | cut -d/ -f1)

# Wait for SSH to be available
while ! nc -z "$VM_IP" 22; do
    sleep 1
done

# # generate ssh key
# ssh-keygen -t ed25519 -N "" -f "$SSH_KEY" <<< y
# # install the ssh public key in the VM
# echo "Installing ssh public key in $VM_NAME..."
# ssh-copy-id -i "$SSH_KEY" -o StrictHostKeyChecking=no andrea@"$VM_IP"

# run: curl -fsSL 'https://raw.githubusercontent.com/conerolabs/homelab-releases/test/install.sh' | bash
echo "Running the install script in $VM_NAME..."
ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no -t andrea@"$VM_IP" "curl -fsSL $INSTALL_SCRIPT_URL | bash"
echo "Installation script completed!"
