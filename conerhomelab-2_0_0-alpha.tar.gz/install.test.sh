#!/bin/bash
set -eo pipefail
VM_NAME="armbian"
SSH_KEY="$HOME/.ssh/$VM_NAME"
INSTALL_SCRIPT_URL="https://raw.githubusercontent.com/conerolabs/homelab-releases/test/install.sh"

bash runVM.sh clean

# # generate ssh key
# ssh-keygen -t ed25519 -N "" -f "$SSH_KEY" <<< y
# # install the ssh public key in the VM
# echo "Installing ssh public key in $VM_NAME..."
# ssh-copy-id -i "$SSH_KEY" -o StrictHostKeyChecking=no andrea@"$VM_IP"

VM_IP=$(virsh domifaddr "$VM_NAME" --source agent | grep 'ipv4' | awk '{print $NF}' | grep '192.' | cut -d/ -f1)

# run: curl -fsSL 'https://raw.githubusercontent.com/conerolabs/homelab-releases/test/install.sh' | bash
echo "Running the install script in $VM_NAME..."
ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no -t andrea@"$VM_IP" "curl -fsSL $INSTALL_SCRIPT_URL | bash"
echo "Installation script completed!"
