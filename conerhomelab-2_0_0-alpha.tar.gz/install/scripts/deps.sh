#!/bin/bash

DEPS_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
source "$DEPS_SCRIPT_DIR/commons.sh"

# Install sqlite3 and jq
if ! command -v sqlite3 &> /dev/null; then
    print_info "Installing sqlite3"
    sudo apt install -y sqlite3
fi
if ! command -v jq &> /dev/null; then
    print_info "Installing jq"
    sudo apt install -y jq
fi

REQUIRED_DEPS_QUERY="SELECT DISTINCT d.name
FROM deps AS d
JOIN service_deps AS sd ON d.id = sd.dep_id
JOIN services AS s ON s.id = sd.service_id
WHERE s.enabled = 1"

ALL_DEPS_JSON=$(sqlite3 -json "$HOMELAB_DB" "select * from deps" | jq .)
REQUIRED_DEPS_JSON=$(sqlite3 -json "$HOMELAB_DB" "$REQUIRED_DEPS_QUERY" | jq .)

function docker_install() {
    # Add Docker's official GPG key:
    sudo apt update
    sudo apt install ca-certificates curl
    sudo install -m 0755 -d /etc/apt/keyrings
    sudo curl -fsSL https://download.docker.com/linux/"$ID"/gpg -o /etc/apt/keyrings/docker.asc
    sudo chmod a+r /etc/apt/keyrings/docker.asc
    # Add the repository to Apt sources:
    sudo tee /etc/apt/sources.list.d/docker.sources <<EOF
Types: deb
URIs: https://download.docker.com/linux/$ID
Suites: "${UBUNTU_CODENAME:-$VERSION_CODENAME}"
Components: stable
Signed-By: /etc/apt/keyrings/docker.asc
EOF
    sudo apt update
    sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
}

# Optional
function headscale_install() {
    # Rileva automaticamente l'architettura (arm64 per la maggior parte dei SoC ARM, amd64 per PC)
    local ARCH VERSION DEB
    ARCH=$(dpkg --print-architecture)
    VERSION=$(curl -s "https://api.github.com/repos/juanfont/headscale/releases/latest" | jq -r '.tag_name' | sed 's/v//')
    DEB="headscale_${VERSION}_linux_${ARCH}.deb"

    # Scarica e installa
    wget "https://github.com/juanfont/headscale/releases/download/v${HEADSCALE_VERSION:-$VERSION}/${DEB}"
    sudo mv ./"$DEB" /var/cache/apt/archives/ && sudo apt install /var/cache/apt/archives/"$DEB"

    # Gestione del servizio nativo
    #sudo systemctl enable --now headscale
    # Verifica che il servizio sia attivo
    #sudo systemctl status headscale
}