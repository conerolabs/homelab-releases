import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import * as colors from "./colors.ts";

export function readDotenv(filePath: string): NodeJS.ProcessEnv {
    if (!fs.existsSync(filePath)) {
        return {};
    }

    const backup = { ...process.env };
    for (const key of Object.keys(process.env)) {
        delete process.env[key];
    }

    try {
        process.loadEnvFile(filePath);
        return { ...process.env };
    } finally {
        for (const key of Object.keys(process.env)) {
            delete process.env[key];
        }
        Object.assign(process.env, backup);
    }
}

export function printEnv(envs: NodeJS.ProcessEnv): void {
    console.log("");
    for (const [k, v] of Object.entries(envs)) {
        console.log(`${colors.YELLOW}${colors.BOLD}  ${k}${colors.END}=${colors.CYAN}'${v}'${colors.END}`);
    }
    console.log("");
}

export function writeEnv(envs: NodeJS.ProcessEnv, filePath: string): void {
    let content = "";
    for (const [k, v] of Object.entries(envs)) {
        content += `${k}='${v}'\n`;
    }
    fs.writeFileSync(filePath, content, "utf-8");
}

function formatKeys(keys: string[]): string {
    return `{${keys.map((k) => `'${k}'`).join(", ")}}`;
}

/**
 * Updates the environment variables in the toPath file based on the templateValues.
 * @param fromPath The path to the template environment file.
 * @param toPath The path to the environment file to update.
 * @param moreEnvs Optional additional env vars in the format KEY=VALUE.
 * @returns The updated environment variables.
 */
export async function setupEnv(fromPath: string, toPath: string, ...moreEnvs: string[]): Promise<NodeJS.ProcessEnv> {
    console.log("\nUpdating environment variables ...\n");

    const templateValues = readDotenv(fromPath);
    const oldValues = readDotenv(toPath);
    const additionalValues: NodeJS.ProcessEnv = {};
    for (const env of moreEnvs) {
        const [key, value] = env.split("=");
        if (key && value) {
            additionalValues[key] = value;
        }
    }

    const templateKeys = new Set(Object.keys(templateValues));
    const oldKeys = new Set(Object.keys(oldValues));
    const additionalKeys = new Set(Object.keys(additionalValues));

    const removedKeys = Array.from(oldKeys).filter((k) => !(templateKeys.union(additionalKeys).has(k)));
    const removedKeysSet = new Set(removedKeys);
    const addedKeys = Array.from(templateKeys.union(additionalKeys)).filter((k) => !oldKeys.has(k));

    const updatedKeys = Array.from(oldKeys.difference(removedKeysSet));

    if (addedKeys.length > 0) {
        console.log(`  ${colors.PLUS} Added: ${colors.YELLOW}${colors.BOLD}${formatKeys(addedKeys)}${colors.END}`);
    }
    if (updatedKeys.length > 0) {
        console.log(`  ${colors.PENCIL}  Updated: ${colors.YELLOW}${colors.BOLD}${formatKeys(updatedKeys)}${colors.END}`);
    }
    if (removedKeys.length > 0) {
        console.log(`  ${colors.ERROR} Removed: ${colors.YELLOW}${colors.BOLD}${formatKeys(removedKeys)}${colors.END}`);
    }

    // Keep old values only if present in template
    const values: NodeJS.ProcessEnv = {};
    for (const [k, v] of Object.entries(oldValues)) {
        if ((templateKeys.union(additionalKeys)).has(k)) {
            values[k] = v;
        }
    }
    // override with template values if not empty or new
    for (const [k, v] of [...Object.entries(templateValues), ...Object.entries(additionalValues)]) {
        if (v !== "" || !oldKeys.has(k)) {
            values[k] = v;
        }
    }

    printEnv(values);
    writeEnv(values, toPath);

    return values;
}

// CLI execution check
const scriptPath = process.argv[1] ? path.resolve(process.argv[1]) : "";
const currentFilePath = fileURLToPath(import.meta.url);

if (scriptPath && (scriptPath === currentFilePath || scriptPath.endsWith("setup_env.ts") || scriptPath.endsWith("setup_env.js"))) {
    const [fromPath, toPath, ...moreEnvs] = process.argv.slice(2);
    if (fromPath && toPath) {
        await setupEnv(fromPath, toPath, ...moreEnvs);
    }
}
