import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import * as colors from "./colors.ts";

export function readDotenv(filePath: string): NodeJS.ProcessEnv {
    if (!fs.existsSync(filePath)) {
        return {};
    }

    const backup = { ...process.env };
    for (const key of Object.keys(process.env)) {
        delete process.env[key];
    }

    try {
        process.loadEnvFile(filePath);
        return { ...process.env };
    } finally {
        for (const key of Object.keys(process.env)) {
            delete process.env[key];
        }
        Object.assign(process.env, backup);
    }
}

export function printEnv(envs: NodeJS.ProcessEnv): void {
    console.log("");
    for (const [k, v] of Object.entries(envs)) {
        console.log(`${colors.YELLOW}${colors.BOLD}  ${k}${colors.END}=${colors.CYAN}'${v}'${colors.END}`);
    }
    console.log("");
}

export function writeEnv(envs: NodeJS.ProcessEnv, filePath: string): void {
    let content = "";
    for (const [k, v] of Object.entries(envs)) {
        content += `${k}='${v}'\n`;
    }
    fs.writeFileSync(filePath, content, "utf-8");
}

function formatKeys(keys: string[]): string {
    return `{${keys.map((k) => `'${k}'`).join(", ")}}`;
}

export async function setupEnv(fromPath: string, toPath: string): Promise<NodeJS.ProcessEnv> {
    console.log("\nUpdating environment variables ...\n");

    const templateValues = readDotenv(fromPath);
    const oldValues = readDotenv(toPath);

    const templateKeys = new Set(Object.keys(templateValues));
    const oldKeys = new Set(Object.keys(oldValues));

    const removedKeys = Array.from(oldKeys).filter((k) => !templateKeys.has(k));
    const addedKeys = Array.from(templateKeys).filter((k) => !oldKeys.has(k));

    const updatedEnvs: Record<string, string> = {};
    for (const [k, v] of Object.entries(templateValues)) {
        if (v && k in oldValues && oldValues[k] !== v) {
            updatedEnvs[k] = v;
        }
    }
    const updatedKeys = Object.keys(updatedEnvs);

    if (addedKeys.length > 0) {
        console.log(`  ${colors.PLUS} Added: ${colors.YELLOW}${colors.BOLD}${formatKeys(addedKeys)}${colors.END}`);
    }
    if (updatedKeys.length > 0) {
        console.log(`  ${colors.PENCIL}  Updated: ${colors.YELLOW}${colors.BOLD}${formatKeys(updatedKeys)}${colors.END}`);
    }
    if (removedKeys.length > 0) {
        console.log(`  ${colors.ERROR} Removed: ${colors.YELLOW}${colors.BOLD}${formatKeys(removedKeys)}${colors.END}`);
    }

    // Keep old values only if present in template, override with template values if not empty or new
    const values: NodeJS.ProcessEnv = {};
    for (const [k, v] of Object.entries(oldValues)) {
        if (templateKeys.has(k)) {
            values[k] = v;
        }
    }
    for (const [k, v] of Object.entries(templateValues)) {
        if (v !== "" || !oldKeys.has(k)) {
            values[k] = v;
        }
    }

    printEnv(values);
    writeEnv(values, toPath);

    return values;
}

// CLI execution check
const scriptPath = process.argv[1] ? path.resolve(process.argv[1]) : "";
const currentFilePath = fileURLToPath(import.meta.url);

if (scriptPath && (scriptPath === currentFilePath || scriptPath.endsWith("setup_env.ts") || scriptPath.endsWith("setup_env.js"))) {
    const [fromPath, toPath] = process.argv.slice(2);
    if (fromPath && toPath) {
        await setupEnv(fromPath, toPath);
    }
}
