#!/bin/bash

GATUS_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$GATUS_SCRIPTS_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"
source "$HOMELAB_SCRIPTS_DIR/oidc.sh"

echo
echo -e "${BLUE}#########################################################"
echo "#              Configurazione di GATUS                  #"
echo "#        -- Uptime monitoring and alerting --           #"
echo -e "#########################################################${NC}"
echo

oidc_client_id gatus
echo
# Authelia Gatus client secret, poi faremo l'hash per Authelia
oidc_client_secret gatus file
echo
echo -e "${OK} Configurazione di Gatus completata."
echo