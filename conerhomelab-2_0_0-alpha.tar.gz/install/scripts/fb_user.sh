#!/bin/bash

ADD_FB_USER_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
source "$ADD_FB_USER_SCRIPT_DIR/commons.sh"
source "${HOMELAB_DIR}/scripts/script-utils.sh"
source "${HOMELAB_DIR}/scripts/env.sh"


function add_admin() {
    #! Interazione Utente
    echo -e "${PENCIL} Utente admin per File Browser? (Deve esistere anche in Authelia):"
    read -p "" -r FB_USERNAME
    echo -e "${PENCIL} Password (Non verrà utilizzata se si passa per Authelia, ma è richiesta):"
    read -s -p "" -r FB_PASSWORD
    crun "filebrowser users add $FB_USERNAME $FB_PASSWORD --perm.admin=true"
    edit_env "FILEBROWSER_ADMIN" "$FB_USERNAME"
}

function add_fb_homepage_user() {    
    echo "Creo l'utente per Homepage service..."
    crun "filebrowser users add homepage homepage-$(openssl rand -base64 8) --perm.admin=false"
    echo
    edit_env "HOMEPAGE_FILEBROWSER_USER" homepage    
}

function add_user() {
    local USER=$1
    echo "Creo l'utente ${USER} in File Browser"
    mkdir -p "${HOMELAB_DIR}/homelab_data/users/${USER}"
    crun "filebrowser users add ${USER} ${USER}-$(openssl rand -base64 8) \
        --perm.admin=false \
        --hideDotfiles=true"
    echo
    echo "Imposto lo scope dell'utente ${USER} a /users/${USER}"
    crun "filebrowser users update ${USER} --scope /users/${USER}"
}

function rm_user() {
    local USER=$1
    echo "Rimuovo l'utente ${USER} da File Browser"
    crun "filebrowser users rm ${USER}"
    rm -rf "${HOMELAB_DIR}"/homelab_data/users/"${USER}"
}

function list_user() {
    crun "filebrowser users ls"
}

cmd=$1
user=$2

if [ "$cmd" = "add" ]; then 
    case $user in
        admin)
            add_admin
            ;;
        homepage)
            add_fb_homepage_user
            ;;
        *)
            add_user "$user"
            ;;
    esac
elif [ "$cmd" = "rm" ]; then 
    rm_user "$user"
else 
    echo "Comando non riconosciuto"
    echo "Usa: $0 [add|rm] <user>"
    exit 1
fi
