#!/bin/bash

HEADSCALE_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$HEADSCALE_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"
source "$HOMELAB_ENV_FILE"

function start() {
    echo "start not yet implemented"
    exit 1
}

function set_dns() {
    NODE_IP=$(tailscale ip -4)
    DNS_IP=${1:-$NODE_IP}
    echo -e "Tailscale node IP: ${CYAN}$NODE_IP${NC}"
    echo -e "Going to change Headscale DNS IP: ${CYAN}$HEADSCALE_DNS -> $DNS_IP{NC}"

    if [[ "$DNS_IP" == "$HEADSCALE_DNS" ]]; then
        echo
    else
        edit_env HEADSCALE_DNS "$DNS_IP"
        source "$HOMELAB_DIR/.env"

        echo "Modifico il file di configurazione di Headscale..."
        export HEADSCALE_DNS="$DNS_IP"
        CREDENTIALS_DIRECTORY='$CREDENTIALS_DIRECTORY'
        export CREDENTIALS_DIRECTORY
        envsubst < "$INSTALL_DATA_DIR"/headscale/config.yaml | sudo tee /etc/headscale/config.yaml > /dev/null

        echo "Riavvio il servizio di Headscale..."
        sudo systemctl restart headscale
        sleep 1
        # Verifica che il servizio sia attivo
        sudo systemctl --no-pager status headscale
    fi    
}

# Parse arguments, first argument is the command, second argument is the IP address of the Tailscale node
COMMAND=$1
TS_NODE_IP=$2

# Check if the command is valid
if [[ "$COMMAND" != "start" && "$COMMAND" != "set_dns" ]]; then
    echo "Usage: $0 {start|set_dns} [TS_NODE_IP]"
    exit 1
fi

# Execute the appropriate function based on the command
if [[ "$COMMAND" == "start" ]]; then
    start
elif [[ "$COMMAND" == "set_dns" ]]; then
    if [[ -z "$TS_NODE_IP" ]]; then
        echo "Using the current Tailscale node as Headscale DNS"
    fi
    set_dns "$TS_NODE_IP"
fi