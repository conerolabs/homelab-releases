#!/bin/bash
set -eEou pipefail
FB_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "${FB_SCRIPT_DIR}"/commons.sh
source "${HOMELAB_SCRIPTS_DIR}"/print.sh
source "${HOMELAB_SCRIPTS_DIR}"/script-utils.sh
source "$HOMELAB_ENV_FILE"

echo
echo -e "${BLUE}#########################################################"
echo -e "##########   Configurazione di FILEBROWSER   ############"
echo -e "##########         -- File Browser --        ############"
echo -e "#########################################################${NC}"
echo

admin=$(crun "filebrowser users ls" | awk 'NR > 1 && $8 == "true" {print $2}')
homepage=$(crun "filebrowser users ls" | awk -v "user=$HOMEPAGE_FILEBROWSER_USER" 'NR > 1 && $2 == user {print $2}')

if [ -z "$admin" ]; then
    crun "filebrowser config init --auth.method=proxy --auth.header=Remote-User"
    bash "${FB_SCRIPT_DIR}"/fb_user.sh add admin
else
    echo -e "${INFO} Utente admin per File Browser già esistente: ${CYAN}${admin}${NC}"
fi
echo
if [ -z "$homepage" ]; then
    bash "${FB_SCRIPT_DIR}"/fb_user.sh add homepage
else 
    echo -e "${INFO} Utente per Homepage già presente: ${CYAN}${homepage}${NC}"
fi
echo

echo "Personalizzazione di File Browser..."
crun 'filebrowser config set --branding.files /branding'

echo
echo -e "${OK} Configurazione di File Browser completata."
echo
