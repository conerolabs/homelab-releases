// ANSI color codes for terminal text formatting

// Basic foreground colors
export const BLACK = "\x1b[0;30m";
export const RED = "\x1b[0;31m";
export const GREEN = "\x1b[0;32m";
export const BROWN = "\x1b[0;33m";
export const BLUE = "\x1b[0;34m";
export const PURPLE = "\x1b[0;35m";
export const CYAN = "\x1b[0;36m";
export const LIGHT_GRAY = "\x1b[0;37m";

// Bright foreground colors
export const DARK_GRAY = "\x1b[1;30m";
export const LIGHT_RED = "\x1b[1;31m";
export const LIGHT_GREEN = "\x1b[1;32m";
export const YELLOW = "\x1b[1;33m";
export const LIGHT_BLUE = "\x1b[1;34m";
export const LIGHT_PURPLE = "\x1b[1;35m";
export const LIGHT_CYAN = "\x1b[1;36m";
export const WHITE = "\x1b[1;37m";

// Background colors
export const BG_BLACK = "\x1b[40m";
export const BG_RED = "\x1b[41m";
export const BG_GREEN = "\x1b[42m";
export const BG_YELLOW = "\x1b[43m";
export const BG_BLUE = "\x1b[44m";
export const BG_PURPLE = "\x1b[45m";
export const BG_CYAN = "\x1b[46m";
export const BG_LIGHT_GRAY = "\x1b[47m";

// Bright background colors
export const BG_DARK_GRAY = "\x1b[100m";
export const BG_LIGHT_RED = "\x1b[101m";
export const BG_LIGHT_GREEN = "\x1b[102m";
export const BG_BRIGHT_YELLOW = "\x1b[103m";
export const BG_LIGHT_BLUE = "\x1b[104m";
export const BG_LIGHT_PURPLE = "\x1b[105m";
export const BG_LIGHT_CYAN = "\x1b[106m";
export const BG_WHITE = "\x1b[107m";

// Formatting
export const BOLD = "\x1b[1m";
export const FAINT = "\x1b[2m";
export const ITALIC = "\x1b[3m";
export const UNDERLINE = "\x1b[4m";
export const BLINK = "\x1b[5m";
export const NEGATIVE = "\x1b[7m";
export const CROSSED = "\x1b[9m";

// Reset
export const END = "\x1b[0m";

// Unicode Symbols
export const ERROR = "❌";
export const CHECK = "✅";
export const WARN = "⚠️";
export const INFO = "ℹ️";
export const PENCIL = "✏️";
export const PLUS = "➕";
export const BIN = "🗑️";
export const LOCKED = "🔒";

export const colors = {
    BLACK,
    RED,
    GREEN,
    BROWN,
    BLUE,
    PURPLE,
    CYAN,
    LIGHT_GRAY,
    DARK_GRAY,
    LIGHT_RED,
    LIGHT_GREEN,
    YELLOW,
    LIGHT_BLUE,
    LIGHT_PURPLE,
    LIGHT_CYAN,
    WHITE,
    BG_BLACK,
    BG_RED,
    BG_GREEN,
    BG_YELLOW,
    BG_BLUE,
    BG_PURPLE,
    BG_CYAN,
    BG_LIGHT_GRAY,
    BG_DARK_GRAY,
    BG_LIGHT_RED,
    BG_LIGHT_GREEN,
    BG_BRIGHT_YELLOW,
    BG_LIGHT_BLUE,
    BG_LIGHT_PURPLE,
    BG_LIGHT_CYAN,
    BG_WHITE,
    BOLD,
    FAINT,
    ITALIC,
    UNDERLINE,
    BLINK,
    NEGATIVE,
    CROSSED,
    END,
    ERROR,
    CHECK,
    WARN,
    INFO,
    PENCIL,
    PLUS,
    BIN,
    LOCKED,
};

export default colors;
