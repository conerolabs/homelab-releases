#!/bin/bash

HOMELAB_DIR=$(cd "$(dirname "${BASH_SOURCE}")/../../homelab" &>/dev/null && pwd)
HOMELAB_SCRIPTS_DIR="${HOMELAB_DIR}/scripts"

HOMELAB_DB=$HOMELAB_DIR/homelab.db

INSTALL_DATA_DIR=$(cd "$(dirname "${BASH_SOURCE}")/../../install" &>/dev/null && pwd)
HOMELAB_ENV_FILE=$HOMELAB_DIR/.env

HOMELAB_COMPOSE_FILE=$HOMELAB_DIR/docker-compose.yml

