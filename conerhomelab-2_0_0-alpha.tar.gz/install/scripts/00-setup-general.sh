#!/bin/bash

GENERAL_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$GENERAL_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"
source "$HOMELAB_SCRIPTS_DIR/env.sh"
source "$HOMELAB_ENV_FILE"

echo
NETWORK_INTERFACE=$(ip -d -j link | jq -r '.[] | select(.operstate == "UP" or .operstate == "UNKNOWN") | select(.linkinfo?.info_kind == null and .link_type != "loopback").ifname')
echo -e "NETWORK_INTERFACE: ${CYAN}${NETWORK_INTERFACE:-${RED}Not Found}${NC}"

LAN_IP=$(ip -4 -o addr show "$NETWORK_INTERFACE" | awk '{printf $4}' | sed 's/\/.*//')
echo -e "LAN_IP: ${CYAN}${LAN_IP:-${RED}Not Found}${NC}"

HOST_PUBLIC_IP=$(curl -s https://ipinfo.io/ip || true)
echo -e "HOST_PUBLIC_IP: ${CYAN}${HOST_PUBLIC_IP:-${RED}Not Found}${NC}"

DOCKER_GROUP_ID=$(getent group docker | cut -d: -f3)
echo -e "DOCKER_GROUP_ID: ${CYAN}${DOCKER_GROUP_ID:-${RED}Not Found}${NC}"

echo

HOST_UID=$(id -u)
echo -e "HOST_UID: ${CYAN}${HOST_UID:-${RED}Not Found}${NC}"

HOST_GID=$(id -g)
echo -e "HOST_GID: ${CYAN}${HOST_GID:-${RED}Not Found}${NC}"

echo

edit_env NETWORK_INTERFACE "$NETWORK_INTERFACE"
edit_env LAN_IP "$LAN_IP" "$HOMELAB_DIR/.env"
edit_env HOST_PUBLIC_IP "$HOST_PUBLIC_IP"
edit_env HOST_UID "$HOST_UID"
edit_env HOST_GID "$HOST_GID"
#edit_env DOCKER_GROUP_ID "$DOCKER_GROUP_ID"

echo