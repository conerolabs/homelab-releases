#!/bin/bash
TS_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$TS_SCRIPT_DIR/script-utils.sh"
source "$HOMELAB_ENV_FILE"


echo

LOGIN_URL=$($HEADSCALE_ENABLED && echo "$HEADSCALE_SERVER_URL" || echo "$TAILSCALE_LOGIN_URL")

config_url=$(tailscale debug prefs | jq .ControlURL)

if [[ "${LOGIN_URL}" == "${config_url//\"/}" ]]; then
    echo "Tailscale è già configurato per usare il login server corretto: $LOGIN_URL"
    #sudo tailscale down
else
    echo "Configuro Tailscale per usare il login server corretto: $LOGIN_URL"
    sudo tailscale logout
fi

bash "$TS_SCRIPT_DIR/tailscale-cli.sh" start
bash "$TS_SCRIPT_DIR/headscale-cli.sh" set_dns