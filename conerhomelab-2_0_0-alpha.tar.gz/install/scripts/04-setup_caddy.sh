#!/bin/bash

set -euo pipefail

CADDY_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "${CADDY_SCRIPT_DIR}"/commons.sh
source "${HOMELAB_SCRIPTS_DIR}"/print.sh

echo
echo -e "${BLUE}#########################################################"
echo -e "##########      Configurazione di CADDY      ############"
echo -e "##########        -- Reverse Proxy --        ############"
echo -e "#########################################################${NC}"
echo
echo "Checking Caddyfile configuration..."
echo
docker compose -f "$HOMELAB_DIR"/docker-compose.yml run --no-deps --rm caddy sh  -c "caddy validate -c /etc/caddy/Caddyfile && \
caddy fmt --overwrite /etc/caddy/Caddyfile && \
echo && \
echo 'Caddyfile is valid and formatted.'"
# && \
# echo 'Generating caddy.json...' && \
# caddy adapt --config /etc/caddy/Caddyfile --pretty > /etc/caddy/caddy.json"

echo
echo -e "${OK} Configurazione di Caddy completata."
echo