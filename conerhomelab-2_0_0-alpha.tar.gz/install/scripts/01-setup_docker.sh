#!/bin/bash
DOCKER_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$DOCKER_SCRIPT_DIR/commons.sh"

if jq -e . < "$INSTALL_DATA_DIR/docker/daemon.json" &>/dev/null; then
    if sudo diff -BEZq /etc/docker/daemon.json "$INSTALL_DATA_DIR/docker/daemon.json" > /dev/null 2>&1; then
        echo "- Docker configuration file /etc/docker/daemon.json is already set."
    else
        echo "- Configuring file /etc/docker/daemon.json ..."
        sudo cp "$INSTALL_DATA_DIR/docker/daemon.json" /etc/docker/daemon.json
        echo "- Restarting Docker ..."
        sudo systemctl restart docker
    fi
else
    echo "- Docker configuration file $INSTALL_DATA_DIR/docker/daemon.json is not a valid JSON file."
fi