#!/bin/bash
WEB_CONFIG_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$WEB_CONFIG_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"
source "$HOMELAB_SCRIPTS_DIR/env.sh"
source "$HOMELAB_SCRIPTS_DIR/oidc.sh"
source "$HOMELAB_ENV_FILE"

echo
echo -e "${BLUE}###############################################################"
echo "###########    Configurazione di Web-Config   ###############"
echo "#####         -- OIDC Auth Configuration --       ##########"
echo -e "###############################################################${NC}"
echo

# Generate WEBCONFIG_OIDC_CLIENT_ID if not present
oidc_client_id web-config
echo
# Generate WEBCONFIG_OIDC_CLIENT_SECRET if not present
oidc_client_secret web-config env
echo

# Generate WEBCONFIG_SESSION_SECRET if not present
echo -e "Generazione della chiave di sessione..."
if [[ -z $WEBCONFIG_SESSION_SECRET ]]; then
    WEBCONFIG_SESSION_SECRET=$(openssl rand -base64 32 | tr -d '\n')
    edit_env WEBCONFIG_SESSION_SECRET "$WEBCONFIG_SESSION_SECRET"
else
    echo -e "La chiave di sessione esiste già."
fi
echo
print_success "Configurazione OIDC per Web-Config completata."