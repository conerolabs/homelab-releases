import { existsSync } from "node:fs";
import path, { join } from "node:path";
import process from "node:process";
import { DatabaseSync } from "node:sqlite";
import { fileURLToPath } from "node:url";
import colors from "./colors.ts";

// CLI execution check
const scriptPath = process.argv[1] ? path.resolve(process.argv[1]) : "";
const currentFilePath = fileURLToPath(import.meta.url);

if (scriptPath && (scriptPath === currentFilePath || scriptPath.endsWith("setup_enabled.ts") || scriptPath.endsWith("setup_enabled.js"))) {
    const [fromDb, toDb] = process.argv.slice(2);
    if (fromDb && toDb) {
        if (!existsSync(fromDb)) {
            console.error(`${colors.RED}From database not found:${colors.END} ${colors.GREEN}${fromDb}${colors.END}`);
            process.exit(1);
        }
        if (!existsSync(toDb)) {
            console.error(`${colors.RED}To database not found:${colors.END} ${colors.GREEN}${toDb}${colors.END}`);
            process.exit(1);
        }
        console.log(`${colors.CYAN}Re-enabling services from ${colors.GREEN}${fromDb}${colors.CYAN} ... ${colors.END}`);
        setupEnabled(fromDb, toDb);
        console.log(`${colors.GREEN}Done.${colors.END}`);
    } else {
        console.error(`${colors.RED}Usage: node setup_enabled.ts <fromDb> <toDb>${colors.END}`);
    }
}

export function setupEnabled(fromDb: string, toDb: string) {
    if (fromDb === toDb) {
        return;
    }

    const fromDbConn = new DatabaseSync(fromDb, { readOnly: true });
    const toDbConn = new DatabaseSync(toDb);
    try {
        const result = fromDbConn.prepare("SELECT name, enabled FROM services").all();

        result.forEach((service: any) => {
            toDbConn.prepare("UPDATE services SET enabled = ? WHERE name = ?").run(service.enabled, service.name);
        });

    } finally {
        fromDbConn.close();
        toDbConn.close();
    }
}