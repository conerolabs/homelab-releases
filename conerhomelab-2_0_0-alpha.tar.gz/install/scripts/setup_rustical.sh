#!/bin/bash

RUSTICAL_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "${RUSTICAL_SCRIPT_DIR}"/commons.sh
source "$HOMELAB_SCRIPTS_DIR/print.sh"
source "$HOMELAB_SCRIPTS_DIR/oidc.sh"
source "$HOMELAB_ENV_FILE"


echo
echo -e "${BLUE}###############################################################"
echo "###########    Configurazione di RustiCal    ###############"
echo "#####        -- Calendar/Contacts Server --       ##########"
echo -e "###############################################################${NC}"
echo

oidc_client_id rustical
echo
# Authelia RustiCal client secret, poi faremo l'hash per Authelia)
# Secret file non ancora supportato da RustiCal, quindi lo leggiamo in un env var (non è ideale, ma è l'unica opzione al momento)
oidc_client_secret rustical env
echo
print_success "Configurazione di RustiCal completata."
echo