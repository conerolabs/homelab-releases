# colors.py
# ANSI color codes for terminal text formatting

# Basic foreground colors
BLACK = "\033[0;30m"
RED = "\033[0;31m"
GREEN = "\033[0;32m"
BROWN = "\033[0;33m"
BLUE = "\033[0;34m"
PURPLE = "\033[0;35m"
CYAN = "\033[0;36m"
LIGHT_GRAY = "\033[0;37m"

# Bright foreground colors
DARK_GRAY = "\033[1;30m"
LIGHT_RED = "\033[1;31m"
LIGHT_GREEN = "\033[1;32m"
YELLOW = "\033[1;33m"
LIGHT_BLUE = "\033[1;34m"
LIGHT_PURPLE = "\033[1;35m"
LIGHT_CYAN = "\033[1;36m"
WHITE = "\033[1;37m"

# Background colors
BG_BLACK = "\033[40m"
BG_RED = "\033[41m"
BG_GREEN = "\033[42m"
BG_YELLOW = "\033[43m"
BG_BLUE = "\033[44m"
BG_PURPLE = "\033[45m"
BG_CYAN = "\033[46m"
BG_LIGHT_GRAY = "\033[47m"

# Bright background colors
BG_DARK_GRAY = "\033[100m"
BG_LIGHT_RED = "\033[101m"
BG_LIGHT_GREEN = "\033[102m"
BG_BRIGHT_YELLOW = "\033[103m"
BG_LIGHT_BLUE = "\033[104m"
BG_LIGHT_PURPLE = "\033[105m"
BG_LIGHT_CYAN = "\033[106m"
BG_WHITE = "\033[107m"

# Formatting
BOLD = "\033[1m"
FAINT = "\033[2m"
ITALIC = "\033[3m"
UNDERLINE = "\033[4m"
BLINK = "\033[5m"
NEGATIVE = "\033[7m"
CROSSED = "\033[9m"

# Reset
END = "\033[0m"

# Unicode Symbols
ERROR = "❌"
CHECK = "✅"
WARN = "⚠️"
INFO = "ℹ️"
PENCIL = "✏️"
PLUS = "➕"
BIN = "🗑️"
LOCKED = "🔒"

# Example usage
if __name__ == "__main__":
    print(RED + "Red text" + END)
    print(GREEN + "Green text" + END)
    print(BLUE + "Blue text" + END)
    print(YELLOW + BOLD + "Bold yellow text" + END)
    print(BG_RED + WHITE + "White text on red background" + END)
    print(BG_GREEN + BLACK + "Black text on green background" + END)
    print(BG_BLUE + YELLOW + "Yellow text on blue background" + END)   