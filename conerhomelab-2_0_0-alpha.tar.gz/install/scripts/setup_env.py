from dotenv import dotenv_values
import colors

manually_set_env_vars = {
    "SERVER_NAME": "nome host del server, usato da Tailscale. Univoco, senza spazi e caratteri speciali",
    # "BACKUP_DEST",
    "DOMAIN": "il dominio principale per il quale verranno generati i certificati TLS",
    # "CADDY_EMAIL",
    "CLOUDFLARE_API_TOKEN": "Il token per le APIs di CLOUDFLARE, necessario per generare i certificati TLS tramite DNS challenge con Caddy.",
    # "TAILSCALE_API_KEY",
    # "NEXT_DNS_API_KEY",
    # "GATUS_TELEGRAM_BOT_TOKEN",
    # "GATUS_TELEGRAM_CHAT_ID",
    # "PORTAINER_ACCESS_TOKEN"
}

def print_env(envs: dict):
    print("")
    for k, v in envs.items():
        print(f"{colors.YELLOW}{colors.BOLD}  {k}{colors.END}={colors.CYAN}'{v}'{colors.END}")
    print("")

def write_env(envs: dict, path: str):
    with open(path, "w") as f:
        for k, v in envs.items():
            f.write(f"{k}='{v}'\n")

def fullfill_env(to_fill: dict, envs: dict):
    fullfilled = envs.copy()
    for var in to_fill:
        if envs[var] == "":
            # ask user to input the value for the missing environment variable
            value = input(f"  Please enter the value for {colors.YELLOW}{colors.BOLD}{var}{colors.END} ({to_fill[var]}):\n  {colors.PENCIL}  ")
            if value:
                fullfilled[var] = value
            else:
                raise ValueError(f"Missing required environment variable: {var}")
    return fullfilled

def setup_env(from_path, to_path):
    print(f"\nUpdating environment variables ...\n")

    template_values = dotenv_values(from_path)
    old_values = dotenv_values(to_path)

    removed_keys = set(old_values.keys()) - set(template_values.keys())
    added_keys = set(template_values.keys()) - set(old_values.keys())
    updated_envs = {k: v for k, v in template_values.items() if v != "" and k in old_values and old_values[k] != v}
    updated_keys = set(updated_envs.keys())
    if added_keys.__len__() > 0:
        print(f"  {colors.PLUS} Added: {colors.YELLOW}{colors.BOLD}{added_keys}{colors.END}")
    if updated_keys.__len__() > 0:
        print(f"  {colors.PENCIL}  Updated: {colors.YELLOW}{colors.BOLD}{updated_keys}{colors.END}")
    if removed_keys.__len__() > 0:
        print(f"  {colors.ERROR} Removed: {colors.YELLOW}{colors.BOLD}{removed_keys}{colors.END}")

    values = {
        **{k: v for k, v in old_values.items() if k in template_values}, # keep old values only if they are present in the template
        **{k: v for k, v in template_values.items() if v != "" or k not in old_values}
    }

    fullfilled_values = fullfill_env(to_fill=manually_set_env_vars, envs=values)
            
    print_env(fullfilled_values)
    write_env(fullfilled_values, to_path)