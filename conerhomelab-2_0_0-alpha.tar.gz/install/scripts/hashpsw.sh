#!/bin/bash
# Argon2 password hashing examples

# Install dependencies if needed
# sudo apt install -y argon2 openssl

set -Eeo pipefail

if [[ -z "$1" ]]; then
    echo "Password parameter missing."
    echo "Usage: $0 <password> <profile> [docker-compose]"
    echo "Available profiles: bitwarden, owasp, authelia"
    exit 1
fi

if [[ -z "$2" ]]; then
    echo "Profile parameter missing."
    echo "Usage: $0 <password> <profile> [docker-compose]"
    echo "Available profiles: bitwarden, owasp, authelia"
    exit 1
fi

if [[ -z "$3" ]] && [ "$2" = "authelia" ]; then
    echo "Docker Compose parameter missing."
    echo "!! Hashing with authelia requires a docker-compose file with authelia service declared" >&2
    echo "Usage: $0 <password> <profile> <docker-compose>"
    exit 1
fi

PSW=$1
PROFILE=$2
COMPOSE_FILE=$3

case $PROFILE in
    bitwarden)
        echo "Using Bitwarden default settings:"
        echo -n "$PSW" | argon2 "$(openssl rand -base64 32)" -e -id -k 65540 -t 3 -p 4
        ;;
    owasp)
        echo "Using OWASP minimum recommended settings:"
        echo -n "$PSW" | argon2 "$(openssl rand -base64 32)" -e -id -k 19456 -t 2 -p 1
        ;;
    authelia)
        echo "Using Authelia recommended settings:"
        # Generiamo un salt casuale di 16 byte (come richiesto da Authelia)
        HASH=$(docker compose -f "$COMPOSE_FILE" run --no-deps --rm authelia authelia crypto hash generate argon2 \
            --password "$PSW" \
            --variant argon2id \
            --iterations 3 \
            --memory 32768 \
            --parallelism 2 | grep -oP '\$argon2id\$.*')
        echo "$HASH"
        ;;
    *)
        echo "Unknown profile value. Please use 'bitwarden', 'owasp', or 'authelia'."
        exit 1
esac