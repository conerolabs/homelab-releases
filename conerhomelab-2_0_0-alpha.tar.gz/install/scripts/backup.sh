#!/bin/bash
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$SCRIPT_DIR"/script-utils.sh

# Configurazione percorsi
DATE=$(date +%Y-%m-%d_%H%M)

# Creazione cartella di destinazione se non esiste
mkdir -p "$BACKUP_DEST"

echo "--- Inizio Backup Nodo 1: $DATE ---"

# 1. Mettere in pausa i container per garantire l'integrità del database (opzionale ma consigliato)
cd "$BACKUP_SOURCE" && docker compose pause

# 2. Backup dei dati tramite rsync
# -a: archivio (mantiene permessi), -v: verbose, -z: compressione
rsync -avz --delete "$INSTALL_DIR" "$BACKUP_DEST"/latest/
rsync -avz /etc/unbound "$BACKUP_DEST"/latest/configs/

# 3. Creazione di uno snapshot compresso (storico)
tar -czf "$BACKUP_DEST"/backup_"$DATE".tar.gz -C "$BACKUP_DEST"/latest .

# 4. Riavvio dei container
cd "$INSTALL_DIR" && docker compose unpause

# 5. Pulizia: mantieni solo gli ultimi 4 backup (circa un mese)
ls -t $BACKUP_DEST/backup_*.tar.gz | tail -n +5 | xargs -d '\n' rm -f --

echo "--- Backup completato con successo ---"
