#!/bin/bash

## Manual Login with OAuth + API key generation

TS_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$TS_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"
source "$HOMELAB_SCRIPTS_DIR/env.sh"
source "$HOMELAB_SCRIPTS_DIR/script-utils.sh"
source "$HOMELAB_ENV_FILE"

function start() {
    local LOGIN_URL
    LOGIN_URL=$($HEADSCALE_ENABLED && echo "$HEADSCALE_SERVER_URL" || echo "$TAILSCALE_LOGIN_URL")
    if tailscale status &>/dev/null; then
        echo "Tailscale client è già in esecuzione"
    else
        echo "Avvio di Tailscale client in corso..."
        echo
        echo "Connessione con il control plane:"
        echo
        echo "  Login server: ${LOGIN_URL}"
        echo "  Hostname: $SERVER_NAME"
        echo
        sudo tailscale up --hostname="$SERVER_NAME" --login-server="$LOGIN_URL" --accept-dns=false
        echo "Tailscale è connesso."
        echo

        # dns_resolver=$(tailscale dns status --json | jq ".Resolvers[0].Addr")

        TS_IP=$(tailscale ip -4)
        if [[ "$TS_IP" == "$TAILSCALE_IP" ]]; then
            echo "L'IP di Tailscale è già configurato come TAILSCALE_IP: $TAILSCALE_IP"
        else
            edit_env TAILSCALE_IP "$TS_IP"
            echo
            echo "Aggiorno i record DNS in PiHole, il binding in Caddy e l'indirizzo per il monitoraggio del nodo Tailscale in Gatus..."
            recreate_container "$HOMELAB_COMPOSE_FILE" pihole gatus caddy
        fi
        if [[ -z "$TAILSCALE_API_KEY" ]]; then
            print_warn "TAILSCALE_API_KEY non è configurata. Creala tramite: https://console.tailscale.com/admin/settings/keys"
            local api_key=""
            read -rp "Inserisci il valore di TAILSCALE_API_KEY: " api_key
            edit_env TAILSCALE_API_KEY "$api_key"
        fi
        # if [[ "${dns_resolver//\"/}" != "$TS_IP" ]]; then
        #     print_warn "Configura questo nodo come DNS resolver della tua tailnet tramite https://console.tailscale.com/admin/dns"
        # fi
    fi
}

function stop() {
    
    sudo tailscale down
    edit_env TAILSCALE_IP ""

    echo "Riavvio Pi-Hole e Caddy per aggiornare la rete dell'HomeLab"
    recreate_container "$HOMELAB_COMPOSE_FILE" caddy pihole
}

# Parse arguments, first argument is the command
COMMAND=$1

# Check if the command is valid
if [[ "$COMMAND" != "start" && "$COMMAND" != "stop" ]]; then
    echo "Usage: $0 {start|stop}"
    exit 1
fi

# Execute the appropriate function based on the command
if [[ "$COMMAND" == "start" ]]; then
    start
elif [[ "$COMMAND" == "stop" ]]; then
    stop
fi