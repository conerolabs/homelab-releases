# Authelia User Management Script

A bash script to add new users to the Authelia `users_database.yml` configuration file with automatic password hashing.

## Location

```
Nodo1/install/scripts/add_authelia_user.sh
```

## Features

- ✅ Automatic password hashing using Authelia's recommended Argon2id settings
- ✅ Input validation (username, email format, groups)
- ✅ Duplicate user detection
- ✅ Automatic configuration backup before modifications
- ✅ YAML formatting and proper indentation
- ✅ Customizable user groups
- ✅ Color-coded output messages

## Prerequisites

- The script sources `script-utils.sh` for utility functions and colored output
- `AUTHELIA_VERSION` must be set in the `.env` file
- Docker must be running to execute the password hashing command
- The `hashpsw.sh` script must be present in the same directory

## Usage

### Basic Syntax

```bash
./add_authelia_user.sh -u <username> -p <password> -e <email> [-d <displayname>] [-g <groups>]
```

### Arguments

| Argument | Required | Description |
| ---------- | ---------- | ------------- |
| `-u <username>` | Yes | Unique username (alphanumeric, dots, hyphens, underscores) |
| `-p <password>` | Yes | Password to hash using Authelia settings |
| `-e <email>` | Yes | Valid email address |
| `-d <displayname>` | No | Full display name (defaults to username) |
| `-g <groups>` | No | Comma-separated groups (defaults to "users") |
| `-h` | No | Show help message |

### Examples

#### Simple User (Developer)

```bash
cd /media/andrea/Data/homelab/Nodo1/install/scripts
./add_authelia_user.sh -u john.dev -p "MySecurePass123!" -e john@example.com
```

This creates a user with:

- Username: `john.dev`
- Display Name: `john.dev` (auto-generated)
- Groups: `users` (default)

#### User with Full Details

```bash
./add_authelia_user.sh \
  -u jane.smith \
  -p "AnotherSecurePass456!" \
  -e jane.smith@company.com \
  -d "Jane Smith"
```

#### Admin User with Custom Groups

```bash
./add_authelia_user.sh \
  -u admin.user \
  -p "SuperSecureAdminPass789!" \
  -e admin@example.com \
  -d "Main Administrator" \
  -g "users,admins,support"
```

## What the Script Does

1. **Validates all inputs** to ensure username, email, and groups format are correct
2. **Checks for duplicates** to prevent overwriting existing users
3. **Backs up the configuration file** with a timestamp before making changes
4. **Hashes the password** using the Authelia Docker image with proper Argon2id settings
5. **Generates YAML** formatted user entry
6. **Appends the user** to the `users_database.yml` file
7. **Displays the backup location** for recovery if needed

## Output Example

``` bash
ℹ Validating inputs...
✅ Configuration backed up to: /media/andrea/Data/homelab/Nodo1/homelab/authelia/config/users_database.yml.backup.20260326_192830
ℹ Hashing password using Authelia profile...
ℹ Adding user 'newuser' with:
  - Email: newuser@example.com
  - Display Name: newuser
  - Groups: users

✅ User 'newuser' has been successfully added!
ℹ Remember to restart Authelia for changes to take effect:
  cd /media/andrea/Data/homelab/Nodo1/homelab && docker-compose restart authelia
```

## After Adding a User

### Apply Changes

The configuration file is automatically backed up, but Authelia needs to be restarted to load the new users:

```bash
cd /media/andrea/Data/homelab/Nodo1/homelab
docker-compose restart authelia
```

### Verify the User

Check the Authelia logs to ensure the user was recognized:

```bash
docker-compose logs authelia | grep -i "user database"
```

### Recovery

If something goes wrong, restore from the backup:

```bash
cp users_database.yml.backup.YYYYMMDD_HHMMSS users_database.yml
```

## File Format Reference

The script generates entries like this:

```yaml
  username:
    password: "$argon2id$v=19$m=32768,t=3,p=2$..."
    displayname: "Display Name"
    email: "user@example.com"
    groups:
      - users
      - additional_group
```

## Security Notes

- ⚠️ **Never share passwords** in command history or scripts
- ⚠️ **Use strong passwords** (minimum 12 characters recommended)
- ⚠️ **Keep backups** of the `users_database.yml` file
- ✅ **Passwords are hashed** using Authelia's recommended Argon2id settings
- ✅ **Backups are created automatically** before modifications

## Troubleshooting

### Error: "User already exists"

- Check if the username is already in the file
- Use a different username or contact an admin to manage existing users

### Error: "Invalid email format"

- Ensure the email follows standard format: `user@domain.com`

### Error: "Failed to hash password"

- Verify Docker is running
- Check that `AUTHELIA_VERSION` is set in `.env`
- Ensure the Authelia Docker image is available

### Changes Not Applied

- Remember to restart the Authelia container
- Check container logs for any errors
- Verify the YAML syntax is correct in the configuration file

## Related Scripts

- [hashpsw.sh](./hashpsw.sh) - Password hashing utility
- [script-utils.sh](./script-utils.sh) - Shared utility functions
