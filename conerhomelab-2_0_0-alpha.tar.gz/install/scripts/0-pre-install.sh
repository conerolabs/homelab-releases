#!/bin/bash
# OS preparation

# shellcheck source=/dev/null
source /etc/os-release # be careful with variables names

if [[ $PRETTY_NAME =~ ^Armbian ]]; then
    bash setup_armbian.sh
fi