#!/bin/bash
set -Eeuo pipefail
AUTHELIA_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$AUTHELIA_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"
source "$HOMELAB_SCRIPTS_DIR/env.sh"
source "$HOMELAB_ENV_FILE"

# Crea la cartella per i segreti
AUTHELIA_SECRETS_DIR="$HOMELAB_DIR/authelia/secrets"
mkdir -p "$AUTHELIA_SECRETS_DIR"
chmod 700 "$AUTHELIA_SECRETS_DIR"
VAULTWARDEN_SECRETS_DIR="$HOMELAB_DIR/vaultwarden/secrets"
GATUS_SECRETS_DIR="$HOMELAB_DIR/gatus/secrets"
# anche se RustiCal non supporta ancora i file per i secret, li teniamo comunque organizzati in cartelle separate per chiarezza e per future estensioni (oltre a mantenere i segreti in env var per ora)
RUSTICAL_SECRETS_DIR="$HOMELAB_DIR/rustical/secrets"
WEBCONFIG_SECRETS_DIR="$HOMELAB_DIR/web-config/secrets"
HEADSCALE_SECRETS_DIR="/etc/headscale/secrets"

function hashSecret() {
    local CLIENT=$1
    local SECRET_FILE=$2
    local ENV_VAR=$3
    local HASH
    echo -e "- Generazione dell'hash Argon2 del segreto del client ${CYAN}$CLIENT${NC} ..."
    if [ -f "$SECRET_FILE" ]; then
        local SECRET
        local file_ext="${SECRET_FILE##*.}"
        # Se il file è un .cred, decripta il segreto prima di hasharlo
        if [[ "$file_ext" == "cred" ]]; then
            echo "  Decripto il secret..."
            # strip the extension (everything after the last dot)
            SECRET=$(sudo systemd-creds decrypt "${SECRET_FILE%.*}")
        else
            SECRET=$(cat "$SECRET_FILE")
        fi
        HASH=$("$AUTHELIA_SCRIPT_DIR"/hashpsw.sh "$SECRET" authelia "$HOMELAB_COMPOSE_FILE" | sed -n '2p')
        echo "  Hash generato: $HASH"
        echo -n "  "
        edit_env "$ENV_VAR" "$HASH"
    else
        print_warning "Il client non ha nessun segreto impostato. Eseguire prima la configurazione di ${CLIENT} e rilanciare lo script."
    fi
}

function create_user() {
    local admin=$1 # empty or "admin"
    local username
    local email
    local default_displayname
    local default_groups="${admin:+'admins,'}users"
    
    echo -e "  ${PENCIL} Username: "
    read -s -p "" -r username
    default_displayname="$username"
    echo -e "  ${PENCIL} Email: "
    read -s -p "" -r email
    echo -e "  ${PENCIL} Display Name [default: ${default_displayname}]: "
    read -s -p "" -r displayname
    echo -e "  ${PENCIL} Groups (comma-separated) [default: $default_groups]: "
    read -s -p "" -r groups
    
    if [ -z "$displayname" ]; then
        displayname="$default_displayname"
    fi
    if [ -z "$groups" ]; then
        groups="$default_groups"
    fi
    
    echo
    echo -e "${PENCIL} Password: ${NC}"
    read -s -p "" -r password
    echo
    read -s -p "${PENCIL} Confirm Password: ${NC}" -r password_confirm
    echo
    if [ "$password" != "$password_confirm" ]; then
        print_error "Passwords do not match. Please try again."
        exit 1
    fi

    bash "$AUTHELIA_SCRIPT_DIR/add_authelia_user.sh" -u "$username" -e "$email" -d "$displayname" -g "$groups" -p "$password"
}

echo
echo -e "${BLUE}#########################################################"
echo -e "#########     Configurazione di AUTHELIA      ###########"
echo -e "#########     -- Authentication Server --     ###########"
echo -e "#########################################################${NC}"
echo

# read -s -p "Attenzione verranno rimossi tutti i dati presenti nello storage di Authelia. Continuare? (digitare 'y' per confermare): " -r PSW_CONFIRM
# echo

# if [ "$PSW_CONFIRM" != "y" ]; then
#     echo "Operazione annullata."
#     exit 1
# fi

# Rimuove il database SQLite esistente (se presente)
#sudo rm authelia/config/db.sqlite3 2>/dev/null || true

echo -e "${YELLOW}Nota:${NC} Se è la prima volta che si esegue lo script, è normale che non ci siano segreti o hash generati. Verranno creati automaticamente. Se invece si sta rieseguendo lo script, i segreti esistenti verranno mantenuti e riutilizzati."
echo
echo "Generazione dei segreti di Authelia:"

# Genera i segreti direttamente nei file
echo "- Generazione del segreto JWT ..."
if [ -f "$AUTHELIA_SECRETS_DIR/JWT_SECRET" ]; then
    echo -e "  ${CYAN}JWT_SECRET${NC} esiste già in $AUTHELIA_SECRETS_DIR"
else
    openssl rand -base64 64 | tr -d '\n' > "$AUTHELIA_SECRETS_DIR/JWT_SECRET"
    echo -e "  ${CYAN}JWT_SECRET${NC} salvato in $AUTHELIA_SECRETS_DIR"
fi

echo "- Generazione del segreto di sessione ..."
if [ -f "$AUTHELIA_SECRETS_DIR/SESSION_SECRET" ]; then
    echo -e "  ${CYAN}SESSION_SECRET${NC} esiste già in $AUTHELIA_SECRETS_DIR"
else
    openssl rand -base64 64 | tr -d '\n' > "$AUTHELIA_SECRETS_DIR/SESSION_SECRET"
    echo -e "  ${CYAN}SESSION_SECRET${NC} salvato in $AUTHELIA_SECRETS_DIR"
fi

echo "- Generazione della chiave di crittografia dello storage ..."
if [ -f "$AUTHELIA_SECRETS_DIR/storage_encryption_key.txt" ]; then
    echo -e "  ${CYAN}storage_encryption_key.txt${NC} esiste già in $AUTHELIA_SECRETS_DIR"
else
    openssl rand -base64 64 | tr -d '\n' > "$AUTHELIA_SECRETS_DIR/storage_encryption_key.txt"
    echo -e "  ${CYAN}storage_encryption_key.txt${NC} salvato in $AUTHELIA_SECRETS_DIR"
fi

echo "- Generazione del segreto HMAC per OIDC ..."
if [ -f "$AUTHELIA_SECRETS_DIR/OIDC_HMAC_SECRET" ]; then
    echo -e "  ${CYAN}OIDC_HMAC_SECRET${NC}${NC} esiste già in $AUTHELIA_SECRETS_DIR"
else
    openssl rand -base64 64 | tr -d '\n' > "$AUTHELIA_SECRETS_DIR/OIDC_HMAC_SECRET"
    echo -e "  ${CYAN}OIDC_HMAC_SECRET${NC} salvato in $AUTHELIA_SECRETS_DIR"
fi

echo "- Generazione della chiave JWKS (RSA) ..." # usiamo un formato file standard
if [ -f "$AUTHELIA_SECRETS_DIR/oidc_jwks_key.pem" ]; then
    echo -e "  ${CYAN}oidc_jwks_key.pem${NC} esiste già in $AUTHELIA_SECRETS_DIR"
else
    openssl genrsa 2048 > "$AUTHELIA_SECRETS_DIR/oidc_jwks_key.pem"
    echo -e "  ${CYAN}oidc_jwks_key.pem${NC} salvato in $AUTHELIA_SECRETS_DIR"
fi

# Se volessimo estrarre la chiave pubblica (non necessaria per Authelia, ma utile per debug o altri usi)
#openssl rsa -in "$AUTHELIA_SECRETS_DIR/oidc_jwks_key.pem" -outform PEM -pubout -out "$AUTHELIA_SECRETS_DIR/oidc_jwks_pubkey.pem"
echo
## CREAZIONE DEI CLIENTS OIDC ##
echo "Configurazione dei clients OIDC di Vaultwarden, Gatus, Rustical e Headscale:"

hashSecret "Vaultwarden" "$VAULTWARDEN_SECRETS_DIR/oidc_client_secret.txt" "AUTHELIA_VAULTWARDEN_SECRET_HASH"
hashSecret "Gatus" "$GATUS_SECRETS_DIR/oidc_client_secret.txt" "AUTHELIA_GATUS_SECRET_HASH"
echo "$RUSTICAL_OIDC_CLIENT_SECRET" > "$RUSTICAL_SECRETS_DIR/oidc_client_secret.txt"
hashSecret "RustiCal" "$RUSTICAL_SECRETS_DIR/oidc_client_secret.txt" "AUTHELIA_RUSTICAL_SECRET_HASH"
echo "$WEBCONFIG_OIDC_CLIENT_SECRET" > "$WEBCONFIG_SECRETS_DIR/oidc_client_secret.txt"
hashSecret "Web-Config" "$WEBCONFIG_SECRETS_DIR/oidc_client_secret.txt" "AUTHELIA_WEBCONFIG_SECRET_HASH"
sudo cp "$HEADSCALE_SECRETS_DIR/oidc_client_secret" "$HEADSCALE_SECRETS_DIR/oidc_client_secret.cred"
hashSecret "Headscale" "$HEADSCALE_SECRETS_DIR/oidc_client_secret.cred" "AUTHELIA_HEADSCALE_SECRET_HASH"
echo
echo -e "Configurazione database degli utenti di Authelia:"
USERS_DB_FILE="$HOMELAB_DIR/authelia/config/users_database.yml"
if [ ! -f "$USERS_DB_FILE" ]; then
    echo -e "  ${CYAN}users_database.yml${NC} non trovato in $HOMELAB_DIR/authelia/config. Creazione di un nuovo file vuoto."
    echo -e "users:\n" > "$USERS_DB_FILE"
    echo -e "  Creazione del primo utente ${CYAN}admin${NC} per Authelia:"
    create_user "admin"
else
    echo -e "  ${CYAN}users_database.yml${NC} trovato in $HOMELAB_DIR/authelia/config"
    echo -e "  TODO: controlla se è presente almeno un utente admin"
fi
print_info "  Utilizza lo script ${ITALIC}add_authelia_user.sh${NOT_ITALIC} per aggiungere altri utenti"
echo
echo -e "Validazione del file di ${CYAN}configurazione${NC} (v$AUTHELIA_VERSION) ..."
docker compose -f "$HOMELAB_DIR"/docker-compose.yml run --no-deps --rm authelia sh -c "\
authelia config validate --config /config/config.yml --config /config/config.oidc.yml && \
authelia config template --config /config/config.yml > /config/resolved.yml && \
authelia config template --config /config/config.oidc.yml > /config/resolved.oidc.yml"

echo
echo -e "${OK} Configurazione di Authelia completata."
echo