#!/bin/bash
################################################################################
# Authelia User Management Script
# Adds a new user to the Authelia users_database.yml configuration file
################################################################################

set -euo pipefail

AUTH_USER_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
# shellcheck source=/dev/null
source "$AUTH_USER_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"

# shellcheck source=/dev/null
source "$HOMELAB_ENV_FILE"

USERS_DB_FILE="${HOMELAB_DIR}/authelia/config/users_database.yml"
HASH_SCRIPT="${AUTH_USER_SCRIPT_DIR}/hashpsw.sh"

# Default groups
DEFAULT_GROUPS="users"

################################################################################
# Helper Functions
################################################################################

show_usage() {
    echo -e "
${CYAN}Add Authelia User${NC} - Adds a new user to the Authelia configuration

${YELLOW}Usage:${NC}
    $0 -u <username> -p <password> -e <email> [-d <displayname>] [-g <groups>]

${YELLOW}Arguments:${NC}
    -u <username>      Username (required)
    -p <password>      Password (required, will be hashed)
    -e <email>         Email address (required)
    -d <displayname>   Display name (optional, defaults to username)
    -g <groups>        Comma-separated groups (optional, defaults to "users")
    -h                 Show this help message

${YELLOW}Examples:${NC}
    # Add user with minimal info
    $0 -u john -p "SecurePassword123!" -e john@example.com

    # Add user with all options
    $0 -u jane -p "SecurePassword456!" -e jane@example.com \\
       -d "Jane Doe" -g "users,admins"

${YELLOW}Note:${NC}
    - The password will be hashed using Authelia settings running Authelia container for hashing
    - The configuration file will be backed up before modifications
    - Ensure AUTHELIA_VERSION is set in .env

" | cat
}

################################################################################
# Validation Functions
################################################################################

validate_username() {
    local username=$1
    
    if [[ ! $username =~ ^[a-zA-Z0-9._-]+$ ]]; then
        print_error "Username must contain only alphanumeric characters, dots, hyphens, and underscores"
        return 1
    fi
    
    if grep -q "^\s*${username}:" "$USERS_DB_FILE"; then
        print_error "User '${username}' already exists in the database"
        return 1
    fi
    
    return 0
}

validate_email() {
    local email=$1
    
    if [[ ! $email =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
        print_error "Invalid email format: ${email}"
        return 1
    fi
    
    return 0
}

validate_groups() {
    local groups=$1
    
    # Basic validation: groups should be comma-separated alphanumeric
    if [[ ! $groups =~ ^[a-zA-Z0-9,_-]+$ ]]; then
        print_error "Groups must be comma-separated alphanumeric values"
        return 1
    fi
    
    return 0
}

################################################################################
# Password Hashing
################################################################################

hash_password() {
    local password=$1
    
    print_info "Hashing password using Authelia profile..."
    
    if [[ ! -f "$HASH_SCRIPT" ]]; then
        print_error "Hash script not found: ${HASH_SCRIPT}"
        return 1
    fi
    
    local hash_output
    hash_output=$("$HASH_SCRIPT" "$password" "authelia" 2>&1 | sed -n '2p') || {
        print_error "Failed to hash password"
        echo "$hash_output"
        return 1
    }
    
    echo "$hash_output"
}

################################################################################
# User Addition
################################################################################

generate_yaml_entry() {
    local username=$1
    local password_hash=$2
    local email=$3
    local displayname=$4
    local groups=$5
    
    # Convert comma-separated groups to YAML array format
    local yaml_groups=""
    IFS=',' read -ra group_array <<< "$groups"
    for group in "${group_array[@]}"; do
        yaml_groups+="      - ${group// /}
"
    done
    
    cat << EOF

  ${username}:
    password: "${password_hash}"
    displayname: "${displayname}"
    email: "${email}"
    groups:
${yaml_groups}
EOF
}

backup_config() {
    local backup_file="${USERS_DB_FILE}.backup.$(date +%Y%m%d_%H%M%S)"
    
    if cp "$USERS_DB_FILE" "$backup_file"; then
        print_success "Configuration backed up to: ${backup_file}"
        return 0
    else
        print_error "Failed to backup configuration file"
        return 1
    fi
}

add_user_to_database() {
    local username=$1
    local password_hash=$2
    local email=$3
    local displayname=$4
    local groups=$5
    
    local yaml_entry
    yaml_entry=$(generate_yaml_entry "$username" "$password_hash" "$email" "$displayname" "$groups")
    
    # Add the new user entry to the file
    echo "$yaml_entry" >> "$USERS_DB_FILE"
    
    print_success "User '${username}' added to the database"
}

################################################################################
# Main Script
################################################################################

main() {
    local username=""
    local password=""
    local email=""
    local displayname=""
    local groups="$DEFAULT_GROUPS"
    
    # Parse command line arguments
    while getopts "u:p:e:d:g:h" opt; do
        case $opt in
            u) username="$OPTARG" ;;
            p) password="$OPTARG" ;;
            e) email="$OPTARG" ;;
            d) displayname="$OPTARG" ;;
            g) groups="$OPTARG" ;;
            h) show_usage; exit 0 ;;
            *) show_usage; exit 1 ;;
        esac
    done
    
    # Validate required arguments
    if [[ -z "$username" ]] || [[ -z "$password" ]] || [[ -z "$email" ]]; then
        print_error "Missing required arguments"
        show_usage
        exit 1
    fi
    
    # Use username as displayname if not provided
    if [[ -z "$displayname" ]]; then
        displayname="$username"
    fi
    
    # Validate inputs
    #print_info "Validating inputs..."
    validate_username "$username" || exit 1
    validate_email "$email" || exit 1
    validate_groups "$groups" || exit 1
    
    # Verify configuration file exists
    if [[ ! -f "$USERS_DB_FILE" ]]; then
        print_error "Users database file not found: ${USERS_DB_FILE}"
        exit 1
    fi
    
    # Backup configuration
    backup_config > /dev/null || exit 1
    
    # Hash password
    local password_hash
    password_hash=$(hash_password "$password" | sed -n '2p') || exit 1

    echo
    print_info "Adding user '${username}' with:"
    echo "  - Email: ${email}"
    echo "  - Display Name: ${displayname}"
    echo "  - Groups: ${groups}"
    echo ""
    
    # Add user to database
    add_user_to_database "$username" "$password_hash" "$email" "$displayname" "$groups" > /dev/null
    
    print_success "User '${username}' has been successfully added!"
    echo
    print_info "If Authelia is running, remember to restart it for changes to take effect:"
    echo -e "${ITALIC}  cd ${HOMELAB_DIR} && docker compose restart authelia${NC}"
    echo
}

# Show help if no arguments provided
if [[ $# -eq 0 ]]; then
    show_usage
    exit 1
fi

main "$@"
