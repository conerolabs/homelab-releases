#!/bin/bash

UNBOUND_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$UNBOUND_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"

echo -e "${BLUE}#########################################################"
echo -e "###            Configurazione di UNBOUND              ###"
echo -e "###           -- DNS Recursive Resolver --            ###"
echo -e "#########################################################${NC}"
echo

# enable DNSSEC validation by fetching root zone's public key
# The -a option specifies the output file for the root key, which is used by Unbound to validate DNSSEC signatures.
echo "- Enabling DNSSEC validation by fetching root zone's public key ..."
sudo unbound-anchor -a /var/lib/unbound/root.key

# create unbound user (if not exists)
# checks for the user first with id and only runs useradd if the check fails.
# creates a system user (-r) with no login shell (-s /sbin/nologin), which is the standard practice for service accounts.
# The unbound user is assumed by default in the configuration to drop privileges for security
echo "- Creating unbound user and setting permissions for /var/lib/unbound ..."
id -u unbound &> /dev/null || sudo useradd -r -s /sbin/nologin unbound
sudo chown -R unbound:unbound /var/lib/unbound

# disable unbound-resolvconf service
# See: https://docs.pi-hole.net/guides/dns/unbound/#disable-resolvconfconf-entry-for-unbound-required-for-debian-bullseye-releases
if systemctl is-active --quiet unbound-resolvconf; then
    echo "- Disabling service unbound-resolvconf ..."
    sudo systemctl disable --now unbound-resolvconf 2>/dev/null || true
else
    echo "- Service unbound-resolvconf is already disabled."
fi

# unbound configuration file
if diff -BEZq /etc/unbound/unbound.conf.d/homelab.conf "$HOMELAB_DIR/homelab_config/unbound/homelab.conf" > /dev/null 2>&1; then
    echo "- Unbound configuration file /etc/unbound/unbound.conf.d/homelab.conf is already set."
else
    echo "- Configuring file /etc/unbound/unbound.conf.d/homelab.conf ..."
    sudo mkdir -p /etc/unbound/unbound.conf.d/
    # Configurazione percorsi
    sudo cp "$HOMELAB_DIR/homelab_config/unbound/homelab.conf" /etc/unbound/unbound.conf.d/

    # check unbound config
    sudo unbound-checkconf
    echo "- Restarting unbound ..."
    sudo service unbound restart
fi

# show unbound configurations
#cat /etc/unbound/unbound.conf.d/*.conf

# check unbound port status
#sudo ss -tulpn | grep unbound

# unbound logs
#sudo journalctl -u unbound -n 20

echo -e "${OK} Configurazione di UNBOUND completata."