#!/bin/bash

NAVIDROME_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$NAVIDROME_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/env.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"
source "$HOMELAB_SCRIPTS_DIR/script-utils.sh"
source "$HOMELAB_ENV_FILE"

echo
echo -e "${BLUE}#############################################################"
echo -e "##########      Configurazione di ${WHITE}NAVIDROME${BLUE}      ############"
echo -e "##########      -- Music Streaming Server --     ############"
echo -e "#############################################################${NC}"
echo

ADMIN_USER_DEFINED=$(crun "navidrome user list -n -f json -l error" | jq '. | map(select(.admin == true)) | .[0].admin')
if [ "$ADMIN_USER_DEFINED" = "true" ]; then
    echo -e "${INFO} Utente admin per Navidrome già esistente."
else
    #! Interazione Utente
    echo -e "${PENCIL} Utente admin per Navidrome? (Deve esistere anche in Authelia):"
    read -p "" -r USERNAME
    crun "navidrome user create -n  --username $USERNAME --admin -l error"
    read -p "Inserisci la stessa password per utilizzare Subsonic API da altri containers (es: Radio Manager): " -s -r PASSWORD
    echo
    
    edit_env "SUBSONIC_USERNAME" "$USERNAME"
    edit_env "SUBSONIC_PASSWORD" "$PASSWORD"

fi
echo
if [ -z "$HOMEPAGE_NAVIDROME_SALT" ] || [ -z "$HOMEPAGE_NAVIDROME_TOKEN" ]; then
    echo "Creazione del token per il widget di Navidrome in Homepage..."
    SALT=$(openssl rand -base64 8)
    edit_env "HOMEPAGE_NAVIDROME_SALT" "$SALT"
    edit_env "HOMEPAGE_NAVIDROME_TOKEN" "$(echo -n "$SUBSONIC_PASSWORD$SALT" | md5sum | awk '{print $1}')"
else
    echo -e "${INFO} Token per il widget di Navidrome già presente."
fi
echo
echo -e "${OK} Configurazione di Navidrome completata."
echo
