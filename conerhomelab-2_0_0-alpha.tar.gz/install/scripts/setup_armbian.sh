#!/bin/bash
ARMBIAN_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$ARMBIAN_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"

echo
echo -e "${BLUE}#########################################################${NC}"
echo
KERNEL_CONFIG_FILE=/etc/sysctl.d/99-homelab-optimizations.conf
ZRAM_CONFIG_FILE=/etc/default/armbian-zram-config
echo "Armbian OS setup ..."

echo "- Setting zram swap algorithm to zstd ..."
# manage also the case where the line is commented and eventually remove the comment
sed "s/^# SWAP_ALGORITHM=.*/SWAP_ALGORITHM=zstd/" "$ZRAM_CONFIG_FILE"   > .zstd.tmp && mv .zstd.tmp "$ZRAM_CONFIG_FILE"
sed "s/^SWAP_ALGORITHM=.*/SWAP_ALGORITHM=zstd/" "$ZRAM_CONFIG_FILE"   > .zstd.tmp && mv .zstd.tmp "$ZRAM_CONFIG_FILE"

echo "- Creating an emergency swap file on disk with lower priority..."
if [ -f /var/swap.img ]; then
    echo "Swap file already exists."
else
    # Crea un file vuoto da 1GB
    sudo fallocate -l 1G /var/swap.img
    sudo chmod 600 /var/swap.img
    # Lo formatta come swap
    sudo mkswap /var/swap.img
    # Lo attiva con priorità bassa (-2)
    sudo swapon -p -2 /var/swap.img
    if [ $(grep -c "/var/swap.img" /etc/fstab) -eq 0 ]; then
        echo "/var/swap.img  none  swap  sw,pri=-2  0  0" >> /etc/fstab
    fi
fi

echo "- Optimizing root filesystem (noatime, commit=600)..."
bash "$INSTALL_DATA_DIR"/armbian/add_fstab_options.sh
echo "  Remounting / ..."
sudo mount -o remount /
sudo systemctl daemon-reload

echo "- Creating configuration file for kernel fine tuning ..."
if [ ! -f $KERNEL_CONFIG_FILE ]; then
    cp "$INSTALL_DATA_DIR"/armbian/99-homelab-optimizations.conf /etc/sysctl.d/
else
    mv "$KERNEL_CONFIG_FILE" "$KERNEL_CONFIG_FILE".bak
    cp "$INSTALL_DATA_DIR"/armbian/99-homelab-optimizations.conf /etc/sysctl.d/
    echo "You can find previous optimization file in $KERNEL_CONFIG_FILE.bak.$(date +%F_%T)"
fi
sudo sysctl --system