#!/bin/bash
# Dependencies installation

DEPS_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source /etc/os-release # be careful with variables names
source "$DEPS_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"
source "$HOMELAB_ENV_FILE"

echo -n "Checking pre-requisites ..."
source "$DEPS_SCRIPT_DIR/deps.sh" # WILL INSTALL JQ AND SQLITE3
echo -e "  ${GREEN}OK${NC}"
# TODO: Eventually check also versions

echo "$REQUIRED_DEPS_JSON" | jq -c '.[]' | while read -r line; do
    name=$(echo "$line" | jq -r '.name')
    bash "$DEPS_SCRIPT_DIR"/deps-manager.sh install "$name"
done