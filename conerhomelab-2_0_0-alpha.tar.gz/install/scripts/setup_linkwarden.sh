#!/bin/bash

LINKWARDEN_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)

source "$LINKWARDEN_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/env.sh"
source "$HOMELAB_SCRIPTS_DIR/oidc.sh"

oidc_client_id linkwarden
oidc_client_secret linkwarden env
edit_env LINKWARDEN_SECRET "$(openssl rand -base64 32 | tr -d '\n')"
edit_env POSTGRES_PASSWORD "$(openssl rand -base64 32 | tr -d '\n')"




