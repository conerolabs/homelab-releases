import subprocess
import json

def ts_host_info(label):
    ts = json.loads(subprocess.run("tailscale status --json", shell=True, capture_output=True, text=True).stdout)
    hostname = ts["Self"]["DNSName"].split(".")[0]
    ip = ts["Self"]["TailscaleIPs"][0]
    id = ts["Self"]["ID"]
    match label:
        case "id":
            return id
        case "hostname":
            return hostname
        case "ip":
            return ip
        case _:
            return None

def ts_peer_info():
    ts = json.loads(subprocess.run("tailscale status --json", shell=True, capture_output=True, text=True).stdout)
    nodes = []
    for nodekey in ts["Peer"]:
        hostname = ts["Peer"][nodekey]["DNSName"].split(".")[0]
        ip = ts["Peer"][nodekey]["TailscaleIPs"][0]
        id = ts["Peer"][nodekey]["ID"]
        nodes.append({"hostname": hostname, "ip": ip})
    for n in nodes:
        print(n)

