#!/bin/bash
# Decodifica un token JWT e ne mostra il contenuto in formato leggibile
if [ $# -ne 1 ]; then
    echo "Uso: $0 <token_jwt>"
    exit 1
fi

# Decodifica il token JWT
TOKEN=$1

echo "$TOKEN" | cut -d. -f2 | base64 -d | jq