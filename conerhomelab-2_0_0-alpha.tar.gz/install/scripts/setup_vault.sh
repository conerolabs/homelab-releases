#!/bin/bash

VAULT_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "${VAULT_SCRIPT_DIR}"/commons.sh
source "${HOMELAB_SCRIPTS_DIR}"/print.sh
source "${HOMELAB_SCRIPTS_DIR}/oidc.sh"
source "${HOMELAB_SCRIPTS_DIR}/env.sh"
source "$HOMELAB_ENV_FILE"

echo
echo -e "${BLUE}###############################################################"
echo "#              Configurazione di VAULTWARDEN                  #"
echo "#                  -- Password Manager --                     #"
echo -e "###############################################################${NC}"
echo

oidc_client_id vaultwarden
# Authelia Vaultwarden client secret, poi faremo l'hash per Authelia
oidc_client_secret vaultwarden file

#! Interazione Utente
if [ -z "${VAULTWARDEN_ADMIN_TOKEN:-}" ]; then
    read -s -p "${PENCIL} Inserisci la password per il token di ADMIN: " -r PSW
    echo
    read -s -p "${PENCIL} Conferma la password:" -r PSW_CONFIRM
    echo
    if [ "$PSW" != "$PSW_CONFIRM" ]; then
        echo "${ERROR} Le password non corrispondono. Riprova."
        exit 1
    fi
    echo "Generazione dell'hash Argon2 per il token di ADMIN ..."
    HASH=$("$VAULT_SCRIPT_DIR"/hashpsw.sh "$PSW" bitwarden | sed -n '2p')
    echo "Hash generato: $HASH"
    edit_env "VAULTWARDEN_ADMIN_TOKEN" "$HASH"
else
    echo "Password per il token di ADMIN già configurata."
fi
echo
echo -e "$OK Configurazione di Vaultwarden completata."
echo