#!/bin/bash
# shellcheck source=/dev/null
source /etc/os-release # be careful with variables names, we need PRETTY_NAME for the welcome message
SETUP_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$SETUP_SCRIPT_DIR"/commons.sh
source "$HOMELAB_SCRIPTS_DIR"/print.sh

ENVIRONMENT=$1
if [ -z "$ENVIRONMENT" ]; then
    print_warning "No environment specified, defaulting to 'PROD'"
    ENVIRONMENT="PROD"
fi
if [ "$ENVIRONMENT" != "PROD" ] && [ "$ENVIRONMENT" != "DEV" ]; then
    print_error "Invalid environment specified: $ENVIRONMENT. Allowed values are 'PROD' and 'DEV'"
    exit 1
fi

source "$INSTALL_DATA_DIR"/.env

echo
echo -e "${BLUE}#########################################################"
echo "###                                                   ###"
echo "###             WELCOME TO CONERO LABS                ###"
echo "###              HOMELAB NODO 1 (v$HOMELAB_VERSION)                ###"
echo -e "${YELLOW}###                   - $ENVIRONMENT -                ${BLUE}###"
echo "###                                                   ###"
echo  -e "#########################################################${NC}"
echo
echo "Detected OS: $PRETTY_NAME"
echo
echo "- Adding bash aliases to ~/.bash_aliases..."
cat "$INSTALL_DATA_DIR"/.bash_aliases >> ~/.bash_aliases
sort -u ~/.bash_aliases > ~/.bash_aliases.tmp && mv ~/.bash_aliases.tmp ~/.bash_aliases

echo

docker compose down || true

bash 00-setup-general.sh
bash 01-setup_docker.sh
bash 02-setup_unbound.sh
bash 03-setup_pihole.sh
bash 04-setup_caddy.sh

# Must be called before setup_authelia.sh
bash setup_web_config.sh
bash setup_rustical.sh
bash setup_gatus.sh
bash setup_vault.sh
bash setup_authelia.sh

#bash setup_myspeed.sh
#bash setup_homepage.sh
bash setup_navidrome.sh
bash setup_filebrowser.sh

bash setup_headscale.sh
# should be the last one.
bash setup_tailscale.sh
