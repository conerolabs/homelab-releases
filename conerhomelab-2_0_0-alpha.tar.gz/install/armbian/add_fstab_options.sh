#!/bin/bash

# Configuration variables
TARGET_MOUNT="/"     # Change this to your target mount point (e.g., /home, /var)
COMMIT_VAL="600"      # The commit interval in seconds (ext4 default is 5)
FSTAB_FILE="/etc/fstab"
BACKUP_FILE="/etc/fstab.bak.$(date +%F_%T)"

echo "Backing up $FSTAB_FILE to $BACKUP_FILE..."
sudo cp "$FSTAB_FILE" "$BACKUP_FILE"

echo "Modifying $FSTAB_FILE for mount point: $TARGET_MOUNT..."

sudo awk -v mnt="$TARGET_MOUNT" -v cmt="$COMMIT_VAL" '
# Match the target mount point exactly in column 2, ignoring commented lines
$2 == mnt && $0 !~ /^[[:space:]]*#/ {
    
    # Check if options already exist
    split($4, opts_arr, ",")
    has_noatime = 0
    has_commit = 0
    
    for (i in opts_arr) {
        if (opts_arr[i] == "noatime") has_noatime = 1
        if (opts_arr[i] ~ /^commit=/) has_commit = 1
    }

    # Append options if they are missing
    if (!has_noatime) $4 = $4 ",noatime"
    if (!has_commit)  $4 = $4 ",commit=" cmt
    
    # Reconstruct the line cleanly
    printf "%-15s %-15s %-10s %-20s %-2s %-2s\n", $1, $2, $3, $4, $5, $6
    next
}
# Print all other lines exactly as they are
{ print $0 }
' "$BACKUP_FILE" | sudo tee "$FSTAB_FILE" > /dev/null

echo "Update complete. Verifying fstab syntax..."
sudo findmnt --verify