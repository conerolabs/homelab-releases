# AUTHELIA

## Docker Compose

Segui questa [guida](https://www.authelia.com/integration/deployment/docker/#using-a-secrets-volume) che elenca i segreti da generare prima di effettuare il deploy.  
Per l'utilizzo di Authelia come OIDC provider, occorre aggiungere anche i seguenti [segreti](https://www.authelia.com/configuration/methods/secrets/#security).

Utilizzeremo quindi lo script [setup_authelia](../setup_authelia.sh) per generari i secrets files e le variabili d'ambiente necessari.

## Configurazione - OIDC

Con OIDC, nel Caddyfile non devi più usare `forward_auth` per Vaultwarden. La protezione non è più a livello di "rete" (Caddy), ma a livello di "applicazione" (Vaultwarden).

### OIDC provider

I campi minimi richiesti per la nostra configurazione per il provider OIDC sono:

```yaml
identity_providers:
  oidc:
    hmac_secret: 'this_is_a_secret_abc123abc123abc'
    jwks:
      - key: |
          -----BEGIN PRIVATE KEY-----
          ...
          -----END PRIVATE KEY-----
    authorization_policies:
      vaulwarden:
        default_policy: 'deny'
        rules:
          - policy: 'one-factor'
            #subject: 'group:services'
            networks:
              - 'tailscale'
              - 'local'
    claims_policies:
      policy_name:
        id_token: []
        access_token: []
        custom_claims:
          claim_name:
            name: 'claim_name'
            attribute: 'attribute_name'
    scopes:
      scope_name:
        claims: []
    clients:
      - ... vedi sezione successiva
```

### OIDC client

---

## Configurazione - password hash - Ottimizzazione RAM

Dato il vincolo dei **2GB di RAM** sulla Rock 2A, il sistema è configurato per minimizzare i picchi di memoria durante l'autenticazione.

### Ottimizzazione Argon2id

L'algoritmo Argon2id è configurato con un costo di memoria di **32MB** (invece dei 1GB di default) per prevenire il trigger dell'OOM Killer durante i login simultanei.

**Parametri tecnici:**

- `memory`: 32768 (32MB)
- `iterations`: 3
- `parallelism`: 2

### Generazione Hash Password

Per aggiungere un utente o cambiare password, utilizzare il container ufficiale per garantire la compatibilità dell'hash:

```bash
docker run --rm authelia/authelia:latest authelia crypto hash generate argon2 \
    --password "TUA_PASSWORD_QUI" \
    --variant argon2id \
    --iterations 3 \
    --memory 32768 \
    --parallelism 2
    --key-length 32 \
    --salt-length 16
```

## Configurazione - access_control

In Authelia, la flessibilità del controllo accessi è uno dei suoi punti di forza. Apprezzerai sicuramente la logica booleana e granulare che sta dietro alla definizione delle regole.

Ecco cosa puoi configurare nella sezione `access_control`.

---

### 1. Le Policies (Cosa può fare l'utente)

Le policy definiscono il **livello di sicurezza** richiesto per accedere a una risorsa.

| Valore | Descrizione | Caso d'uso tipico |
| --- | --- | --- |
| **`bypass`** | Nessuna autenticazione richiesta. Il traffico passa liberamente. | Portale di login, file statici pubblici, API pubbliche. |
| **`one_factor`** | Richiede solo username e password (1FA). | Servizi interni a basso rischio (es. una dashboard di monitoraggio). |
| **`two_factor`** | Richiede password + un secondo fattore (TOTP, WebAuthn/Yubikey). | Vaultwarden, SSH gateway, pannelli admin. |
| **`deny`** | Accesso negato categoricamente a chiunque soddisfi i criteri. | Disabilitare temporaneamente un servizio o bloccare IP sospetti. |

---

### 2. Il campo Subject (Chi è l'utente)

Il `subject` definisce **a chi** si applica la regola. È un array di array (OR di AND), il che permette combinazioni molto potenti.

#### Valori standard

**`user:<username>`**: Specifica un singolo utente (es. `user:mario`).
**`group:<group_name>`**: Specifica tutti gli utenti appartenenti a un gruppo definito in `users_database.yml` (es. `group:admins`).

#### Esempi di logica booleana

**Logica AND (Tutti i criteri devono essere veri):**

```yaml
# L'utente deve essere 'luca' E far parte del gruppo 'developers'
subject: ["user:luca", "group:developers"]

```

**Logica OR (Almeno uno dei criteri deve essere vero):**

```yaml
# L'utente deve essere 'mario' OPPURE far parte del gruppo 'admins'
subject:
  - ["user:mario"]
  - ["group:admins"]

```

---

### 3. Altri criteri di filtro (Oltre al Subject)

Oltre al "chi", puoi filtrare in base al "da dove" o "cosa":

**`networks`**: Filtra in base all'IP dell'utente (es. `192.168.1.0/24`). Molto utile se vuoi che da casa (LAN) basti la password, ma da fuori (Internet) serva il 2FA.
**`resources`**: Filtra in base al path URL usando RegEx (es. `^/admin/.*$`).
**`methods`**: Filtra in base ai verbi HTTP (GET, POST, etc.).

---

### 4. Esempio Pratico "Hardened"

Mettiamo insieme tutto per il tuo Nodo 1:

```yaml
access_control:
  default_policy: deny
  rules:
    - domain: "auth.conerolabs.com"
      policy: bypass

    # Se accedo dalla mia LAN (o Tailscale), basta la password
    - domain: "vault.conerolabs.com"
      networks: ["100.64.0.0/10", "192.168.1.0/24"]
      subject: "group:admins"
      policy: one_factor

    # Se accedo da Internet pubblica, obbliga il 2FA (TOTP)
    - domain: "vault.conerolabs.com"
      subject: "group:admins"
      policy: two_factor

    # Tutti gli altri servizi del Nodo 2/3 richiedono login semplice
    - domain: "*.conerolabs.com"
      policy: one_factor

```

#### Tailscale networks

Gli indirizzi di **Tailscale** sono nel range `100.64.0.0/10`. Inserendolo nelle `networks`, puoi creare politiche di accesso "intelligenti" che riconoscono quando sei connesso alla tua rete sicura.

## Notifiche di Reset Password

Puoi configurare l'invio delle email in due modi: tramite un server SMTP (soluzione per produzione) oppure salvando le email su un File locale (soluzione per sviluppo).

### Server SMTP

```yaml
notifier:
  disable_startup_check: false
  smtp:
    host: smtp.example.com
    port: 587
    timeout: 5s
    username: notifications@example.com
    password: password_segreta
    sender: Authelia <notifications@example.com>
    identifier: localhost
    subject_full_path: "[Authelia] {{.Title}}"
    startup_check_address: test@example.com
```

### File locale

```yaml
notifier:
  filesystem:
    filename: /var/lib/authelia/notifications.txt
```

Affinché il reset funzioni, devi assicurarti che l'endpoint interno di Authelia sia raggiungibile e che le impostazioni del server permettano l'invio.

Inoltre, è fondamentale definire il base_url globale nel file di configurazione, altrimenti Authelia non saprà come generare il link da inserire nell'email:

```yaml
server:
  host: 0.0.0.0
  port: 9091
  # URL pubblico del tuo portale Authelia
  external_url: https://auth.conerolabs.com
```
