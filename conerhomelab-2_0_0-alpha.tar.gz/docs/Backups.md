# Homelab Backup Strategy: Restic & Backrest

This document defines the production backup strategy for Conero Homelab (Nodo 1) on Debian Linux. The system uses **Restic** for client-side encrypted, deduplicated snapshots, orchestrated by a containerized **Backrest** Web UI.

---

## 1. Architecture & The 3-2-1 Strategy

The architecture adheres to the 3-2-1 backup rule:
- **3 Copies of Data**: Primary live data, 1 local backup repository, and 1 offsite cloud repository.
- **2 Different Media**: Fast local NVMe/SSD on the host + External USB storage / Local NAS.
- **1 Offsite Copy**: Cloudflare R2 (S3-compatible, zero-egress fee, highly durable object storage).

```
 ┌─────────────────────────────────────────────────────────────┐
 │                         DEBIAN HOST                         │
 │                                                             │
 │   Docker Containers:                                        │
 │   • PostgreSQL / Vaultwarden / Authelia / RustiCal / etc.   │
 │                                                             │
 │   ┌─────────────────────────────────────────────────────┐   │
 │   │                 Backrest Container                  │   │
 │   │  • Web UI (:9898) behind Caddy + Authelia SSO       │   │
 │   │  • Pre-Backup Hook: Zero-downtime DB staging dumps  │   │
 │   │  • Post-Backup Hook: Staging cleanup                │   │
 │   │  • Restic Engine (FastCDC deduplication, AES-256)   │   │
 │   └──────────────────────────┬──────────────────────────┘   │
 └──────────────────────────────┼──────────────────────────────┘
                                │
             ┌──────────────────┴──────────────────┐
             ▼                                     ▼
   ┌───────────────────┐                 ┌───────────────────┐
   │  Local Repository │                 │   Cloudflare R2   │
   │  /repos/local     │                 │   Remote S3 Repo  │
   │  (External USB)   │                 │   (Offsite Cloud) │
   └───────────────────┘                 └───────────────────┘
```

---

## 2. Service & Data Classification

| Service | Data Type & Path | Consistency Risk | Backup Strategy |
| :--- | :--- | :--- | :--- |
| **`postgres`** (Linkwarden) | Relational DB (`./pgdata`) | **Critical**: Live raw file copy corrupts WAL state. | **Pre-backup hook**: `pg_dumpall` to uncompressed SQL in `/userdata/staging`. Exclude raw `./pgdata`. |
| **`vaultwarden`** | SQLite + WAL (`./vaultwarden/db.sqlite3*`) + RSA keys & secrets | **High**: In-flight WAL writes cause corrupt snapshots. Missing keys = unrecoverable vault. | **Pre-backup hook**: Atomic `sqlite3 VACUUM INTO`. Snapshot `rsa_key.pem` and `secrets/`. |
| **`authelia`** | SQLite (`./authelia/config/db.sqlite3`) + configs & secrets | **High**: User 2FA credentials and sessions. | **Pre-backup hook**: Atomic `sqlite3 VACUUM INTO`. Snapshot `./authelia/secrets/` and YAML configs. |
| **`rustical`** | SQLite (`./rustical/data/db.sqlite3`) | **Medium**: CalDAV/CardDAV events and contacts. | **Pre-backup hook**: Atomic `sqlite3 VACUUM INTO`. |
| **`web-config`** | SQLite (`./homelab.db`) | **High**: Homelab deployment and network state. | **Pre-backup hook**: Atomic `sqlite3 VACUUM INTO`. |
| **`caddy`** | Named volumes `caddy_data`, `caddy_config` + `./caddy/etc/caddy` | **Medium**: Losing `caddy_data` loses ACME certificates & private keys (rate limit risk). | Mounted as read-only volume to Backrest and snapshotted. |
| **`portainer`** | Named volume `portainer_data` | **Medium**: BoltDB state. | Mounted as read-only volume to Backrest and snapshotted. |
| **`pihole`** | Configs + SQLite (`./pihole/etc-pihole/pihole-FTL.db`) | **Low**: Query logs & gravity blocklists. | Atomic `sqlite3 VACUUM INTO` and configs. |
| **`filebrowser`** | BoltDB (`./filebrowser/db/filebrowser.db`) + configs | **Medium**: User settings and permissions. | Snapshot DB and configs. |
| **`gatus` & `myspeed`** | SQLite / logs (`./gatus/data/data.db`, `./myspeed`) | **Low**: Historical uptime and speedtest metrics. | Snapshot or exclude if ephemeral. |
| **`homelab_data`** | Shared user files (`./homelab_data/users`) | **Medium**: User personal documents. | Included in Plan 2 (Files). |
| **`music`** | `./homelab_data/music` | **Bulk Media**: Music files. | **EXCLUDED** from both local and cloud backups as per policy. |
| **`navidrome`** | `./navidrome/data` | **Low**: Database + Cache. | Backup DB; **Exclude `./navidrome/data/cache`**. |
| **Host Secrets** | `.env`, `docker-compose.yml`, `scripts/` | **Critical**: Secrets and tokens required to re-instantiate containers. | Snapshotted under Plan 1 (Core). |

---

## 3. Docker Compose & Infrastructure

The `backrest` service is integrated into `docker-compose.yml`:

```yaml
  backrest:
    profiles:
      - backrest
    build:
      context: .
      dockerfile_inline: |
        FROM garethgeorge/backrest:${BACKREST_VERSION:-latest}
        RUN apk add --no-cache sqlite postgresql-client gzip bash curl
    image: conerolabs/backrest:${BACKREST_VERSION:-latest}
    container_name: backrest
    hostname: backrest
    restart: unless-stopped
    networks:
      - infra-network
    ports:
      - "9898:9898"
    environment:
      TZ: ${TZ}
      BACKREST_DATA: "/data"
      BACKREST_CONFIG: "/config/config.json"
      XDG_CACHE_HOME: "/cache"
      CLOUDFLARE_R2_ACCOUNT_ID: "${CLOUDFLARE_R2_ACCOUNT_ID}"
      CLOUDFLARE_R2_BUCKET: "${CLOUDFLARE_R2_BUCKET}"
      AWS_ACCESS_KEY_ID: "${CLOUDFLARE_R2_ACCESS_KEY_ID}"
      AWS_SECRET_ACCESS_KEY: "${CLOUDFLARE_R2_SECRET_ACCESS_KEY}"
      AWS_DEFAULT_REGION: "auto"
      RESTIC_PASSWORD: "${RESTIC_PASSWORD}"
    volumes:
      # Backrest persistent internal state, restic binary, and config
      - ./backrest/config:/config
      - ./backrest/data:/data
      - backrest_cache:/cache

      # Access to Docker daemon to run database dump hooks
      - /var/run/docker.sock:/var/run/docker.sock

      # Backup source paths (mounted read-only for safety)
      - ./:/userdata/homelab:ro
      - caddy_data:/userdata/volumes/caddy_data:ro
      - caddy_config:/userdata/volumes/caddy_config:ro
      - portainer_data:/userdata/volumes/portainer_data:ro
      
      # Staging folder for pre-backup database dumps
      - ./backups/staging:/userdata/staging:rw

      # Target repository (if backing up to a local disk/USB mount)
      - ${BACKUP_DEST:-/mnt/backup_usb/homelab_backups/nodo1}:/repos/local:rw
    deploy:
      resources:
        limits:
          memory: 384M
```

### Caddy Reverse Proxy & Security

The Web UI is routed via Caddy in `caddy/etc/caddy/sites-available/backup.caddy`:
- Subdomain: `backup.{$DOMAIN}`
- Protected with **Authelia Single Sign-On** (`auth_check`)
- Restricted to **LAN (192.168.1.0/24)** and **Tailscale (100.64.0.0/10)** networks.

---

## 4. Zero-Downtime Backup Hooks

Backrest executes lifecycle hooks directly inside its container:

1. **Pre-Backup Hook (`scripts/backup-pre-hook.sh`)**:
   - Dumps PostgreSQL using `docker exec postgres pg_dumpall` without taking the container down.
   - Executes atomic SQLite snapshots using `sqlite3 ... "VACUUM INTO ..."` on Vaultwarden, Authelia, RustiCal, Homelab, and Pi-hole databases.
   - Places clean database snapshots into `/userdata/staging`.
2. **Snapshot Engine**: Restic chunks, deduplicates, encrypts, and sends the snapshot to the target repository.
3. **Post-Backup Hook (`scripts/backup-post-hook.sh`)**:
   - Cleans up `/userdata/staging` so raw database dumps do not remain unencrypted on the host disk.

---

## 5. Cloudflare R2 Remote Setup Guide

### 1. Create Bucket
1. Log into your [Cloudflare Dashboard](https://dash.cloudflare.com/).
2. Navigate to **R2 Storage** -> **Create bucket**.
3. Name the bucket (e.g., `homelab-backups`).
4. Keep the default location or choose your closest region.

### 2. Generate API Credentials
1. Under **R2 Storage**, click **Manage R2 API Tokens**.
2. Click **Create API Token**.
3. Select **Object Read & Write**.
4. Set **Apply to specific buckets only** -> Select `homelab-backups`.
5. Click **Create API Token**.
6. Note down:
   - **Token Value / Access Key ID**
   - **Secret Access Key**
   - **Account ID** (visible on the right-hand panel of your Cloudflare R2 page)

### 3. Update `.env`
Add your credentials to `.env`:
```bash
CLOUDFLARE_R2_ACCOUNT_ID="your_cloudflare_account_id"
CLOUDFLARE_R2_BUCKET="homelab-backups-nodo1"
CLOUDFLARE_R2_ACCESS_KEY_ID="your_access_key_id"
CLOUDFLARE_R2_SECRET_ACCESS_KEY="your_secret_access_key"
RESTIC_PASSWORD="a_strong_random_encryption_passphrase"
```

---

## 6. Automated Configuration Script (No UI Setup Needed)

Instead of manually clicking through the Backrest Web UI at `https://backup.yourdomain.com` (or `http://192.168.1.91:9898` locally), you can fully configure Backrest and Restic with a single automated script:

```bash
cd /media/andrea/Data/homelab/Nodo1/homelab
./scripts/configure-backrest.sh
```

### What `configure-backrest.sh` Automates:
1. **Reads Environment**: Loads `RESTIC_PASSWORD`, `BACKUP_DEST`, and Cloudflare R2 credentials from `.env`.
2. **Copies Template Config**:
   - Reads the template from `homelab_config/backrest/config.json` (which safely references environment variables `${RESTIC_PASSWORD}`, `${CLOUDFLARE_R2_ACCOUNT_ID}`, etc., without hardcoding secrets).
   - Copies it to the active `$CONFIG_DIR/config.json` (`./backrest/config/config.json`).
   - Configures `local-repo` (`/repos/local`) and `r2-repo` (Cloudflare S3 endpoint).
   - Sets up `plan-core-local`, `plan-core-r2`, and `plan-files-local` with all database exclusions and hooks.
   - Configures `"auth": {"disabled": true}` so access is seamlessly governed by Authelia Single Sign-On.
3. **Initializes Restic Repositories**: Automatically runs `restic init` on both the local USB destination and the Cloudflare R2 remote bucket.

---

### Reference: Backrest Configuration Walkthrough (Manual Alternative)

If you ever wish to inspect or modify settings in the Web UI (`https://backup.{$DOMAIN}`):

#### 1. Local Repository (`local-repo`)
- **Storage Type**: Local Path
- **Path**: `/repos/local`
- **Password**: Your `RESTIC_PASSWORD`
- Click **Initialize** to create the Restic repo on the local drive.

#### 2. Cloudflare R2 Repository (`r2-repo`)
- **Storage Type**: Other S3 Compatible (or S3)
- **Bucket / URL**: `s3:https://<ACCOUNT_ID>.r2.cloudflarestorage.com/<BUCKET_NAME>`
- **Custom Environment Variables**:
  - `AWS_ACCESS_KEY_ID`: `<YOUR_R2_ACCESS_KEY_ID>`
  - `AWS_SECRET_ACCESS_KEY`: `<YOUR_R2_SECRET_ACCESS_KEY>`
  - `AWS_DEFAULT_REGION`: `auto`
- **Password**: Your `RESTIC_PASSWORD`
- Click **Initialize** to format the R2 bucket as a Restic repository.

---

### Step B: Configure Backup Plans

#### Plan 1: `plan-core` (Configs, Secrets, Database Dumps)
- **Target Repositories**: `local-repo` AND `r2-repo`
- **Schedule (Cron)**: `0 3 * * *` (Daily at 3:00 AM)
- **Source Paths**:
  - `/userdata/staging` *(atomic database dumps generated by pre-backup hook)*
  - `/userdata/homelab` *(all service configurations, secrets, and orchestration files)*
  - `/userdata/volumes/caddy_data` *(Let's Encrypt certificates & account key)*
  - `/userdata/volumes/caddy_config` *(Caddy runtime autosave config)*
  - `/userdata/volumes/portainer_data` *(Portainer database & stack configs)*
- **Exclusion Patterns**:
  ```text
  # Logs & Ephemeral files
  *.log
  *.tmp
  *.bak

  # Heavy data, caches, and backups (handled separately or excluded)
  /userdata/homelab/pgdata/**
  /userdata/homelab/homelab_data/**
  /userdata/homelab/linkwarden/**
  /userdata/homelab/backrest/data/**
  /userdata/homelab/backups/**
  /userdata/homelab/tmp/**
  /userdata/homelab/navidrome/data/cache/**
  /userdata/homelab/vaultwarden/tmp/**

  # Active raw SQLite databases & WAL/SHM files (safely dumped to /userdata/staging)
  /userdata/homelab/vaultwarden/db.sqlite3*
  /userdata/homelab/authelia/config/db.sqlite3*
  /userdata/homelab/rustical/data/db.sqlite3*
  /userdata/homelab/homelab*.db*
  /userdata/homelab/pihole/etc-pihole/*.db*
  /userdata/homelab/gatus/data/data.db*
  /userdata/homelab/navidrome/data/navidrome.db*
  /userdata/homelab/myspeed/storage.db*
  /userdata/homelab/filebrowser/db/*.db*
  ```
- **Hooks**:
  - **Pre-backup Hook** (`CONDITION_SNAPSHOT_START`):
    - Command: `/userdata/homelab/scripts/backup-pre-hook.sh`
    - Error behavior: `ON_ERROR_FATAL` (aborts snapshot if DB dump fails)
  - **Post-backup Hook** (`CONDITION_SNAPSHOT_END`):
    - Command: `/userdata/homelab/scripts/backup-post-hook.sh`
    - Error behavior: `ON_ERROR_IGNORE`
- **Retention**:
  - Daily: `14`
  - Weekly: `8`
  - Monthly: `12`

#### Plan 2: `plan-files` (User Assets, Linkwarden Archives)
- **Target Repositories**: `local-repo` (and optionally `r2-repo`)
- **Schedule (Cron)**: `0 4 * * 0` (Weekly on Sunday at 4:00 AM)
- **Source Paths**:
  - `/userdata/homelab/homelab_data`
  - `/userdata/homelab/linkwarden`
- **Exclusion Patterns**:
  ```
  /userdata/homelab/homelab_data/music/**
  /userdata/homelab/navidrome/data/cache/**
  /userdata/homelab/tmp/**
  *.cache
  ```
  > [!IMPORTANT]
  > `/userdata/homelab/homelab_data/music/**` is strictly excluded from all plans as per user specification.
- **Retention**:
  - Weekly: `4`
  - Monthly: `6`

---

## 7. Disaster Recovery & Restoration Runbook

In a worst-case scenario (complete hardware failure or fresh Debian reinstall):

### 1. Install Debian & Docker
```bash
sudo apt update && sudo apt install -y docker.io docker-compose-v2 restic
sudo usermod -aG docker $USER
```

### 2. Connect to the Backup Repository
Set environment variables for Restic:
```bash
export RESTIC_PASSWORD="your_restic_password"

# For Local USB:
export RESTIC_REPOSITORY="/mnt/backup_usb/homelab_backups/nodo1"

# OR for Cloudflare R2:
export AWS_ACCESS_KEY_ID="your_r2_access_key_id"
export AWS_SECRET_ACCESS_KEY="your_r2_secret_access_key"
export AWS_DEFAULT_REGION="auto"
export RESTIC_REPOSITORY="s3:https://<ACCOUNT_ID>.r2.cloudflarestorage.com/<BUCKET_NAME>"
```

### 3. Restore Files
```bash
mkdir -p /tmp/restore
restic restore latest --target /tmp/restore

# Move restored homelab files into place
sudo cp -a /tmp/restore/userdata/homelab /media/andrea/Data/homelab/Nodo1/homelab
```

### 4. Restore Named Docker Volumes
```bash
docker volume create caddy_data
docker volume create caddy_config
docker volume create portainer_data

docker run --rm -v caddy_data:/target -v /tmp/restore/userdata/volumes/caddy_data:/source alpine cp -a /source/. /target/
docker run --rm -v caddy_config:/target -v /tmp/restore/userdata/volumes/caddy_config:/source alpine cp -a /source/. /target/
docker run --rm -v portainer_data:/target -v /tmp/restore/userdata/volumes/portainer_data:/source alpine cp -a /source/. /target/
```

### 5. Restore Databases & Start Services
```bash
cd /media/andrea/Data/homelab/Nodo1/homelab

# 1. Start PostgreSQL
docker compose up -d postgres

# 2. Restore PostgreSQL dump
zcat /tmp/restore/userdata/staging/postgres_all.sql.gz | docker exec -i postgres psql -U postgres

# 3. Restore clean SQLite databases from staging
[ -f /tmp/restore/userdata/staging/vaultwarden.sqlite3 ] && cp /tmp/restore/userdata/staging/vaultwarden.sqlite3 ./vaultwarden/db.sqlite3
[ -f /tmp/restore/userdata/staging/authelia.sqlite3 ]   && cp /tmp/restore/userdata/staging/authelia.sqlite3 ./authelia/config/db.sqlite3
[ -f /tmp/restore/userdata/staging/rustical.sqlite3 ]   && cp /tmp/restore/userdata/staging/rustical.sqlite3 ./rustical/data/db.sqlite3
[ -f /tmp/restore/userdata/staging/homelab.sqlite3 ]    && cp /tmp/restore/userdata/staging/homelab.sqlite3 ./homelab.db
[ -f /tmp/restore/userdata/staging/navidrome.sqlite3 ]  && cp /tmp/restore/userdata/staging/navidrome.sqlite3 ./navidrome/data/navidrome.db
[ -f /tmp/restore/userdata/staging/myspeed.sqlite3 ]    && cp /tmp/restore/userdata/staging/myspeed.sqlite3 ./myspeed/storage.db
[ -f /tmp/restore/userdata/staging/gatus.sqlite3 ]      && cp /tmp/restore/userdata/staging/gatus.sqlite3 ./gatus/data/data.db
[ -f /tmp/restore/userdata/staging/pihole-FTL.sqlite3 ] && cp /tmp/restore/userdata/staging/pihole-FTL.sqlite3 ./pihole/etc-pihole/pihole-FTL.db
[ -f /tmp/restore/userdata/staging/filebrowser.db ]      && cp /tmp/restore/userdata/staging/filebrowser.db ./filebrowser/db/filebrowser.db

# 4. Launch the entire homelab
docker compose up -d
```