# Manuale Completo di Installazione e Configurazione di Headscale

Questo manuale descrive in modo approfondito l'installazione e la configurazione di un'infrastruttura VPN mesh self-hosted basata su **Headscale** installato nativamente, affiancato da **Headscale-UI** e **Caddy** in Docker, con integrazione di **Pi-hole** come server DNS interno e **Authelia** per l'autenticazione Single Sign-On (OIDC) e la protezione dell'interfaccia web (Forward Auth).

---

## 1. Architettura dell'Infrastruttura

L'architettura adotta un approccio **ibrido**:

* **Headscale Core e Caddy**: Girano nativamente sul sistema operativo host (Ubuntu/Armbian) per garantire massime prestazioni, stabilità e un accesso semplificato alle risorse di rete della macchina. Caddy funge da reverse proxy globale, gestendo i certificati SSL/TLS e instradando il traffico web verso la UI o verso il backend nativo.
* **Headscale-UI**: Gira isolato in container Docker.
* **Pi-hole**: Utilizzato come resolver DNS della rete mesh, configurato per bloccare pubblicità e malware a livello di rete per tutti i client connessi.
* **Authelia**: Funge da Identity Provider (IdP) centrale, gestendo l'autenticazione a due fattori (2FA) sia per l'accesso ai client (via OIDC nativo) sia per l'interfaccia web (via Forward Auth).

---

## 2. Installazione di Headscale Nativo

### 2.1. Installazione del pacchetto `.deb`

Scarica l'ultima versione del pacchetto `.deb` dal repository ufficiale di Headscale su GitHub ed eseguine l'installazione:

```bash
# Rileva automaticamente l'architettura (arm64 per Armbian, amd64 per Ubuntu standard)
ARCH=$(dpkg --print-architecture)
VERSION=$(curl -s "https://api.github.com/repos/juanfont/headscale/releases/latest" | grep '"tag_name"' | sed -E 's/.*"([^"]+)".*/\1/' | sed 's/v//')

wget "https://github.com/juanfont/headscale/releases/download/v${VERSION}/headscale_${VERSION}_linux_${ARCH}.deb"
sudo apt install ./headscale_${VERSION}_linux_${ARCH}.deb

```

L'installazione creerà automaticamente:

* La directory di configurazione: `/etc/headscale/`
* La directory dei dati e del database: `/var/lib/headscale/`
* L'utente di sistema e il servizio `systemd` dedicato (`headscale`).

### 2.2. Configurazione del file di sistema (`/etc/headscale/config.yaml`)

Il file autogenerato è molto esteso e contiene valori di esempio bloccanti. Sostituiscilo o modificalo con questa configurazione minimale e ottimizzata per lavorare dietro Caddy e integrarsi con il resto dell'infrastruttura:

```yaml
# /etc/headscale/config.yaml

# L'indirizzo pubblico esterno utilizzato dai client per raggiungere il pannello di controllo.
# Deve corrispondere al dominio gestito da Caddy.
server_url: https://vpn.conerolabs.com

# Indirizzo di ascolto locale del demone Headscale. 
listen_addr: 127.0.0.1:8084
metrics_listen_addr: 127.0.0.1:9092

# Configurazione del Database (SQLite nativo)
database:
  type: sqlite
  path: /var/lib/headscale/db.sqlite

# Configurazione TLS disabilitata in Headscale (la crittografia viene gestita a monte da Caddy)
tls_cert_path: ""
tls_key_path: ""

# Prefissi IP privati assegnati ai nodi all'interno della VPN mesh
prefixes:
  v4: 100.64.0.0/10
  v6: fd7a:115c:a1e0::/48

# Configurazione dei server di relay DERP (per superare NAT aggressivi)
derp:
  server:
    enabled: true
    region_id: 999
    region_code: "headscale"
    region_name: "Headscale Embedded DERP"
    stun_listen_addr: "0.0.0.0:3478"
  urls:
    - https://controlplane.tailscale.com/derpmap/default
  paths: []
  auto_update_enabled: true
  update_frequency: 24h

# Configurazione DNS (Iniziale - verrà modificata per Pi-hole nel capitolo 4)
dns:
  magic_dns: true
  base_domain: vpn.internal
  nameservers:
    global:
      - 1.1.1.1
      - 8.8.8.8

```

Dopo la modifica, avvia e abilita il servizio:

```bash
sudo systemctl enable --now headscale

```

---

## 3. Configurazione dell'Ambiente Docker (Headscale-UI)

Per l'interfaccia grafica, prepariamo un ecosistema Docker leggero.

### 3.1. Il file `docker-compose.yml`

```yaml
version: '3.8'

services:
  headscale-ui:
    image: ghcr.io/gurucomputing/headscale-ui:latest
    container_name: headscale-ui
    restart: unless-stopped
    ports:
      - 8085:8080
```

Per consentire alla UI di comunicare in sicurezza con Headscale, è necessario generare una chiave API dal server:

```Bash
sudo headscale apikeys create --expiration 90d
```

Una volta avviato il container, vai alla sezione Settings della web ui e inserisci la chiave API generata.

---

## 4. Integrazione di Pi-hole sullo stesso Server

Se Pi-hole è installato sulla stessa macchina di Headscale, configurarlo come DNS per la rete mesh richiede accortezze specifiche per evitare routing loop o malfunzionamenti fuori casa.

### 4.1. Regole per il `base_domain` (MagicDNS)

* **Best Practice**: Il `base_domain` (es. `vpn.internal`) deve essere **diverso** dal `server_url` (es. `hs.tuodominio.it`). Se fossero uguali, MagicDNS intercetterebbe il traffico verso il server di controllo, isolando i nodi dalla VPN.
* Evita l'estensione `.local` poiché è riservata a mDNS (Avahi/Bonjour) e genera conflitti su Linux e macOS. Utilizza suffissi privati sicuri come `.internal`, `.lan`, o `.mesh`.

### 4.2. Far entrare il Server nella propria Mesh

Per far sì che i client usino Pi-hole ovunque si trovino, il server Pi-hole deve rispondere su un IP della VPN raggiungibile da tutti.

1. Installa il client Tailscale sul server Headscale/Pi-hole:

```bash
curl -fsSL https://tailscale.com/install.sh | sh

```

2. Connetti il server a se stesso specificando l'istanza locale:

```bash
sudo tailscale up --login-server http://127.0.0.1:8084

```

3. Approva il nodo tramite la CLI di Headscale o Headscale-UI e annota l'IP assegnato (es. **`100.64.0.1`**).

### 4.3. Configurazione dell'interfaccia su Pi-hole

Di default Pi-hole rifiuta query che non provengono dalla LAN fisica.

1. Accedi alla dashboard web di Pi-hole.
2. Vai su **Settings** -> **DNS** -> **Interface settings**.
3. Seleziona **Permit all origins** (o *Bind only to all local interfaces*).
*(Assicurati tramite il firewall del tuo OS che la porta pubblica 53 del server sia chiusa verso internet).*

### 4.4. Modifica dei Nameservers in Headscale

Per evitare **DNS Leak** (richieste inviate in parallelo a Pi-hole e a DNS pubblici), **rimuovi completamente** ogni server DNS pubblico (come 1.1.1.1) dalla sezione `dns.nameservers.global` di Headscale. Mantieni esclusivamente l'IP VPN di Pi-hole.

Modifica `/etc/headscale/config.yaml`:

```yaml
dns:
  magic_dns: true
  base_domain: conerolabs.vpn
  nameservers:
    global:
      - 100.64.0.1 # SOLO l'IP Tailscale/Headscale del tuo server Pi-hole

```

Riavvia Headscale per applicare:

```bash
sudo systemctl restart headscale

```

---

## 5. Autenticazione OIDC con Authelia

Per implementare il Single Sign-On con l'autenticazione a due fattori (2FA) per i client che si connettono alla VPN, integriamo Authelia via OpenID Connect (OIDC).

### 5.1. Configurazione di Authelia (`configuration.yml`)

Headscale richiede che i claim relativi a `email` e `groups` siano inclusi direttamente all'interno dell'ID Token. È necessario definire una `claims_policy` esplicita in Authelia per abilitare questo comportamento (escape hatch).

Aggiungi sotto la sezione `identity_providers.oidc`:

```yaml
identity_providers:
  oidc:
    claims_policies:
      headscale_policy:
        id_token:
          - 'email'
          - 'groups'

    clients:
      - client_id: 'headscale'
        client_name: 'Headscale Mesh VPN'
        client_secret: '$pbkdf2-sha512$310000$vG...' # Secret generato e cifrato con authelia crypto hash
        public: false
        authorization_policy: 'two_factor' # Richiede la 2FA per l'accesso alla VPN
        require_pkce: true
        pkce_challenge_method: 'S256'
        redirect_uris:
          - 'https://hs.tuodominio.it/oidc/callback'
        scopes:
          - 'openid'
          - 'profile'
          - 'email'
          - 'groups'
        claims_policy: 'headscale_policy'

```

### 5.2. Configurazione di Headscale (`config.yaml`)

Abilita e configura il blocco `oidc` nel file `/etc/headscale/config.yaml` inserendo il client secret in chiaro:

```yaml
oidc:
  only_start_if_oidc_is_available: true
  issuer: "https://auth.conerolabs.com"
  client_id: "headscale"
  client_secret: "IL_TUO_SECRET_IN_CHIARO_IMPOSTATO_SU_AUTHELIA"
  scope: ["openid", "profile", "email", "groups"]
  pkce:
    enabled: true
    method: "S256"
  # Opzionale: limita l'accesso alla VPN solo ai membri di un gruppo specifico di Authelia
  allowed_groups:
    - vpn_users

```

Riavvia il servizio Headscale: `sudo systemctl restart headscale`.

---

## 6. Protezione di Headscale-UI con Authelia (Forward Auth)

Headscale-UI è una Single Page Application (SPA) e non supporta nativamente il login OIDC. Per proteggerla, utilizziamo il meccanismo della **Forward Authentication** sul reverse proxy Caddy, bloccando l'accesso al percorso web.

### 6.1. Definizione della regola d'accesso in Authelia

Nel file `configuration.yml` di Authelia, sotto `access_control.rules`, aggiungi una regola per proteggere la UI lasciando libero il resto del traffico di Headscale:

```yaml
access_control:
  default_policy: deny
  rules:
    - domain: 'hs.tuodominio.it'
      resources:
        - '^/web.*'
      policy: two_factor

```

### 6.2. Aggiornamento del `Caddyfile`

Modifichiamo il `Caddyfile` per usare i blocchi `handle`. Isoleremo il percorso `/web*` passandolo sotto il controllo del modulo `forward_auth` di Authelia prima di servire la UI. Il traffico di sistema di Headscale (comprese le callback OIDC) rimarrà accessibile senza la Forward Auth sul browser.

```caddy
hs.tuodominio.it {
    
    # 1. Protezione dell'interfaccia grafica Headscale-UI
    handle /web* {
        # Sostituisci authelia:9091 con l'host/porta corretti del tuo container Authelia
        forward_auth authelia:9091 {
            uri /api/verify?rd=[https://auth.tuodominio.it/](https://auth.tuodominio.it/)
            copy_headers Remote-User Remote-Groups Remote-Name Remote-Email
        }
        
        reverse_proxy headscale-ui:80
    }

    # 2. Catch-all per il traffico dei client Tailscale e chiamate API nativa
    handle {
        reverse_proxy host.docker.internal:8080
    }
}

```

Riavvia il container di Caddy per applicare le modifiche:

```bash
docker compose restart caddy

```

---

## 7. Comandi Utili per la Gestione Operativa

Lavorando con Headscale nativo, la CLI viene eseguita direttamente sull'host. Ecco i comandi principali da conoscere:

### Gestione Utenti (User/Namespace)

* Creare un utente manualmente: `sudo headscale users create nome_utente`
* Elencare gli utenti: `sudo headscale users list`
* Eliminare un utente: `sudo headscale users destroy nome_utente`

### Gestione Nodi e Dispositivi

* Elencare tutti i nodi connessi: `sudo headscale nodes list`
* Registrare manualmente un nodo (se non usi OIDC): `sudo headscale nodes register --user nome_utente --key node:chiave_del_client`
* Rimuovere un nodo della rete: `sudo headscale nodes delete -i <ID_NODO>`

### Gestione Chiavi di Autenticazione (Pre-auth Keys)

* Generare una chiave riutilizzabile (utile per deploy automatizzati di server):

```bash
sudo headscale preauthkeys create --user nome_utente --reusable --expiration 30d

```

### Controllo dei Servizi e Log

* Verificare lo stato di Headscale nativo: `sudo systemctl status headscale`
* Visualizzare i log in tempo reale di Headscale: `journalctl -u headscale -f`
* Visualizzare i log del reverse proxy: `docker compose logs -f caddy`
