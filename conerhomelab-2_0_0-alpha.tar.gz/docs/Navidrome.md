# Navidrome

## Installation

<https://www.navidrome.org/docs/installation/docker/>
To create the user in setup_navidrome.sh script use navidrome cli:

``` bash
# Create an admin user
navidrome user create --username alice --email alice@example.com --admin

# Edit user role
navidrome user edit --user alice --set-regular

# Update password interactively
navidrome user edit --user alice --set-password

# List users as JSON
navidrome user list --format json

# Delete user by username or ID
navidrome user delete --user alice
```

## External Auth

<https://www.navidrome.org/docs/getting-started/extauth-quickstart/>
You need to bypass /rest/* path for Subsonic API, subsonic api auth will be managed by Navidrome.
Remember to set a password for the users.

## Radio Manager

A separate service to find and add radio stations. Find the salt to use in chrome dev tools in application tab after logging in.

## Clients

### Ultrasonic

