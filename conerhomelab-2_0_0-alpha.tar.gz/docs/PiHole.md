# PiHole

## Ubuntu

https://docs.pi-hole.net/docker/tips-and-tricks/

Disable dns stub resolver:

```bash
sudo sh -c 'mkdir -p /etc/systemd/resolved.conf.d && printf "[Resolve]\nDNSStubListener=no\n" | tee /etc/systemd/resolved.conf.d/no-stub.conf'
sudo sh -c 'rm -f /etc/resolv.conf && ln -s /run/systemd/resolve/resolv.conf /etc/resolv.conf'
systemctl restart systemd-resolved
```

Disable services occupying port 53:

```bash
sudo systemctl stop libvirtd.service libvirtd.socket libvirtd-ro.socket libvirtd-admin.socket
sudo snap stop lxd
sudo systemctl disable libvirtd.service libvirtd.socket libvirtd-ro.socket libvirtd-admin.socket
sudo snap disable lxd
```

Verify port 53:

```bash
sudo lsof -i :53
```

Eventually kill processes

```bash
sudo kill -9 pid
```

To enable again:

```bash
sudo systemctl enable --now libvirtd.service libvirtd.socket
sudo snap enable lxd # da verificare se funziona
```
