# Vaultwarden

## ADMIN TOKEN



## Integrazione con AUTHELIA come OIDC provider

Per utilizzare il SSO con OIDC al momento (06/12/2026) occorre utilizzare l'immagine docker di `testing` comunque molto stabile.
Si è seguito questa [guida](https://github.com/dani-garcia/vaultwarden/wiki/Enabling-SSO-support-using-OpenId-Connect)

### 1. Core Identity (L'identità del servizio)

- `SSO_ENABLED=true`: Attiva il modulo OIDC all'interno di Vaultwarden. Senza questo, le altre variabili vengono ignorate.

- `SSO_AUTHORITY=https://auth.conerolabs.com`: È l'URL del tuo "Identity Provider" (Authelia). Vaultwarden contatterà questo indirizzo per scaricare le chiavi pubbliche e validare i token che riceve.

- `SSO_CLIENT_ID=vaultwarden`: È il "nome utente" dell'applicazione. Deve corrispondere esattamente al client_id che scriverai nel file di configurazione di Authelia.

- `SSO_CLIENT_SECRET=insecure_secret`: È la "password" dell'applicazione. Serve a Vaultwarden per dimostrare ad Authelia di essere autorizzato a richiedere i dati degli utenti. (Nel tuo caso la metteremo nel file .env).

### 2. User Experience (Il comportamento del login)

- `SSO_ONLY=false`:

  - Se false: Sulla pagina di login vedrai sia il form classico (Email/Password) sia il tasto "Log in with SSO". Utile come "paracadute" se Authelia dovesse avere problemi.

  - Se true: Scompare tutto e resta solo il tasto SSO. Massima sicurezza, ma se Authelia va giù, resti fuori dal vault.

- `SSO_PKCE=true`: Significa Proof Key for Code Exchange. È un'estensione di sicurezza che impedisce a un malintenzionato di intercettare il codice di autorizzazione durante il "palleggio" tra browser e server. Tienilo sempre su true.

### 3. Permissions (Cosa chiediamo ad Authelia)

- `SSO_SCOPES=profile email offline_access`: Qui Vaultwarden dice ad Authelia: "Oltre a sapere chi è l'utente, passami anche la sua email, il suo profilo e un token di accesso a lungo termine (offline_access)". Quest'ultimo è fondamentale per non dover rifare il login ogni volta che riapri l'app sul telefono.

---

<https://www.authelia.com/integration/openid-connect/clients/vaultwarden/>
