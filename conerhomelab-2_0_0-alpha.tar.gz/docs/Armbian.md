# Armbian

Si è scelto Armbian Minimal basato su Debian Trixie (13) per bilanciare stabilità e modernità dei pacchetti (Kernel 6.x+, Docker Engine 25+).  
Scelte Software & Motivazioni

- Armbian-Ramlog: Attivo.
I log vengono scritti in un disco ZRAM da 50MB e sincronizzati su disco ogni 24 ore. (DEFAULT Armbian)
In modo da proteggere la MicroSD SanDisk Max Endurance dai cicli di scrittura eccessivi dei servizi Docker e del sistema.
- ZRAM-Config: Attivo.
Configurato un dispositivo /dev/zram0 da ~1GB con algoritmo zstd. (DEFAULT Armbian usa lzo-rle):
`SWAP_ALGORITHM=zstd nel file /etc/default/armbian-zram-config`.

La compressione RAM permette di gestire un carico di lavoro superiore alla memoria fisica disponibile senza ricorrere allo swap su disco, mantenendo alta la reattività.

## Gestione Avanzata della Memoria (Memory Layering)

Il sistema implementa una strategia a tre livelli per massimizzare l'uptime e le performance.  
Livelli di Swap e Priorità

| Livello | Tipo | Dimensione | Priorità | Ruolo |
| --- | --- | --- | --- | --- |
| L1 | RAM Fisica | 2 GB | - | Esecuzione processi e cache filesystem |
| L2 | ZRAM (Swap) | 1 GB | 5 (DEFAULT) | Buffer compresso ad alta velocità |
| L3 | Swap File (SD) | 1 GB | -2 | Paracadute di emergenza (Anti-OOM) |

Per creare il file di swap:

```bash
# 1. Crea un file vuoto da 1GB
sudo fallocate -l 1G /var/swap.img
# 2. Permessi di sicurezza
sudo chmod 600 /var/swap.img
# 3. Formattalo come swap
sudo mkswap /var/swap.img
# 4. Attivalo con priorità bassa (-2)
sudo swapon -p -2 /var/swap.img
```

Aggiungi lo swap al filesystem table: in `/etc/fstab` aggiungi la riga `/var/swap.img  none  swap  sw,pri=-2  0  0`

## Ottimizzazione dei Parametri del Kernel (sysctl)

Configurati nel file `/etc/sysctl.d/99-homelab-optimizations.conf`:

- `vm.swappiness=100`: Forza il kernel a utilizzare la ZRAM il prima possibile, liberando RAM fisica per la cache I/O e i database (Vaultwarden/Authelia).
- `vm.vfs_cache_pressure=50`: Riduce la frequenza con cui il kernel elimina la cache dei metadati dei file (inode/dentry).Motivazione: Riduce la latenza di accesso al filesystem sulla MicroSD, migliorando la velocità di risposta generale.
- `vm.admin_reserve_kbytes=8192`: Riserva sempre questa quantità di memoria (nel nostro caso 8MB) esclusivamente per gli utenti con privilegi di root.
- `vm.dirty_writeback_centisecs=60000`: Il kernel sveglia il processo di scrittura ogni 10 minuti (60000 centisecs).
- `vm.dirty_expire_centisecs=60000`: Età massima di un dato "sporco" in RAM prima della scrittura forzata.

### vm.swappiness

La swappiness definisce quanto aggressivamente il kernel debba spostare pagine di memoria dalla RAM fisica allo swap. Il valore va da 0 a 200 (sui kernel moderni come quello di Trixie).

- Valore Basso (es. 10): Il kernel cerca di non usare lo swap a meno che non sia assolutamente necessario. Questo è ideale se lo swap è su un disco lento (HDD o MicroSD), perché evita rallentamenti.
- Valore Alto (es. 100): Il kernel sposta volentieri le pagine di memoria "inattive" (parti di programmi che non stai usando in quel momento) nello swap.

Perché 100 nel tuo caso?
Dato che il tuo swap primario è ZRAM (quindi RAM compressa, velocissima), vogliamo che il kernel la usi il più possibile. Spostando i dati meno usati nella ZRAM compressa, liberi RAM fisica "pura" per:

- Buffer di scrittura (velocizza i database di Vaultwarden/Authelia).
- Cache di lettura (velocizza l'avvio dei container).
- Picchi improvvisi (il famoso costo di memoria di Argon2id).

### vm.vfs_cache_pressure

Questo parametro controlla la tendenza del kernel a reclamare la memoria utilizzata per le cache delle directory e degli inode (VFS - Virtual File System). In pratica, è la memoria che il sistema usa per ricordarsi "dove sono i file sul disco" senza doverli cercare ogni volta.

- Valore Default (100): Il kernel cerca di mantenere un equilibrio "giusto" tra cache dei file e memoria dei processi.
- Valore Alto (>100): Il kernel elimina aggressivamente la cache del filesystem per dare spazio ai programmi. Questo rallenta le operazioni sui file (es. un ls o una scansione di cartelle).
- Valore Basso (<100): Il kernel "preferisce" tenere i dati del filesystem in cache, anche a costo di swappare un po' di più i programmi.

### vm.admin_reserve_kbytes

In Linux, quando la memoria scarseggia, il kernel cerca di soddisfare le richieste dei processi finché non esaurisce ogni singolo byte. Il problema è che se un processo utente (magari un container Docker che "impazzisce") consuma tutta la RAM, anche tu, come amministratore (root), potresti non riuscire più a fare nulla.

Non riusciresti a fare il login via SSH, non riusciresti a lanciare htop o kill per fermare il processo colpevole, perché anche quei comandi hanno bisogno di un po' di RAM per essere eseguiti.

vm.admin_reserve_kbytes dice al kernel: "Riserva sempre questa quantità di memoria (nel nostro caso 8MB) esclusivamente per gli utenti con privilegi di root."

---

Applica le modifiche senza riavviare:

```bash
sudo sysctl --system
```

## Ottimizzazione dei logs e della ram

**Obiettivo:** Massimizzare la longevità della MicroSD (SanDisk Max Endurance) e l'efficienza dei 2GB di RAM su Debian Trixie.

## 1. Gestione Memoria (Layering)

Il sistema è configurato per utilizzare tre livelli di memoria con priorità decrescente.

### L1: ZRAM (RAM Compressa)

Utilizzata come swap primario per evitare l'accesso al disco.

**Device:** `/dev/zram0`
**Algoritmo:** `zstd` (miglior rapporto compressione/CPU)
**Dimensione:** ~1GB (50% della RAM fisica)
**Priorità:** `100`

### L2: Swap File (Paracadute su SD)

Interviene solo in caso di saturazione della ZRAM per evitare il crash del sistema (OOM).

**File:** `/var/swap.img`
**Dimensione:** 1GB
**Priorità:** `-2` (L'ultima scelta del Kernel)

---

## 2. Parametri Kernel (`/etc/sysctl.d/99-homelab-optimizations.conf`)

Questi parametri istruiscono il Kernel su come bilanciare RAM e Scritture.

```text
# --- Ottimizzazioni Nodo 1 (Radxa Rock 2A 2GB) ---

# Forza il kernel a preferire la ZRAM rispetto allo swap fisico
vm.swappiness=100

# Protegge la cache del filesystem per ridurre le letture sulla SD
vm.vfs_cache_pressure=50

# Riserva 8MB per l'utente root (permette il login SSH anche in caso di saturazione RAM)
vm.admin_reserve_kbytes=8192

# --- Ottimizzazioni Scrittura Log (Minimizzazione I/O) ---

# Il kernel sveglia il processo di scrittura ogni 10 minuti (60000 centisecs)
vm.dirty_writeback_centisecs = 60000

# Età massima di un dato "sporco" in RAM prima della scrittura forzata
vm.dirty_expire_centisecs = 60000

```

---

## 3. Ottimizzazione Filesystem (`/etc/fstab`)

Configurazione per rendere il sistema "pigro" nelle scritture fisiche.

```text
# Esempio di riga per la partizione ROOT
UUID=XXXX... / ext4 defaults,noatime,commit=600 0 1

# Riga per lo Swap File di emergenza
/var/swap.img none swap sw,pri=-2 0 0

```

**`noatime`**: Disabilita l'aggiornamento della data di ultimo accesso ai file (riduce le scritture del 50% circa).
**`commit=600`**: Accumula le modifiche ai file in RAM e le scrive sulla SD solo ogni 10 minuti in un unico blocco.

---

## 4. Protezione Log (Armbian-ramlog & Docker)

I log sono la principale causa di usura della SD. Li abbiamo isolati.

### Armbian-ramlog

**Mount:** `/var/log` montato in ZRAM (disco virtuale separato).
**Capacità:** 50MB (espandibili a 100MB).
**Sincronizzazione:** Solo una volta al giorno o allo spegnimento.

### Docker Logging (`/etc/docker/daemon.json`)

Configurazione per evitare che i log dei container riempiano il disco o generino I/O eccessivo.

```json
{
  "log-driver": "local",
  "log-opts": {
    "max-size": "5m",
    "max-file": "5",
    "compress": "true"
  }
}

```

*Nota: Grazie al `commit=600` impostato in fstab, queste scritture vengono comunque bufferizzate in RAM prima di finire sulla SD.*

---

## 5. Comandi utili

`htop`

### Comandi di Verifica Rapida

**Stato Memoria/Swap:** `swapon --show` e `zramctl`
**Occupazione Log RAM:** `df -h /var/log`
**Verifica Parametri Kernel:** `sysctl vm.swappiness vm.vfs_cache_pressure`
**Verifica Opzioni Mount:** `mount | grep " / "`

### CPU

```bash
armbianmonitor -m
```

### NETWORK

```bash
# Controllo porte aperte su rete
ss -tulwn
