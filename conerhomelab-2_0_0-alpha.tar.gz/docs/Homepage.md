# Homepage

## Docker Configuration - `docker.yaml`

https://gethomepage.dev/configs/docker/

## Widget Configuration - `services.yaml`

```yaml
- Infrastruttura:
    - Pi-hole:
        icon: pi-hole.png
        href: https://dns.infra-node.iguana-justitia.ts.net
        description: DNS Filtering
        widget:
          type: pihole
          url: http://localhost:8081
          key: YOUR_PIHOLE_API_KEY # La trovi nelle impostazioni di Pi-hole

    - Vaultwarden:
        icon: vaultwarden.png
        href: https://vault.infra-node.iguana-justitia.ts.net
        description: Password Manager
        
- Monitoraggio:
    - Uptime Kuma:
        icon: uptime-kuma.png
        href: https://status.infra-node.ts.net
        widget:
          type: uptimekuma
          url: http://localhost:3001
          slug: default # O il nome del gruppo specifico

- Gestione:
    - Portainer:
        icon: portainer.png
        href: https://portainer.infra-node.tuodominio.ts.net
        widget:
          type: portainer
          url: http://localhost:9443
          key: YOUR_PORTAINER_API_KEY
```
