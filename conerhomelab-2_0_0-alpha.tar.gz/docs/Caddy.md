# CADDY as Reverse Proxy

## Configurazione nel Caddyfile

[Caddyfile docs](https://caddyserver.com/docs/caddyfile)
[Caddyfile environment variables](https://caddyserver.com/docs/caddyfile/concepts#environment-variables)
[Homelab Caddyfile](../caddy/Caddyfile)

---

## Tailscale domains

Domains ending in `.ts.net` certificates will not be managed by Caddy. Instead, Caddy will automatically attempt to get these certificates at handshake-time from the locally-running [Tailscale](https://tailscale.com/)  instance. This requires that [HTTPS is enabled in your Tailscale account](https://tailscale.com/kb/1153/enabling-https/)  and the Caddy process must either be running as root, or you must configure `tailscaled` to give your Caddy user permission to fetch certificates.

 https://caddyserver.com/docs/automatic-https

 Per abilitare **HTTPS** con Caddy utilizzando i domini **MagicDNS** di Tailscale (es. `nome-macchina.tua-rete.ts.net`), Caddy sfrutta l'integrazione nativa con l'autorità di certificazione di Tailscale. Questo permette di ottenere certificati TLS validi automaticamente senza esporre porte pubblicamente o usare Let's Encrypt.

### Requisiti Preliminari
Prima di configurare Caddy, assicurati che nel pannello di amministrazione di Tailscale siano attive le seguenti opzioni:
*   **MagicDNS**: Deve essere abilitato per risolvere i nomi `.ts.net`.
*   **HTTPS Certificates**: Deve essere abilitato nelle impostazioni DNS per permettere a Tailscale di rilasciare certificati per i domini della tailnet.

### Configurazione del Caddyfile
La configurazione è estremamente semplice. Caddy rileva automaticamente i domini `.ts.net` e utilizza il gestore dei certificati di Tailscale se il socket di Tailscale è accessibile.

Ecco un esempio base di `Caddyfile`:

```caddyfile
nome-macchina.tua-rete.ts.net {
    reverse_proxy localhost:3000
}
```

Quando Caddy vede un dominio `.ts.net`, tenta automaticamente di ottenere un certificato da Tailscale. Se hai bisogno di forzare esplicitamente l'uso dei certificati Tailscale (ad esempio per configurazioni complesse o domini personalizzati nella tailnet), puoi usare la direttiva `get_certificate`:

```caddyfile
nome-macchina.tua-rete.ts.net {
    tls {
        get_certificate tailscale
    }
    reverse_proxy localhost:3000
}
```

### Integrazione in Docker
Se esegui Caddy in un container Docker insieme a Tailscale, è fondamentale permettere a Caddy di comunicare con il demone Tailscale per richiedere i certificati. Questo si ottiene montando il socket di Tailscale nel container di Caddy.

Ecco un esempio di configurazione `docker-compose.yml`:

```yaml
services:
  caddy:
    image: caddy:latest
    volumes:
      - ./Caddyfile:/etc/caddy/Caddyfile
      - caddy_data:/data
      - caddy_config:/config
      # Monta il socket di Tailscale per permettere a Caddy di richiedere certificati
      - type: bind
        source: /var/run/tailscale/tailscale.sock # O il percorso dove tailscale espone il socket
        target: /var/run/tailscale/tailscale.sock
        read_only: true
    network_mode: "service:tailscale" # Condivide la rete con il container tailscale
    depends_on:
      - tailscale

  tailscale:
    image: tailscale/tailscale:latest
    environment:
      - TS_AUTH_KEY=tskey-auth-...
      - TS_HOSTNAME=caddy-proxy
    cap_add:
      - NET_ADMIN
    devices:
      - /dev/net/tun:/dev/net/tun
    volumes:
      - tailscale_state:/var/lib/tailscale
      - tailscale_sock:/var/run/tailscale # Volume condiviso per il socket

volumes:
  caddy_data
  caddy_config
  tailscale_state
  tailscale_sock
```

In questa configurazione:
1.  Il servizio `tailscale` si connette alla rete e crea il socket.
2.  Il servizio `caddy` condivide lo stack di rete (`network_mode: service:tailscale`) e monta il socket, permettendogli di agire come un client locale per richiedere i certificati TLS per il dominio MagicDNS.

## Private Domain

If you do not have a public domain, you cannot use public Certificate Authorities like Let's Encrypt. Instead, you should use **Caddy's built-in internal Certificate Authority (CA)** or an external tool like **mkcert** to generate locally trusted certificates.

### Option 1: Caddy's Built-in Internal CA (Recommended)
Caddy can automatically generate and manage a local root CA to sign certificates for any hostname (e.g., `app.local`, `192.168.1.5`).

1.  **Configure Caddy**: Add `tls internal` to your site block.
    ```caddyfile
    app.local {
        tls internal
        reverse_proxy localhost:8080
    }
    ```
2.  **Trust the CA**: Caddy generates a root certificate at `/data/caddy/pki/authorities/local/root.crt` (path may vary by OS/installation). You must install this file into the **Trusted Root Certification Authorities** store on every client device (browser/OS) that accesses the server.
    *   **Linux**: `sudo cp root.crt /usr/local/share/ca-certificates/ && sudo update-ca-certificates`
    *   **Windows/macOS**: Double-click the `.crt` file and select "Install Certificate" or add to Keychain.
    *   **Command**: Running `caddy trust` (if available in your build) can automate this for the local machine.

### Option 2: Using mkcert
mkcert is a popular tool specifically designed for creating locally trusted development certificates without complex CA management.

1.  **Install & Setup**: Run `mkcert -install` to create and trust a local CA on your current machine.
2.  **Generate Certs**: Create a certificate for your private domain:
    ```bash
    mkcert app.local 127.0.0.1
    ```
3.  **Configure Caddy**: Point Caddy to the generated files.
    ```caddyfile
    app.local {
        tls app.local+1.pem app.local+1-key.pem
        reverse_proxy localhost:8080
    }
    ```
    *Note: You must manually copy the generated CA root to other devices if they need to access the server.*



## Autenticazione OIDC con Authelia

Con OIDC, non devi più usare `forward_auth` per Vaultwarden. La protezione non è più a livello di "rete" (Caddy), ma a livello di "applicazione" (Vaultwarden).
