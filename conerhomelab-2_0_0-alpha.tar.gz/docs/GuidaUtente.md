# Guida Utente

## Installazione Nodo 1

1. Scarica ed esegui lo script di installazione:

```bash
curl -fsSL https://raw.githubusercontent.com/conerolabs/homelab-releases/main/install.sh | bash
```

2. Completa la configurazione connettendoti dalla stessa rete LAN all'indirizzo IP del nodo: 192.168.x.y:8090


## Configurazione Web

All'indirizzo ip del nodo o a config.{DOMAIN} una volta configurato, puoi accedere all'interfaccia web di configurazione del Nodo 1 per completare l'installazione delle dipendenze, configurare la rete, gli utenti, i backup, i servizi docker, ecc.

### Completare l'installazione

Al primo avvio l'interfaccia si presenterà con un grande bottone per avviare l'installazione delle dipendenze necessarie. A questo punto è sufficiente cliccare su "Start Homelab" e seguire la procedura guidata (tutto o quasi ancora da implementare)


Da qui puoi: (tutto o quasi ancora da implementare)
1. Gestire i servizi Docker (avviare, fermare, configurare e controllare lo stato di salute di un servizio)
2. Controllare i log (console wrapper per docker compose logs <SERVIZIO> oppure journalctl)
3. Gestire gli utenti
4. Gestire i backup
5. Gestire le impostazioni di rete (cambio dominio, dns resolver, dynamic dns, ecc)
6. Controllare lo stato di salute del Nodo 1 (Connessione di rete, connessione vpn, servizi docker, servizi di sistema, ecc)
