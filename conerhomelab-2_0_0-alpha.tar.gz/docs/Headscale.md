# Headscale

## Installation

Installa direttamente sull'host senza utilizzare Docker.

```bash
ARCH=$(dpkg --print-architecture)
VERSION=$(curl -s "https://api.github.com/repos/juanfont/headscale/releases/latest" | jq -r '.tag_name' | sed 's/v//')
DEB="headscale_${VERSION}_linux_${ARCH}.deb"

# Scarica e installa
wget "https://github.com/juanfont/headscale/releases/download/v${HEADSCALE_VERSION:-$VERSION}/${DEB}"
sudo mv ./"$DEB" /var/cache/apt/archives/ && sudo apt install /var/cache/apt/archives/"$DEB"
```

L'installazione creerà automaticamente:

* La directory di configurazione: `/etc/headscale/`
* La directory dei dati e del database: `/var/lib/headscale/`
* L'utente di sistema e il servizio `systemd` dedicato (`headscale`).

## Configuration

### OIDC Client Secret

Puoi salvare in sicurezza l'`oidc client secret` di Headscale sfruttando `LoadCredential` di systemd. Headscale supporta nativamente questa funzione leggendo il segreto dal file puntato dalla variabile d'ambiente `$CREDENTIALS_DIRECTORY` creata da systemd.

### 1. Configurazione del File di Policy (`config.yaml`)

Nel file di configurazione di Headscale (solitamente `/etc/headscale/config.yaml`), **non** inserire il segreto in chiaro. Usa invece la direttiva `client_secret_path` puntando alla variabile d'ambiente fornita da systemd.

Modifica la sezione `oidc` come segue:

```yaml
oidc:
  issuer: "https://auth.conerolabs.com"
  client_id: "tuo-client-id"
  
  # NON usare client_secret qui.
  # Usa client_secret_path con la variabile d'ambiente: il percorso punta al file decifrato in memoria da systemd
  client_secret_path: "$CREDENTIALS_DIRECTORY/oidc_client_secret"
```

**Nota critica:** Le variabili `client_secret` e `client_secret_path` si escludono a vicenda. Assicurati che `client_secret` sia commentato o rimosso.

### 2. Configurazione dell'Unità Systemd (`headscale.service`)

Devi modificare o creare un file di override per il servizio systemd di Headscale per caricare il segreto criptato e passarlo alla directory delle credenziali.

```bash
sudo mkdir -p /etc/systemd/system/headscale.service.d
sudo tee /etc/systemd/system/headscale.service.d/override.conf > /dev/null <<EOF
[Service]
# Usa LoadCredentialEncrypted per file .cred criptati
LoadCredentialEncrypted=oidc_client_secret:/etc/headscale/secrets/oidc_client_secret
EOF
```

oppure interattivamente, esegui `systemctl edit headscale` e imposta:

```ini
[Service]
# Usa LoadCredentialEncrypted per file .cred criptati
LoadCredentialEncrypted=oidc_client_secret:/etc/headscale/secrets/oidc_client_secret
```

*Assicurati che il file sorgente (`/etc/headscale/secrets/oidc_client_secret`) esista, contenga **solo** il segreto (niente spazi extra o newline alla fine, vedi nota sotto) e abbia permessi restrittivi (es. `chmod 600`, proprietario `root`).*

Utilizza lo strumento `systemd-creds` per criptare il tuo segreto. Questo lo lega all'ID della macchina (e opzionalmente al TPM se disponibile), rendendolo illeggibile se copiato su un altro server.

```bash
# Crea il file criptato (assicurati di usare --name per definire l'ID della credenziale)
echo -n "il-tuo-segreto-oidc" | systemd-creds encrypt --name=oidc_client_secret - /etc/headscale/secrets/oidc_client_secret
```

Verifica lo stato con `systemctl status headscale` e controlla i log (`journalctl -u headscale`) per assicurarti che l'autenticazione OIDC venga inizializzata correttamente senza errori di "invalid client secret".

Ricarica il demone e riavvia il servizio:

```bash
sudo systemctl daemon-reload
sudo systemctl restart headscale.service
```

#### Vantaggi e Requisiti

* **Sicurezza:** Il file `/etc/headscale/secrets/oidc_client_secret.cred` è inutile se rubato, poiché può essere decifrato solo dallo stesso systemd sulla stessa macchina (grazie alla chiave master di sistema o al TPM).
* **Trasparenza:** Per il processo di Headscale, il file appare come un normale file di testo in `$CREDENTIALS_DIRECTORY`, quindi non richiede modifiche al software.
* **Verifica:** Puoi testare la decrittografia manuale (per debug) con:

```bash
systemd-creds cat /etc/headscale/secrets/oidc_client_secret.cred
```

### Verification in Automation

To verify the automation succeeded within your script, check the exit status of `daemon-reload` or inspect the merged config:

```bash
if sudo systemctl daemon-reload; then
    echo "Override applied successfully."
    # Optional: Verify the specific setting is active
    systemctl show <service_name> --property=Environment
else
    echo "Failed to reload systemd daemon."
    exit 1
fi
```

## Getting Started

### Crea il primo utente

Se configurato con un oidc provider come Authelia, avviando il client verrà richiesto di effettuare il login rimandandoti al portale di autenticazione del provider. Una volta loggato l'utente verrà creato automaticamente.

### Crea un API key da utilizzare con l'interfaccia web

```bash
sudo headscale apikeys create --expiration 90d
```

## UI

[Headscale-UI](https://github.com/gurucomputing/headscale-ui): install inside a container.  
Image: [ghcr.io/gurucomputing/headscale-ui:latest](https://github.com/gurucomputing/headscale-ui/pkgs/container/headscale-ui)

Navigare in Settings e aggiungere l'API key generata precedentemente con headscale.
