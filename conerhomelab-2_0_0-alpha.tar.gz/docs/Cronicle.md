# Cronicle

Cronicle is a multi-node task scheduler and tool for distributed job execution. It features a web-based front-end for managing scheduled events, real-time logging, and monitoring, making it an ideal replacement for standard crontab in complex environments.

## Installation

cronicle user must have same group id (GID) of `docker` group on host machine. Usually `999`, that correspond to `ping` group in cronicle/edge image.  
Also we need to install `docker-cli` and `docker-cli-compose` on the image to allow docker management directly from cronicle jobs.  
Therefore we need to customize the image with an inline dockerfile in docker-compose.yml

## Integration with Caddy

## Running jobs

Nella sezione Admin, configurare il plugin **Shell Script**, alla voce 'advanced' impostare 'Run as Group (GID)': `ping`
