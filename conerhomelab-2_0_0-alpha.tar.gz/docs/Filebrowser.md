# Filebrowser

## Authentication

Filebrowser authenticate using Authelia, so you need to have a user in Authelia to access Filebrowser.
Occorre creare lo stesso utente in Filebrowser per poter accedere.