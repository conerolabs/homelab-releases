# Caddyfile

The Caddyfile configures a secure, self-hosted homelab environment with automatic HTTPS, dynamic DNS, and centralized authentication via Authelia. It uses **snippets** to reduce repetition and **environment variables** for secrets.

## Global Configuration

The global block (`{ ... }`) sets server-wide options:

* **`email`**: Sets the ACME email address for Let's Encrypt certificates using `{env.CADDY_EMAIL}`.
* **`admin`**: Exposes the Caddy admin API on the gateway IP (`{env.DOCKER_NETWORK_GATEWAY}`) at port `2019` for remote management.
* **`dynamic_dns`**: Automatically updates DNS records for `conerolabs.com` (specifically the root `@`, `vpn`, and `auth` subdomains) via Cloudflare. It checks for IP changes every **5 minutes** and only updates **IPv4** records.

## Reusable Snippets

Three snippets define reusable logic to keep site blocks clean:

1. **`(auth_check)`**: Wraps the `forward_auth` directive. It sends incoming requests to Authelia at `localhost:9091` (endpoint `/api/authz/forward-auth`). If Authelia returns a 2xx status, Caddy copies identity headers (`Remote-User`, `Remote-Groups`, etc.) to the backend request; otherwise, the user is redirected to the login page.
2. **`(dns_auth)`**: Configures TLS to use the **DNS-01 challenge** via Cloudflare. This allows Caddy to obtain certificates for domains that might not be publicly routable yet or to avoid port 80 conflicts. It explicitly uses Cloudflare's resolvers (`1.1.1.1`, `1.0.0.1`) to ensure propagation checks succeed quickly.

## Site Configurations

### 1. Authelia Portal

**`auth.{$DOMAIN}`**

* Serves the Authelia login portal itself.
* Uses `dns_auth` for certificates.
* Proxies traffic directly to the Authelia container on `localhost:9091` without requiring authentication (to allow login).

### 2. VPN Service (Public)

**`vpn.{$DOMAIN}`**

* **Publicly accessible** (no `remote_ip` restriction).
* **CORS Handling**: Explicitly handles `OPTIONS` preflight requests for the `/web*` path, returning a `204` with appropriate CORS headers before authentication.
* **Authentication**: The `@ui` matcher applies `auth_check` to `/web*` traffic, proxying authorized users to port `8085`.
* **Backend**: All other traffic (likely the VPN protocol itself) bypasses auth and goes to `localhost:8084`.

### 3. Internal Services (LAN/Tailscale Only)

The following services use `@private` matcher to restrict access to the local network or Tailscale tunnel:

* **PiHole (`dns.{$DOMAIN}`)**: Allows unauthenticated access to the login API (`/api/info/login`) but requires `auth_check` for the dashboard, redirecting root `/` to `/admin`. Proxies to `localhost:8081`.
* **Vaultwarden (`vault.{$DOMAIN}`)**: Simple reverse proxy to `localhost:8080` with full auth protection.
* **Homepage (`home.{$DOMAIN}`)**:
  * **Exception**: The `/widgets/calendar` path is **public** (no auth). It rewrites the path and adds a `Basic` Authorization header before proxying to `localhost:4000`.
  * **Default**: All other paths require `auth_check` and proxy to `localhost:3000`.
* **Gatus (`status.{$DOMAIN}`)**: Status dashboard proxied to `localhost:8082` with auth.
* **RustiCal (`calendar.{$DOMAIN}`)**: Proxied to `localhost:4000`. Authentication is handled internally by the app via OIDC, so the Caddy `auth_check` is not imported.
* **MySpeed (`speedtest.{$DOMAIN}`)**: Requires auth, proxies to `localhost:5216`.
* **Portainer (`portainer.{$DOMAIN}`)**: **Authentication is commented out** (`#import auth_check`), relying on Portainer's internal login. Proxies to `localhost:9000`.
* **Navidrome (`music.{$DOMAIN}`)**: Uses a matcher `@protected` to bypass auth for `/ping` and `/rest/*` endpoints (likely for music players). All other paths require `auth_check`. Proxies to `localhost:4533`.
* **FileBrowser (`files.{$DOMAIN}`)**: Bypasses auth for `/healthz` checks; all other paths require `auth_check`. Proxies to `localhost:8083`.

### 4. LAN Only

* **Cronicle (`cron.{$DOMAIN}`)**: Explicitly binds only to LAN ips (excluding Tailscale) and requires `auth_check`. Proxies to `localhost:3012`.
