# Gatus

## Alerting

### Telegram

Telegram Alerts enable real-time notifications for events, system monitoring, or critical updates using Telegram’s Bot API. These alerts can be sent to individual users, groups, or channels via custom bots.

#### Setting Up Telegram Alerts

To configure Telegram alerts, follow these general steps:

- Create a Telegram Bot:
  - Contact @BotFather in Telegram.
  - Use the /newbot command to create a new bot.
  - Copy the API token provided (e.g., 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11).

- Obtain Chat ID:
  - Start a conversation with your bot.
  - Use the Telegram API to retrieve the chat ID:
    - Visit: https://api.telegram.org/bot<your_bot_token>/getUpdates
    - The response includes the chat_id under message.chat.id.
