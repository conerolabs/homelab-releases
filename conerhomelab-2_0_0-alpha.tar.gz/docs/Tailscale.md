# Tailscale

## Configure NameServer list

https://tailscale.com/api#tag/dns

Use Tailscale API to change the NameServer list (if you do not want to do it from admin console)

## Exit Node 

https://tailscale.com/docs/features/exit-nodes?tab=linux

1. Advertise the device as an exit node (`sudo tailscale up --advertise-exit-node`)
2. Allow the exit node from admin console (If the device is authenticated by a user who can approve exit nodes in autoApprovers, the exit node will automatically be approved.)
3. Use the exit node from client devices (Each device must enable the exit node separately: `sudo tailscale up --exit-node=<node_name>`)
