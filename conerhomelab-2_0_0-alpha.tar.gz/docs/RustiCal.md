# RustiCal

Find RustiCal docs [here](https://lennart-k.github.io/rustical/).

## Docker Container

## Authentication

RustiCal use OIDC (OpenID Connect) to authenticate. No need to forward auth with Caddy, it's managed directly by RustiCal.

## Integration with Homepage Dashboard

You need the link to the .ics calendar file:  
`https://calendar.conerolabs.com/caldav/principal/andrea/056012a7-5e87-4583-b478-cdb058d27d9c`  
Follow the homepage guide: <https://gethomepage.dev/widgets/services/calendar/#monthly-view>
You will need to setup basic authentication with an App Token generated from Radical web ui. In Caddy detect if request comes from Homepage and in case add proper auth header.

## With Gnome Online Accounts

You must generate an App token for Gnome from Rustical web ui.
In Settings -> Gnome Online Accounts choose a `Calendar, Contacts and Files` account type. (WebDAV)
Insert calendar.conerolabs.com as server and insert the previosly generated app token.

## With Gnome Evolution Mail client (Deprecated)

You must generate an App token for Gnome Evolution from Rustical web ui.
In Evolution go to calendars -> `New` button -> Collection Account

1. Insert user name.
2. Expand advanced options and insert calendar.conerolabs.com as Server.
3. Flag CalDAV/CardDAV server
4. press `Look Up` button.

A message asking to click to insert the password appears.
Insert the App token as the password and here we go!

## With DAVx5 client

Installl DAVx5 on Android from F-Droid (on Play Store is not free).
Log in with NextCloud flow.
