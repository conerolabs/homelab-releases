# Homelab Development

## Virtual Machine

1. install qemu and virt-manager on ubuntu
2. download the image:
    https://dl.armbian.com/uefi-x86/archive/Armbian_26.2.1_Uefi-x86_noble_cloud_6.18.8_minimal.img.qcow2.xz
3. uncompress the image file

```bash
curl -LO https://dl.armbian.com/uefi-x86/archive/Armbian_26.2.1_Uefi-x86_trixie_cloud_6.18.8_minimal.img.qcow2.xz
xz -d Armbian_26.2.1_Uefi-x86_trixie_cloud_6.18.8_minimal.img.qcow2.xz   
```

4. start virt-manager and create a virtual machine with the .qcow2 file

## Release (.tar.gz file)

Use `tag-release` script to tag the release commit even if it is enough to push a tag starting with `v`.

Then, thanks to github actions, the script is called automatically and the .tar.gz file is pushed to [homelab-releases](https://github.com/conerolabs/homelab-releases) public repository, available to be downloaded.

With the script, the version number is automatically incremented after pushing the tag.

### Using git archive

Run the script 'release.sh'

```bash
git archive -o conerhomelab-v"${HOMELAB_VERSION//./_}".tar.gz HEAD . ':!install/scripts/tests/' ':!release.sh'
```

## Installation

Download install.sh from git repo.
Execute the script.

```bash
curl -L https://raw.githubusercontent.com/ConeroLabs/Homelab/main/install/install.sh | bash
```
