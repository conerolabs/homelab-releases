#!/bin/bash
set -eEuo pipefail
SERVICE_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
source "$SERVICE_SCRIPT_DIR/directories.sh"

declare -A sites

sites=(
    [caddy]="proxy"
    [pihole]="dns"
    [authelia]="auth"
    [homepage]="home"
    [rustical]="calendar"
    [cronicle]="cron"
    [filebrowser]="files"
    [navidrome]="music"
    [portainer]="portainer"
    [myspeed]="speedtest"
    [gatus]="status"
    [vaultwarden]="vault"
    [headscale]="vpn"
)


CADDYFILE_FOLDER="$HOMELAB_DIR/caddy/etc/caddy"
ENABLED_SITES_FOLDER="$CADDYFILE_FOLDER/sites-enabled"
AVAILABLE_SITES_FOLDER="$CADDYFILE_FOLDER/sites-disabled"

# Parse arguments, first argument is the command
cmd=$1
service=$2

# Se il servizio è già abilitato non fa niente.
function enable() {
    echo "Abilitazione del servizio $service"
    if [ -f "$ENABLED_SITES_FOLDER/${sites[$service]}.caddy" ]; then
        echo "$service è già abilitato."
        docker compose -f "$HOMELAB_DIR/docker-compose.yml" up -d "$service"
    elif [ -f "$AVAILABLE_SITES_FOLDER/${sites[$service]}.caddy" ]; then
        ln -s "$AVAILABLE_SITES_FOLDER/${sites[$service]}.caddy" "$ENABLED_SITES_FOLDER/${sites[$service]}.caddy"
        # Avviamo anche caddy nel caso non sia in esecuzione
        docker compose -f "$HOMELAB_DIR/docker-compose.yml" up -d caddy "$service"
        docker compose -f "$HOMELAB_DIR/docker-compose.yml" exec caddy caddy reload --config "/etc/caddy/Caddyfile"
    elif [[ -v sites[${service}] ]]; then
        echo "$service è abilitato di default."
        docker compose -f "$HOMELAB_DIR/docker-compose.yml" up -d "$service"
    else
        echo "Il servizio $service non esiste."
    fi
}

function disable() {
    echo "Disabilitazione del servizio $service"
    if [ ! -f "$ENABLED_SITES_FOLDER/${sites[$service]}.caddy" ]; then
        echo "$service è già disabilitato."
        return
    fi
    rm "$ENABLED_SITES_FOLDER/${sites[$service]}.caddy"
    docker exec caddy caddy reload --config "/etc/caddy/Caddyfile"
    docker compose -f "$HOMELAB_DIR/docker-compose.yml" down "$service"
}

function reload() {
    echo "Da implementare"
}

function health() {
    if docker compose healthcheck "$service"; then
        echo ""
    else
        echo ""
    fi
}

case $cmd in
    enable)
        enable
        ;;
    disable)
        disable
        ;;
    reload)
        reload
        ;;
    healthcheck)
        health
        ;;
    *)
        echo "Usage: $0 {enable|disable|reload|health} {service}"
        ;;
esac


function handle_error() {
    echo "Si è verificato un errore."
    case $cmd in
        enable)
            mv "$ENABLED_SITES_FOLDER/${sites[$service]}.caddy" "$AVAILABLE_SITES_FOLDER" || true
            ;;
        disable)
            mv "$AVAILABLE_SITES_FOLDER/${sites[$service]}.caddy" "$ENABLED_SITES_FOLDER" || true
            ;;
        reload)
            ;;
        healthcheck)
            ;;
    esac
}

trap 'handle_error' ERR