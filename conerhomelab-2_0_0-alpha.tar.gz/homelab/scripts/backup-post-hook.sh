#!/usr/bin/env bash
# ==============================================================================
# Backrest Post-Backup Hook
# Executed inside the Backrest container after snapshot completes.
# Cleans up unencrypted dumps from the staging directory.
# ==============================================================================
set -eo pipefail

STAGING_DIR="/userdata/staging"

echo "[$(date -Iseconds)] [Post-Backup Hook] Cleaning up staging directory..."

if [ -d "$STAGING_DIR" ]; then
    rm -rf "${STAGING_DIR:?}"/*
fi

echo "[$(date -Iseconds)] [Post-Backup Hook] Staging directory clean."

