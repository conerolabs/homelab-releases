#!/bin/bash

ENV_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
source "$ENV_SCRIPT_DIR/print.sh"
source "$ENV_SCRIPT_DIR/error-utils.sh"
TMP=$(cd "$ENV_SCRIPT_DIR/../tmp" &>/dev/null && pwd)
print_debug "Script directory: ${LIGHT_CYAN}$ENV_SCRIPT_DIR" "${BASH_SOURCE[0]##*/}"
print_debug "TMP folder: ${LIGHT_CYAN}$TMP$" "${BASH_SOURCE[0]##*/}"

function edit_env() {

    local ENV_VAR=$1
    local VALUE=$2
    local ENV_FILE=${3:-"$(cd "$ENV_SCRIPT_DIR/.." &>/dev/null && pwd)/.env"}
    local ESCAPED_VALUE
    print_debug "ENV_FILE: ${LIGHT_CYAN}$ENV_FILE" "${BASH_SOURCE[0]##*/}"


    ESCAPED_VALUE="$(echo "$VALUE" | "$ENV_SCRIPT_DIR"/sed_escape.sh -m replacement)"
    # Check if the variable exists in the .env file, if not add it, otherwise replace it
    if ! grep -q "^${ENV_VAR}=" "$ENV_FILE"; then
        echo -e "${INFO} Aggiungo la variabile ${CYAN}$ENV_VAR${NC} al file .env ..."
        echo -e "\n${ENV_VAR}='${VALUE}'" >> "$ENV_FILE"
    else
        echo -e "${INFO} Aggiorno la variabile ${CYAN}$ENV_VAR${NC} nel file .env ..."
        sed "s/^${ENV_VAR}=.*/${ENV_VAR}='$ESCAPED_VALUE'/" "$ENV_FILE"   > "$TMP/.env"
        #cp -f "$TMP/.env" "$ENV_FILE"
        cat "$TMP/.env" > "$ENV_FILE"
        rm "$TMP/.env"
    fi
    echo -e "${OK} File .env aggiornato"
}

function rm_env() {
    local ENV_VAR=$1
    local ENV_FILE=${2:-"$ENV_SCRIPT_DIR/../.env"}
    # Check if the variable exists in the .env file
    if ! grep -q "^${ENV_VAR}=" "$ENV_FILE"; then
        print_warning "La variabile $ENV_VAR non esiste nel file .env"
        return 0
    fi
    echo -e "${INFO} Rimuovo la variabile ${CYAN}$ENV_VAR${NC} dal file .env ..."
    sed "/^${ENV_VAR}=/d" "$ENV_FILE" > .env.tmp && mv .env.tmp "$ENV_FILE"
}
