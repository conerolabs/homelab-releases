#!/bin/bash

ERR_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
source "$ERR_SCRIPT_DIR/print.sh"

function handle_error() {
  set +e
  local exit_code=$3
  local line_no=$1
  local file=$2
  local command=$BASH_COMMAND
  print_error "Error on line ${line_no} of ${file}"
  print_error "Command: ${command} (exit code: ${exit_code})"
  set -e
  exit ${exit_code}
}

trap 'handle_error $LINENO ${BASH_SOURCE[0]} $?' ERR
