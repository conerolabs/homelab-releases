#!/bin/bash

set -Eeuo pipefail
echo
# echo -n "Bash version: "
# bash --version
# echo
# echo -n "sed version: "
# sed --version
# echo
UPDIP_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
ENV_FILE_FOLDER=$(cd "$UPDIP_SCRIPT_DIR/.." &>/dev/null && pwd)

source "$UPDIP_SCRIPT_DIR/directories.sh"
source "$UPDIP_SCRIPT_DIR/env.sh"
source "$UPDIP_SCRIPT_DIR/print.sh"
source "$ENV_FILE_FOLDER/.env"

print_debug "Script: ${LIGHT_CYAN}${BASH_SOURCE[0]}${NC}" "${BASH_SOURCE[0]##*/}"
echo

IP_SERVICES=(https://api.ipify.org https://ifconfig.me/ip https://ipinfo.io/ip)

set +e
# Fetch current public IP
n=${#IP_SERVICES[@]}
RANDOM_INDEX=$(( RANDOM % n ))
for ((i=0; i<n; i++)); do
  SERVICE="${IP_SERVICES[($RANDOM_INDEX + $i) % n]}"
  echo -n -e "Verifica dell'IP tramite il servizio ${LIGHT_GREEN}${SERVICE}${NC} ..."  
    NEW_IP=$(curl -s "$SERVICE")
    if [ -n "$NEW_IP" ]; then
      echo -e "   ${CYAN}$NEW_IP${NC}"
      break
    else
      echo -e "   ${RED}Failed${NC}"
      print_error "La verifica dell'IP è fallita con tutti i servizi: ${IP_SERVICES[*]}"
      exit 1
    fi
done

set -e
if [ "$HOST_PUBLIC_IP" != "$NEW_IP" ]; then
  echo "L'indirizzo IP è cambiato da $HOST_PUBLIC_IP a $NEW_IP"
  echo "Aggiorno il file .env e riavvio Authelia per applicare i cambiamenti..."
  echo
  # Update the IP in the YAML file
  #yq eval "(.access_control.networks[] | select(.name == \"public_host\") | .networks[0]) = \"$NEW_IP\"" -i "$CONFIG_FILE"
  edit_env HOST_PUBLIC_IP "$NEW_IP"
  
  # Restart Authelia to apply changes (adjust command for your setup)
  docker compose -f "$HOMELAB_DIR/docker-compose.yml" restart authelia
else
  echo -e "L'indirizzo IP è sempre lo stesso: ${CYAN}$HOST_PUBLIC_IP${NC}"
  echo "Nessuna azione da compiere."
fi
echo