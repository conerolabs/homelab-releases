#!/bin/bash
# run with sudo

curl -fsSL https://tailscale.com/install.sh | sh