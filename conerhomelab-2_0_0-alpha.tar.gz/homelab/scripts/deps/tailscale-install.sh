#!/bin/bash
# run with sudo

curl -fsSL https://tailscale.com/install.sh | sh
# after installation: set the operator user to avoid using root
tailscale set --operator="$USER"