#!/bin/bash
# run with sudo
set -Eeou pipefail

DEPS_CHECK_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
source "$DEPS_CHECK_SCRIPT_DIR/../print.sh"
source "$DEPS_CHECK_SCRIPT_DIR/deps.sh"

ACTION=$1
NAME=${2:-''}
START=${3:-false}

DEFAULT_CHECK="command -v $NAME"
if [[ -f "$HOMELAB_DB" ]]; then
    CHECK_CMD=$(echo "$ALL_DEPS_JSON" | jq --arg n "$NAME" -r '.[] | select(.name==$n).check_cmd')
    INSTALL_CMD=$(echo "$ALL_DEPS_JSON" | jq --arg n "$NAME" -r '.[] | select(.name==$n).install_cmd')
    REMOVE_CMD=$(echo "$ALL_DEPS_JSON" | jq --arg n "$NAME" -r '.[] | select(.name==$n).remove_cmd')
fi

function check_dep() {
    if ! eval "${CHECK_CMD:-$DEFAULT_CHECK}" &> /dev/null; then
        echo false
        return 1
    else
        echo true
        return 0
    fi
}

function install_dep() {
    echo -e "Checking if ${CYAN}$NAME${NC} is installed ..."
    if ! check_dep > /dev/null; then
        echo -e "${YELLOW}$NAME${NC} is not installed"
        if [[ -z "$INSTALL_CMD" ]]; then
            echo -e "No installation command found for $NAME"
            return 1
        else
            echo -e "Installing ${CYAN}$NAME${NC}..."
            set -x
            $INSTALL_CMD
            set +x
        fi
    else
        echo -e "  ${OK} $NAME is installed"
    fi
}

function remove_dep() {
    echo -e "Checking if ${CYAN}$NAME${NC} is installed ..."
    if check_dep > /dev/null; then
        echo -e "$NAME is installed"
        if [[ -z "$REMOVE_CMD" ]]; then
            echo -e "No removal command found for $NAME"
            return 1
        else
            echo -e "Removing ${CYAN}$NAME${NC}..."
            set -x
            $REMOVE_CMD
            set +x
        fi
    fi
}

function start_dep() {
    echo -e "Starting ${CYAN}$NAME${NC}..."
    sudo systemctl start "$NAME"
}

function stop_dep() {
    echo -e "Stopping ${CYAN}$NAME${NC}..."
    sudo systemctl stop "$NAME"
}

function restart_dep() {
    echo -e "Restarting ${CYAN}$NAME${NC}..."
    sudo systemctl restart "$NAME"
}

case "$ACTION" in
    "install")
        install_dep
    ;;
    "check")
        check_dep
    ;;
    "start")
        start_dep
    ;;
    "stop")
        stop_dep
    ;;
    "restart")
        restart_dep
    ;;
    "remove")
        remove_dep
    ;;
    *)  
        echo -e "${ERROR} Invalid action: $ACTION${NC}"; exit 1;;
esac
