#!/bin/bash
# run with sudo

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
HOMELAB_DIR=$(cd "$SCRIPT_DIR/.." &>/dev/null && pwd)

source "$HOMELAB_DIR/.env" || echo "WARNING - .env not found" # to load HEADSCALE_VERSION

# Rileva automaticamente l'architettura (arm64 per la maggior parte dei SoC ARM, amd64 per PC)
ARCH=$(dpkg --print-architecture)
VERSION=$(curl -s "https://api.github.com/repos/juanfont/headscale/releases/latest" | jq -r '.tag_name' | sed 's/v//')
DEB="headscale_${VERSION}_linux_${ARCH}.deb"

# Scarica e installa
wget "https://github.com/juanfont/headscale/releases/download/v${HEADSCALE_VERSION:-$VERSION}/${DEB}"
mv ./"$DEB" /var/cache/apt/archives/ && apt install /var/cache/apt/archives/"$DEB"