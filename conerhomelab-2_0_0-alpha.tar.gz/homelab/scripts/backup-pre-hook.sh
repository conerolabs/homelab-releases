#!/usr/bin/env bash
# ==============================================================================
# Backrest Pre-Backup Hook
# Executed inside the Backrest container before a snapshot operation starts.
# Dumps PostgreSQL and takes atomic WAL-safe snapshots of SQLite databases.
# ==============================================================================
set -eo pipefail

STAGING_DIR="/userdata/staging"
mkdir -p "$STAGING_DIR"
rm -f "$STAGING_DIR"/* 2>/dev/null || true

echo "[$(date -Iseconds)] [Pre-Backup Hook] Starting consistent database dumps..."

# 1. PostgreSQL (Linkwarden)
if docker ps --format '{{.Names}}' | grep -q "^postgres$"; then
    echo "[$(date -Iseconds)] Dumping PostgreSQL (all databases)..."
    docker exec postgres pg_dumpall -U postgres | gzip > "$STAGING_DIR/postgres_all.sql.gz"
fi

# 2. Vaultwarden SQLite
if [ -f "/userdata/homelab/vaultwarden/db.sqlite3" ]; then
    echo "[$(date -Iseconds)] Creating atomic snapshot of Vaultwarden DB..."
    sqlite3 "/userdata/homelab/vaultwarden/db.sqlite3" "VACUUM INTO '$STAGING_DIR/vaultwarden.sqlite3'" || true
fi

# 3. Authelia SQLite
if [ -f "/userdata/homelab/authelia/config/db.sqlite3" ]; then
    echo "[$(date -Iseconds)] Creating atomic snapshot of Authelia DB..."
    sqlite3 "/userdata/homelab/authelia/config/db.sqlite3" "VACUUM INTO '$STAGING_DIR/authelia.sqlite3'" || true
fi

# 4. RustiCal SQLite
if [ -f "/userdata/homelab/rustical/data/db.sqlite3" ]; then
    echo "[$(date -Iseconds)] Creating atomic snapshot of RustiCal DB..."
    sqlite3 "/userdata/homelab/rustical/data/db.sqlite3" "VACUUM INTO '$STAGING_DIR/rustical.sqlite3'" || true
fi

# 5. Web-Config Homelab DB
if [ -f "/userdata/homelab/homelab.db" ]; then
    echo "[$(date -Iseconds)] Creating atomic snapshot of Homelab DB..."
    sqlite3 "/userdata/homelab/homelab.db" "VACUUM INTO '$STAGING_DIR/homelab.sqlite3'" || true
fi

# 6. Pi-hole FTL DB
if [ -f "/userdata/homelab/pihole/etc-pihole/pihole-FTL.db" ]; then
    echo "[$(date -Iseconds)] Creating atomic snapshot of Pi-hole DB..."
    sqlite3 "/userdata/homelab/pihole/etc-pihole/pihole-FTL.db" "VACUUM INTO '$STAGING_DIR/pihole-FTL.sqlite3'" || true
fi

# 7. Gatus DB
if [ -f "/userdata/homelab/gatus/data/data.db" ]; then
    echo "[$(date -Iseconds)] Creating atomic snapshot of Gatus DB..."
    sqlite3 "/userdata/homelab/gatus/data/data.db" "VACUUM INTO '$STAGING_DIR/gatus.sqlite3'" || true
fi

# 8. Navidrome DB (Metadata, playlists, star ratings)
if [ -f "/userdata/homelab/navidrome/data/navidrome.db" ]; then
    echo "[$(date -Iseconds)] Creating atomic snapshot of Navidrome DB..."
    sqlite3 "/userdata/homelab/navidrome/data/navidrome.db" "VACUUM INTO '$STAGING_DIR/navidrome.sqlite3'" || true
fi

# 9. MySpeed DB (Speedtest history)
if [ -f "/userdata/homelab/myspeed/storage.db" ]; then
    echo "[$(date -Iseconds)] Creating atomic snapshot of MySpeed DB..."
    sqlite3 "/userdata/homelab/myspeed/storage.db" "VACUUM INTO '$STAGING_DIR/myspeed.sqlite3'" || true
fi

# 10. Filebrowser DB (BoltDB: user accounts, shares, permissions)
if [ -f "/userdata/homelab/filebrowser/db/filebrowser.db" ]; then
    echo "[$(date -Iseconds)] Copying Filebrowser DB..."
    cp "/userdata/homelab/filebrowser/db/filebrowser.db" "$STAGING_DIR/filebrowser.db" || true
fi

echo "[$(date -Iseconds)] [Pre-Backup Hook] All staging dumps completed successfully."
ls -lh "$STAGING_DIR"

