#!/bin/bash

# Italic
ITALIC='\e[3m'
NOT_ITALIC='\e[23m'
# Foreground
RED='\e[0;31m'
LIGHT_RED='\033[38;5;88m'
GREEN='\e[0;32m'
LIGHT_GREEN='\033[38;5;78m'
YELLOW='\e[0;33m'
BLUE='\e[0;34m'
MAGENTA='\e[0;35m'
CYAN='\033[0;36m'
LIGHT_CYAN='\033[38;5;247m'
WHITE='\e[1;37m'
# Background
BG_RED='\e[0;41m'
BG_GREEN='\e[0;42m'
GRAY='\033[38;5;59m'
# Reset
NC='\033[0m'
# Symbols
OK='\u2705'
WARN='\u26A0'
ERROR='\u274C'
PENCIL='\u270F'
INFO='\u2139'

function print_info() {
    echo -e "${INFO} ${CYAN}$1${NC}"
}

function print_debug() {
    local MSG=$1
    set +u
    local filename=$2
    if [ -n "$DEBUG" ]; then
        echo -e "${GRAY}[DEBUG] [$filename] $MSG${NC}"
    fi
    set -u
}

function print_success() {
    echo -e "${OK} $1"
}

function print_warning() {
    echo -e "${WARN} ${YELLOW}$1${NC}"
}

function print_error() {
    echo -e "${ERROR} ${RED}$1${NC}" >&2
}

# TODO: to test
function erase_lines() {
  local n=${1:-1}
  for ((i=0; i<n; i++)); do
    echo -ne "\033[1A\033[2K"
  done
}

function progress(){
    local label=${1:-"Processing"}
    local width=40
    local progress=${2:-0} # int between 0 and 100

    echo -ne "\r${label} ["
    for ((j=0; j<progress*width/100; j++)); do echo -ne "#"; done
    for ((j=progress*width/100; j<width; j++)); do echo -ne " "; done
    echo -ne "] $progress%"
    if [[ "$progress" == "100" ]]; then
        echo -e " ${OK}"
    fi
}