#!/bin/bash

OIDC_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)

source "$OIDC_SCRIPT_DIR/directories.sh"
source "$OIDC_SCRIPT_DIR/env.sh"
source "$OIDC_SCRIPT_DIR/print.sh"

function oidc_client_id() {
  local name=$1
  local env_var_name
  env_var_name=$(echo "${name}" | sed 's/-//g' | tr '[:lower:]' '[:upper:]')_OIDC_CLIENT_ID
  echo "Generazione del client id di '${name}' per Authelia ..."
  if [[ -z "${!env_var_name:-}" ]]; then
      CLIENT_ID=${name}-$(openssl rand -hex 8)
      edit_env "${env_var_name}" "$CLIENT_ID"
      echo "  Client ID: $CLIENT_ID"
  else
      echo -e "  Il ${CYAN}client ID${NC} esiste già: ${!env_var_name}"
  fi
}

function create_secret_file() {
  local name=$1
  local value=$2
  local secrets_dir="$HOMELAB_DIR/${name}/secrets"
  local secret_file="$secrets_dir/oidc_client_secret.txt"
  if [ -f "$secret_file" ]; then
    echo -e "  ${CYAN}oidc_client_secret.txt${NC} esiste già in $secrets_dir"
  else
    mkdir -p "$secrets_dir"
    chmod 700 "$secrets_dir"
    echo -n "$value" > "$secret_file"
    echo -e "  ${CYAN}Client Secret${NC} memorizzato su file: $secret_file"
  fi
}

# Se nessun storage specificato, salva il client secret come variabile d'ambiente, altrimenti salva su file o su systemd-creds
function oidc_client_secret() {
  local name=$1
  local storage=${2:-env} # default storage is env, other options are file, systemd-creds
  local value=${3:-''}
  local env_var_name
  # Converti il nome del servizio in nome della variabile d'ambiente (tutto maiuscolo, senza trattini)
  env_var_name=$(echo "${name}" | sed 's/-//g' | tr '[:lower:]' '[:upper:]')_OIDC_CLIENT_SECRET
  if [ "$value" == "" ]; then
      echo "Generazione del client secret di '${name}' per Authelia ..."
      CLIENT_SECRET=$(openssl rand -base64 32 | tr -d '\n')
  else
      echo -e "  Utilizzo il secret di '${name}' fornito in input ..."
      CLIENT_SECRET="$value"
  fi
  if [[ "$storage" == "file" ]]; then
      create_secret_file "$name" "$CLIENT_SECRET"
  elif [[ "$storage" == "systemd-creds" ]]; then
      local secrets_dir="/etc/${name}/secrets"
      local secret_file="$secrets_dir/oidc_client_secret"
      if [ -f "$secret_file" ]; then
        echo -e "  ${CYAN}oidc_client_secret${NC} esiste già in $secrets_dir"
      else
        sudo mkdir -p "$secrets_dir"
        echo -n "$CLIENT_SECRET" | sudo systemd-creds encrypt --name=oidc_client_secret - "$secret_file"
        echo -e "  ${CYAN}Client Secret${NC} memorizzato su file: $secret_file"
      fi
  else
    if [[ -z "${!env_var_name:-}" ]]; then
      edit_env "${env_var_name}" "$CLIENT_SECRET"
    else
      echo -e "  Il ${CYAN}client secret${NC} esiste già: ${!env_var_name}"
    fi
    create_secret_file "$name" "$CLIENT_SECRET" # Creiamo lo stesso il file per chiarezza di gestione
  fi
}