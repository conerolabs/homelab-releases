#!/bin/bash

OIDC_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)

source "$OIDC_SCRIPT_DIR/directories.sh"
source "$OIDC_SCRIPT_DIR/env.sh"
source "$OIDC_SCRIPT_DIR/print.sh"

function oidc_client_id() {
  local name=$1
  local env_var_name
  env_var_name=$(echo "${name}" | sed 's/-//g' | tr '[:lower:]' '[:upper:]')_OIDC_CLIENT_ID
  echo "Generazione del client id di '${name}' per Authelia ..."
  if [[ -z "${!env_var_name:-}" ]]; then
      CLIENT_ID=${name}-$(openssl rand -hex 8)
      edit_env "${env_var_name}" "$CLIENT_ID"
      echo "  Client ID: $CLIENT_ID"
  else
      echo -e "  Il ${CYAN}client ID${NC} esiste già: ${!env_var_name}"
  fi
}

# Se nessun storage specificato, salva il client secret come variabile d'ambiente, altrimenti salva su file o su systemd-creds
function oidc_client_secret() {
  local name=$1
  local storage=${2:-env} # default storage is env, other options are file, systemd-creds
  local env_var_name
  env_var_name=$(echo "${name}" | sed 's/-//g' | tr '[:lower:]' '[:upper:]')_OIDC_CLIENT_SECRET
  echo "Generazione del client secret di '${name}' per Authelia ..."
  CLIENT_SECRET=$(openssl rand -base64 32 | tr -d '\n')
  if [[ "$storage" == "file" ]]; then
      local secrets_dir="$HOMELAB_DIR/${name}/secrets"
      local secret_file="$secrets_dir/oidc_client_secret.txt"
      if [ -f "$secret_file" ]; then
        echo -e "  ${CYAN}oidc_client_secret.txt${NC} esiste già in $secrets_dir"
      else
        mkdir -p "$secrets_dir"
        chmod 700 "$secrets_dir"
        echo -n "$CLIENT_SECRET" > "$secret_file"
        echo -e "  ${CYAN}Client Secret${NC} memorizzato su file: $secret_file"
      fi
  elif [[ "$storage" == "systemd-creds" ]]; then
      local secrets_dir="/etc/${name}/secrets"
      local secret_file="$secrets_dir/oidc_client_secret"
      if [ -f "$secret_file" ]; then
        echo -e "  ${CYAN}oidc_client_secret${NC} esiste già in $secrets_dir"
      else
        sudo mkdir -p "$secrets_dir"
        echo -n "$CLIENT_SECRET" | sudo systemd-creds encrypt --name=oidc_client_secret - "$secret_file"
        echo -e "  ${CYAN}Client Secret${NC} memorizzato su file: $secret_file"
      fi
  else
    if [[ -z "${!env_var_name:-}" ]]; then
      edit_env "${env_var_name}" "$CLIENT_SECRET"
    else
      echo -e "  Il ${CYAN}client secret${NC} esiste già: ${!env_var_name}"
    fi
  fi
}