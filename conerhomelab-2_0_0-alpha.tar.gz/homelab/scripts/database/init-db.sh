#!/bin/bash
SCRIPT_DIR=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd)
source $SCRIPT_DIR/../directories.sh

DB_FILE=${1:-"$HOMELAB_DIR"/homelab.db}

sqlite3 "$DB_FILE" < "$SCRIPT_DIR"/sql/schema.sql
sqlite3 "$DB_FILE" < "$SCRIPT_DIR"/sql/init-data.sql