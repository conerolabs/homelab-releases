INSERT INTO service_actions VALUES(2,'deploy','pihole','docker compose up -d --remove-orphans pihole','cmd',0,NULL);
INSERT INTO service_actions VALUES(3,'start','docker','systemctl start docker','cmd',1,NULL);
INSERT INTO service_actions VALUES(4,'start','tailscale','tailscale up --hostname="$SERVER_NAME" --login-server="$TAILSCALE_LOGIN_URL" --accept-dns=false --operator="$USER"','cmd',1,'SERVER_NAME,TAILSCALE_LOGIN_URL,USER');
INSERT INTO service_actions VALUES(5,'deploy','caddy','docker compose up -d --remove-orphans caddy','cmd',0,NULL);
INSERT INTO service_actions VALUES(6,'deploy','authelia','docker compose up -d --remove-orphans authelia','cmd',0,NULL);
INSERT INTO service_actions VALUES(7,'stop','tailscale','tailscale down','cmd',0,NULL);
