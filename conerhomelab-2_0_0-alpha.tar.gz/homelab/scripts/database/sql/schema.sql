CREATE TABLE IF NOT EXISTS envs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  value TEXT,
  descr TEXT,
  visible BOOLEAN NOT NULL DEFAULT (true),
  readonly BOOLEAN NOT NULL DEFAULT (false),
  created_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP),
  updated_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP),
  deleted_at TIMESTAMP DEFAULT (NULL)
);
CREATE VIEW IF NOT EXISTS docker_services_view AS SELECT s.name, s.docker_img, e.value AS version
FROM services s
LEFT JOIN envs e ON s.version = e.name
WHERE s.TYPE = 'docker'
/* docker_services_view(name,docker_img,version) */;
CREATE TABLE IF NOT EXISTS users (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	username TEXT NOT NULL,
	email TEXT NOT NULL,
	display_name TEXT NOT NULL,
	groups TEXT DEFAULT ('users') NOT NULL,
	created_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP)
);
CREATE TABLE IF NOT EXISTS service_actions (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	"action" TEXT NOT NULL,
	service TEXT NOT NULL,
	cmd TEXT NOT NULL, cmd_type TEXT DEFAULT ('cmd') NOT NULL, sudo INTEGER DEFAULT (0), args TEXT,
	FOREIGN KEY (service) REFERENCES services(name) ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE TABLE IF NOT EXISTS services (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	name TEXT NOT NULL,
	descr TEXT,
	subdomain TEXT,
	icon TEXT,
	"type" TEXT DEFAULT ('docker') NOT NULL,
	visible BOOLEAN DEFAULT (true) NOT NULL,
	docker_img TEXT,
	version TEXT,
	required BOOLEAN DEFAULT (false) NOT NULL, enabled INTEGER,
	CONSTRAINT services_envs_FK FOREIGN KEY (version) REFERENCES envs(name)
);
CREATE UNIQUE INDEX IF NOT EXISTS services_name_IDX ON services (name);
CREATE TABLE IF NOT EXISTS deps (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	name TEXT NOT NULL,
	install_cmd TEXT NOT NULL,
	check_cmd TEXT NOT NULL,
	remove_cmd TEXT,
	descr TEXT
, status_cmd TEXT, type);
CREATE TABLE IF NOT EXISTS "service_envs" (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_name TEXT NOT NULL,
  env_name TEXT NOT NULL,
  FOREIGN KEY(service_name) REFERENCES services(name) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY(env_name) REFERENCES envs(name) ON DELETE CASCADE ON UPDATE CASCADE,
  UNIQUE(service_name, env_name)
);
CREATE VIEW IF NOT EXISTS service_envs_view AS
SELECT s.name AS service_name, e.visible, e.name AS var_name
FROM services s
LEFT JOIN service_envs se ON s.name = se.service_name
INNER JOIN envs e ON se.env_name = e.name
/* service_envs_view(service_name,visible,var_name) */;
CREATE TABLE IF NOT EXISTS "service_deps" (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_name TEXT NOT NULL,
  dep_name TEXT NOT NULL,
  FOREIGN KEY(service_name) REFERENCES services(name) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY(dep_name) REFERENCES deps(name) ON DELETE CASCADE ON UPDATE CASCADE,
  UNIQUE(service_name, dep_name)
);
CREATE VIEW IF NOT EXISTS service_deps_view AS
SELECT s.name AS service_name, d.name AS dep_name
FROM services s
LEFT JOIN service_deps sd ON s.name = sd.service_name
INNER JOIN deps d ON sd.dep_name = d.name
/* service_deps_view(service_name,dep_name) */;
CREATE UNIQUE INDEX IF NOT EXISTS deps_name_IDX ON deps (name);
