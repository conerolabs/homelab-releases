#!/bin/bash
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

DEFAULT_TABLES="deps,services,service_actions,service_deps,service_envs"
IFS=',' read -ra TABLES <<< "$DEFAULT_TABLES"

#todo: parse arguments: -d <database> -t <tables> -o <file_name>
#example: ./dump-data.sh -d homelab.db -t users,media -o "file"
for ARG in "$@"; do
    case $ARG in
        -d)
            FROM=$2
            shift
            shift
            ;;
        -t)
            #split the string $2 into an array, echo a warning message if the string is empty
            IFS=',' read -ra TABLES <<< "$2"
            shift
            shift
            ;;
        -o)
            FILE_PATH=$2
            shift
            shift
            ;;
    esac
done

echo "Generating SQL script to dump data from ${TABLES:-"all tables"} in $FROM"
# foreach element in $TABLES call the command below but with the right index for that table in the TABLES array
for TABLE in "${TABLES[@]}"; do
    if [ -n "$FILE_PATH" ]; then
        OUTPUT_FILE=$FILE_PATH
        sqlite3 "$PWD/$FROM" ".dump ${TABLE} --data-only" >> "$PWD/$OUTPUT_FILE"
        echo "SQL generated for table $TABLE in: $PWD/$OUTPUT_FILE"
    fi
    
    OUTPUT_TABLE_FILE="$SCRIPT_DIR/sql/$TABLE-data.sql"
    sqlite3 "$PWD/$FROM" ".dump ${TABLE} --data-only" > "$OUTPUT_TABLE_FILE"
    echo "SQL script generated for table $TABLE: $OUTPUT_TABLE_FILE"
done