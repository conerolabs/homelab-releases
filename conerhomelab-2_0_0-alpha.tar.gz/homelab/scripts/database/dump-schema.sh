#!/bin/bash
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

FROM=$1
TABLE=$2

OUTPUT_FILE="$SCRIPT_DIR/sql/${TABLE:-"schema"}.sql"

echo "Generating SQL script to dump schema from ${TABLE:-"all tables"} in $FROM"
sqlite3 "${SCRIPT_DIR}/$FROM" ".schema ${TABLE:-}" \
| sed 's/^CREATE TABLE IF NOT EXISTS /CREATE TABLE /' \
| sed 's/^CREATE TABLE /CREATE TABLE IF NOT EXISTS /' \
| sed 's/^CREATE VIEW IF NOT EXISTS /CREATE VIEW /' \
| sed 's/^CREATE VIEW /CREATE VIEW IF NOT EXISTS /' \
| sed 's/^CREATE UNIQUE INDEX IF NOT EXISTS /CREATE UNIQUE INDEX /' \
| sed 's/^CREATE UNIQUE INDEX /CREATE UNIQUE INDEX IF NOT EXISTS /' > "$OUTPUT_FILE"

echo "SQL script generated: $OUTPUT_FILE"