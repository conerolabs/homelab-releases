#!/bin/bash
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
FROM=$1
TO=$2

if [ -z "$FROM" ] || [ -z "$TO" ]; then
    echo "Usage: $0 <from> <to>"
    exit 1
fi

echo "Migrating schema from $FROM to $TO"

# Check if the target schema exists
if [ ! -f "$TO" ]; then
    echo "Target schema $TO not found"
    exit 1
fi

# Check if the source schema exists
if [ ! -f "$FROM" ]; then
    echo "Source schema $FROM not found"
    exit 1
fi

# Create backup of current database
cp "$FROM" "$FROM.bak"
echo "Backup created at $FROM.bak"

## TODO: Add logic to handle data migration from old schema to new schema
## Check if sqldiff exists
if ! command -v sqldiff &> /dev/null; then
    echo "sqldiff not found. Please install it (sudo apt install sqlite3-tools)"
    exit 1
fi

## TODO: Add logic to handle data migration from old schema to new schema
# Use sqldiff to generate the SQL commands to migrate from the old schema to the new schema
# Pipe the output to sqlite3 to apply the changes to the database
echo "Generating SQL commands to migrate the schema from $FROM to $TO:"
echo
SQL_DIFF=$(sqldiff --schema "$FROM" "$TO")
echo "$SQL_DIFF"
echo
read -r -p "Press Enter to apply the SQL commands to migrate the schema, or Ctrl+C to abort:"
echo
echo "$SQL_DIFF" | sqlite3 "$FROM"
echo "Migration completed successfully"

echo "Updating dump schema script..."
bash "${SCRIPT_DIR}/dump-schema.sh" "$FROM"