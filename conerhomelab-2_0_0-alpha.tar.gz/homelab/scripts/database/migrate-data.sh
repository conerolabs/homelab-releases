#!/bin/bash
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

FROM=$1
TO=$2
TABLE=$3

echo "Copying data from ${TABLE:-"all tables"} in $TO to $FROM"

if [ -z "$TABLE" ]; then
    SQL_DIFF=$(sqldiff "$FROM" "$TO");
else
    SQL_DIFF=$(sqldiff --table "$TABLE" "$FROM" "$TO");
fi
echo "$SQL_DIFF"
echo
read -r -p "Press Enter to apply the SQL commands to migrate the data, or Ctrl+C to abort:"
echo "$SQL_DIFF" | sqlite3 "$FROM"
echo "Migration completed successfully"

echo "Updating dump scripts..."
if [ -z "$TABLE" ]; then
    bash "${SCRIPT_DIR}/dump-data.sh" -d "$FROM"
else
    bash "${SCRIPT_DIR}/dump-data.sh" -d "$FROM" -t "$TABLE"
fi