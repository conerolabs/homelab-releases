#!/usr/bin/env bash
# ==============================================================================
# configure-backrest.sh
# Automates the configuration of Restic repositories and Backrest plans/hooks
# without requiring manual configuration in the Web UI.
# ==============================================================================
set -eo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
source "$SCRIPT_DIR/directories.sh"
source "$HOMELAB_DIR/.env"

print_info "Starting automated Backrest & Restic setup..."

# 1. Validation of required environment variables
if [ -z "${RESTIC_PASSWORD:-}" ]; then
    print_error "RESTIC_PASSWORD is not set in $HOMELAB_DIR/.env!"
    echo "Please set a strong encryption password in .env before running this script."
    exit 1
fi

BACKUP_DEST_DIR="${BACKUP_DEST:-/mnt/backup_usb/homelab_backups/nodo1}"
print_info "Local backup target: ${CYAN}$BACKUP_DEST_DIR${NC}"

# Check for Cloudflare R2
HAS_R2=false
if [ -n "${CLOUDFLARE_R2_ACCOUNT_ID:-}" ] && [ -n "${CLOUDFLARE_R2_BUCKET:-}" ]; then
    HAS_R2=true
    print_info "Cloudflare R2 detected: ${CYAN}s3:https://${CLOUDFLARE_R2_ACCOUNT_ID}.r2.cloudflarestorage.com/${CLOUDFLARE_R2_BUCKET}${NC}"
else
    print_warning "Cloudflare R2 credentials incomplete in .env. Skipping remote R2 repository configuration."
fi

# 2. Prepare directories
CONFIG_DIR="$HOMELAB_DIR/backrest/config"
DATA_DIR="$HOMELAB_DIR/backrest/data"
STAGING_DIR="$HOMELAB_DIR/backups/staging"

mkdir -p "$CONFIG_DIR" "$DATA_DIR" "$STAGING_DIR"
if [ -d "$(dirname "$BACKUP_DEST_DIR")" ]; then
    mkdir -p "$BACKUP_DEST_DIR" 2>/dev/null || true
fi

# 3. Copy configuration from homelab_config
TEMPLATE_CONFIG="$HOMELAB_DIR/homelab_config/backrest/config.json"
CONFIG_FILE="$CONFIG_DIR/config.json"

if [ ! -f "$TEMPLATE_CONFIG" ]; then
    print_error "Template configuration not found at $TEMPLATE_CONFIG!"
    exit 1
fi

print_info "Copying Backrest configuration from homelab_config to $CONFIG_DIR..."
cp "$TEMPLATE_CONFIG" "$CONFIG_FILE"
print_success "Backrest configuration file copied successfully."

# 4. Initialize Restic Repositories via Docker (if accessible)
print_info "Verifying and initializing Restic repositories..."

# 4a. Local Repository
if [ -d "$BACKUP_DEST_DIR" ]; then
    if [ ! -f "$BACKUP_DEST_DIR/config" ]; then
        print_info "Initializing local Restic repository at $BACKUP_DEST_DIR..."
        docker run --rm \
            -e RESTIC_PASSWORD="$RESTIC_PASSWORD" \
            -v "$BACKUP_DEST_DIR:/repo" \
            restic/restic:latest init --repo /repo || print_warning "Local init failed (permission or disk error). Backrest autoInitialize will retry."
    else
        print_success "Local Restic repository already initialized."
    fi
else
    print_warning "Local backup directory $BACKUP_DEST_DIR does not exist yet or is not mounted. Backrest will auto-initialize it once mounted."
fi

# 4b. Cloudflare R2 Repository
if [ "$HAS_R2" = true ]; then
    R2_URI="s3:https://${CLOUDFLARE_R2_ACCOUNT_ID}.r2.cloudflarestorage.com/${CLOUDFLARE_R2_BUCKET}"
    print_info "Checking Cloudflare R2 repository..."
    docker run --rm \
        -e RESTIC_PASSWORD="$RESTIC_PASSWORD" \
        -e AWS_ACCESS_KEY_ID="$CLOUDFLARE_R2_ACCESS_KEY_ID" \
        -e AWS_SECRET_ACCESS_KEY="$CLOUDFLARE_R2_SECRET_ACCESS_KEY" \
        -e AWS_DEFAULT_REGION="auto" \
        restic/restic:latest snapshots --repo "$R2_URI" >/dev/null 2>&1 && {
            print_success "Cloudflare R2 repository already initialized."
        } || {
            print_info "Initializing Cloudflare R2 repository..."
            docker run --rm \
                -e RESTIC_PASSWORD="$RESTIC_PASSWORD" \
                -e AWS_ACCESS_KEY_ID="$CLOUDFLARE_R2_ACCESS_KEY_ID" \
                -e AWS_SECRET_ACCESS_KEY="$CLOUDFLARE_R2_SECRET_ACCESS_KEY" \
                -e AWS_DEFAULT_REGION="auto" \
                restic/restic:latest init --repo "$R2_URI" || print_warning "R2 init failed. Backrest autoInitialize will retry."
        }
fi

