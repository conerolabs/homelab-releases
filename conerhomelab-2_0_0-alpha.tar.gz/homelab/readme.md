# Conero Homelab

## Installation

Run 'install.sh' script. It will download the tar.gz archive and extract it.

<!-- TODO fix wrong link: point to release repo -->
```bash
curl -L https://github.com/conerolabs/homelab/blob/6acbdbfd2e9be521b1ad3e725a621471f2b76f1e/Nodo1/install.sh | bash
```

## Start services

```bash
docker compose up -d
```

## Stop services

```bash
docker compose down
```

## Services

- Auth Server (Authelia)
- Password Manager (Vaultwarden)

### DNS recursive resolver (unbound)

Nessun Profiling Esterno: Utilizzando un resolver pubblico, un singolo provider (es. Google, Cloudflare, ISP) vede il 100% delle tue richieste DNS, permettendogli di costruire un profilo dettagliato della tua navigazione. Con un resolver locale, le query vengono distribuite direttamente tra i server Root, TLD e Autoritativi; nessun singolo soggetto esterno ha visibilità completa sulla tua attività

### DNS filtering and caching (Pi-hole)

A differenza delle estensioni del browser (come uBlock Origin), Pi-hole agisce come un "buco nero" DNS a livello di rete.

Copertura Totale: Blocca pubblicità, tracker e domini di telemetria su qualsiasi dispositivo connesso al Wi-Fi, inclusi Smart TV, console di gioco, dispositivi IoT e app mobili che non supportano estensioni di blocco.

Risparmio di Banda: Impedendo il caricamento di contenuti pubblicitari pesanti, si riduce il consumo di dati e si velocizza la navigazione, specialmente su connessioni lente.

Limitazione: Non può bloccare annunci video integrati nello stesso flusso del contenuto (es. annunci pre-roll di YouTube o Twitch), poiché questi provengono dagli stessi domini del video legittimo.

- Reverse Proxy (Caddy)
- Dashboard (Homepage)
- Services Monitoring (Gatus)
- Network Speed Test (MySpeed)
- Containers Management (Portainer)
- Calendars and Contacts (RustiCal)
