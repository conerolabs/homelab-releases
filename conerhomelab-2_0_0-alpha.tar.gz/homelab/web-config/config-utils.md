## getSystemCategories()

La logica di [`getSystemCategories()`](file:///media/andrea/Data/homelab/Nodo1/web-config/config-utils.ts#L182-L246) è questa:

### Fase 1 — Prepara il filtro per i servizi
Normalizza i nomi dei servizi Docker (lowercase, senza trattini/underscore) e li mette in un `Set`:
```js
const serviceSet = new Set(['caddy','authelia','redis','pihole', ...])
// normalizzati: 'caddy', 'authelia', 'redis', ...
```

### Fase 2 — Scansiona `.env` riga per riga

Per ogni riga del `.env` fa due cose:

**Se la riga è un commento** (`#...`), prova a usarlo come **nome di categoria**. Il commento viene accettato come titolo solo se passa tutti questi filtri:
| Condizione | Esempio scartato |
|---|---|
| non vuoto | `#` |
| lunghezza < 30 caratteri | `# Run all the setup_*.sh scripts...` |
| non contiene `=` | `#TAILSCALE_IP='...'` |
| non è una variabile commentata (`# VAR=...`) | `#UPSTREAM_DNS_SERVERS=...` |
| non contiene `/`, `.`, `:`, `(`, `)` | `# 45.90.28.0#ConeroLabs...` |
| inizia con lettera maiuscola | `# not used at the moment` |
| non contiene parole chiave escluse | `# Run all...`, `# Environment variables...` |

Se passa tutti i controlli → diventa il `currentCategory` (es. `"Headscale"`, `"Folders"`, `"Images Versions"`).

**Se la riga è una variabile** (`KEY=value`), la aggiunge alla categoria corrente **solo se** la categoria non corrisponde a un nome di servizio Docker (così le variabili di Caddy, Authelia, ecc. non finiscono nei pannelli di sistema).

### Risultato
```
"General"       → [HOMELAB_VERSION, SERVER_NAME, ...]
"Folders"       → [INSTALL_DIR, BACKUP_DEST]
"Headscale"     → [HEADSCALE_VERSION, HEADSCALE_SERVER_URL, ...]
"Images Versions" → [AUTHELIA_VERSION, CADDY_VERSION, ...]
```