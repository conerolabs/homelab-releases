import type { DnsProvider } from "./dto.ts";

export const dnsProviders: DnsProvider[] = [
    {
        name: "alidns",
        description: "Alibaba Cloud DNS",
        module: "github.com/caddy-dns/alidns",
        params: ["access_key_id", "access_key_secret"]
    },
    {
        name: "azure",
        description: "Azure DNS",
        module: "github.com/caddy-dns/azure",
        params: ["tenant_id", "client_id", "client_secret"]
    },
    {
        name: "cloudflare",
        description: "Cloudflare",
        module: "github.com/caddy-dns/cloudflare",
        params: ["api_token"]
    },
    {
        name: "digitalocean",
        description: "DigitalOcean",
        module: "github.com/caddy-dns/digitalocean",
        params: ["api_token"]
    },
    {
        name: "desec",
        description: "deSEC",
        module: "github.com/caddy-dns/desec",
        params: ["api_token"]
    },
    {
        name: "dnspod",
        description: "DNSPod",
        module: "github.com/caddy-dns/dnspod",
        params: ["access_key_id", "access_key_secret"]
    },
    {
        name: "duckdns",
        description: "DuckDNS",
        module: "github.com/caddy-dns/duckdns",
        params: ["api_token"]
    },
    {
        name: "gandi",
        description: "Gandi",
        module: "github.com/caddy-dns/gandi",
        params: ["api_token"]
    },
    {
        name: "godaddy",
        description: "GoDaddy",
        module: "github.com/caddy-dns/godaddy",
        params: ["api_key", "api_secret"]
    },
    {
        name: "googleclouddns",
        description: "Google Cloud DNS",
        module: "github.com/caddy-dns/googleclouddns",
        params: ["credentials"]
    },
    {
        name: "hetzner",
        description: "Hetzner",
        module: "github.com/caddy-dns/hetzner",
        params: ["api_token"]
    },
    {
        name: "metaname",
        description: "MetaName",
        module: "github.com/caddy-dns/metaname",
        params: ["api_key", "api_secret"]
    },
    {
        name: "netcup",
        description: "Netcup",
        module: "github.com/caddy-dns/netcup",
        params: ["customer_number", "password"]
    },
    {
        name: "netlify",
        description: "Netlify",
        module: "github.com/caddy-dns/netlify",
        params: ["api_token"]
    },
    {
        name: "openstack-designate",
        description: "OpenStack Designate",
        module: "github.com/caddy-dns/openstack-designate",
        params: ["auth_url", "username", "password", "project_name"]
    },
    {
        name: "route53",
        description: "AWS Route 53",
        module: "github.com/caddy-dns/route53",
        params: ["access_key_id", "secret_access_key"]
    },
    {
        name: "vultr",
        description: "Vultr",
        module: "github.com/caddy-dns/vultr",
        params: ["api_token"]
    },
    {
        name: "acmedns",
        description: "ACME DNS",
        module: "github.com/caddy-dns/acmedns",
        params: ["username", "password", "subdomain", "server_url"]
    }
];