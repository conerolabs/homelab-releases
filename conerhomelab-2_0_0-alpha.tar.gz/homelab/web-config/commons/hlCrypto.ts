#!/usr/bin/env node
import { hash, type HashOptions } from 'argon2';
import { execFileSync } from "node:child_process";
import { generateKeyPairSync } from 'node:crypto';
import { randomBytes } from "node:crypto";
import process from "node:process";

export type ProfileName = "bitwarden" | "owasp" | "authelia";

export const PROFILES: Record<ProfileName, HashOptions & { label: string }> = {
  bitwarden: {
    type: 2,
    label: "Using Bitwarden default settings:",
    memoryCost: 65540,
    timeCost: 3,
    parallelism: 4,
    salt: randomBytes(32),
  },
  owasp: {
    type: 2,
    label: "Using OWASP minimum recommended settings:",
    memoryCost: 19456,
    timeCost: 2,
    parallelism: 1,
    salt: randomBytes(32),
  },
  authelia: {
    type: 2,
    label: "Using Authelia recommended settings:",
    memoryCost: 32768,
    timeCost: 3,
    parallelism: 2,
    salt: randomBytes(16),
  },
};

export function decryptSystemdCredential(encryptedFilePath: string, credentialName: string) {
  try {
    // Esegue: systemd-creds decrypt --name <nome> <percorso_file> -
    // Il trattino finale '-' indica di scrivere l'output su stdout
    const output = execFileSync('systemd-creds', [
      'decrypt',
      '--name', credentialName, // Importante: deve corrispondere al nome usato in encrypt
      encryptedFilePath,
      '-'
    ], {
      encoding: 'utf8',
      env: { ...process.env } // Eredita l'ambiente se necessario (es. per TPM)
    });

    return output.trim(); // Rimuovi eventuali newline finali
  } catch (error: any) {
    console.error(`Errore nella decrittografia di ${credentialName}:`, error.message);
    if (error.stderr) console.error('Dettagli:', error.stderr.toString());
    throw error;
  }
}

export function generateRsaKeyPair(keySize: number = 2048) {
  const { privateKey, publicKey } = generateKeyPairSync('rsa', {
    modulusLength: keySize,
    publicKeyEncoding: {
      type: 'spki',
      format: 'pem'
    },
    privateKeyEncoding: {
      type: 'pkcs8',
      format: 'pem',
    }
  });
  return { publicKey, privateKey };
}


/**
 * Generates an Argon2id PHC formatted password hash using native Node.js crypto.argon2Sync.
 */
export async function generateArgon2idHash(password: string, config: HashOptions): Promise<string> {
  console.log(`CRYPTO - generating hash with options: ${JSON.stringify(config, null, 2)}`)
  const hashedPassword = await hash(password, config);
  console.log(`CRYPTO - generated hash: ${hashedPassword}`)
  return hashedPassword;
}

export function main(): void {
  const args = process.argv.slice(2);
  const password = args[0];
  const profileArg = args[1]?.toLowerCase() as ProfileName;

  if (!password) {
    console.log("Password parameter missing.");
    console.log("Usage: hashpsw <password> <profile>");
    console.log("Available profiles: bitwarden, owasp, authelia");
    process.exit(1);
  }

  if (!profileArg) {
    console.log("Profile parameter missing.");
    console.log("Usage: hashpsw <password> <profile>");
    console.log("Available profiles: bitwarden, owasp, authelia");
    process.exit(1);
  }

  const profile = PROFILES[profileArg];
  if (!profile) {
    console.log("Unknown profile value. Please use 'bitwarden', 'owasp', or 'authelia'.");
    process.exit(1);
  }

  console.log(profile.label);
  const hash = generateArgon2idHash(password, profile);
  console.log(hash);
}

// main();
