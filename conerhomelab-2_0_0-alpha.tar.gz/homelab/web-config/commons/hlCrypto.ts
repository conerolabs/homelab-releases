#!/usr/bin/env node
import { hash, type HashOptions } from 'argon2';
import { generateKeyPairSync } from 'node:crypto';
import { randomBytes } from "node:crypto";
import process from "node:process";
import { ShellService } from '../backend/services/shell.service.ts';
import { SystemService } from '../backend/services/system.service.ts';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import path from 'node:path';

export type ProfileName = "bitwarden" | "owasp" | "authelia";

export const HASH_PROFILES: Record<ProfileName, HashOptions & { label: string }> = {
  bitwarden: {
    type: 2,
    label: "Using Bitwarden default settings:",
    memoryCost: 65540,
    timeCost: 3,
    parallelism: 4,
    salt: randomBytes(32),
  },
  owasp: {
    type: 2,
    label: "Using OWASP minimum recommended settings:",
    memoryCost: 19456,
    timeCost: 2,
    parallelism: 1,
    salt: randomBytes(32),
  },
  authelia: {
    type: 2,
    label: "Using Authelia recommended settings:",
    memoryCost: 32768,
    timeCost: 3,
    parallelism: 2,
    salt: randomBytes(16),
  },
};

export async function encryptSystemdCredential(value: string, credentialName: string, encryptedFilePath: string) {
  const tmpDir = path.join(homedir(), 'hl_tmp');
  const tmpFilePath = path.join(tmpDir, `${credentialName}.txt`);
  try {
    // Esegue: systemd-creds encrypt --name <nome> <input> <percorso_file>
    mkdirSync(tmpDir, { recursive: true });
    writeFileSync(tmpFilePath, value);
    const command = `systemd-creds encrypt --name ${credentialName} ${tmpFilePath} ${encryptedFilePath}`
    const { stderr, exitCode } = await ShellService.execCommand(command, SystemService.getSudoPassword()).result;
    if (exitCode !== 0) {
      throw new Error(`Error encrypting credential ${credentialName} in ${encryptedFilePath}: ${stderr}`);
    }
  } catch (error: any) {
    console.error(`CRYPTO - Error encrypting credential ${credentialName} in ${encryptedFilePath}:`, error.message);
    if (error.stderr) console.error('Details:', error.stderr.toString());
    throw error;
  } finally {
    console.log(`CRYPTO - removing temp dir: ${tmpDir}`);
    rmSync(tmpDir, { force: true, recursive: true });
  }
}

export async function decryptSystemdCredential(encryptedFilePath: string, credentialName: string) {
  try {
    // Esegue: systemd-creds decrypt --name <nome> <percorso_file> -
    // Il trattino finale '-' indica di scrivere l'output su stdout
    const command = `systemd-creds decrypt --name ${credentialName} ${encryptedFilePath} -`
    const { stdout, stderr, exitCode } = await ShellService.execCommand(command, SystemService.getSudoPassword()).result;
    if (exitCode !== 0) {
      throw new Error(`Error decrypting credential ${credentialName} in ${encryptedFilePath}: ${stderr}`);
    }
    return stdout.trim(); // Rimuovi eventuali newline finali
  } catch (error: any) {
    console.error(`Error decrypting credential ${credentialName} in ${encryptedFilePath}:`, error.message);
    if (error.stderr) console.error('Details:', error.stderr.toString());
    throw error;
  }
}

export function generateRsaKeyPair(keySize: number = 2048) {
  const { privateKey, publicKey } = generateKeyPairSync('rsa', {
    modulusLength: keySize,
    publicKeyEncoding: {
      type: 'spki',
      format: 'pem'
    },
    privateKeyEncoding: {
      type: 'pkcs8',
      format: 'pem',
    }
  });
  return { publicKey, privateKey };
}

/** 
 * Generates a random base64 string of the specified size.
 * Its behaviour is like openssl rand -base64 <size> but it returns only <size> characters.
 * @param size - The size of the random string to generate.
 * @returns A random base64 string of the specified size.
 */
export function generateKey(size: number = 32): string {
  return randomBytes(size).toString('base64').slice(0, size);
}

/**
 * Generates an Argon2id PHC formatted password hash using native Node.js crypto.argon2Sync.
 */
export async function generateArgon2idHash(password: string, config: HashOptions): Promise<string> {
  console.log(`CRYPTO - generating hash with options: ${JSON.stringify(config, null, 2)}`)
  const hashedPassword = await hash(password, config);
  console.log(`CRYPTO - generated hash: ${hashedPassword}`)
  return hashedPassword;
}

export function main(): void {
  const args = process.argv.slice(2);
  const password = args[0];
  const profileArg = args[1]?.toLowerCase() as ProfileName;

  if (!password) {
    console.log("Password parameter missing.");
    console.log("Usage: hashpsw <password> <profile>");
    console.log("Available profiles: bitwarden, owasp, authelia");
    process.exit(1);
  }

  if (!profileArg) {
    console.log("Profile parameter missing.");
    console.log("Usage: hashpsw <password> <profile>");
    console.log("Available profiles: bitwarden, owasp, authelia");
    process.exit(1);
  }

  const profile = HASH_PROFILES[profileArg];
  if (!profile) {
    console.log("Unknown profile value. Please use 'bitwarden', 'owasp', or 'authelia'.");
    process.exit(1);
  }

  console.log(profile.label);
  const hash = generateArgon2idHash(password, profile);
  console.log(hash);
}

// main();
