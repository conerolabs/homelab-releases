import { type PathLike, readFileSync, writeFileSync } from "node:fs";
import yaml from "js-yaml";

export function loadYaml<T>(path: PathLike): T {
    try {
        const content = readFileSync(path, 'utf-8');
        return yaml.load(content) as T;
    } catch (err) {
        console.error(`Error loading YAML file from ${path}:`, err);
        throw err;
    }
}

export function parseYaml<T>(content: string): T {
    try {
        return yaml.load(content) as T;
    } catch (err) {
        console.error(`Error parsing YAML content:`, err);
        throw err;
    }
}

export function saveYaml<T>(path: PathLike, data: T) {
    try {
        const yamlString = yaml.dump(data);
        writeFileSync(path, yamlString, 'utf-8');
    } catch (err) {
        console.error(`Error saving YAML file to ${path}:`, err);
        throw err;
    }
}