export type ServiceModel = {
    id?: number;
    name: string;
    descr?: string;
    subdomain?: string;
    icon?: string;
    type?: 'host' | 'docker';
    docker_img?: string;
    version?: string;
    envs: string[];
    enabled?: boolean | null;
    visible?: boolean;
    required?: boolean;
    actions?: ServiceActionModel[];
}

export type EnvModel = {
    id?: number;
    name: string;
    value?: string;
    descr?: string;
    readonly?: boolean;
    visible?: boolean;
}

export type Config = {
    services: ServiceModel[];
    envs: EnvModel[];
}

export type ServiceActionModel = {
    id?: number;
    action: 'start' | 'stop' | 'setup' | 'deploy';
    service: string;
    cmd: string;
    cmd_type: 'script' | 'cmd'
    sudo?: boolean;
}

export type DependencyModel = {
    id?: number;
    name: string;
    check_cmd: string;
    status_cmd: string | null;
    install_cmd: string | null;
    remove_cmd: string | null;
}

export type UserModel = {
    id?: number;
    username: string;
    email: string;
    password?: string;
    display_name: string;
    groups?: string;
    created_at?: string;
}