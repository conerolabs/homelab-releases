export function arrayToMap<T>(arr: T[], keyFn: (item: T) => string): Record<string, T> {
    return arr.reduce((acc, item) => {
        acc[keyFn(item)] = item;
        return acc;
    }, {} as Record<string, T>);
}

export type FieldsMap<From extends object, To extends object> = {
    [FromK in keyof From]?: keyof To | (() => any);
}

export type TransformationMap<From extends object, To extends object> =
    Map<keyof From, { field: keyof To, transformer?: (value: From[keyof From]) => To[keyof To] }>;

export function mapFields<From extends object, To extends object>(from: From, mapper: TransformationMap<From, To>): To {
    const to: To = {} as To;
    for (const [fromK, trans] of mapper.entries()) {
        if (fromK in from) {
            to[trans.field as keyof To] =
                (trans.transformer || ((value: any) => value))(from[fromK as keyof From]);
        }
    }
    return to;
}

// TODO: tests
export function validateIP(ip: string): boolean {
    const regex = /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    return regex.test(ip);
}

// TODO: tests
export function validateMail(email: string): boolean {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

// TODO: tests
export function validateDomain(domain: string): boolean {
    const regex = /^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
    return regex.test(domain);
}
