export function arrayToMap<T>(arr: T[], keyFn: (item: T) => string): Record<string, T> {
    return arr.reduce((acc, item) => {
        acc[keyFn(item)] = item;
        return acc;
    }, {} as Record<string, T>);
}

export type FieldsMap<From extends object, To extends object> = {
    [FromK in keyof From]?: keyof To | (() => any);
}

export type TransformationMap<From extends object, To extends object> =
    Map<keyof From, { field: keyof To, transformer?: (value: From[keyof From]) => To[keyof To] }>;

export function mapFields<From extends object, To extends object>(from: From, mapper: TransformationMap<From, To>): To {
    const to: To = {} as To;
    for (const [fromK, trans] of mapper.entries()) {
        if (fromK in from) {
            to[trans.field as keyof To] =
                (trans.transformer || ((value: any) => value))(from[fromK as keyof From]);
        }
    }
    return to;
}