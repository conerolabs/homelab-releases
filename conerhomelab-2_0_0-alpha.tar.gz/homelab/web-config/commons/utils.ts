import { networkInterfaces } from "node:os";

export function arrayToMap<T>(arr: T[], keyFn: (item: T) => string): Record<string, T> {
    return arr.reduce((acc, item) => {
        acc[keyFn(item)] = item;
        return acc;
    }, {} as Record<string, T>);
}

export type FieldsMap<From extends object, To extends object> = {
    [FromK in keyof From]?: keyof To | (() => any);
}

export type TransformationMap<From extends object, To extends object> =
    Map<keyof From, { field: keyof To, transformer?: (value: From[keyof From]) => To[keyof To] }>;

export function mapFields<From extends object, To extends object>(from: From, mapper: TransformationMap<From, To>): To {
    const to: To = {} as To;
    for (const [fromK, trans] of mapper.entries()) {
        if (fromK in from) {
            to[trans.field as keyof To] =
                (trans.transformer || ((value: any) => value))(from[fromK as keyof From]);
        }
    }
    return to;
}

// TODO: tests
export function validateIP(ip: string): boolean {
    const regex = /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    return regex.test(ip);
}

// TODO: tests
export function validateMail(email: string): boolean {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

// TODO: tests
export function validateDomain(domain: string): boolean {
    const regex = /^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
    return regex.test(domain);
}

// Interfaces to skip (Tailscale, Docker, libvirt, etc.)
const SKIP_IFACES = /^(tailscale|utun|docker|veth|virbr|br-|tap|tun|vmnet)/i;

// IP ranges to skip (Tailscale CGNAT, Docker default, etc.)
const SKIP_RANGES = [
    /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./,  // Tailscale: 100.64.0.0/10
    /^172\.(1[6-9]|2\d|3[01])\./,                  // Docker: 172.16.0.0/12
    /^192\.168\.122\./,                             // libvirt default
];

export function getLanIp() {
    const interfaces = networkInterfaces();

    for (const [name, addrs] of Object.entries(interfaces)) {
        if (SKIP_IFACES.test(name)) continue;

        for (const addr of addrs) {
            if (addr.family !== 'IPv4' || addr.internal) continue;
            if (SKIP_RANGES.some(re => re.test(addr.address))) continue;
            return addr.address;
        }
    }
    return '127.0.0.1';
}
