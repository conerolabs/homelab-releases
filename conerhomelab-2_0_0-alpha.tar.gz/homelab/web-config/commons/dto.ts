import type { EnvModel, ServiceModel } from "./models.ts";

export type JobResult = {
    name: string
    success: boolean;
    message?: string;
    successfullTasks?: string[] | JobResult[];
    failedTasks?: string[] | JobResult[];
}

export type DepsCheckResult = CheckResult & {
    missing?: string[];
    notRunning?: string[];
}

// success: true when installed and configured
export type ServicesCheckResult = CheckResult & {
    config?: JobResult[];
}

export type AdminCheckResult = CheckResult & {
    message?: string;
}

export type DependencyStatus = {
    name: string;
    installed: boolean;
    running?: boolean;
    error?: string;
};

export type Config = {
    services: ServiceModel[];
    envs: EnvModel[];
}

export type SudoStatus = {
    needPassword: boolean;
}

export type StatusResponse = {
    serverName: string;
    deps: DepsCheckResult;
    admin: AdminCheckResult;
    services: ServicesCheckResult;
    domain?: string | null;
    vpn?: VpnMode;
    dns?: string | null;
}

export type VpnMode = 'tailscale' | 'headscale' | null;

export type HomelabStatus = {
    serverName: string;
    deps: boolean; // deps installed
    admin: boolean; // admin user exists
    services: boolean; // services configured
    domain: string | null;
    vpn: VpnMode;
    dns: string | null; // upstream DNS server
}

export type NetworkInfo = {
    interface?: string;
    lanIp?: string;
    tailscaleIp?: string;
    publicIp?: string;
    domain?: string;
    dns?: string;
}

export interface CheckResult {
    success: boolean;
}