import type { EnvModel, ServiceModel } from "./models";

export type SetupCheckResult = {
    name: string;
    success: boolean;
    message?: string;
}

export type DepsCheckResult = CheckResult & {
    missing?: string[];
}

export type ServicesCheckResult = CheckResult & {
    notConfigured?: SetupCheckResult[];
}

export type AdminCheckResult = CheckResult & {
    message?: string;
}

export type DependencyStatus = {
    name: string;
    installed: boolean;
    error?: string;
};

export type Config = {
    services: ServiceModel[];
    envs: EnvModel[];
}

export type SudoStatus = {
    needPassword: boolean;
}

export type StatusResponse = {
    deps: DepsCheckResult;
    admin: AdminCheckResult;
    services: ServicesCheckResult;
}

export type HomelabStatus = {
    deps: boolean; // deps installed
    admin: boolean; // admin user exists
    services: boolean; // services configured
}

export type NetworkInfo = {
    interface?: string;
    lanIp?: string;
    tailscaleIp?: string;
    publicIp?: string;
    domain?: string;
}

export interface CheckResult {
    success: boolean;
}