import type { EnvModel, ServiceModel } from "./models.ts";

export type JobResult = {
    name: string;
    service: string;
    success: boolean;
    message?: string;
    successfullTasks?: string[] | JobResult[];
    failedTasks?: string[] | JobResult[];
}

export type DepsCheckResult = CheckResult & {
    missing?: string[];
    notConfigured?: string[];
    notRunning?: string[];
}

// success: true when installed and configured
export type ServicesCheckResult = CheckResult & {
    results?: JobResult[];
}

export type AdminCheckResult = CheckResult & {
    message?: string;
}

export type DependencyStatus = {
    name: string;
    installed: boolean;
    setup?: boolean;
    running?: boolean;
    error?: string;
};

export type Config = {
    services: ServiceModel[];
    envs: EnvModel[];
}

export type SudoStatus = {
    needPassword: boolean;
}

export type StatusResponse = {
    serverName: string;
    deps: DepsCheckResult;
    admin: AdminCheckResult;
    services: ServicesCheckResult;
    domain?: string | null;
    vpn?: VpnInfo;
    dns?: string | null;
}

export type VpnMode = 'tailscale' | 'headscale' | 'none' | null;

export type VpnInfo = {
    mode: VpnMode | null;
    status?: 'NoState' | 'InUseOtherUser' | 'NeedsLogin' | 'NeedsMachineAuth' | 'Stopped' | 'Starting' | 'Running';
    apiKey?: boolean; // true if api key is set, false otherwise
}

export type StartVpnOutput = {
    success: boolean;
    loginUrl?: string | null;
    tailscaleIp?: string;
    error?: string;
}

export type VpnConfigParams = {
    mode: VpnMode;
    apiKey?: string;
}

export type HomelabStatus = {
    serverName: string;
    deps: boolean; // deps installed
    admin: boolean; // admin user exists
    services: boolean; // services configured
    domain: string | null;
    vpn: VpnInfo;
    dns: string | null; // upstream DNS server
}

export type HomelabStatusDetails = HomelabStatus & {
    missingDeps: string[];
    notConfiguredDeps: string[];
    notRunningDeps: string[];
    notConfiguredServices: JobResult[];
}

export interface DnsProvider {
    name: string;
    description: string;
    module: string;
    params: string[];
}

export type NetworkInfo = {
    interface?: string;
    lanIp?: string;
    tailscaleIp?: string;
    vpnInfo?: VpnInfo;
    publicIp?: string;
    domain?: string;
    dns?: string;
    ddns?: boolean;
}

export interface CheckResult {
    success: boolean;
}