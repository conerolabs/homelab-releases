import type { EnvModel, ServiceModel } from "./models";

export type SetupCheckResult = {
    name: string;
    success: boolean;
    message?: string;
    failedChecks?: string[] | SetupCheckResult[];
}

export type SetupResult = {
    success: boolean;
    error?: string;
}

export type DepsCheckResult = CheckResult & {
    missing?: string[];
    notRunning?: string[];
}

// success: true when installed and configured
export type ServicesCheckResult = CheckResult & {
    config?: SetupCheckResult[];
}

export type AdminCheckResult = CheckResult & {
    message?: string;
}

export type DependencyStatus = {
    name: string;
    installed: boolean;
    running?: boolean;
    error?: string;
};

export type Config = {
    services: ServiceModel[];
    envs: EnvModel[];
}

export type SudoStatus = {
    needPassword: boolean;
}

export type StatusResponse = {
    deps: DepsCheckResult;
    admin: AdminCheckResult;
    services: ServicesCheckResult;
    domain?: string | null;
    vpn?: VpnMode;
    dns?: string | null;
}

export type VpnMode = 'tailscale' | 'headscale' | null;

export type HomelabStatus = {
    deps: boolean; // deps installed
    admin: boolean; // admin user exists
    services: boolean; // services configured
    domain: string | null;
    vpn: VpnMode;
    dns: string | null; // upstream DNS server
}

export type NetworkInfo = {
    interface?: string;
    lanIp?: string;
    tailscaleIp?: string;
    publicIp?: string;
    domain?: string;
    dns?: string;
}

export interface CheckResult {
    success: boolean;
}