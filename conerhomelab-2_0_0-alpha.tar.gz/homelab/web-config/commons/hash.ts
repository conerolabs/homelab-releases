import { hash, type HashOptions } from 'argon2';
import { parseAutheliaConfig } from '../backend/config-utils.ts';
import type { AutheliaHashOptions, AutheliaConfig } from '../backend/config-utils.ts';
import { mapFields, type TransformationMap } from './utils.ts';

async function generateHash(password: string, options: HashOptions) {
    console.log(`CRYPTO - generating hash with options: ${JSON.stringify(options, null, 2)}`)
    const hashedPassword = await hash(password, options);
    console.log(`CRYPTO - generated hash: ${hashedPassword}`)
    return hashedPassword;
}

const hashOptionsTransformer: TransformationMap<AutheliaHashOptions, HashOptions> = new Map([
    ['variant', {
        field: 'type',
        transformer: (value: string | number) => ['argon2d', 'argon2i', 'argon2id'].indexOf(String(value).toLowerCase()) as HashOptions['type']
    }],
    ['iterations', { field: 'timeCost' }],
    ['memory', { field: 'memoryCost' }],
    ['parallelism', { field: 'parallelism' }],
    ['key_length', { field: 'hashLength' }],
]);

function loadAutheliaHashOptions(config?: AutheliaConfig): HashOptions {
    const data = config ?? parseAutheliaConfig();
    const options: AutheliaHashOptions = data.authentication_backend.file.password.argon2;
    console.log("CONFIG - Authelia hash options: ", JSON.stringify(options, null, 2));
    const hashOptions: HashOptions = mapFields(options, hashOptionsTransformer);
    return hashOptions;
}

export async function generateAutheliaHash(password: string, config?: AutheliaConfig): Promise<string> {
    const hashOptions = loadAutheliaHashOptions(config);
    const hashedPassword = await generateHash(password, hashOptions);
    return hashedPassword;
}