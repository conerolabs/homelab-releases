import test from "node:test";
import assert from "node:assert";
import type { TestContext } from "node:test";
import { type HashOptions, argon2id } from "argon2";
import { generateArgon2idHash, PROFILES } from "./hlCrypto.ts";

const AUTHELIA_HASH_OPTIONS: HashOptions & { raw: false } = {
    type: argon2id as 0 | 1 | 2, // variant
    timeCost: 3, // iterations
    memoryCost: 32768, // memory 32 MB
    parallelism: 2, // parallelism
    hashLength: 32, // key_length
    raw: false,
}

const expectedPattern = new RegExp(
    `^\\\$argon2id\\\$v=19\\\$m=${AUTHELIA_HASH_OPTIONS.memoryCost},p=${AUTHELIA_HASH_OPTIONS.parallelism},t=${AUTHELIA_HASH_OPTIONS.timeCost}\\\$[A-Za-z0-9+/]+={0,2}\\\$[A-Za-z0-9+/]+={0,2}\$`
)

test('hash.authelia', async (t: TestContext) => {
    const password = 'password';
    const hashedPassword = await generateAutheliaHash(password);
    assert.ok(hashedPassword);
    assert.strictEqual(typeof hashedPassword, 'string');
    assert.match(hashedPassword, expectedPattern);
});

test('hash.secret', async (t: TestContext) => {

    const password = 'supersegretochenessunoscopriràmai'
    const hashedPassword = await generateArgon2idHash(password, PROFILES.authelia);
    assert.ok(hashedPassword);
    assert.strictEqual(typeof hashedPassword, 'string');
    assert.match(hashedPassword, expectedPattern);
})