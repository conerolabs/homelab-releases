import test from "node:test";
import assert from "node:assert";
import { generateAutheliaHash } from "./hash.ts";
import type { TestContext } from "node:test";
import { type HashOptions, argon2id } from "argon2";

test('hash.authelia', async (t: TestContext) => {
    const AUTHELIA_HASH_OPTIONS: HashOptions & { raw: false } = {
        type: argon2id as 0 | 1 | 2, // variant
        timeCost: 3, // iterations
        memoryCost: 32768, // memory 32 MB
        parallelism: 2, // parallelism
        hashLength: 32, // key_length
        raw: false,
    }
    const password = 'password';
    const expectedPattern = new RegExp(
        `^\\\$argon2id\\\$v=19\\\$m=${AUTHELIA_HASH_OPTIONS.memoryCost},p=${AUTHELIA_HASH_OPTIONS.parallelism},t=${AUTHELIA_HASH_OPTIONS.timeCost}\\\$[A-Za-z0-9+/]+={0,2}\\\$[A-Za-z0-9+/]+={0,2}\$`
    )
    const hashedPassword = await generateAutheliaHash(password);
    assert.ok(hashedPassword);
    assert.strictEqual(typeof hashedPassword, 'string');
    assert.match(hashedPassword, expectedPattern);
});