import type { Config } from "../commons/dto"
import type { EnvModel, ServiceModel } from "../commons/models"

type SetConfigAction = {
    type: 'SET_CONFIG',
    payload: Config
}
type SetServiceAction = {
    type: 'SET_SERVICE',
    payload: ServiceModel
}
type SetEnvAction = {
    type: 'SET_ENV',
    payload: EnvModel
}
type SetServicesAction = {
    type: 'SET_SERVICES',
    payload: ServiceModel[]
}
type SetEnvsAction = {
    type: 'SET_ENVS',
    payload: EnvModel[]
}
export type ConfigAction =
    | SetConfigAction
    | SetServiceAction
    | SetEnvAction
    | SetServicesAction
    | SetEnvsAction

export const configReducer = (state: Config, action: ConfigAction) => {
    switch (action.type) {
        case 'SET_CONFIG':
            return action.payload;
        case 'SET_SERVICES':
            return {
                ...state,
                services: action.payload
            };
        case 'SET_ENVS':
            return {
                ...state,
                envs: action.payload
            };
        case 'SET_SERVICE':
            return {
                ...state,
                services: state.services.map(s =>
                    s.name === action.payload.name ? { ...s, ...action.payload } : s
                )
            }
        case 'SET_ENV':
            return {
                ...state,
                envs: state.envs.map(e =>
                    e.name === action.payload.name ? { ...e, ...action.payload } : e
                )
            };
        default:
            return state;
    }
}