import type { AdminCheckResult, Config, DepsCheckResult, ServicesCheckResult, SetupCheckResult, StatusResponse, SudoStatus } from "../commons/dto";
import { ConsoleActions, type ConsoleAction, type ConsoleJob } from "./providers/ConsoleModalProvider";

export type ConsoleMessage = {
  type: 'log' | 'stdout' | 'stderr' | 'done' | 'error';
  code?: number;
  text: string
}

type ServiceStatus = {
  service: string;
  running: boolean;
  status: string;
  health: 'healthy' | 'unhealthy' | 'starting' | 'none' | 'unknown';
  healthDetail?: string | null;
  containerId?: string | null;
}

const defaultHeaders = {
  'Content-Type': 'application/json',
};

export const CONFIG_SERVER_URL = import.meta.env.VITE_CONFIG_SERVER_URL
console.log('CONFIG_SERVER_URL', CONFIG_SERVER_URL)

export class DepsApiClient {
  static async getAvailableDeps() {
    const response = await fetch(`${CONFIG_SERVER_URL}/api/deps`);
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const deps = await response.json();
    return deps;
  }

  static async installDeps() {

  }
}

export class ConfigApiClient {

  static async loadConfig() {
    console.log('Loading configuration from /api/config');
    const response = await fetch(`${CONFIG_SERVER_URL}/api/config`);
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const config = await response.json();
    return config;
  }

  static async saveConfig(payload: Config) {
    const response = await fetch(`${CONFIG_SERVER_URL}/api/config`, {
      method: 'POST',
      headers: defaultHeaders,
      body: JSON.stringify(payload),
    });
    if (!response.ok) throw new Error('HTTP Status ' + response.status);
    return response.json();
  }
}

export class ServiceApiClient {
  static async getServiceStatus(serviceName: string): Promise<ServiceStatus> {
    const response = await fetch(`${CONFIG_SERVER_URL}/api/service/${encodeURIComponent(serviceName)}/status`);
    if (!response.ok) throw new Error('Status request failed');
    return response.json();
  }

  static async streamServiceAction(serviceName: string, action: string, onDone: () => void) {
    return { url: `${CONFIG_SERVER_URL}/api/service/${encodeURIComponent(serviceName)}/${encodeURIComponent(action)}`, onDone };
  }

  static async streamDeploy(onDone: () => void) {
    return { url: `${CONFIG_SERVER_URL}/api/deploy`, onDone };
  }
}

export class SystemApiClient {
  static async needPasswordPrompt(action: ConsoleAction): Promise<boolean> {
    const response = await fetch(`${CONFIG_SERVER_URL}/api/system/sudo?action=${action}`);
    if (!response.ok) throw new Error('HTTP Status ' + response.status);
    const json = await response.json() as SudoStatus;
    return json.needPassword;
  }

  static async sendSudoPassword(password: string) {
    const response = await fetch(`${CONFIG_SERVER_URL}/api/system/sudo`, {
      method: 'POST',
      headers: defaultHeaders,
      body: JSON.stringify({ password }),
    });
    if (!response.ok) throw new Error('HTTP Status ' + response.status);
    return response.json();
  }
}

export class UserApiClient {
  static async registerUser(payload: {
    username: string;
    password: string;
    email: string;
    display_name?: string;
    isAdmin?: boolean;
  }) {
    const response = await fetch(`${CONFIG_SERVER_URL}/api/user/register`, {
      method: 'POST',
      headers: defaultHeaders,
      body: JSON.stringify(payload),
    });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    return response.json();
  }
}

export class StatusApiClient {
  static async getStatus(): Promise<StatusResponse> {
    const response = await fetch(`${CONFIG_SERVER_URL}/api/status`);
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const status = await response.json();
    return status;
  }

  static async getAdminStatus(): Promise<AdminCheckResult> {
    const response = await fetch(`${CONFIG_SERVER_URL}/api/status/admin`);
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const status = await response.json() as { admin: AdminCheckResult };
    return status.admin;
  }

  static async getDepsStatus(): Promise<DepsCheckResult> {
    const response = await fetch(`${CONFIG_SERVER_URL}/api/status/deps`);
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const status = await response.json() as { deps: DepsCheckResult };
    return status.deps;
  }

  static async getServicesStatus(): Promise<ServicesCheckResult> {
    const response = await fetch(`${CONFIG_SERVER_URL}/api/status/services`);
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const status = await response.json() as { services: ServicesCheckResult };
    return status.services;
  }

  static async getServiceStatus(service: string): Promise<SetupCheckResult> {
    const response = await fetch(`${CONFIG_SERVER_URL}/api/status/service/${encodeURIComponent(service)}`);
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const status = await response.json() as { service: SetupCheckResult };
    return status.service;
  }
}

export class ConsoleApiClient {
  public static executeAction(job: ConsoleJob, onConsoleMessage: (this: EventSource, ev: MessageEvent<any>) => any, onConnectionError: (this: EventSource, ev: Event) => any) {
    const eventSource = new EventSource(ConsoleActions[job.action].apiUrl(job))
    eventSource.onmessage = onConsoleMessage
    eventSource.onerror = onConnectionError
    return eventSource
  }
}
