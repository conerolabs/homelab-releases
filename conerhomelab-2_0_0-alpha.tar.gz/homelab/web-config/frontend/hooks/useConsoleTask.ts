import { useState } from "react";
import { useConsoleModal } from "../providers/ConsoleModalProvider";
import type { ConsoleJob } from "../providers/ConsoleModalProvider";
import { SystemApiClient } from "../api";
import { usePromptModal } from "../providers/PromptModalProvider";

export function useConsoleTask() {
    const [isRunning, setIsRunning] = useState<boolean>(false);
    const { openConsole } = useConsoleModal();
    const { promptSudoPassword } = usePromptModal();

    async function sudoChecks(job: ConsoleJob): Promise<void> {
        try {
            const needPassword = await SystemApiClient.needPasswordPrompt(job.action);

            let sudoPassword: string | null = null;
            if (needPassword) {
                sudoPassword = await promptSudoPassword();
                if (!sudoPassword) {
                    throw new Error("Sudo password is required");
                }
                await SystemApiClient.sendSudoPassword(sudoPassword);
            }
        } catch (error) {
            throw new Error("Failed to check sudo permission", { cause: error });
        }
    }

    async function runConsoleTask(job: ConsoleJob, onSuccess?: () => void | Promise<void>, onClose?: () => void | Promise<void>) {
        try {
            await sudoChecks(job);
            setIsRunning(true);
            openConsole(
                job,
                () => {
                    onSuccess();
                    setIsRunning(false)
                },
                () => {
                    onClose();
                    setIsRunning(false)
                }
            );
        } catch (error) {
            console.error("Error running task:", error);
        } finally {
            setIsRunning(false);
        }
    }

    return {
        runConsoleTask,
        isRunning,
        setIsRunning
    }
}