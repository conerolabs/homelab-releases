import { useState } from "react";

export function useTimer() {
    const [remainingTime, setRemainingTime] = useState(0);
    const [running, setRunning] = useState(false);
    const [intervalId, setIntervalId] = useState<number | null>(null);

    function startTimer(durationMs: number, onComplete?: () => void) {
        console.log('Starting timer for ' + durationMs + 'ms');
        clearTimer();
        setRunning(true);
        const startT = Date.now();
        const id = setInterval(() => {
            const newRemainingTime = durationMs - (Date.now() - startT);
            if (newRemainingTime <= 0) {
                clearTimer(id);
                onComplete?.();
            } else {
                setRemainingTime(newRemainingTime);
            }
        }, 1000);
        console.log('Timer started: ', id);
        setIntervalId(id);
    }

    function clearTimer(id?: number | null) {
        const toClear = id ?? intervalId;
        toClear && clearInterval(toClear);
        toClear && console.log('Timer cleared: ', toClear);
        setRunning(false);
        setRemainingTime(0);
    }

    return { remainingTime, running, startTimer, clearTimer };
}