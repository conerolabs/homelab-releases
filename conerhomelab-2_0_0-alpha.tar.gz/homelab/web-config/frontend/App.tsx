import Header from "./Header";
import { Toaster } from "react-hot-toast";
import Footer from "./Footer";
import { Outlet } from "react-router";

export default function App() {

  return (
    <div className="container">
      <Header />
      <Outlet />
      <Footer />
      <Toaster position="top-center"
        reverseOrder={false}
        toastOptions={{
          style: {
            borderRadius: '8px',
            background: 'var(--card-bg)',
            border: '1px solid var(--card-border)',
            color: 'var(--text-main)',
            backdropFilter: 'blur(12px)',
            boxShadow: '0 10px 25px var(--shadow-dark)',
            fontWeight: 500,
            fontSize: '0.9rem',
          },
          success: {
            style: {
              borderColor: 'var(--success-glow)',
            }
          },
          error: {
            style: {
              borderColor: 'var(--error-glow)',
            }
          }
        }} />
    </div>
  )
}