import { createBrowserRouter } from "react-router";
import { RouterProvider } from "react-router/dom";
import ConfigurationPage from "../pages/ConfigurationPage";
import DepsPage from "../pages/DepsPage";
import App from "../App";
import Home from "../pages/Home";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        index: true,
        element: <Home />
      },
      {
        path: "config",
        element: <ConfigurationPage />
      },
      {
        path: "deps",
        element: <DepsPage />
      }
    ]
  }
]);

export default function HomelabRouterProvider() {
  return (
    <RouterProvider router={router} />
  );

}
