import { createContext, useContext, useEffect, useReducer } from "react";
import { configReducer } from "../ConfigReducer";
import type { Config, EnvModel, ServiceModel } from "../../commons/models";
import { ConfigApiClient } from "../api";

type ConfigContextType = {
    config: Config;
    getSystemVars: () => Set<string>;
    getDockerServices: () => ServiceModel[];
    getSystemServices: () => ServiceModel[];

}

type ConfigActionsContextType = {
    setConfig: (config: Config) => void;
    setService: (service: ServiceModel) => void;
    setEnv: (env: EnvModel) => void;
    setServices: (services: ServiceModel[]) => void;
    setEnvs: (envs: EnvModel[]) => void;
    saveConfig: () => Promise<void>;
}

const ConfigContext = createContext<ConfigContextType>({
    config: { services: [], envs: [] },
    getSystemVars: () => new Set<string>(),
    getDockerServices: () => [],
    getSystemServices: () => []
});

const ConfigActionsContext = createContext<ConfigActionsContextType>({
    setConfig: () => { },
    setService: () => { },
    setEnv: () => { },
    setServices: () => { },
    setEnvs: () => { },
    saveConfig: async () => { }
});

function ConfigProvider({ children }: { children: React.ReactNode }) {
    const CONFIG_SERVER_URL = import.meta.env.VITE_CONFIG_SERVER_URL;
    const [config, dispatch] = useReducer(configReducer, { services: [], envs: [] });

    function getSystemVars(): Set<string> {
        return new Set(config.services.filter(s => s.type === 'host').flatMap(s => s.envs));
    }
    function getDockerServices(): ServiceModel[] {
        return config.services
            .filter(s => s.type === 'docker')
            .sort()
    }

    function getSystemServices(): ServiceModel[] {
        return config.services
            .filter(s => s.type === 'host')
            .sort()
    }

    const value = {
        config,
        getSystemVars,
        getDockerServices,
        getSystemServices
    }

    const configActions: ConfigActionsContextType = {
        setConfig: (config: Config) => {
            dispatch({ type: 'SET_CONFIG', payload: config });
        },
        setService: (service: ServiceModel) => {
            dispatch({ type: 'SET_SERVICE', payload: service });
        },
        setEnv: (env: EnvModel) => {
            dispatch({ type: 'SET_ENV', payload: env });
        },
        setServices: (services: ServiceModel[]) => {
            dispatch({ type: 'SET_SERVICES', payload: services });
        },
        setEnvs: (envs: EnvModel[]) => {
            dispatch({ type: 'SET_ENVS', payload: envs });
        },
        saveConfig: async () => { await ConfigApiClient.saveConfig(config) },
    }

    useEffect(() => {
        fetch(`${CONFIG_SERVER_URL}/api/config`) // TODO: use api.ts
            .then(response => response.json())
            .then((data: Config) => {
                dispatch({ type: 'SET_CONFIG', payload: data });
            })
            .catch(error => {
                console.error('Error fetching config:', error);
            });
    }, []);

    return (
        <ConfigContext.Provider value={value}>
            <ConfigActionsContext.Provider value={configActions}>
                {children}
            </ConfigActionsContext.Provider>
        </ConfigContext.Provider>
    )

}

function useConfig() {
    return useContext(ConfigContext);
}

function useConfigActions() {
    return useContext(ConfigActionsContext)
}

export { ConfigProvider, useConfig, useConfigActions };