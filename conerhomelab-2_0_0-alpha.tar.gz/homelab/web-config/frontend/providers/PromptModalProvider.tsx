import { createContext, useContext, useState, useRef, type ReactNode } from "react";
import PromptModal, { type PromptField } from "../modals/PromptModal";

export type PromptModalOptions = {
  title?: string;
  message?: string | ReactNode;
  icon?: 'key' | 'lock' | 'shield' | 'info' | 'warning' | ReactNode;
  fields?: PromptField[];
  inputType?: 'text' | 'password' | 'number' | 'email';
  inputLabel?: string;
  inputPlaceholder?: string;
  inputDefaultValue?: string;
  confirmText?: string;
  cancelText?: string;
  confirmVariant?: 'primary' | 'success' | 'danger';
};

type PromptModalContextType = {
  promptInput: (options: PromptModalOptions) => Promise<Record<string, string> | string | null>;
  promptSudoPassword: (message?: string) => Promise<string | null>;
  closePrompt: () => void;
};

const PromptModalContext = createContext<PromptModalContextType | undefined>(undefined);

export function PromptModalProvider({ children }: { children: ReactNode }) {
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    options: PromptModalOptions;
  }>({
    isOpen: false,
    options: {},
  });

  const resolverRef = useRef<((value: Record<string, string> | string | null) => void) | null>(null);

  const promptInput = (options: PromptModalOptions): Promise<Record<string, string> | string | null> => {
    return new Promise((resolve) => {
      // If there's an existing unresolved prompt, resolve it with null first
      if (resolverRef.current) {
        resolverRef.current(null);
      }
      resolverRef.current = resolve;
      setModalState({
        isOpen: true,
        options,
      });
    });
  };

  const promptSudoPassword = (message = "Administrative privileges are required to perform this action. Please enter your sudo password."): Promise<string | null> => {
    return promptInput({
      title: "Sudo Password Required",
      message,
      icon: "key",
      inputType: "password",
      inputLabel: "Sudo Password",
      inputPlaceholder: "Enter your sudo password...",
      confirmText: "Authenticate & Proceed",
      confirmVariant: "danger",
    }) as Promise<string | null>;
  };

  const handleClose = () => {
    if (resolverRef.current) {
      resolverRef.current(null);
      resolverRef.current = null;
    }
    setModalState(prev => ({ ...prev, isOpen: false }));
  };

  const handleSubmit = (values: Record<string, string>) => {
    if (resolverRef.current) {
      // If single default field ("value"), resolve directly with string value for convenience
      const keys = Object.keys(values);
      if (keys.length === 1 && keys[0] === "value") {
        resolverRef.current(values.value);
      } else {
        resolverRef.current(values);
      }
      resolverRef.current = null;
    }
    setModalState(prev => ({ ...prev, isOpen: false }));
  };

  return (
    <PromptModalContext.Provider value={{ promptInput, promptSudoPassword, closePrompt: handleClose }}>
      {children}
      <PromptModal
        isOpen={modalState.isOpen}
        {...modalState.options}
        onClose={handleClose}
        onSubmit={handleSubmit}
      />
    </PromptModalContext.Provider>
  );
}

export function usePromptModal() {
  const context = useContext(PromptModalContext);
  if (!context) {
    throw new Error("usePromptModal must be used within a PromptModalProvider");
  }
  return context;
}
