import { createContext, useContext, useState, useCallback, useRef, type ReactNode } from "react";
import LoadingModal, { type LoadingModalProps } from "../modals/LoadingModal";

export type LoadingModalOptions = Omit<LoadingModalProps, 'isOpen'>;

export type LoadingModalContextType = {
  isLoading: boolean;
  showLoading: (options?: LoadingModalOptions | string) => void;
  hideLoading: () => void;
  setMessage: (message: string) => void;
  setProgress: (progress: number | null) => void;
  withLoading: <T>(
    promiseOrFn: (() => Promise<T>) | Promise<T>,
    options?: LoadingModalOptions | string
  ) => Promise<T>;
};

const LoadingModalContext = createContext<LoadingModalContextType | undefined>(undefined);

const DEFAULT_OPTIONS: LoadingModalOptions = {
  title: "Loading Data...",
  message: "Please wait while data is being loaded.",
  icon: "spinner",
};

export function LoadingModalProvider({ children }: { children: ReactNode }) {
  const [activeCount, setActiveCount] = useState(0);
  const [options, setOptions] = useState<LoadingModalOptions>(DEFAULT_OPTIONS);
  const activeCountRef = useRef(0);

  const showLoading = useCallback((opts?: LoadingModalOptions | string) => {
    activeCountRef.current += 1;
    setActiveCount(activeCountRef.current);

    if (opts) {
      const parsedOptions: LoadingModalOptions = typeof opts === "string" ? { message: opts } : opts;
      setOptions(prev => ({
        ...DEFAULT_OPTIONS,
        ...prev,
        ...parsedOptions,
      }));
    }
  }, []);

  const hideLoading = useCallback(() => {
    activeCountRef.current = Math.max(0, activeCountRef.current - 1);
    setActiveCount(activeCountRef.current);
    if (activeCountRef.current === 0) {
      setOptions(DEFAULT_OPTIONS);
    }
  }, []);

  const setMessage = useCallback((message: string) => {
    setOptions(prev => ({ ...prev, message }));
  }, []);

  const setProgress = useCallback((progress: number | null) => {
    setOptions(prev => ({ ...prev, progress }));
  }, []);

  const withLoading = useCallback(async <T,>(
    promiseOrFn: (() => Promise<T>) | Promise<T>,
    opts?: LoadingModalOptions | string
  ): Promise<T> => {
    showLoading(opts);
    try {
      if (typeof promiseOrFn === "function") {
        return await promiseOrFn();
      }
      return await promiseOrFn;
    } finally {
      hideLoading();
    }
  }, [showLoading, hideLoading]);

  const isOpen = activeCount > 0;

  const handleCancel = () => {
    if (options.onCancel) {
      options.onCancel();
    }
    // Reset active count on explicit user cancel
    activeCountRef.current = 0;
    setActiveCount(0);
    setOptions(DEFAULT_OPTIONS);
  };

  return (
    <LoadingModalContext.Provider
      value={{
        isLoading: isOpen,
        showLoading,
        hideLoading,
        setMessage,
        setProgress,
        withLoading,
      }}
    >
      {children}
      <LoadingModal
        isOpen={isOpen}
        {...options}
        onCancel={options.cancelable ? handleCancel : undefined}
      />
    </LoadingModalContext.Provider>
  );
}

export function useLoadingModal(): LoadingModalContextType {
  const context = useContext(LoadingModalContext);
  if (!context) {
    throw new Error("useLoadingModal must be used within a LoadingModalProvider");
  }
  return context;
}

export const useLoading = useLoadingModal;
