import { createContext, useContext, useState } from "react";

type ThemeContextType = {
    theme: 'light' | 'dark',
    setTheme: (theme: 'light' | 'dark') => void
    toggleTheme: () => void
}
const ThemeContext = createContext({ theme: 'dark', setTheme: () => { }, toggleTheme: () => { } } as ThemeContextType);

function useTheme() {
    const context = useContext(ThemeContext);
    if (context === undefined) {
        throw new Error('useTheme must be used within a ThemeProvider');
    }
    return context;
}

function ThemeProvider({ children }: { children: React.ReactNode }) {
    const html = document.documentElement;
    const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const saved = localStorage.getItem('theme') as 'light' | 'dark' || null;
    const defaultTheme = saved || (systemDark ? 'dark' : 'light');
    const [theme, setTheme] = useState(defaultTheme);

    function handleSetTheme(theme: 'light' | 'dark') {
        localStorage.setItem('theme', theme);
        html.setAttribute('data-theme', theme);
        setTheme(theme)
    }

    function toggleTheme() {
        handleSetTheme(theme === 'light' ? 'dark' : 'light');
    }

    const value = {
        theme,
        setTheme: handleSetTheme,
        toggleTheme
    };
    return (
        <ThemeContext.Provider value={value}>
            {children}
        </ThemeContext.Provider>
    );
}

export { useTheme, ThemeProvider }