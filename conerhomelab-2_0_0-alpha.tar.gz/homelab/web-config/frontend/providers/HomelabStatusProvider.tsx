import { createContext, useCallback, useContext, useEffect, useState } from "react";
import type { AdminCheckResult, DepsCheckResult, SetupCheckResult, StatusResponse } from "../../commons/dto";
import { StatusApiClient } from "../api";
import { useConfig } from "./ConfigProvider";

type HomelabStatusContextType =
    {
        depsStatus: boolean;
        missingDeps: string[];
        servicesStatus: boolean;
        notConfiguredServices: SetupCheckResult[];
        hasAdmin: boolean;
        domain: string | null;
        refreshAllStatus: () => Promise<StatusResponse | null>;
        refreshDepsStatus: () => Promise<DepsCheckResult | null>;
        refreshServiceStatus: (service: string) => Promise<SetupCheckResult | null>;
        refreshAdminStatus: () => Promise<AdminCheckResult | null>;
        setDepsStatus: (status: boolean) => void;
        setMissingDeps: (deps: string[]) => void;
        setHasAdmin: (status: boolean) => void;
        isLoading: boolean;
    };

const HomelabStatusContext = createContext<HomelabStatusContextType>({
    depsStatus: false,
    servicesStatus: false,
    missingDeps: [],
    notConfiguredServices: [],
    hasAdmin: false,
    domain: null,
    isLoading: true,
    refreshAllStatus: () => Promise.resolve(null),
    refreshDepsStatus: () => Promise.resolve(null),
    refreshServiceStatus: () => Promise.resolve(null),
    refreshAdminStatus: () => Promise.resolve(null),
    setDepsStatus: () => { },
    setMissingDeps: () => { },
    setHasAdmin: () => { },
});

function HomelabStatusProvider({ children }: { children: React.ReactNode }) {
    const [depsStatus, setDepsStatus] = useState<boolean>(false);
    const [missingDeps, setMissingDeps] = useState<string[]>([]);
    const [servicesStatus, setServicesStatus] = useState<boolean>(false);
    const [notConfiguredServices, setNotConfiguredServices] = useState<SetupCheckResult[]>([]);
    const [hasAdmin, setHasAdmin] = useState<boolean>(false);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const { config } = useConfig();

    const refreshAllStatus = useCallback(async (): Promise<StatusResponse> => {
        setIsLoading(true);
        let status: StatusResponse;
        try {
            status = await StatusApiClient.getStatus();

            setDepsStatus(status.deps.success);
            setMissingDeps(status.deps.missing ?? []);
            setServicesStatus(status.services.success);
            setNotConfiguredServices(status.services.notConfigured ?? []);
            setHasAdmin(status.admin.success);
        } finally {
            setIsLoading(false);
        }
        return status;
    }, []);

    async function refreshDepsStatus() {
        setIsLoading(true);
        let status: DepsCheckResult | null = null;
        try {
            status = await StatusApiClient.getDepsStatus();
            setDepsStatus(status.success);
            setMissingDeps(status.missing ?? []);
        } finally {
            setIsLoading(false);
        }
        return status;
    }

    async function refreshServiceStatus(service: string) {
        setIsLoading(true);
        let status: SetupCheckResult | null = null;
        try {
            status = await StatusApiClient.getServiceStatus(service);
            // all service are now configured, the only missing was the current service
            if (status.success && !servicesStatus && notConfiguredServices.filter(s => s.name !== service).length === 0) {
                setServicesStatus(true);
                setNotConfiguredServices([]);
            }
            // other service are still not configured
            else if (status.success && !servicesStatus && notConfiguredServices.filter(s => s.name !== service).length > 0) {
                setNotConfiguredServices(notConfiguredServices.filter(s => s.name !== service));
            }
            // service is not configured
            else if (!status.success) {
                setServicesStatus(false);
                if (!notConfiguredServices.some(s => s.name === service)) {
                    setNotConfiguredServices([...notConfiguredServices, status]);
                }
            }
        } finally {
            setIsLoading(false);
        }
        return status;
    }

    async function refreshAdminStatus() {
        setIsLoading(true);
        let status: AdminCheckResult | null = null;
        try {
            status = await StatusApiClient.getAdminStatus();
            setHasAdmin(status.success);
        } finally {
            setIsLoading(false);
        }
        return status;
    }

    const value = {
        depsStatus,
        missingDeps,
        servicesStatus,
        notConfiguredServices,
        hasAdmin,
        domain: config?.envs.find(e => e.name === 'DOMAIN')?.value ?? null,
        refreshAllStatus,
        refreshDepsStatus,
        refreshServiceStatus,
        refreshAdminStatus,
        setDepsStatus,
        setMissingDeps,
        setHasAdmin,
        isLoading
    }

    useEffect(() => { refreshAllStatus() }, [refreshAllStatus])

    return (
        <HomelabStatusContext.Provider value={value}>
            {children}
        </HomelabStatusContext.Provider>
    )
}

function useHomelabStatus() {
    return useContext(HomelabStatusContext);
}

export { HomelabStatusProvider, useHomelabStatus };