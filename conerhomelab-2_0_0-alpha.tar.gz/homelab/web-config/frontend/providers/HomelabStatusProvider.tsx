import { createContext, useCallback, useContext, useEffect, useState } from "react";
import type { AdminCheckResult, DepsCheckResult, HomelabStatus, SetupCheckResult, StatusResponse, VpnMode } from "../../commons/dto";
import { StatusApiClient } from "../api";
import { useConfig, useConfigActions } from "./ConfigProvider";

type HomelabStatusContextType =
    HomelabStatus & {
        missingDeps: string[];
        notRunningDeps: string[];
        notConfiguredServices: SetupCheckResult[];
        refreshAllStatus: () => Promise<StatusResponse | null>;
        refreshDepsStatus: () => Promise<DepsCheckResult | null>;
        refreshServiceStatus: (service: string) => Promise<SetupCheckResult | null>;
        refreshAdminStatus: () => Promise<AdminCheckResult | null>;
        setDeps: (status: boolean) => void;
        setMissingDeps: (deps: string[]) => void;
        setNotRunningDeps: (deps: string[]) => void;
        setAdmin: (status: boolean) => void;
        setDomain: (domain: string) => void;
        setDns: (dns: string) => void;
        setVpn: (vpn: VpnMode) => void;
        isLoading: boolean;
        isReady: () => boolean;
    };

const HomelabStatusContext = createContext<HomelabStatusContextType>({
    deps: false,
    services: false,
    admin: false,
    missingDeps: [],
    notRunningDeps: [],
    notConfiguredServices: [],
    domain: null,
    vpn: null,
    dns: null,
    isLoading: true,
    isReady: () => false,
    refreshAllStatus: () => Promise.resolve(null),
    refreshDepsStatus: () => Promise.resolve(null),
    refreshServiceStatus: () => Promise.resolve(null),
    refreshAdminStatus: () => Promise.resolve(null),
    setDeps: () => { },
    setMissingDeps: () => { },
    setNotRunningDeps: () => { },
    setAdmin: () => { },
    setDomain: () => { },
    setDns: () => { },
    setVpn: () => { }
});

function HomelabStatusProvider({ children }: { children: React.ReactNode }) {
    const [deps, setDeps] = useState<boolean>(false);
    const [missingDeps, setMissingDeps] = useState<string[]>([]);
    const [notRunningDeps, setNotRunningDeps] = useState<string[]>([]);
    const [services, setServices] = useState<boolean>(false);
    const [notConfiguredServices, setNotConfiguredServices] = useState<SetupCheckResult[]>([]);
    const [admin, setAdmin] = useState<boolean>(false);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const { config } = useConfig();
    const { setEnv, setService } = useConfigActions();

    const refreshAllStatus = useCallback(async (): Promise<StatusResponse> => {
        setIsLoading(true);
        let status: StatusResponse;
        try {
            status = await StatusApiClient.getStatus();

            setDeps(status.deps.success);
            setMissingDeps(status.deps.missing ?? []);
            setNotRunningDeps(status.deps.notRunning ?? []);
            setServices(status.services.success);
            setNotConfiguredServices(status.services.config ?? []);
            setAdmin(status.admin.success);
        } finally {
            setIsLoading(false);
        }
        return status;
    }, []);

    async function refreshDepsStatus() {
        setIsLoading(true);
        let status: DepsCheckResult | null = null;
        try {
            status = await StatusApiClient.getDepsStatus();
            setDeps(status.success);
            setMissingDeps(status.missing ?? []);
            setNotRunningDeps(status.notRunning ?? []);
        } finally {
            setIsLoading(false);
        }
        return status;
    }

    async function refreshServiceStatus(service: string) {
        setIsLoading(true);
        let status: SetupCheckResult | null = null;
        try {
            status = await StatusApiClient.getServiceStatus(service);
            // all service are now configured, the only missing was the current service
            if (status.success && !services && notConfiguredServices.filter(s => s.name !== service).length === 0) {
                setServices(true);
                setNotConfiguredServices([]);
            }
            // other service are still not configured
            else if (status.success && !services && notConfiguredServices.filter(s => s.name !== service).length > 0) {
                setNotConfiguredServices(notConfiguredServices.filter(s => s.name !== service));
            }
            // service is not configured
            else if (!status.success) {
                setServices(false);
                if (!notConfiguredServices.some(s => s.name === service)) {
                    setNotConfiguredServices([...notConfiguredServices, status]);
                }
            }
        } finally {
            setIsLoading(false);
        }
        return status;
    }

    async function refreshAdminStatus() {
        setIsLoading(true);
        let status: AdminCheckResult | null = null;
        try {
            status = await StatusApiClient.getAdminStatus();
            setAdmin(status.success);
        } finally {
            setIsLoading(false);
        }
        return status;
    }

    const isReady = () => {
        return deps && admin && services && !!vpn && !!domain && !!dns;
    }

    const headscaleService = config.services.find(s => s.name === 'headscale');
    const headscaleUI = config.services.find(s => s.name === 'headscale-ui');
    const unboundService = config.services.find(s => s.name === 'unbound');
    const vpn = headscaleService?.enabled === null ? null : (headscaleService?.enabled ? 'headscale' : 'tailscale') as VpnMode;
    function setVpn(vpn: VpnMode) {
        setService({ ...headscaleService, enabled: vpn === 'headscale' });
        setService({ ...headscaleUI, enabled: vpn === 'headscale' });
    }
    const domain = config.envs.find(e => e.name === 'DOMAIN')?.value ?? null;
    const dns = config.envs.find(e => e.name === 'UPSTREAM_DNS_SERVERS')?.value ?? null;
    function setDomain(domain: string) {
        setEnv({ name: 'DOMAIN', value: domain })
    }
    function setDns(dns: string) {
        setEnv({ name: 'UPSTREAM_DNS_SERVERS', value: dns })
        setService({ ...unboundService, enabled: dns === '127.0.0.1#5335' })
    }

    const value = {
        deps,
        missingDeps,
        notRunningDeps,
        services,
        notConfiguredServices,
        admin,
        domain,
        dns,
        vpn,
        refreshAllStatus,
        refreshDepsStatus,
        refreshServiceStatus,
        refreshAdminStatus,
        setDeps,
        setMissingDeps,
        setNotRunningDeps,
        setAdmin,
        setVpn,
        setDomain,
        setDns,
        isLoading,
        isReady
    }

    useEffect(() => { refreshAllStatus() }, [refreshAllStatus])

    return (
        <HomelabStatusContext.Provider value={value}>
            {children}
        </HomelabStatusContext.Provider>
    )
}

function useHomelabStatus() {
    return useContext(HomelabStatusContext);
}

export { HomelabStatusProvider, useHomelabStatus };