import { createContext, useContext, useState } from "react";
import ConsoleModal from "../modals/ConsoleModal";
import { CONFIG_SERVER_URL } from "../api";

export type ConsoleAction = 'start' | 'stop' | 'deploy' | 'install' | 'uninstall'
export type ConsoleJob = {
    action: ConsoleAction,
    service?: string | null,
}
type ConsoleConfig = {
    apiUrl: (job: ConsoleJob) => URL,
    jobName: (job: ConsoleJob) => string,
    initialText: (job: ConsoleJob) => string
}

export const ConsoleActions: Record<ConsoleAction, ConsoleConfig> = {
    'install': {
        apiUrl: job => new URL(`api/deps/install/${job.service ?? ''}`, `${CONFIG_SERVER_URL}`),
        jobName: job => `${job.service ?? 'Dependencies'} installation`,
        initialText: job => `Installing ${job.service ?? 'all dependencies'}...`
    },
    'uninstall': {
        apiUrl: job => new URL(`api/deps/uninstall/${job.service ?? ''}`, `${CONFIG_SERVER_URL}`),
        jobName: job => `${job.service ?? 'Dependencies'} removal`,
        initialText: job => `Removing ${job.service ?? 'all dependencies'}...`
    },
    'start': {
        apiUrl: job => new URL(`api/service/${job.service}/start`, `${CONFIG_SERVER_URL}`),
        jobName: job => job.service ?? 'No service',
        initialText: job => `Starting ${job.service}...`
    },
    'stop': {
        apiUrl: job => new URL(`api/service/${job.service}/stop`, `${CONFIG_SERVER_URL}`),
        jobName: job => job.service ?? 'No service',
        initialText: job => `Stopping ${job.service}...`
    },
    'deploy': {
        apiUrl: () => new URL(`api/deploy`, `${CONFIG_SERVER_URL}`),
        jobName: () => 'Deploy',
        initialText: () => 'Deploying configuration...'
    }
}
type ConsoleModalContextType = {
    openConsole: (
        job: ConsoleJob,
        onSuccess?: (() => void | Promise<void>) | null,
        onClose?: (() => void | Promise<void>) | null
    ) => void;
    closeModal: () => void;
}

const ConsoleModalContext = createContext<ConsoleModalContextType>({
    openConsole: () => { console.warn('Console modal not initialized yet.') },
    closeModal: () => { console.warn('Console modal not initialized yet.') }
});

export function ConsoleModalProvider({ children }: { children: React.ReactNode }) {
    const [consoleParams, setConsoleParams] = useState<{
        job: ConsoleJob | null,
        onSuccess?: (() => void | Promise<void>) | null,
        onClose?: (() => void | Promise<void>) | null
    }>({ job: null, onSuccess: null, onClose: null })

    function openConsole(
        job: ConsoleJob,
        onSuccess?: (() => void | Promise<void>) | null,
        onClose?: (() => void | Promise<void>) | null
    ) {
        console.log('openConsole', job)
        setConsoleParams({ job, onSuccess, onClose });
    }

    function closeModal() {
        console.log('Closing console modal...')
        if (consoleParams.onClose) {
            consoleParams.onClose();
        }
        setConsoleParams({ job: null, onSuccess: null, onClose: null });
    }

    const value = {
        openConsole,
        closeModal,
        ...consoleParams
    }

    return (
        <ConsoleModalContext.Provider value={value}>
            {children}
            <ConsoleModal
                isOpen={Boolean(consoleParams?.job?.action)}
                job={consoleParams?.job ?? null}
                onClose={closeModal}
                onSuccess={consoleParams?.onSuccess ?? null}
            />
        </ConsoleModalContext.Provider>
    )
}

export function useConsoleModal() {
    const ctx = useContext(ConsoleModalContext);
    if (!ctx) {
        throw new Error('useConsoleModal must be used within a ConsoleModalProvider');
    }
    return ctx;
}