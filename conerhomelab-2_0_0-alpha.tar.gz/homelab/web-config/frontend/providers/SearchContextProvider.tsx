import { createContext, useContext, useState } from "react";
import type { ServiceModel } from "../../commons/models";

type SearchContextType = {
    searchText: string;
    setSearchText: (searchText: string) => void;
    serviceSearchFilter: (searchText: string) => (service: ServiceModel) => boolean
}

function serviceSearchFilter(searchText: string) {
    return (service: ServiceModel) =>
        !searchText ||
        service.name.toLowerCase().includes(searchText.toLowerCase()) ||
        ((service.descr ?? '').toLowerCase().includes(searchText.toLowerCase()))
}

const SearchContext = createContext<SearchContextType>({
    searchText: '',
    setSearchText: () => { },
    serviceSearchFilter
});

function useSearchContext() {
    const context = useContext(SearchContext);
    if (context === undefined) {
        throw new Error('useSearchContext must be used within a SearchContextProvider');
    }
    return context;
}

function SearchContextProvider({ children }: { children: React.ReactNode }) {
    const [searchText, setSearchText] = useState('');
    const value = {
        searchText,
        setSearchText,
        serviceSearchFilter
    }
    return (
        <SearchContext.Provider value={value}>
            {children}
        </SearchContext.Provider>
    )
}

export { useSearchContext, SearchContextProvider }