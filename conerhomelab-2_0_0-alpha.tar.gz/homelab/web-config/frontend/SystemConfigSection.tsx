import ServiceCard from "./components/ServiceCard";
import SystemCard from "./components/SystemCard";
import { useState } from "react";
import { useSearchContext } from "./providers/SearchContextProvider";
import type { EnvModel, ServiceModel } from "../commons/models";

type SystemConfigSectionProps = {
    services: ServiceModel[];
    envs: EnvModel[];
    systemVars: Set<string>;
}

export default function SystemConfigSection({ services, envs, systemVars }: SystemConfigSectionProps) {
    const [expanded, setExpanded] = useState(false);

    const { searchText, serviceSearchFilter } = useSearchContext();

    function getSystemCardEnvs(category: 'system' | 'network'): EnvModel[] {
        const service = services.find(s => s.name === category);
        if (!service) return [];
        const filteredEnvs = envs
            .filter(v => v.visible)
            .filter(v => !v.name.endsWith('_VERSION'))
            .filter(v => service.envs.includes(v.name));
        console.log(filteredEnvs.map(v => v.name));
        return filteredEnvs;
    }

    return (
        <section className="system-config-section">
            <div className={`system-header ${expanded ? "expanded" : ""}`} onClick={() => setExpanded(!expanded)}>
                <div className="system-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <circle cx="12" cy="12" r="3" />
                        <path
                            d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                    </svg>
                    System Configuration
                </div>
                <div className={`system-arrow ${expanded ? "expanded" : ""}`} id="systemArrow">
                    <svg viewBox="0 0 24 24">
                        <polyline points="6 9 12 15 18 9" />
                    </svg>
                </div>
            </div>

            <div className={`system-content ${expanded ? "expanded" : ""}`}>
                <div className="system-grid">
                    <SystemCard categoryName="system" envs={getSystemCardEnvs('system')} />
                    <SystemCard categoryName="network" envs={getSystemCardEnvs('network')} />
                    {
                        services.filter(s => s.name !== 'system' && s.name !== 'network')
                            .filter(serviceSearchFilter(searchText))
                            .map(s => {
                                const serviceEnvs = envs.filter(v => s.envs.includes(v.name));
                                return <ServiceCard service={s}
                                    envs={serviceEnvs}
                                    systemVars={systemVars}
                                    key={s.name}
                                    enableMonitor={true} />
                            })
                    }
                </div>
            </div>
        </section>
    );
}