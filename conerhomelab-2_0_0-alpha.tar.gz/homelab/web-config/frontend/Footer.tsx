export default function Footer() {
    return (
        <footer className="page-footer">
            <p>&copy; 2026 Conero Labs – All rights reserved.</p>
        </footer>
    )
}