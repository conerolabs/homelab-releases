import WizardPage from "./WizardPage";
import { useHomelabStatus } from "../providers/HomelabStatusProvider";
import { useEffect } from "react";
import { useLoading } from "../providers/LoadingModalProvider";

function DashboardPage() {
    return (
        <div className="page-container" style={{ textAlign: "center", padding: "60px 20px" }}>
            <h1 style={{ fontFamily: "var(--font-title)", fontSize: "2rem", color: "var(--text-light)" }}>Homelab Dashboard</h1>
            <p style={{ color: "var(--text-muted)", marginTop: "10px" }}>System dependencies, admin user, and core services are configured and running!</p>
        </div>
    );
}

export default function Home() {
    const { isLoading, isReady } = useHomelabStatus();
    const { showLoading, hideLoading } = useLoading();

    useEffect(() => {
        if (isLoading) {
            showLoading("checking homelab status...");
        } else {
            hideLoading();
        }
        return hideLoading;
    }, [isLoading, showLoading, hideLoading]);


    return isReady() ? <DashboardPage /> : <WizardPage />;
}