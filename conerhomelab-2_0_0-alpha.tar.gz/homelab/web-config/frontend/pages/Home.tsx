import WizardPage from "./WizardPage";
import type { HomelabStatus } from "../../commons/dto";
import { useHomelabStatus } from "../providers/HomelabStatusProvider";
import { useEffect } from "react";
import { useLoading } from "../providers/LoadingModalProvider";

function DashboardPage() {
    return (
        <div className="page-container" style={{ textAlign: "center", padding: "60px 20px" }}>
            <h1 style={{ fontFamily: "var(--font-title)", fontSize: "2rem", color: "var(--text-light)" }}>Homelab Dashboard</h1>
            <p style={{ color: "var(--text-muted)", marginTop: "10px" }}>System dependencies, admin user, and core services are configured and running!</p>
        </div>
    );
}

export default function Home() {
    const { depsStatus, hasAdmin, servicesStatus, isLoading } = useHomelabStatus();
    const { showLoading, hideLoading } = useLoading();
    const homelabStatus: HomelabStatus = {
        deps: depsStatus,
        admin: hasAdmin,
        services: servicesStatus
    };
    console.log("HOMELAB STATUS", homelabStatus);
    const isReady = homelabStatus.deps && homelabStatus.admin && homelabStatus.services;

    useEffect(() => {
        if (isLoading) {
            showLoading("checking homelab status...");
        } else {
            hideLoading();
        }
        return hideLoading;
    }, [isLoading, showLoading, hideLoading]);


    return isReady ? <DashboardPage /> : <WizardPage />;
}