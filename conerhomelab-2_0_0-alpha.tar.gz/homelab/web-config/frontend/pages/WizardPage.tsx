import WizardStepHeader from "../components/wizard/WizardStepHeader";
import StepDepsInstall from "../components/wizard/StepDepsInstall";
import StepAdminUser from "../components/wizard/StepAdminUser";
import StepServicesConfig from "../components/wizard/StepServicesConfig";
import { useHomelabStatus } from "../providers/HomelabStatusProvider";
import StepNetworkSetup from "../components/wizard/StepNetworkSetup";

export default function WizardPage() {
    const { deps, admin, services, domain, vpn, dns } = useHomelabStatus();

    const status = {
        deps,
        admin,
        services,
        domain,
        vpn,
        dns
    }

    return (
        <div className="page-container">
            <div className="wizard-container">

                {/* Step Progress Bar */}
                <WizardStepHeader status={status} />

                {/* Active Step Content */}
                {!status.deps && (
                    <StepDepsInstall />
                )}

                {status.deps && (!status.vpn || !status.domain || !status.dns) && (
                    <StepNetworkSetup />
                )}

                {status.deps && status.vpn && status.domain && status.dns && !status.admin && (
                    <StepAdminUser />
                )}

                {status.deps && status.vpn && status.domain && status.dns && status.admin && !status.services && (
                    <StepServicesConfig />
                )}

            </div>
        </div>
    );
}
