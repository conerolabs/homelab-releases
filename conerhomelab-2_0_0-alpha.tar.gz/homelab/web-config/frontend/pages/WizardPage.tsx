import WizardStepHeader from "../components/wizard/WizardStepHeader";
import StepDepsInstall from "../components/wizard/StepDepsInstall";
import StepAdminUser from "../components/wizard/StepAdminUser";
import StepServicesConfig from "../components/wizard/StepServicesConfig";
import { useHomelabStatus } from "../providers/HomelabStatusProvider";
import StepNetworkSetup from "../components/wizard/StepNetworkSetup";

export default function WizardPage() {
    const { depsStatus, hasAdmin, servicesStatus, domain } = useHomelabStatus();

    const status = {
        deps: depsStatus,
        admin: hasAdmin,
        services: servicesStatus,
        domain: domain
    }

    return (
        <div className="page-container">
            <div className="wizard-container">

                {/* Step Progress Bar */}
                <WizardStepHeader status={status} />

                {/* Active Step Content */}
                {!status.deps && (
                    <StepDepsInstall />
                )}

                {status.deps && !status.domain && (
                    <StepNetworkSetup />
                )}

                {status.deps && status.domain && !status.admin && (
                    <StepAdminUser />
                )}

                {status.deps && status.domain && status.admin && !status.services && (
                    <StepServicesConfig />
                )}

            </div>
        </div>
    );
}
