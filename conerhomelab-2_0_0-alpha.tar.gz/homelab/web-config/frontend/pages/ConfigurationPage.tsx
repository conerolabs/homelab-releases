import FooterActionBar from "../FooterActionBar";
import ManageServicesSection from "../ManageServicesSection";
import { useConfig } from "../providers/ConfigProvider";
import SystemConfigSection from "../SystemConfigSection";
import { ConfigApiClient } from "../api";
import toast from "react-hot-toast";
import { useConsoleModal } from "../providers/ConsoleModalProvider";

export default function ConfigurationPage() {

    const { config, getSystemVars, getDockerServices, getSystemServices } = useConfig();
    const { openConsole } = useConsoleModal();
    const systemVars = getSystemVars();
    const systemServices = getSystemServices();
    const dockerServices = getDockerServices();

    function onDeploySuccess() {
        toast.success('Configuration deployed successfully!')
    }

    function startDeploy() {
        openConsole({ action: 'deploy' }, null, onDeploySuccess);
    }

    if (!config) return <div>Loading...</div>;

    return (
        <div className="page-container">
            <div className="page-title">
                <h2> Web Configuration Engine v1.0</h2>
            </div>

            <SystemConfigSection services={systemServices} envs={config.envs} systemVars={systemVars} />
            <ManageServicesSection services={dockerServices} envs={config.envs} systemVars={systemVars} />

            <FooterActionBar activeCount={dockerServices.filter(s => s.enabled).length}
                totalCount={dockerServices.length}
                onSave={() => toast.promise(ConfigApiClient.saveConfig(config), {
                    loading: 'Saving configuration...',
                    success: 'Configuration saved successfully!',
                    error: 'Failed to save configuration.',
                })}
                onDeploy={startDeploy} />
        </div>
    )
}