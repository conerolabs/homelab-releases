import { useEffect, useState } from "react"
import type { DependencyStatus } from "../../commons/dto";
import DependencyCard from "../ui/DependencyCard";
import { useConsoleModal } from "../providers/ConsoleModalProvider";
import { CONFIG_SERVER_URL, SystemApiClient } from "../api";
import '../deps.css';
import { usePromptModal } from "../providers/PromptModalProvider";

export default function DepsPage() {

    const [deps, setDeps] = useState<DependencyStatus[]>([]);
    const [isInstalling, setIsInstalling] = useState(false);
    const { openConsole } = useConsoleModal();
    const { promptSudoPassword } = usePromptModal();

    // Load dependency status board
    function loadDepBoard() {
        fetch(`${CONFIG_SERVER_URL}/api/deps/status`)
            .then(r => r.json() as Promise<DependencyStatus[]>)
            .then(setDeps)
            .catch(e => console.error('Failed to load dependencies status', e));
    }

    async function handleInstallAll() {
        try {
            const needPassword = await SystemApiClient.needPasswordPrompt('install');

            let sudoPassword: string | null = null;
            if (needPassword) {
                sudoPassword = await promptSudoPassword();
                if (!sudoPassword) {
                    return;
                }
                await SystemApiClient.sendSudoPassword(sudoPassword);
            }

            setIsInstalling(true);
            openConsole(
                {
                    action: 'install',
                    sudo: sudoPassword
                },
                () => { console.log('Deps installation successfull') },
                () => {
                    setIsInstalling(false);
                    loadDepBoard();
                }
            );
        } catch (e) {
            console.error('Failed to install dependencies', e);
        }
    }

    useEffect(() => {
        loadDepBoard();
    }, []);

    return (
        <div className="page-container">
            <section className="install-section">
                <div className="install-section-header">
                    <button disabled={isInstalling} onClick={handleInstallAll} className="btn btn-primary">Run Installer</button>
                    <div>
                        <h2>Install Required Dependencies</h2>
                        <p>This page runs the <code>1-deps-install.sh</code> script to install all required system packages.</p>
                    </div>
                </div>

                <div className="deps-board">
                    {deps.map(dep => <DependencyCard key={dep.name} dep={dep} />)}
                </div>
            </section>
        </div>
    )
}