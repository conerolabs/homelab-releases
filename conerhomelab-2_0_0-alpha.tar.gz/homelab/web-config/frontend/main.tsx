import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import { ConfigProvider } from "./providers/ConfigProvider"
import { ConsoleModalProvider } from "./providers/ConsoleModalProvider"
import { PromptModalProvider } from "./providers/PromptModalProvider"
import { LoadingModalProvider } from "./providers/LoadingModalProvider"
import { SearchContextProvider } from "./providers/SearchContextProvider"
import { ThemeProvider } from './providers/ThemeProvider'
import HomelabRouterProvider from './providers/HomelabRouterProvider'
import { HomelabStatusProvider } from './providers/HomelabStatusProvider'

createRoot(document.getElementById('root')!).render(
    <StrictMode>
        <ThemeProvider>
            <ConfigProvider>
                <HomelabStatusProvider>
                    <SearchContextProvider>
                        <ConsoleModalProvider>
                            <PromptModalProvider>
                                <LoadingModalProvider>
                                    <HomelabRouterProvider />
                                </LoadingModalProvider>
                            </PromptModalProvider>
                        </ConsoleModalProvider>
                    </SearchContextProvider>
                </HomelabStatusProvider>
            </ConfigProvider>
        </ThemeProvider>
    </StrictMode>
)

