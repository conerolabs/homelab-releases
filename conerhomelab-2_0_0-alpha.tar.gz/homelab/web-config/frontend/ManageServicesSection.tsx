import { useState } from "react";
import ServicesGrid from "./ServicesGrid";
import type { HomelabService, HomelabEnv } from "./ConfigReducer";

type ManageServicesSectionProps = {
    services: HomelabService[],
    envs: HomelabEnv[],
    systemVars: Set<string>
}

export default function ManageServicesSection({ services, envs, systemVars }: ManageServicesSectionProps) {
    const [expanded, setExpanded] = useState(false);

    return (
        <section className="system-config-section">
            <div className={`system-header ${expanded ? "expanded" : ""}`} onClick={() => setExpanded(!expanded)}>
                <div className="services-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                    </svg>
                    Manage Services
                </div>
                <div className={`system-arrow ${expanded ? "expanded" : ""}`}>
                    <svg viewBox="0 0 24 24">
                        <polyline points="6 9 12 15 18 9" />
                    </svg>
                </div>
            </div>

            <ServicesGrid services={services} envs={envs} systemVars={systemVars} expanded={expanded} />

        </section>
    );
}
