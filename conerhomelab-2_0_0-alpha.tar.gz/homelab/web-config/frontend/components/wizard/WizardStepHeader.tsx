import type { HomelabStatus } from "../../../commons/dto";

type Props = {
    status: HomelabStatus;
}

export default function WizardStepHeader({ status }: Props) {
    // Step 1 active if deps false
    // Step 2 active if deps true & admin false
    // Step 3 active if deps true & admin true & services false

    const step1Completed = status.deps;
    const step2Completed = !!status.domain && !!status.vpn && !!status.dns;
    const step3Completed = status.admin;
    const step4Completed = status.services;

    const currentStep = !status.deps ? 1 : !status.domain ? 2 : !status.admin ? 3 : 4;

    return (
        <div className="wizard-stepper">
            {/* Step 1 */}
            <div className={`wizard-step-item ${currentStep === 1 ? 'active' : ''} ${step1Completed ? 'completed' : ''}`}>
                <div className="wizard-step-badge">
                    {step1Completed ? (
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                            <polyline points="20 6 9 17 4 12" />
                        </svg>
                    ) : '1'}
                </div>
                <div className="wizard-step-info">
                    <span className="wizard-step-title">System & Dependencies</span>
                    <span className="wizard-step-subtitle">Install system packages</span>
                </div>
            </div>

            <div className={`wizard-step-line ${step1Completed ? 'filled' : ''}`} />

            {/* Step 2 */}
            <div className={`wizard-step-item ${currentStep === 2 ? 'active' : ''} ${step2Completed ? 'completed' : ''}`}>
                <div className="wizard-step-badge">
                    {step2Completed ? (
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                            <polyline points="20 6 9 17 4 12" />
                        </svg>
                    ) : '2'}
                </div>
                <div className="wizard-step-info">
                    <span className="wizard-step-title">Network Setup</span>
                    <span className="wizard-step-subtitle">Domain, VPN, DNS</span>
                </div>
            </div>

            <div className={`wizard-step-line ${step2Completed ? 'filled' : ''}`} />

            {/* Step 3 */}
            <div className={`wizard-step-item ${currentStep === 3 ? 'active' : ''} ${step3Completed ? 'completed' : ''}`}>
                <div className="wizard-step-badge">
                    {step3Completed ? (
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                            <polyline points="20 6 9 17 4 12" />
                        </svg>
                    ) : '3'}
                </div>
                <div className="wizard-step-info">
                    <span className="wizard-step-title">Admin Account</span>
                    <span className="wizard-step-subtitle">Create primary user</span>
                </div>
            </div>

            <div className={`wizard-step-line ${step3Completed ? 'filled' : ''}`} />

            {/* Step 4 */}
            <div className={`wizard-step-item ${currentStep === 4 ? 'active' : ''} ${step4Completed ? 'completed' : ''}`}>
                <div className="wizard-step-badge">
                    {step4Completed ? (
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                            <polyline points="20 6 9 17 4 12" />
                        </svg>
                    ) : '4'}
                </div>
                <div className="wizard-step-info">
                    <span className="wizard-step-title">Services Setup</span>
                    <span className="wizard-step-subtitle">Configure services</span>
                </div>
            </div>
        </div>
    );
}
