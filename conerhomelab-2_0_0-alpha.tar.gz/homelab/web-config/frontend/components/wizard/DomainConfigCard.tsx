import { useState } from "react";
import { usePromptModal } from "../../providers/PromptModalProvider";

export type DomainMode = 'public' | 'local';

type DomainConfigCardProps = {
    selectedMode: DomainMode;
    onConfirm: (domain: string) => void;
}

export default function DomainConfigCard({ selectedMode, onConfirm }: DomainConfigCardProps) {
    const [mode, setMode] = useState<DomainMode>(selectedMode);
    const [publicDomain, setPublicDomain] = useState<string>('');
    const { promptInput } = usePromptModal();
    const handlePublicDomainClick = async () => {
        const domain = await promptInput({
            title: 'Enter your domain name',
            message: 'You need a public domain if you want to use Headscale or automatic Let\'s Encrypt/ZeroSSL certificates. Furthermore you will need to configure Dynamic DNS for your domain if you don\'t have a static IP address.',
            inputDefaultValue: publicDomain,
            inputPlaceholder: 'your-domain.com',
            inputLabel: 'Domain Name',
            confirmText: 'Confirm',
            cancelText: 'Cancel'
        }) as string;
        console.log("Domain is: ", domain);
        if (domain) {
            setMode(domain ? 'public' : 'local');
            setPublicDomain(domain);
            onConfirm(domain);
        }
    };

    return (
        <div className="domain-config-section">
            <h3 className="domain-config-title">Domain Configuration</h3>
            <div className="domain-options-grid">

                {/* Option 1: Without Public Domain */}
                <div
                    className={`domain-card ${mode === 'local' ? 'selected' : ''}`}
                    onClick={() => {
                        setMode('local');
                        onConfirm('local');
                    }}
                >
                    <div className="domain-card-header">
                        <div className="domain-card-name">
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                                </svg>
                                <span>Without Public Domain</span>
                            </div>
                        </div>
                        <div className="domain-card-radio" />
                    </div>

                    <ul className="domain-details-list">
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>Connections via Tailscale only (Headscale disabled)</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>Caddy uses internal TLS (CA cert imported to clients)</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>No Cloudflare Dynamic DNS required</span>
                        </li>
                    </ul>
                </div>

                {/* Option 2: With Public Domain */}
                <div
                    className={`domain-card ${mode === 'public' ? 'selected' : ''}`}
                    onClick={handlePublicDomainClick}//{() => onSelectMode('public')}
                >
                    <div className="domain-card-header">
                        <div className="domain-card-name">
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <circle cx="12" cy="12" r="10" />
                                    <line x1="2" y1="12" x2="22" y2="12" />
                                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                                </svg>
                                <span>With Public Domain</span>
                            </div>
                            <div>
                                <span className="domain-card-selected-domain">{publicDomain || ''}</span>
                            </div>
                        </div>
                        <div className="domain-card-radio" />
                    </div>

                    <ul className="domain-details-list">
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>Connections via Tailscale and Headscale</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>Caddy uses automatic Let's Encrypt / ZeroSSL TLS</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>Cloudflare DDNS updates public IP for Authelia/Headscale</span>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    );
}
