export type DomainMode = 'public' | 'local';

type DomainConfigCardProps = {
    domain: string;
    selectedMode: DomainMode;
    onSelectMode: (mode: DomainMode) => Promise<void>;
    disabledMode?: DomainMode;
}

export default function DomainConfigCard({ domain, selectedMode, onSelectMode, disabledMode }: DomainConfigCardProps) {

    const resolvePublicDomainLabel = (d: string) => {
        console.log('Domain: ' + d);
        console.log('Selected mode: ' + selectedMode);
        if (d === 'local' && selectedMode === 'local') {
            return '';
        }
        else if ((!d || d === 'local') && selectedMode === 'public') {
            return 'click to set domain...';
        }
        else if ((d && d !== 'local') && selectedMode === 'public') {
            return d;
        }
        else if ((d && d !== 'local') && selectedMode === 'local') {
            console.warn("You are trying to use a public domain with local mode. This is not allowed.");
            return d;
        }
    }

    return (
        <div className="domain-config-section">
            <h3 className="domain-config-title">Domain Configuration</h3>
            <div className="domain-options-grid">

                {/* Option 1: Without Public Domain */}
                <div
                    className={`domain-card ${selectedMode === 'local' ? 'selected' : ''} ${disabledMode === 'local' ? 'disabled' : ''}`}
                    onClick={() => {
                        if (disabledMode !== 'local') {
                            onSelectMode('local');
                        }
                    }}
                >
                    <div className="domain-card-header">
                        <div className="domain-card-name">
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                                </svg>
                                <span>Without Public Domain</span>
                            </div>
                        </div>
                        <div className="domain-card-radio" />
                    </div>

                    <ul className="domain-details-list">
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>Connections via Tailscale only (Headscale disabled)</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>Caddy uses internal TLS (CA cert imported to clients)</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>No Cloudflare Dynamic DNS required</span>
                        </li>
                    </ul>
                </div>

                {/* Option 2: With Public Domain */}
                <div
                    className={`domain-card ${selectedMode === 'public' ? 'selected' : ''} ${disabledMode === 'public' ? 'disabled' : ''}`}
                    onClick={() => {
                        if (disabledMode !== 'public') {
                            onSelectMode('public');
                        }
                    }}
                >
                    <div className="domain-card-header">
                        <div className="domain-card-name">
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <circle cx="12" cy="12" r="10" />
                                    <line x1="2" y1="12" x2="22" y2="12" />
                                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                                </svg>
                                <span>With Public Domain</span>
                            </div>
                            <div>
                                <span className="domain-card-selected-domain">{resolvePublicDomainLabel(domain)}</span>
                            </div>
                        </div>
                        <div className="domain-card-radio" />
                    </div>

                    <ul className="domain-details-list">
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>Connections via Tailscale and Headscale</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>Caddy uses automatic Let's Encrypt / ZeroSSL TLS</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span>Cloudflare DDNS updates public IP for Authelia/Headscale</span>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    );
}
