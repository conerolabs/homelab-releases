import { useState } from "react";

export type DnsMode = 'unbound' | 'cloudflare' | 'quad9' | 'adguard' | 'google' | 'nextdns' | 'custom';

export type DnsOption = {
    id: DnsMode;
    name: string;
    badge: string;
    badgeClass: string;
    servers: string;
    description: string;
    features: string[];
    isLocal?: boolean;
};

export const DNS_RESOLVER_OPTIONS: DnsOption[] = [
    {
        id: 'unbound',
        name: 'Unbound (Local Resolver)',
        badge: 'Self-Hosted (Local)',
        badgeClass: 'badge-selfhosted',
        servers: '127.0.0.1#5335',
        description: 'Runs a local Unbound recursive DNS resolver directly on your homelab server.',
        features: [
            '100% Privacy: Queries ICANN Root DNS Servers directly with no third-party tracking',
            'Full Data Control: No upstream DNS logs or ISP telemetry',
            'Built-in DNSSEC validation and local response caching'
        ],
        isLocal: true
    },
    {
        id: 'cloudflare',
        name: 'Cloudflare DNS',
        badge: 'Public DNS',
        badgeClass: 'badge-public',
        servers: '1.1.1.1 ; 1.0.0.1',
        description: 'Ultra-fast public DNS resolver with strong privacy guarantees (logs purged within 24h).',
        features: [
            'World\'s fastest public DNS resolution speed',
            'Strict privacy commitment (never sells user data)',
            'Supports DNS-over-HTTPS (DoH) and DNS-over-TLS (DoT)'
        ]
    },
    {
        id: 'quad9',
        name: 'Quad9 DNS',
        badge: 'Public DNS (Security)',
        badgeClass: 'badge-public',
        servers: '9.9.9.9 ; 149.112.112.112',
        description: 'Swiss non-profit DNS resolver featuring automated malicious domain & threat blocking.',
        features: [
            'Real-time threat intelligence and malware/phishing domain blocking',
            'Swiss jurisdiction privacy protection',
            'DNSSEC validation enabled by default'
        ]
    },
    {
        id: 'adguard',
        name: 'AdGuard DNS',
        badge: 'Public DNS (AdBlock)',
        badgeClass: 'badge-public',
        servers: '94.140.14.14 ; 94.140.15.15',
        description: 'Privacy-focused public DNS resolver that filters out ads, trackers, and phishing.',
        features: [
            'Built-in blocking of advertising network domains & trackers',
            'Protection against malicious and phishing websites',
            'Zero configuration required'
        ]
    },
    {
        id: 'google',
        name: 'Google Public DNS',
        badge: 'Public DNS',
        badgeClass: 'badge-cloud',
        servers: '8.8.8.8 ; 8.8.4.4',
        description: 'Globally distributed, highly available public DNS service focused on speed and reliability.',
        features: [
            'Global infrastructure with low latency worldwide',
            'High uptime and DDoS resilience',
            'Fast and accurate domain resolution'
        ]
    },
    // {
    //     id: 'nextdns',
    //     name: 'NextDNS',
    //     badge: 'Cloud Firewall',
    //     badgeClass: 'badge-cloud',
    //     servers: '45.90.28.115 ; 45.90.30.115',
    //     description: 'Modern cloud DNS resolver offering customizable security and privacy filters.',
    //     features: [
    //         'Cloud DNS firewall capabilities',
    //         'Customizable blocklists and privacy protections',
    //         'Supports profile-based custom DNS routing'
    //     ]
    // },
    {
        id: 'custom',
        name: 'Custom Upstream DNS',
        badge: 'Custom',
        badgeClass: 'badge-cloud',
        servers: 'User specified',
        description: 'Specify your own custom upstream DNS server addresses (IPv4 or IPv6).',
        features: [
            'Use custom private or corporate DNS servers',
            'Semicolon-separated list of IP addresses',
            'Flexible configuration'
        ]
    }
];

type DnsConfigCardProps = {
    selectedMode: DnsMode;
    customDnsValue: string;
    onSelectMode: (mode: DnsMode) => void;
    onCustomDnsChange: (value: string) => void;
};

export default function DnsConfigCard({
    selectedMode,
    customDnsValue,
    onSelectMode,
    onCustomDnsChange
}: DnsConfigCardProps) {
    const [isExpanded, setIsExpanded] = useState<boolean>(false);
    const [lastSelectedPublicMode, setLastSelectedPublicMode] = useState<DnsMode>(
        selectedMode !== 'unbound' ? selectedMode : 'cloudflare'
    );

    const unboundOption = DNS_RESOLVER_OPTIONS.find(opt => opt.id === 'unbound')!;
    const publicOptions = DNS_RESOLVER_OPTIONS.filter(opt => opt.id !== 'unbound');

    const isLocalSelected = selectedMode === 'unbound';
    const isPublicSelected = !isLocalSelected;

    const currentPublicMode: DnsMode = isPublicSelected ? selectedMode : lastSelectedPublicMode;
    const selectedPublicOption = publicOptions.find(opt => opt.id === currentPublicMode) || publicOptions[0];

    const handleSelectPublicMode = (mode: DnsMode) => {
        setLastSelectedPublicMode(mode);
        onSelectMode(mode);
    };

    return (
        <div className="domain-config-section">
            <div className="vpn-config-header-row" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <h3 className="domain-config-title" style={{ margin: 0 }}>DNS Resolver Configuration</h3>
                <button
                    type="button"
                    className={`vpn-help-btn ${isExpanded ? 'active' : ''}`}
                    onClick={() => setIsExpanded(!isExpanded)}
                    title={isExpanded ? "Hide explanation" : "What is a DNS Resolver?"}
                    style={{
                        background: 'transparent',
                        border: 'none',
                        cursor: 'pointer',
                        padding: '4px',
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: isExpanded ? 'var(--primary)' : 'var(--text-muted)',
                        transition: 'all 0.2s ease',
                        borderRadius: '50%'
                    }}
                >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                        <line x1="12" y1="17" x2="12.01" y2="17"></line>
                    </svg>
                </button>
            </div>

            {/* Educational Banner & Explanation */}
            {isExpanded && (
                <div className="vpn-info-box">
                    <div className="vpn-info-header">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="12" cy="12" r="10" />
                            <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" />
                            <path d="M2 12h20" />
                        </svg>
                        <h4>What is a DNS Resolver & Upstream DNS?</h4>
                    </div>
                    <p className="vpn-info-text">
                        A <strong>Domain Name System (DNS) Resolver</strong> translates human-friendly domain names (like <code>example.com</code>) into numerical IP addresses. In your homelab, DNS is used by Pi-hole and system services to route all network queries.
                    </p>
                    <p className="vpn-info-text">
                        <strong>Public DNS Resolvers vs. Local Unbound:</strong>
                    </p>
                    <ul className="domain-details-list" style={{ marginLeft: '12px' }}>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span><strong>Public DNS (Cloudflare, Quad9, etc.):</strong> Fast and zero-maintenance, but queries are processed by external third-party servers.</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span><strong>Unbound Local Resolver (Recommended for Privacy):</strong> A local recursive DNS server running directly on your server that queries ICANN root nameservers directly. No external provider sees your DNS queries.</span>
                        </li>
                    </ul>
                </div>
            )}

            {/* Options Grid (2 Cards: Local vs Public) */}
            <div className="domain-options-grid">
                {/* Card 1: Local Resolver (Unbound) */}
                <div
                    className={`domain-card ${isLocalSelected ? 'selected' : ''}`}
                    onClick={() => onSelectMode('unbound')}
                    style={{ borderLeft: '4px solid #10b981' }}
                >
                    <div className="domain-card-header">
                        <div className="domain-card-name">
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect>
                                    <rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect>
                                    <line x1="6" y1="6" x2="6.01" y2="6"></line>
                                    <line x1="6" y1="18" x2="6.01" y2="18"></line>
                                </svg>
                                <span>{unboundOption.name}</span>
                            </div>
                            <span className={`vpn-card-badge ${unboundOption.badgeClass}`}>{unboundOption.badge}</span>
                        </div>
                        <div className="domain-card-radio" />
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                        <span>Servers: <strong style={{ color: 'var(--text-main)', fontFamily: 'monospace' }}>{unboundOption.servers}</strong></span>
                    </div>

                    <p style={{ fontSize: '0.88rem', color: 'var(--text-muted)', margin: 0, lineHeight: '1.4' }}>
                        {unboundOption.description}
                    </p>

                    <ul className="domain-details-list">
                        {unboundOption.features.map((feat, idx) => (
                            <li key={idx}>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                                <span>{feat}</span>
                            </li>
                        ))}
                    </ul>
                </div>

                {/* Card 2: Public DNS Resolver */}
                <div
                    className={`domain-card ${isPublicSelected ? 'selected' : ''}`}
                    onClick={() => {
                        if (!isPublicSelected) {
                            handleSelectPublicMode(currentPublicMode);
                        }
                    }}
                >
                    <div className="domain-card-header">
                        <div className="domain-card-name">
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <circle cx="12" cy="12" r="10" />
                                    <line x1="2" y1="12" x2="22" y2="12" />
                                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                                </svg>
                                <span>Public DNS Resolver</span>
                            </div>
                            <span className="vpn-card-badge badge-public">Public DNS</span>
                        </div>
                        <div className="domain-card-radio" />
                    </div>

                    {/* Dropdown to select public provider */}
                    <div style={{ marginTop: '4px' }} onClick={(e) => e.stopPropagation()}>
                        <label style={{ fontSize: '0.82rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>
                            Select Upstream Provider:
                        </label>
                        <select
                            className="dns-custom-input"
                            value={currentPublicMode}
                            onChange={(e) => handleSelectPublicMode(e.target.value as DnsMode)}
                            style={{ cursor: 'pointer' }}
                        >
                            {publicOptions.map((opt) => (
                                <option key={opt.id} value={opt.id} style={{ background: '#1e293b', color: '#fff' }}>
                                    {opt.name} ({opt.servers})
                                </option>
                            ))}
                        </select>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                        <span>Servers: <strong style={{ color: 'var(--text-main)', fontFamily: 'monospace' }}>{selectedPublicOption.servers}</strong></span>
                    </div>

                    {currentPublicMode === 'custom' && (
                        <div style={{ marginTop: '4px' }} onClick={(e) => e.stopPropagation()}>
                            <label style={{ fontSize: '0.82rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                                Upstream DNS Server IPs (semicolon separated):
                            </label>
                            <input
                                type="text"
                                className="dns-custom-input"
                                value={customDnsValue}
                                placeholder="e.g. 1.1.1.1; 8.8.8.8"
                                onChange={(e) => onCustomDnsChange(e.target.value)}
                            />
                        </div>
                    )}

                    <ul className="domain-details-list">
                        {selectedPublicOption.features.map((feat, idx) => (
                            <li key={idx}>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                                <span>{feat}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
}
