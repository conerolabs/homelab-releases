import { useEffect, useState } from "react";
import type { DependencyStatus } from "../../../commons/dto";
import DependencyCard from "../../ui/DependencyCard";
import { CONFIG_SERVER_URL } from "../../api";
import { useHomelabStatus } from "../../providers/HomelabStatusProvider";
import { useConsoleTask } from "../../hooks/useConsoleTask";

export default function StepDepsInstall() {
    const [deps, setDeps] = useState<DependencyStatus[]>([]);
    const { runConsoleTask, isRunning } = useConsoleTask();
    const { refreshDepsStatus, depsStatus, domain } = useHomelabStatus();

    const installedCount = deps.filter((d) => d.installed).length;

    function loadDepBoard() {
        fetch(`${CONFIG_SERVER_URL}/api/deps/required/status`)
            .then((r) => r.json() as Promise<DependencyStatus[]>)
            .then(setDeps)
            .catch((e) => console.error("Failed to load dependencies status", e));
    }

    async function handleInstallAll() {
        try {
            runConsoleTask(
                { action: "install" },
                () => {
                    console.log("Deps installation successful");
                    refreshDepsStatus();
                },
                () => {
                    loadDepBoard();
                }
            );
        } catch (e) {
            console.error("Failed to install dependencies", e);
        }
    }

    useEffect(() => {
        if (depsStatus && domain) window.location.reload();
        else loadDepBoard();
    }, [depsStatus, domain]);

    return (
        <div className="wizard-card">
            <div className="wizard-card-header">
                <h2 className="wizard-card-title">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2">
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
                        <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
                        <line x1="12" y1="22.08" x2="12" y2="12" />
                    </svg>
                    Initial Homelab Setup & System Dependencies
                </h2>
                <p className="wizard-card-description">
                    Welcome to your Homelab setup wizard. System dependencies must be installed before configuring services and creating user accounts.
                </p>
            </div>

            {/* Central Start Homelab Hero CTA */}
            <div className="wizard-hero-cta">
                <button
                    disabled={isRunning}
                    onClick={handleInstallAll}
                    className="btn-start-homelab"
                >
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <polygon points="5 3 19 12 5 21 5 3" />
                    </svg>
                    <span>{isRunning ? "Installing Dependencies..." : "Start Homelab"}</span>
                </button>
                <p style={{ margin: 0, fontSize: "0.9rem", color: "var(--text-muted)" }}>
                    Launches the main installer script (<code>1-deps-install.sh</code>) to automatically prepare your system.
                </p>
            </div>

            {/* Dependency Status Board */}
            <div className="install-section">
                <div className="deps-section-header">
                    <div className="deps-section-title-group">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                            <line x1="8" y1="21" x2="16" y2="21"></line>
                            <line x1="12" y1="17" x2="12" y2="21"></line>
                        </svg>
                        <h3 className="deps-section-title">System Dependencies Status</h3>
                    </div>
                    {deps.length > 0 && (
                        <div className={`deps-status-counter ${installedCount === deps.length ? 'all-installed' : ''}`}>
                            <span className="deps-status-dot"></span>
                            <span>{installedCount} of {deps.length} Installed</span>
                        </div>
                    )}
                </div>
                <div className="deps-board">
                    {deps.map((dep) => (
                        <DependencyCard key={dep.name} dep={dep} onActionSuccess={loadDepBoard} />
                    ))}
                </div>
            </div>
        </div>
    );
}
