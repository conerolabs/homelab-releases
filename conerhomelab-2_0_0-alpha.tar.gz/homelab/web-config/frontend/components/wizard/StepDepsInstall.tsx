import { useEffect, useState } from "react";
import type { DependencyStatus } from "../../../commons/dto";
import { CONFIG_SERVER_URL } from "../../api";
import { useHomelabStatus } from "../../providers/HomelabStatusProvider";
import { useConsoleTask } from "../../hooks/useConsoleTask";
import DepsBoard from "../DepsBoard";

export default function StepDepsInstall() {
    const [deps, setDeps] = useState<DependencyStatus[]>([]);
    const { runConsoleTask, isRunning } = useConsoleTask();
    const { refreshDepsStatus, deps: depsStatus } = useHomelabStatus();

    function loadDeps() {
        fetch(`${CONFIG_SERVER_URL}/api/deps/required/status`)
            .then((r) => r.json() as Promise<DependencyStatus[]>)
            .then(setDeps)
            .catch((e) => console.error("Failed to load dependencies status", e));
    }

    async function handleInstallAll() {
        try {
            runConsoleTask(
                { action: "install" },
                () => {
                    console.log("Deps installation successful");
                    refreshDepsStatus();
                },
                () => {
                    loadDeps();
                }
            );
        } catch (e) {
            console.error("Failed to install dependencies", e);
        }
    }

    useEffect(() => {
        if (depsStatus) window.location.reload();
        else loadDeps();
    }, [depsStatus]);

    return (
        <div className="wizard-card">
            <div className="wizard-card-header">
                <h2 className="wizard-card-title">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2">
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
                        <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
                        <line x1="12" y1="22.08" x2="12" y2="12" />
                    </svg>
                    Initial Homelab Setup & System Dependencies
                </h2>
                <p className="wizard-card-description">
                    Welcome to your Homelab setup wizard. System dependencies must be installed before configuring services and creating user accounts.
                </p>
            </div>

            {/* Central Start Homelab Hero CTA */}
            <div className="wizard-hero-cta">
                <button
                    disabled={isRunning}
                    onClick={handleInstallAll}
                    className="btn-start-homelab"
                >
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <polygon points="5 3 19 12 5 21 5 3" />
                    </svg>
                    <span>{isRunning ? "Installing Dependencies..." : "Start Homelab"}</span>
                </button>
                <p style={{ margin: 0, fontSize: "0.9rem", color: "var(--text-muted)" }}>
                    Launches the main installer script (<code>1-deps-install.sh</code>) to automatically prepare your system.
                </p>
            </div>

            {/* Dependency Status Board */}
            <DepsBoard deps={deps} />
        </div>
    );
}
