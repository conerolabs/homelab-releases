import { useState } from "react";
import type { VpnMode } from "../../../commons/dto";

type VpnConfigCardProps = {
    selectedMode: VpnMode;
    onSelectMode: (mode: VpnMode) => void;
};

export default function VpnConfigCard({ selectedMode, onSelectMode }: VpnConfigCardProps) {
    const [mode, setMode] = useState<VpnMode>(selectedMode);
    const [isExpanded, setIsExpanded] = useState<boolean>(false);

    const handleSelect = (newMode: VpnMode) => {
        setMode(newMode);
        onSelectMode(newMode);
    };

    return (
        <div className="vpn-config-section">
            <div className="vpn-config-header-row" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <h3 className="vpn-config-title" style={{ margin: 0 }}>Vpn Configuration</h3>
                <button
                    type="button"
                    className={`vpn-help-btn ${isExpanded ? 'active' : ''}`}
                    onClick={() => setIsExpanded(!isExpanded)}
                    title={isExpanded ? "Hide explanation" : "What is a VPN?"}
                    style={{
                        background: 'transparent',
                        border: 'none',
                        cursor: 'pointer',
                        padding: '4px',
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: isExpanded ? 'var(--primary)' : 'var(--text-muted)',
                        transition: 'all 0.2s ease',
                        borderRadius: '50%'
                    }}
                >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                        <line x1="12" y1="17" x2="12.01" y2="17"></line>
                    </svg>
                </button>
            </div>

            {/* Educational Banner & Explanation (Expanded when help icon is clicked) */}
            {isExpanded && (
                <div className="vpn-info-box">
                    <div className="vpn-info-header">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                        <h4>What is a VPN connection & why do we need it?</h4>
                    </div>
                    <p className="vpn-info-text">
                        A <strong>Virtual Private Network (VPN)</strong> establishes a secure, end-to-end encrypted connection (tunnel) between your remote devices (smartphones, laptops, tablets) and your home server over the public internet.
                    </p>
                    <p className="vpn-info-text">
                        <strong>Why it's essential for your Homelab:</strong> Exposing homelab web dashboards or administrative ports directly to the open internet exposes your network to automated port scanners, brute-force attacks, and security vulnerabilities. A VPN allows you to access all your self-hosted services safely from anywhere in the world as if you were connected directly to your home Wi-Fi, without opening risky incoming router ports.
                    </p>

                    <div className="vpn-tailscale-intro">
                        <div className="vpn-info-header" style={{ marginTop: '12px', marginBottom: '12px' }}>
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                            </svg>
                            <h4>Introducing Tailscale</h4>
                        </div>
                        <p className="vpn-info-text">
                            <strong>Tailscale</strong> is a zero-config mesh VPN built on top of the modern, high-performance <strong>WireGuard®</strong> protocol. Instead of routing all your network traffic through a slow central bottleneck server, Tailscale establishes direct peer-to-peer encrypted connections between your devices with zero complex firewall configuration.
                        </p>
                    </div>
                </div>
            )}

            {/* Interactive Options Grid */}
            <div className="domain-options-grid" style={{ marginTop: '8px' }}>

                {/* Solution 1: Tailscale Only */}
                <div
                    className={`domain-card ${mode === 'tailscale' ? 'selected' : ''}`}
                    onClick={() => handleSelect('tailscale')}
                >
                    <div className="domain-card-header">
                        <div className="domain-card-name">
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path>
                                </svg>
                                <span>Tailscale Only</span>
                            </div>
                            <span className="vpn-card-badge badge-cloud">Cloud Managed</span>
                        </div>
                        <div className="domain-card-radio" />
                    </div>

                    <p style={{ fontSize: '0.88rem', color: 'var(--text-muted)', margin: 0 }}>
                        Connects your homelab nodes using the official hosted Tailscale control plane (<code>controlplane.tailscale.com</code>).
                    </p>

                    <ul className="domain-details-list">
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span><strong>Hassle-Free Setup:</strong> Managed official cloud coordination server with zero server maintenance.</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span><strong>Standard Authentication:</strong> Login via Google, GitHub, Microsoft, or Apple SSO accounts.</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span><strong>Automatic Features:</strong> Built-in MagicDNS, key rotation, and web admin dashboard out of the box.</span>
                        </li>
                    </ul>
                </div>

                {/* Solution 2: Tailscale + Headscale */}
                <div
                    className={`domain-card ${mode === 'headscale' ? 'selected' : ''}`}
                    onClick={() => handleSelect('headscale')}
                >
                    <div className="domain-card-header">
                        <div className="domain-card-name">
                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect>
                                    <rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect>
                                    <line x1="6" y1="6" x2="6.01" y2="6"></line>
                                    <line x1="6" y1="18" x2="6.01" y2="18"></line>
                                </svg>
                                <span>Tailscale + Headscale</span>
                            </div>
                            <span className="vpn-card-badge badge-selfhosted">Self Hosted</span>
                        </div>
                        <div className="domain-card-radio" />
                    </div>

                    <p style={{ fontSize: '0.88rem', color: 'var(--text-muted)', margin: 0 }}>
                        Uses the Tailscale VPN client paired with an open-source, self-hosted <strong>Headscale</strong> coordination server running on your homelab.
                    </p>

                    <ul className="domain-details-list">
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span><strong>100% Data Sovereignty:</strong> Complete control over your network without relying on third-party cloud servers.</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span><strong>Custom Infrastructure:</strong> Tailscale nodes coordinate directly with your Headscale instance.</span>
                        </li>
                        <li>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
                            <span><strong>Requires Public Domain:</strong> Requires setting up a public domain name for Headscale endpoint routing.</span>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    );
}
