import { useState } from "react";
import toast from "react-hot-toast";
import { UserApiClient } from "../../api";
import { useHomelabStatus } from "../../providers/HomelabStatusProvider";

export default function StepAdminUser() {
    const [username, setUsername] = useState("");
    const [displayName, setDisplayName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { refreshAdminStatus } = useHomelabStatus();

    async function handleSubmit(e: React.FormEvent) {
        e.preventDefault();

        if (!username.trim()) {
            toast.error("Username is required");
            return;
        }

        if (!email.trim() || !email.includes("@")) {
            toast.error("Valid email is required");
            return;
        }

        if (!password || password.length < 4) {
            toast.error("Password must be at least 4 characters");
            return;
        }

        try {
            setIsSubmitting(true);
            await UserApiClient.registerUser({
                username: username.trim(),
                display_name: displayName.trim() || username.trim(),
                email: email.trim(),
                password: password,
                isAdmin: true,
            });

            toast.success("Administrator created successfully!");
            refreshAdminStatus();
        } catch (err: any) {
            console.error("Failed to register admin user", err);
            toast.error(err.message || "Failed to create administrator account");
        } finally {
            setIsSubmitting(false);
        }
    }

    return (
        <div className="wizard-card">
            <div className="wizard-card-header" style={{ textAlign: "center", alignItems: "center" }}>
                <div
                    style={{
                        width: "60px",
                        height: "60px",
                        borderRadius: "50%",
                        background: "var(--primary-gradient)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        boxShadow: "0 0 20px var(--primary-glow)",
                        marginBottom: "6px",
                    }}
                >
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)" strokeWidth="2">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                        <circle cx="12" cy="7" r="4" />
                    </svg>
                </div>
                <h2 className="wizard-card-title">Create Primary Administrator</h2>
                <p className="wizard-card-description" style={{ maxWidth: "600px" }}>
                    Network setup is completed! Next, set up your primary admin user for Authelia authentication and homelab access.
                </p>
            </div>

            <form onSubmit={handleSubmit} className="registration-form-container">
                <div className="form-group">
                    <label htmlFor="username">Username *</label>
                    <input
                        id="username"
                        type="text"
                        className="form-input"
                        placeholder="e.g. admin"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        disabled={isSubmitting}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="displayName">Display Name</label>
                    <input
                        id="displayName"
                        type="text"
                        className="form-input"
                        placeholder="e.g. System Administrator (defaults to username)"
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        disabled={isSubmitting}
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="email">Email Address *</label>
                    <input
                        id="email"
                        type="email"
                        className="form-input"
                        placeholder="admin@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        disabled={isSubmitting}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="password">Password *</label>
                    <input
                        id="password"
                        type="password"
                        className="form-input"
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        disabled={isSubmitting}
                        required
                    />
                </div>

                <div style={{ marginTop: "12px", textAlign: "center" }}>
                    <button
                        type="submit"
                        disabled={isSubmitting}
                        className="btn-start-homelab"
                        style={{ width: "100%", justifyContent: "center" }}
                    >
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                            <circle cx="8.5" cy="7" r="4" />
                            <line x1="20" y1="8" x2="20" y2="14" />
                            <line x1="23" y1="11" x2="17" y2="11" />
                        </svg>
                        <span>{isSubmitting ? "Creating Admin User..." : "Start Homelab"}</span>
                    </button>
                </div>
            </form>
        </div>
    );
}
