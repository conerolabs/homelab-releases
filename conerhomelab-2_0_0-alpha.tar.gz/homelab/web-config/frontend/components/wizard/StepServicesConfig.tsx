import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { useConfig, useConfigActions } from "../../providers/ConfigProvider";
import ServiceCard from "../ServiceCard";
import { ConfigApiClient, DepsApiClient, StatusApiClient } from "../../api";
import { useConsoleModal } from "../../providers/ConsoleModalProvider";
import { useNavigate } from "react-router";
import { useLoadingModal } from "../../providers/LoadingModalProvider";

export default function StepServicesConfig() {
    const { config, getDockerServices, getSystemServices } = useConfig();
    const { setService, saveConfig } = useConfigActions();
    const navigate = useNavigate();

    const { openConsole } = useConsoleModal();

    const dockerServices = getDockerServices();
    const systemServices = getSystemServices();
    const allServices = [...systemServices, ...dockerServices];

    // Filter required services (services marked as required or system core services)
    const requiredServices = allServices.filter(s => s.required || s.enabled);
    const [requiredConfigured, setRequiredConfigured] = useState(false);
    const [misconfiguredServices, setMisconfiguredServices] = useState<string[]>([]);

    useEffect(() => {
        toast.promise(saveConfig(), {
            loading: 'Saving configuration...',
            success: 'Configuration saved successfully!',
            error: 'Failed to save configuration.'
        });
    }, []);

    useEffect(() => {
        toast.promise(async () => {
            const { installed: dockerInstalled, running: dockerRunning } = await DepsApiClient.getDepStatus('docker')
            if (!dockerInstalled || !dockerRunning) {
                console.log("Docker not installed or not running, cannot configure services");
                return Promise.reject("Docker not installed or not running");
            }
        }, {
            loading: "Checking Docker status...",
            success: "Docker is running!",
            error: "Docker is not running. Please start it with 'sudo systemctl start docker' and refresh the page",
        });

        StatusApiClient.getServicesStatus()
            .then(r => {
                const misconfig = r.config.filter(c => c.success === false).map(c => c.name);
                setMisconfiguredServices(misconfig);
                setRequiredConfigured(
                    !misconfig.some(s => requiredServices.map(rs => rs.name).includes(s)));
            });
    }, []);

    useEffect(() => {
        window.scroll({
            top: 0,
            behavior: 'instant'
        });
    }, []);

    const [isConfiguringAll, setIsConfiguringAll] = useState(false);

    function handleConfigureAllRequired() {
        try {
            setIsConfiguringAll(true);
            // Enable all required services in config state
            requiredServices.forEach((service) => {
                if (!service.enabled) {
                    setService({ ...service, enabled: true });
                }
            });
            toast.success("All required services configured & enabled!");
        } catch (e) {
            console.error("Failed to configure required services", e);
            toast.error("Error configuring required services");
        } finally {
            setIsConfiguringAll(false);
        }
    }

    function handleLaunchDashboard() {
        if (!config) return;
        toast.promise(ConfigApiClient.saveConfig(config), {
            loading: "Saving homelab configuration...",
            success: "Homelab configuration saved! Starting services...",
            error: "Failed to save homelab configuration.",
        }).then(() => {
            openConsole({ action: "deploy" }, () => {
                navigate("/dashboard");
            });
        });
    }

    if (!config) {
        return (
            <div className="wizard-card" style={{ textAlign: "center", padding: "40px" }}>
                <p>Loading services configuration...</p>
            </div>
        );
    }

    return (
        <div className="wizard-card">
            <div className="wizard-card-header">
                <div className="wizard-services-header">
                    <div>
                        <h2 className="wizard-card-title">
                            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2">
                                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                            </svg>
                            Configure Homelab Services
                        </h2>
                        <p className="wizard-card-description">
                            Admin user created! Configure your required homelab services below. Once all required services are enabled, you can start the dashboard.
                        </p>
                    </div>

                    <div className="wizard-services-actions">
                        <button
                            disabled={isConfiguringAll || requiredConfigured}
                            onClick={handleConfigureAllRequired}
                            className="btn btn-secondary"
                        >
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <polyline points="9 11 12 14 22 4" />
                                <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
                            </svg>
                            <span>{requiredConfigured ? "All Required Configured" : "Configure All Required"}</span>
                        </button>

                        <button
                            disabled={!requiredConfigured}
                            onClick={handleLaunchDashboard}
                            className="btn btn-primary btn-lg"
                        >
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <polygon points="5 3 19 12 5 21 5 3" />
                            </svg>
                            <span>Launch Dashboard</span>
                        </button>
                    </div>
                </div>
            </div>

            {/* Services Cards List */}
            <div className="services-grid expanded" style={{ marginTop: "10px" }}>
                {allServices.filter(
                    s => s.type === 'docker' || (s.type === 'host' && !s.enabled)
                ).map((service) => {
                    const version = config.envs.filter((e) => service.envs.includes(e.name))
                        .filter(e => e.name.includes('VERSION'));

                    return <ServiceCard service={service} enableMonitor={false} envs={version} systemVars={new Set()} key={service.name} missingConfig={misconfiguredServices.includes(service.name)} />;
                })}
            </div>
        </div>
    );
}
