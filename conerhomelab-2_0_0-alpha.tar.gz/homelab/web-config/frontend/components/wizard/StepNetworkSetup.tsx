import type { DomainMode } from "./DomainConfigCard";
import DomainConfigCard from "./DomainConfigCard";
import VpnConfigCard from "./VpnConfigCard";
import DnsConfigCard, { type DnsMode, DNS_RESOLVER_OPTIONS } from "./DnsConfigCard";
import { useHomelabStatus } from "../../providers/HomelabStatusProvider";
import { useConfig } from "../../providers/ConfigProvider";
import type { VpnMode } from "../../../commons/dto";
import { useEffect, useState } from "react";
import { usePromptModal } from "../../providers/PromptModalProvider";
import { useConsoleTask } from "../../hooks/useConsoleTask";
import { DepsApiClient } from "../../api";

export default function StepNetworkSetup() {
    const { domain, vpn, dns, setVpn, setDomain, setDns } = useHomelabStatus();
    const { config } = useConfig();

    const [vpnMode, setVpnMode] = useState<VpnMode>(vpn);
    const [currentDomain, setCurrentDomain] = useState<string>(domain || 'local');
    const [domainMode, setDomainMode] = useState<DomainMode>((domain && domain !== 'local') ? 'public' : 'local');

    // Initialize DNS resolver state
    const unboundService = config.services.find(s => s.name === 'unbound');

    const determineInitialDnsMode = (): DnsMode => {
        if (unboundService?.enabled || dns?.includes('127.0.0.1')) {
            return 'unbound';
        }
        const match = DNS_RESOLVER_OPTIONS.find(opt => opt.id !== 'unbound' && opt.id !== 'custom' && dns.includes(opt.servers.split(';')[0].trim()));
        if (match) {
            return match.id;
        }
        if (dns) {
            return 'custom';
        }
        return 'cloudflare';
    };

    const [dnsMode, setDnsMode] = useState<DnsMode>(determineInitialDnsMode);
    const [customDns, setCustomDns] = useState<string>(dns);

    const { promptInput } = usePromptModal();
    const { runConsoleTask } = useConsoleTask();

    const onVpnSelected = async (mode: VpnMode) => {
        setVpnMode(mode);
        if (mode === 'headscale' && (!currentDomain || currentDomain === 'local')) {
            await onDomainSelected('public');
        }
        else if (mode === 'tailscale') {
            console.log("You can chose both local domain or public domain when using just tailscale");
        }
    };

    const onDomainSelected = async (mode: DomainMode) => {
        setDomainMode(mode);
        if (mode === 'local') {
            console.log("Domain is local, no need to enter a domain name");
            setCurrentDomain('local');
            return;
        }
        const domain = await promptInput({
            title: 'Enter your domain name',
            message: 'You need a public domain if you want to use Headscale or automatic Let\'s Encrypt/ZeroSSL certificates. Furthermore you will need to configure Dynamic DNS for your domain if you don\'t have a static IP address.',
            inputDefaultValue: currentDomain !== 'local' ? currentDomain : '',
            inputPlaceholder: 'your-domain.com',
            inputLabel: 'Domain Name',
            inputOnValidate: validateDomain,
            confirmText: 'Confirm',
            cancelText: 'Cancel'
        }) as string;
        console.log("Domain is: ", domain);
        setCurrentDomain(domain);
    };

    const handleNext = async () => {
        console.log("Current domain: ", currentDomain, "VPN mode: ", vpnMode, "DNS mode: ", dnsMode);

        // Save DNS configuration
        let targetDnsServers = '1.1.1.1;1.0.0.1';
        if (dnsMode === 'unbound') {
            targetDnsServers = '127.0.0.1#5335';
            const unboundStatus = await DepsApiClient.getDepStatus('unbound');
            if (!unboundStatus.installed) {
                await runConsoleTask(
                    {
                        service: 'unbound',
                        action: 'install',
                    },
                    () => { setDns(targetDnsServers) }
                );
                return;
            }
        } else if (dnsMode === 'custom') {
            targetDnsServers = customDns.trim();
        } else {
            const selectedOpt = DNS_RESOLVER_OPTIONS.find(opt => opt.id === dnsMode);
            if (selectedOpt) {
                targetDnsServers = selectedOpt.servers.replace(/\s*;\s*/g, ';');
            }
        }
        setDns(targetDnsServers);

        if (currentDomain) {
            setDomain(currentDomain);
            if (vpnMode === 'headscale') {
                const headscaleStatus = await DepsApiClient.getDepStatus('headscale');
                if (!headscaleStatus.installed) {
                    runConsoleTask(
                        {
                            service: 'headscale',
                            action: 'install',
                        },
                        () => { setVpn('headscale'); }
                    );
                    return;
                }
                console.log("Headscale is already installed. Enabling it...");
                setVpn('headscale');
            }
            else {
                setVpn(vpnMode);
            }
        }
    };

    function isValidDomain(domain: string) {
        const regex = /^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
        return regex.test(domain);
    }

    function validateDomain(domain: string) {
        return isValidDomain(domain) || 'Please enter a valid domain name';
    }

    const validateStep = () => {
        if (!currentDomain || (vpnMode !== 'tailscale' && vpnMode !== 'headscale')) {
            return false;
        }
        if (vpnMode === 'headscale' && currentDomain === 'local') {
            return false;
        }
        if (currentDomain !== 'local' && !isValidDomain(currentDomain)) {
            console.log("Invalid domain: ", currentDomain);
            return false;
        }
        if (dnsMode === 'custom' && !customDns.trim()) {
            return false;
        }
        return true;
    };

    useEffect(() => {
        window.scroll({
            top: 0,
            behavior: 'instant'
        });
    }, []);

    return (
        <div className="wizard-card">
            <div className="wizard-card-header">
                <h2 className="wizard-card-title">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="16" y="16" width="6" height="6" rx="1" />
                        <rect x="2" y="16" width="6" height="6" rx="1" />
                        <rect x="9" y="2" width="6" height="6" rx="1" />
                        <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" />
                        <path d="M12 12V8" />
                    </svg>
                    Network Setup
                </h2>
                <p className="wizard-card-description">
                    System dependencies are installed! Next, configure your VPN connection solution, domain name, and DNS resolver for your homelab.
                </p>
            </div>

            {/* VPN Configuration Section */}
            <VpnConfigCard selectedMode={vpnMode} onSelectMode={onVpnSelected} />

            {/* Domain Configuration Choice */}
            <DomainConfigCard
                selectedMode={domainMode}
                onSelectMode={onDomainSelected}
                domain={currentDomain}
                disabledMode={vpnMode === 'headscale' ? 'local' : undefined}
            />

            {/* DNS Resolver Configuration Section */}
            <DnsConfigCard
                selectedMode={dnsMode}
                customDnsValue={customDns}
                onSelectMode={(mode) => setDnsMode(mode)}
                onCustomDnsChange={(val) => setCustomDns(val)}
            />

            {/* Button to proceed to the next step */}
            <button className={`wizard-card-next-button ${validateStep() ? '' : 'disabled'}`} onClick={handleNext}>
                Next
            </button>

        </div>
    );
}