import type { DomainMode } from "./DomainConfigCard";
import DomainConfigCard from "./DomainConfigCard";
import { useHomelabStatus } from "../../providers/HomelabStatusProvider";
import { useConfigActions } from "../../providers/ConfigProvider";
import { useState } from "react";

export default function StepNetworkSetup() {
    const { domain } = useHomelabStatus();
    const [currentDomain, setCurrentDomain] = useState<string>(domain ?? 'local');
    const { setEnv } = useConfigActions();

    const domainMode: DomainMode = (domain && domain !== 'local') ? 'public' : 'local';

    const handleNext = () => {
        console.log("Current domain: ", currentDomain);
        if (currentDomain) {
            setEnv({ name: 'DOMAIN', value: currentDomain });
        }
    };

    return (
        <div className="wizard-card">
            <div className="wizard-card-header">
                <h2 className="wizard-card-title">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="16" y="16" width="6" height="6" rx="1" />
                        <rect x="2" y="16" width="6" height="6" rx="1" />
                        <rect x="9" y="2" width="6" height="6" rx="1" />
                        <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" />
                        <path d="M12 12V8" />
                    </svg>
                    Network Setup
                </h2>
                <p className="wizard-card-description">
                    Here you can configure the domain name for your homelab.
                </p>
            </div>

            {/* Domain Configuration Choice */}
            <DomainConfigCard selectedMode={domainMode} onConfirm={setCurrentDomain} />
            {/* Add a button to go to the next step style it properly*/}
            <button className="wizard-card-next-button" onClick={handleNext}>
                Next
            </button>

        </div>
    );
}
