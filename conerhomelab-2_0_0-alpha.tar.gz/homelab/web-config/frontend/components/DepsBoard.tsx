import type { DependencyStatus } from "../../commons/dto";
import { useHomelabStatus } from "../providers/HomelabStatusProvider";
import DependencyCard from "./DependencyCard";

type DepsBoardProps = {
    deps: DependencyStatus[];
}

export default function DepsBoard({ deps }: DepsBoardProps) {

    const { refreshDepsStatus, missingDeps, notRunningDeps } = useHomelabStatus();
    const readyCount = deps.filter(d => d.installed && (d.running ?? true)).length;

    return (
        <div className="install-section">
            <div className="deps-section-header">
                <div className="deps-section-title-group">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                        <line x1="8" y1="21" x2="16" y2="21"></line>
                        <line x1="12" y1="17" x2="12" y2="21"></line>
                    </svg>
                    <h3 className="deps-section-title">System Dependencies Status</h3>
                </div>
                {deps.length > 0 && (
                    <div className={`deps-status-counter ${readyCount === deps.length ? 'all-installed' : ''}`}>
                        <span className="deps-status-dot"></span>
                        <span>{readyCount} of {deps.length} Ready</span>
                    </div>
                )}
            </div>
            <div className="deps-board">
                {deps.map((dep) => {
                    const running = notRunningDeps.includes(dep.name) ? false : (dep.running !== undefined ? true : undefined);
                    const installed = !missingDeps.includes(dep.name);
                    return (
                        <DependencyCard key={dep.name} dep={{ ...dep, running, installed }} onActionSuccess={refreshDepsStatus} />
                    );
                })}
            </div>
        </div>
    );
}