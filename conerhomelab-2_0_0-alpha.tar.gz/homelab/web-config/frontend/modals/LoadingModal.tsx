import React from "react";

export type LoadingModalProps = {
  isOpen: boolean;
  title?: string;
  message?: string;
  subtext?: string;
  progress?: number | null; // Percentage 0-100 or null for indeterminate
  cancelable?: boolean;
  onCancel?: () => void;
  icon?: 'spinner' | 'database' | 'cloud' | 'sync' | 'shield' | React.ReactNode;
};

export default function LoadingModal({
  isOpen,
  title = "Loading Data...",
  message = "Please wait while we fetch the latest information.",
  subtext,
  progress = null,
  cancelable = false,
  onCancel,
  icon = "spinner",
}: LoadingModalProps) {
  if (!isOpen) return null;

  const renderIcon = () => {
    if (typeof icon !== "string") return icon;
    switch (icon) {
      case "database":
        return (
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <ellipse cx="12" cy="5" rx="9" ry="3" />
            <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
            <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
          </svg>
        );
      case "cloud":
        return (
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" />
          </svg>
        );
      case "sync":
        return (
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="loading-icon-spin">
            <path d="M21.5 2v6h-6M2.5 22v-6h6" />
            <path d="M2 11.5a10 10 0 0 1 18.8-4.3L21.5 8M22 12.5a10 10 0 0 1-18.8 4.3L2.5 16" />
          </svg>
        );
      case "shield":
        return (
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          </svg>
        );
      case "spinner":
      default:
        return (
          <svg className="loading-spinner-svg" viewBox="0 0 50 50">
            <circle
              className="loading-spinner-track"
              cx="25"
              cy="25"
              r="20"
              fill="none"
              strokeWidth="4"
            />
            <circle
              className="loading-spinner-head"
              cx="25"
              cy="25"
              r="20"
              fill="none"
              strokeWidth="4"
            />
          </svg>
        );
    }
  };

  return (
    <div className={`modal-overlay ${isOpen ? "open" : ""}`} role="dialog" aria-modal="true" aria-busy="true">
      <div className="modal-container loading-modal-container">
        <div className="loading-modal-content">
          <div className="loading-spinner-wrapper">
            <div className="loading-glow-ring" />
            {renderIcon()}
          </div>

          <div className="loading-text-group">
            <h3 className="loading-modal-title">{title}</h3>
            {message && <p className="loading-modal-message">{message}</p>}
            {subtext && <span className="loading-modal-subtext">{subtext}</span>}
          </div>

          {progress !== null && (
            <div className="loading-progress-container">
              <div className="loading-progress-bar">
                <div
                  className="loading-progress-fill"
                  style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
                />
              </div>
              <span className="loading-progress-text">{Math.round(progress)}%</span>
            </div>
          )}

          {cancelable && onCancel && (
            <button
              type="button"
              className="btn btn-secondary loading-cancel-btn"
              onClick={onCancel}
            >
              Cancel
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
