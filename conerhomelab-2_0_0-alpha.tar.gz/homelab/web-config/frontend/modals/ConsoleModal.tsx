import { useEffect, useRef, useState } from "react";
import { ConsoleApiClient, type ConsoleMessage } from "../api";
import { useTimer } from "../hooks/useTimer";
import { AnsiUp } from 'ansi_up';
import { ConsoleActions, type ConsoleJob } from "../providers/ConsoleModalProvider";

type ConsoleModalProps = {
  isOpen: boolean;
  job: ConsoleJob | null;
  onClose?: () => void;
  onSuccess?: (() => void) | null;
}

type LogLine = {
  key: number;
  type: 'system' | 'log' | 'error';
  text: string;
}

export default function ConsoleModal({ isOpen, job, onClose, onSuccess }: ConsoleModalProps) {

  const [title, setTitle] = useState<string>('');
  const [logLines, setLogLines] = useState<LogLine[]>([]);
  const [isSuccess, setIsSuccess] = useState(false);
  const { remainingTime, startTimer, clearTimer } = useTimer()
  const bottomRef = useRef<HTMLDivElement>(null);
  const scrollToBottom = () => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }

  const ansiUp = new AnsiUp();

  function onConsoleMessage(jobname: string) {
    return function (this: EventSource, event: MessageEvent) {
      let data: ConsoleMessage
      try {
        data = JSON.parse(event.data)
      } catch {
        data = { type: 'log', text: event.data }
      }
      switch (data.type) {
        case 'log':
          setLogLines(prev => [...prev, { key: prev.length, type: 'log', text: data.text }]);
          break;
        case 'error':
          setLogLines(prev => [...prev, { key: prev.length, type: 'error', text: data.text }]);
          break;
        case 'done':
          const code = data.code ?? 'unknown';
          setLogLines(prev => [...prev, { key: prev.length, type: 'system', text: `${jobname} completed. Process exited with code: ${code}` }]);
          this.close();
          if (code === 0) setIsSuccess(true);
          startTimer(10000, closeOnSuccess)
          break;
        default:
          setLogLines(prev => [...prev, { key: prev.length, type: 'error', text: `Unexpected message type: ${JSON.stringify(data)}` }]);
          break;
      }
    }
  }

  function onConnectionError(this: EventSource, event: Event) {
    console.log('ConsoleModal - Connection error', event);
    setLogLines(prev => [...prev, { key: prev.length, type: 'error', text: 'Connection to log stream lost.' }]);
    this.close();
  }

  useEffect(() => {
    if (!job?.action) {
      setLogLines(prev => [...prev, { key: prev.length, type: 'error', text: 'No job selected' }]);
      return;
    }

    const jobname = ConsoleActions[job.action].jobName(job);
    const initialText = ConsoleActions[job.action].initialText(job);
    setTitle(jobname ?? 'No service selected');
    setLogLines([{ key: 0, type: 'system', text: initialText }]);

    const eventSource = ConsoleApiClient.executeAction(job, onConsoleMessage(jobname), onConnectionError)

    return () => {
      setLogLines([]);
      eventSource?.close();
      clearTimer();
      setIsSuccess(false);
    }
  }, [job])

  function closeModal() {
    clearTimer();
    setLogLines([]);
    setIsSuccess(false);
    onClose?.();
  }

  function closeOnSuccess() {
    onSuccess?.();
    closeModal();
  }

  useEffect(() => {
    scrollToBottom();
  }, [logLines])

  return (
    <div className={`modal-overlay ${isOpen ? 'open' : ''}`}>
      <div className="modal-container">
        <div className="modal-header">
          <h2>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6366f1" strokeWidth="2">
              <polyline points="4 17 10 11 4 5" />
              <line x1="12" y1="19" x2="20" y2="19" />
            </svg>
            <span>{title}</span>
          </h2>
          <button className="modal-close-btn" onClick={isSuccess ? closeOnSuccess : closeModal}>
            <svg viewBox="0 0 24 24">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        <div className="console-body">
          {logLines.map((line, index) => (
            <div key={index} className={`console-line ${line.type}`} dangerouslySetInnerHTML={{ __html: ansiUp.ansi_to_html(line.text) }} />
          ))}
          <div ref={bottomRef} />
        </div>
        <div className="modal-footer">
          {remainingTime > 0 &&
            <button className="btn btn-secondary" onClick={() => clearTimer()}>
              Don't close the window
            </button>
          }
          <button className="btn btn-primary" onClick={isSuccess ? closeOnSuccess : closeModal}>
            <svg viewBox="0 0 24 24">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
            Close {remainingTime > 0 ? `(${Math.round(remainingTime / 1000)}s)` : ''}
          </button>
        </div>
      </div>
    </div>
  )
}