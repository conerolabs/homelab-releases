import { useEffect, useRef, useState, type ReactNode } from "react";

export type PromptField = {
  name: string;
  label?: string;
  type?: 'text' | 'password' | 'number' | 'email';
  placeholder?: string;
  defaultValue?: string;
  required?: boolean;
  hint?: string;
  onValidate?: (value: string) => boolean | string;
};

export type PromptModalOptions = {
  title?: string;
  message?: string | ReactNode;
  icon?: 'key' | 'lock' | 'shield' | 'info' | 'warning' | ReactNode;
  fields?: PromptField[];
  inputType?: 'text' | 'password' | 'number' | 'email';
  inputLabel?: string;
  inputPlaceholder?: string;
  inputDefaultValue?: string;
  inputOnValidate?: (value: string | number) => boolean | string;
  confirmText?: string;
  cancelText?: string;
  confirmVariant?: 'primary' | 'success' | 'danger';
};

export type PromptModalProps = PromptModalOptions & {
  isOpen: boolean;
  errorMessage?: string | null;
  onClose: () => void;
  onSubmit: (values: Record<string, string>) => void | Promise<void>;
};

export default function PromptModal({
  isOpen,
  title = "Information Required",
  message,
  icon = "lock",
  fields,
  inputType = "text",
  inputLabel,
  inputPlaceholder,
  inputDefaultValue = "",
  inputOnValidate,
  confirmText = "Proceed",
  cancelText = "Cancel",
  confirmVariant = "primary",
  errorMessage: externalError = null,
  onClose,
  onSubmit,
}: PromptModalProps) {
  // Normalize fields: if no fields prop, construct a single field array
  const effectiveFields: PromptField[] = fields && fields.length > 0 ? fields : [
    {
      name: "value",
      label: inputLabel ?? (inputType === "password" ? "Password" : "Value"),
      type: inputType,
      placeholder: inputPlaceholder ?? (inputType === "password" ? "Enter password..." : "Enter value..."),
      defaultValue: inputDefaultValue,
      required: true,
      onValidate: inputOnValidate,
    }
  ];

  const [formValues, setFormValues] = useState<Record<string, string>>({});
  const [showPasswordMap, setShowPasswordMap] = useState<Record<string, boolean>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [internalError, setInternalError] = useState<string | null>(null);

  const firstInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      const initialValues: Record<string, string> = {};
      effectiveFields.forEach(field => {
        initialValues[field.name] = field.defaultValue ?? "";
      });
      setFormValues(initialValues);
      setShowPasswordMap({});
      setInternalError(null);
      setIsSubmitting(false);

      // Autofocus first input after animation
      setTimeout(() => {
        firstInputRef.current?.focus();
        firstInputRef.current?.select();
      }, 50);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleInputChange = (name: string, val: string) => {
    setFormValues(prev => ({ ...prev, [name]: val }));
    if (internalError) setInternalError(null);
  };

  const togglePasswordVisibility = (fieldName: string) => {
    setShowPasswordMap(prev => ({ ...prev, [fieldName]: !prev[fieldName] }));
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isSubmitting) return;

    // Validate required fields
    for (const field of effectiveFields) {
      if (field.required && !formValues[field.name]?.trim()) {
        setInternalError(`Please enter a valid ${field.label || field.name}.`);
        return;
      }
    }

    // Validate fields with onValidate callback
    for (const field of effectiveFields) {
      if (field.onValidate) {
        const result = field.onValidate(formValues[field.name]);
        if (typeof result === "string" && result.trim() !== "") {
          setInternalError(result);
          return;
        }
      }
    }

    try {
      setIsSubmitting(true);
      setInternalError(null);
      await onSubmit(formValues);
    } catch (err: any) {
      setInternalError(err?.message || "An error occurred. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Escape" && !isSubmitting) {
      onClose();
    }
  };

  const renderIcon = () => {
    if (typeof icon !== "string") return icon;
    switch (icon) {
      case "key":
        return (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 2l-2 2m-1.5 1.5L4 19l-2 2 2 2 2-2 3.5-3.5M15 4.5l3 3" />
          </svg>
        );
      case "shield":
        return (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          </svg>
        );
      case "info":
        return (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="16" x2="12" y2="12" />
            <line x1="12" y1="8" x2="12.01" y2="8" />
          </svg>
        );
      case "warning":
        return (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
            <line x1="12" y1="9" x2="12" y2="13" />
            <line x1="12" y1="17" x2="12.01" y2="17" />
          </svg>
        );
      case "lock":
      default:
        return (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
            <path d="M7 11V7a5 5 0 0 1 10 0v4" />
          </svg>
        );
    }
  };

  const activeError = externalError || internalError;
  const btnClass = confirmVariant === "danger" ? "btn-danger" : confirmVariant === "success" ? "btn-success" : "btn-primary";

  return (
    <div className={`modal-overlay ${isOpen ? "open" : ""}`} onKeyDown={handleKeyDown}>
      <div className="modal-container prompt-modal-container" role="dialog" aria-modal="true">
        <div className="modal-header">
          <h2>
            {renderIcon()}
            <span>{title}</span>
          </h2>
          <button className="modal-close-btn" onClick={onClose} disabled={isSubmitting} type="button" aria-label="Close modal">
            <svg viewBox="0 0 24 24">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        <div className="prompt-modal-body">
          {message && <div className="prompt-modal-message">{message}</div>}

          {activeError && (
            <div className="prompt-modal-error">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
              <span>{activeError}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="prompt-modal-form">
            {effectiveFields.map((field, idx) => {
              const isPasswordType = field.type === "password";
              const isShowingPassword = showPasswordMap[field.name];
              const actualInputType = isPasswordType ? (isShowingPassword ? "text" : "password") : (field.type || "text");

              return (
                <div key={field.name} className="prompt-modal-field">
                  {field.label && <label className="prompt-modal-label" htmlFor={`prompt-field-${field.name}`}>{field.label}</label>}
                  <div className="prompt-modal-input-wrapper">
                    <input
                      id={`prompt-field-${field.name}`}
                      ref={idx === 0 ? firstInputRef : undefined}
                      type={actualInputType}
                      className={`prompt-modal-input ${isPasswordType ? "has-toggle" : ""}`}
                      placeholder={field.placeholder}
                      value={formValues[field.name] || ""}
                      onChange={e => handleInputChange(field.name, e.target.value)}
                      disabled={isSubmitting}
                      required={field.required}
                    />
                    {isPasswordType && (
                      <button
                        type="button"
                        className="prompt-modal-toggle-btn"
                        onClick={() => togglePasswordVisibility(field.name)}
                        tabIndex={-1}
                        title={isShowingPassword ? "Hide password" : "Show password"}
                      >
                        {isShowingPassword ? (
                          <svg viewBox="0 0 24 24">
                            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
                            <line x1="1" y1="1" x2="23" y2="23" />
                          </svg>
                        ) : (
                          <svg viewBox="0 0 24 24">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                            <circle cx="12" cy="12" r="3" />
                          </svg>
                        )}
                      </button>
                    )}
                  </div>
                  {field.hint && <span className="prompt-modal-hint">{field.hint}</span>}
                </div>
              );
            })}
          </form>
        </div>

        <div className="modal-footer">
          <button type="button" className="btn btn-secondary" onClick={onClose} disabled={isSubmitting}>
            {cancelText}
          </button>
          <button type="button" className={`btn ${btnClass}`} onClick={() => handleSubmit()} disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <svg className="btn-spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" strokeDasharray="32" strokeDashoffset="12" />
                </svg>
                Processing...
              </>
            ) : (
              <>
                <svg viewBox="0 0 24 24">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
                {confirmText}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
