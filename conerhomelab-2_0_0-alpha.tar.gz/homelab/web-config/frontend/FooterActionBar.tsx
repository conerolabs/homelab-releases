type FooterActionBarProps = {
    activeCount: number,
    totalCount: number,
    onSave: () => void,
    onDeploy: () => void
}

export default function FooterActionBar({ activeCount, totalCount, onSave, onDeploy }: FooterActionBarProps) {
    return (
        <div className="action-bar">
            <div className="action-info">
                <div className="status-summary">
                    Active Services: <strong>{activeCount} / {totalCount}</strong>
                </div>
            </div>
            <div className="btn-group">
                <button className="btn btn-secondary" onClick={onSave}>
                    <svg viewBox="0 0 24 24">
                        <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
                        <polyline points="17 21 17 13 7 13 7 21" />
                        <polyline points="7 3 7 8 15 8" />
                    </svg>
                    Save Setup
                </button>
                <button className="btn btn-success" onClick={onDeploy}>
                    <svg viewBox="0 0 24 24">
                        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
                    </svg>
                    Deploy Changes
                </button>
            </div>
        </div>
    )
}