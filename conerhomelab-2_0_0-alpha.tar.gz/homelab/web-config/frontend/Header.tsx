import { useConfig } from "./providers/ConfigProvider"
import { useSearchContext } from "./providers/SearchContextProvider";
import { useTheme } from "./providers/ThemeProvider";

export default function Header() {

    const { config } = useConfig();
    const homelabVersion = config.envs.find(e => e.name === 'HOMELAB_VERSION')?.value ?? 'unknown'
    const serverName = config.envs.find(e => e.name === 'SERVER_NAME')?.value ?? 'unknown'

    const { searchText, setSearchText } = useSearchContext();
    const { toggleTheme } = useTheme();

    const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSearchText(event.target.value);
    }

    return (
        <header>
            <div className="logo-container">
                <div className="logo-icon">
                    <img src="frontend/images/logo.svg" alt="Conerolabs Logo" width="300" height="200" />
                </div>
                <div className="logo-text">
                    <h1 id="homelabTitle">Conero Homelab v{homelabVersion}</h1>
                    <p id="homelabSubtitle">@{serverName}</p>
                </div>
            </div>

            <div className="search-filter-wrapper">
                <input type="text" id="searchInput" className="search-input" placeholder="Search services..." onChange={handleSearchChange} value={searchText} />
                <button className="theme-toggle" title="Toggle dark/light theme" onClick={toggleTheme}>
                    <svg className="theme-icon-dark" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                    </svg>
                    <svg className="theme-icon-light" viewBox="0 0 24 24" fill="currentColor">
                        <circle cx="12" cy="12" r="5" />
                        <line x1="12" y1="1" x2="12" y2="3" />
                        <line x1="12" y1="21" x2="12" y2="23" />
                        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
                        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
                        <line x1="1" y1="12" x2="3" y2="12" />
                        <line x1="21" y1="12" x2="23" y2="12" />
                        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
                        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
                    </svg>
                </button>
            </div>
        </header>
    )
}