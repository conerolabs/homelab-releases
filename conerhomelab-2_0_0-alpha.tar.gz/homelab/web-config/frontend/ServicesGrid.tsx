import type { EnvModel, ServiceModel } from "../commons/models";
import ServiceCard from "./components/ServiceCard";
import { useSearchContext } from "./providers/SearchContextProvider";

type ServicesGridProps = {
    services: ServiceModel[];
    envs: EnvModel[];
    systemVars: Set<string>;
    expanded: boolean;
}

export default function ServicesGrid({ services, envs, systemVars, expanded }: ServicesGridProps) {

    const { searchText, serviceSearchFilter } = useSearchContext();

    return (
        <div className={`services-grid ${expanded ? "expanded" : ""}`}>
            {
                services
                    .filter(serviceSearchFilter(searchText))
                    .map(service => {
                        const serviceEnvs = envs.filter(e => service.envs.includes(e.name))
                        return <ServiceCard service={service} envs={serviceEnvs} systemVars={systemVars} key={service.name} enableMonitor={true} />;
                    })
            }
        </div>
    )
}