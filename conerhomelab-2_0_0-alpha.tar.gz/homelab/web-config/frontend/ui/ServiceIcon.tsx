import { useEffect, useRef, useState } from 'react';

// Configure your base path here
const ICON_PATH = '../images/icons';

type ServiceIconProps = {
    service: string;
    size?: number;
    className?: string;
}

const ServiceIcon = ({ service, size = 24, className, ...props }: ServiceIconProps) => {
    const [SvgComponent, setSvgComponent] = useState<any>(null);
    const [error, setError] = useState<any>(null);
    const isMounted = useRef(true);

    useEffect(() => {
        isMounted.current = true;
        setSvgComponent(null);
        setError(null);

        const loadIcon = async () => {
            try {
                // Try Vite syntax first if you are using Vite
                const module = await import(`../images/icons/${service}.svg?react`);
                const Component = module.default;

                if (isMounted.current) {
                    if (!Component) {
                        throw new Error('Component is undefined');
                    }
                    setSvgComponent(() => Component);
                }
            } catch (err) {
                if (isMounted.current) {
                    console.error(`Failed to load icon: ${service}`, err);
                    setError(err);
                }
            }
        };

        loadIcon();

        return () => {
            isMounted.current = false;
        };
    }, [service]);

    if (error) {
        // Optional: Render a fallback or null
        return <span style={{ color: 'red' }}>Icon "{service}" not found</span>;
    }

    if (!SvgComponent) {
        // Optional: Render a loading skeleton or null
        return <div style={{ width: size, height: size, background: '#eee' }} />;
    }

    return <SvgComponent {...props} />;
};

export default ServiceIcon;   