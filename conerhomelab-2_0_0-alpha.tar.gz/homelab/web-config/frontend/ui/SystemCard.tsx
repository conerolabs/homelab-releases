import CardInput from "./CardInput";
import type { HomelabEnv } from "../ConfigReducer";
import { useState } from "react";

type SystemCardProps = {
  categoryName: string;
  envs: HomelabEnv[];
};

export default function SystemCard({ categoryName, envs }: SystemCardProps) {
  const catId = `card-content-${categoryName}`;
  const [expanded, setExpanded] = useState(true);

  return (
    <div className="config-card">
      <h3 className={`config-card-header ${expanded ? "expanded" : ""}`}
        data-target={catId}
        onClick={() => setExpanded(!expanded)}>
        <span>{categoryName}</span>
        <svg className="config-card-arrow" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9" /></svg>
      </h3>
      <div className={`config-card-content ${expanded ? "expanded" : ""}`}>
        {envs.map(v => <CardInput varInfo={v} key={v.name} />)}
      </div>
    </div>
  )
}