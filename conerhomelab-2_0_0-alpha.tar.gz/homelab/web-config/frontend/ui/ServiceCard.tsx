import { useEffect, useState } from 'react';
import { useConfigActions } from '../providers/ConfigProvider';
import CardInput from './CardInput';
import ServiceIcon from './ServiceIcon';
import { useConsoleModal } from '../providers/ConsoleModalProvider';
import { ServiceApiClient } from '../api';
import type { EnvModel, ServiceModel } from '../../commons/models';

type ServiceCardProps = {
  service: ServiceModel;
  envs: EnvModel[];
  systemVars: Set<string>;
  refreshTime?: number;
}
type ServiceMonitor = {
  state: string;
  health: string;
  error?: string | null;
}

type ServiceStatus = {
  running: boolean;
  status: string;
  health: 'healthy' | 'unhealthy' | 'starting' | 'none' | 'unknown';
  healthDetail?: string | null;
  containerId?: string | null;
}

type ServiceCardMonitorProps = {
  isVisible: boolean;
  monitor: ServiceMonitor;
}

export default function ServiceCard({ service, envs, systemVars, refreshTime = 30000 }: ServiceCardProps) {

  const isRequired = service.required;
  const name = service.name;
  const version = envs.find(e => e.name === service.version)?.value ?? "";
  const { setService, setEnv } = useConfigActions();
  const { openConsole } = useConsoleModal();
  const [monitor, setMonitor] = useState<ServiceMonitor>({ state: "checking", health: "checking" });
  const [status, setStatus] = useState<ServiceStatus>({ running: false, status: 'unknown', health: 'unknown' })

  const statusFormatter: Record<string, { label: string, class: string }> = {
    running: { label: 'Running', class: 'status-chip--running' },
    restarting: { label: 'Restarting', class: 'status-chip--loading' },
    stopped: { label: 'Stopped', class: 'status-chip--stopped' },
    healthy: { label: 'Healthy', class: 'status-chip--healthy' },
    unhealthy: { label: 'Unhealthy', class: 'status-chip--unhealthy' },
    checking: { label: 'Checking...', class: 'status-chip--loading' },
    error: { label: 'Unavailable', class: 'status-chip--error' },
    none: { label: 'None', class: 'status-chip--unknown' },
    unknown: { label: 'Unknown', class: 'status-chip--unknown' },
  };

  const sortedEnvs = envs.filter(e => e.visible)
    .filter(e => !e.name.includes('_VERSION'))
    .toSorted((a, b) => a.name.localeCompare(b.name))
    .toReversed()
    .toSorted((a, b) => Number(systemVars.has(a.name)) - Number(systemVars.has(b.name)))
    .toReversed()

  const toggleEnabled = () => {
    setService({ ...service, enabled: !service.enabled })
  }

  const updateEnv = (name: string, value: string) => {
    setEnv({ name, value })
  }

  const startService = () => {
    openConsole({ action: 'start', service: name }, refreshServiceStatus)
  }

  const stopService = () => {
    openConsole({ action: 'stop', service: name }, refreshServiceStatus)
  }

  const refreshServiceStatus = async () => {
    if (service.enabled) {
      console.log(`${name}: Refreshing service status...`);
      setMonitor({ state: 'checking', health: 'checking' });
      try {
        const status = await ServiceApiClient.getServiceStatus(name);
        setStatus(status);
        if (status.running) {
          setMonitor({ state: 'running', health: status.health });
        } else if (status.status === 'restarting') {
          setMonitor({ state: 'restarting', health: status.health });
        } else {
          setMonitor({ state: 'stopped', health: 'none' });
        }
      } catch (error) {
        setMonitor({ state: 'error', health: 'error', error: String(error) });
      }
    } else {
      console.log(`${name}: Service is disabled. Skipping status refresh.`)
    }
  }

  useEffect(() => {
    refreshServiceStatus();
    const intervalId = setInterval(refreshServiceStatus, refreshTime);
    return () => clearInterval(intervalId);
  }, [service.enabled]);

  function ServiceSwitch({ enabled, onChange }: { enabled: boolean, onChange: (enabled: boolean) => void }) {
    return (
      <label className={`service-switch ${isRequired ? 'disabled' : ''}`} title={isRequired ? "Required services cannot be disabled" : ''}>
        <input type="checkbox" className="service-toggle" data-service="${name}" checked={enabled} onChange={() => onChange(!enabled)} disabled={isRequired} />
        <span className="slider"></span>
      </label>
    )
  }

  function ServiceCardHeader() {
    return (
      <div className="service-card-header">
        <div className="service-info">
          <div className="service-icon">
            <ServiceIcon service={name} />
          </div>
          <div className="service-meta">
            <h2>{name}<a href="" className={`service-link fa ${service.enabled ? '' : 'disabled'}`}>&#xf08e;</a></h2>
            <span className="service-badge">{isRequired ? 'Required' : (service.enabled ? 'Active' : 'Disabled')}</span>
          </div>
        </div>
        <ServiceSwitch enabled={service.enabled ?? false} onChange={toggleEnabled} />
      </div>
    )
  }

  function ServiceCardMonitor({ isVisible, monitor }: ServiceCardMonitorProps) {

    return (
      <div className={`service-status-grid ${isVisible ? '' : 'hidden'}`}>
        <div className="service-status-item">
          <span className="status-label">State</span>
          <span id="status-${name}" className={`status-chip ${statusFormatter[monitor.state]?.class || 'status-chip--unknown'}`}>{statusFormatter[monitor.state]?.label || 'Unknown'}</span>
        </div>
        <div className="service-status-item" title={status.healthDetail ?? ''}>
          <span className="status-label">Health</span>
          <span id="health-${name}" className={`status-chip ${statusFormatter[monitor.health]?.class || 'status-chip--unknown'}`}>{statusFormatter[monitor.health]?.label || 'Unknown'}</span>
        </div>
      </div>
    )
  }

  function ServiceCardVars() {

    const [expanded, setExpanded] = useState<boolean>(false)

    if (envs.length > 0) return (<>
      <button className={`service-vars-toggle ${expanded ? 'expanded' : ''}`}
        onClick={() => setExpanded(!expanded)}>
        <svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9" /></svg>
        Environment Variables ({envs.length})
      </button>
      <div className="service-vars-content">
        <div className="env-list">
          {sortedEnvs.map((v) => {
            return <CardInput key={v.name} varInfo={v} onChange={updateEnv} />;
          })}
        </div>
      </div></>)
    else return <div style={{ display: 'none' }}></div>
  }

  function ServiceCardActions({ isVisible, actions }: { isVisible: boolean, actions: ('start' | 'stop')[] }) {
    function StartButton({ isVisible }: { isVisible: boolean }) {
      return (
        <button className={`btn btn-primary service-action-btn ${isVisible ? '' : 'hidden'}`} type="button" onClick={startService}>
          <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3" /></svg>
          Start
        </button>
      )
    }
    function StopButton({ isVisible }: { isVisible: boolean }) {
      return (
        <button className={`btn btn-danger service-action-btn ${isVisible ? '' : 'hidden'}`} type="button" onClick={stopService}>
          <svg viewBox="0 0 24 24"><polygon points="5 5 19 5 19 19 5 19 5 5" /></svg>
          Stop
        </button>
      )
    }
    return (
      <div className={`service-actions ${isVisible ? '' : 'hidden'}`}>
        {actions.includes('start') && <StartButton isVisible={!status.running} />}
        {actions.includes('stop') && <StopButton isVisible={status.running} />}
      </div>
    )
  }

  return (
    <div className={`service-card ${service.enabled ? 'active' : ''}`} id={`card-${name}`}>
      <ServiceCardHeader />
      <div className="service-description">{service.descr || 'No description available.'}</div>
      <ServiceCardMonitor isVisible={service.enabled ?? false} monitor={monitor} />
      <ServiceCardVars />
      <ServiceCardActions isVisible={service.enabled ?? false} actions={['start', 'stop']} />
      <div className="service-version">
        <span className="version-badge">{version}</span>
      </div>
    </div>
  )
}