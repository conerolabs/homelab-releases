import type { DependencyStatus } from "../../commons/dto";
import { useConsoleTask } from "../hooks/useConsoleTask";

type DependencyCardProps = {
    dep: DependencyStatus,
    onActionSuccess: () => void,
    onActionError?: () => void
}

export default function DependencyCard({ dep, onActionSuccess, onActionError }: DependencyCardProps) {
    const { runConsoleTask } = useConsoleTask();

    function install() {
        runConsoleTask(
            { action: 'install', service: dep.name },
            () => { console.log(`${dep.name} installed successfully`); onActionSuccess(); },
            () => { console.log(`${dep.name} installation failed`); onActionError?.(); },
        );
    }

    function uninstall() {
        runConsoleTask(
            { action: 'uninstall', service: dep.name },
            () => { console.log(`${dep.name} uninstalled successfully`); onActionSuccess(); },
            () => { console.log(`${dep.name} uninstallation failed`); onActionError?.(); },
        );
    }

    return (
        <div className={`dep-item ${dep.installed ? 'installed' : 'missing'}`}>
            <div className="dep-info">
                <div className="dep-icon-wrapper">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
                        <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
                        <line x1="12" y1="22.08" x2="12" y2="12" />
                    </svg>
                </div>
                <div className="dep-details">
                    <h4 className="dep-name-text">{dep.name}</h4>
                    <span className={`dep-status-badge ${dep.installed ? 'installed' : 'missing'}`}>
                        {dep.installed ? (
                            <>
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                                    <polyline points="20 6 9 17 4 12"></polyline>
                                </svg>
                                Installed
                            </>
                        ) : (
                            <>
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <line x1="12" y1="8" x2="12" y2="12"></line>
                                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                                </svg>
                                Missing
                            </>
                        )}
                    </span>
                </div>
            </div>

            <div className="dep-actions">
                {!dep.installed ? (
                    <button className="btn-dep-action btn-dep-install" onClick={install} title={`Install ${dep.name}`}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                            <polyline points="7 10 12 15 17 10"></polyline>
                            <line x1="12" y1="15" x2="12" y2="3"></line>
                        </svg>
                        <span>Install</span>
                    </button>
                ) : (
                    <button className="btn-dep-action btn-dep-remove" onClick={uninstall} title={`Remove ${dep.name}`}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="3 6 5 6 21 6"></polyline>
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                        <span>Remove</span>
                    </button>
                )}
            </div>
        </div>
    );
}