import { useEffect, useState } from "react";
import type { HomelabEnv } from "../ConfigReducer";

type CardInputProps = {
    varInfo: HomelabEnv;
    onChange: (name: string, value: string) => void;
}

export default function CardInput({ varInfo, onChange }: CardInputProps) {
    const varName = varInfo.name;
    const ro = varInfo.readonly;
    const [value, setValue] = useState('');
    const tickVars = ['_SECRET_HASH', 'VAULTWARDEN_ADMIN_TOKEN', '_SECRET'];

    useEffect(() => {
        setValue(varInfo.value || '');
    }, [varInfo]);

    if (tickVars.some((suffix) => varName.endsWith(suffix))) {
        return (
            <div className="env-field-readonly">
                <label className="env-label" htmlFor={`input-${varName}`}>
                    {varName}
                    <div className="env-hint">
                        <span>Automatically generated, use the setup script to change it.</span>
                    </div>
                </label>
                <div className="env-input-wrapper">
                    <span className="env-input-tick">&#x2714;</span>
                </div>
            </div>
        )
    }

    return (
        <div className={ro ? 'env-field-readonly fa' : 'env-field fa'}>
            <label className="env-label" htmlFor={`input-${varName}`}>
                {varName}
                {(varInfo.descr?.length ?? 0 > 0) ? <span style={{ marginLeft: '4px', cursor: 'help' }} title={varInfo.descr}>&#x0F059;</span> : ''}
            </label>
            <div className="env-input-wrapper">
                <input type="text"
                    className="env-input"
                    value={value || ''}
                    readOnly={ro}
                    onChange={(e) => setValue(e.target.value)}
                    onBlur={(e) => onChange(varName, e.target.value)}
                />
            </div>
        </div>
    )
}