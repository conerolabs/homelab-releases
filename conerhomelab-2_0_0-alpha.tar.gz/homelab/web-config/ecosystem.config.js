export const apps = [
    {
        name: "web-config-app",
        script: "./backend/server.ts",
        env_production: {
            NODE_ENV: "production"
        },
        env_development: {
            NODE_ENV: "development"
        }
    },
];   