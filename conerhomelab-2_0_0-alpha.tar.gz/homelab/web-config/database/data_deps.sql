-- deps: jq, docker, headscale, python3, python3-dotenv, unbound, unbound-anchor, tailscale, yq, git

INSERT INTO deps(name, install_cmd, check_cmd)
VALUES
  ('jq', 'sudo apt install -y jq', 'command -v jq'),
  (
    'docker',
    'docker_install',
    'command -v docker'
  ), ('headscale', 'headscale_install', 'command -v headscale'),
  (
    'python3',
    'sudo apt install -y python3',
    'command -v python3'
  ),
  (
    'python3-dotenv',
    'sudo apt install -y python3-dotenv',
    'python3 -c "import dotenv"'
  ), ('unbound', 'sudo apt install -y unbound', 'command -v unbound'),
  (
    'unbound-anchor',
    'sudo apt install -y unbound-anchor',
    'command -v unbound-anchor'
  ),
  (
    'tailscale',
    'curl -fsSL https://tailscale.com/install.sh | sh',
    'command -v tailscale'
  )
ON CONFLICT (name) DO NOTHING;

-- -- yq
-- INSERT INTO deps(name, install_cmd, check_cmd)
-- VALUES ('yq', 'sudo apt install -y yq', 'command -v yq');

-- -- git
-- INSERT INTO deps(name, install_cmd, check_cmd)
-- VALUES ('git', 'sudo apt install -y git', 'command -v git');

