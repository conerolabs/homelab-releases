import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { AUTHELIA_USERS_PATH, COMPOSE_PATH, ENV_PATH } from '../backend/config-utils.ts';
import { syncEnvs, syncServices, syncUsers } from './db-utils.ts';
import { getLogger } from '../backend/logger.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const log = getLogger('db', { msgPrefix: 'DB - ' });

export let db: DatabaseSync = null;

/**
 * Initialize database connection and sync the database with the environment variables and docker-compose services.
 */
function init() {

    const dbFile = process.env.NODE_ENV === 'production' ? 'homelab.db' : 'homelab-dev.db'
    db = new DatabaseSync(join(process.env.INSTALL_DIR, dbFile));
    log.info(`Found at ${join(process.env.INSTALL_DIR, dbFile)}`);

    log.info('Syncing...');

    if (process.env.NODE_ENV !== 'production') {
        const schemaPath = join(__dirname, 'sql', 'schema.sql')
        const schema = readFileSync(schemaPath, 'utf-8');
        db.exec(schema);
    }
    syncEnvs(ENV_PATH);
    syncUsers(AUTHELIA_USERS_PATH);
    if (process.env.NODE_ENV !== 'production') {
        syncServices(COMPOSE_PATH);
    }
    log.info('Sync completed');
    // initData();
}

function initData() {
    log.info('Initializing data...');
    const depsDataPath = join(__dirname, 'sql', 'data', 'deps.sql')
    const depsData = readFileSync(depsDataPath, 'utf-8');
    db.exec(depsData);
    const servicesDataPath = join(__dirname, 'sql', 'data', 'services.sql')
    const servicesData = readFileSync(servicesDataPath, 'utf-8');
    db.exec(servicesData);
    const envsDataPath = join(__dirname, 'sql', 'data', 'envs.sql')
    const envsData = readFileSync(envsDataPath, 'utf-8');
    db.exec(envsData);
    const serviceDepsDataPath = join(__dirname, 'sql', 'data', 'service_deps.sql')
    const serviceDepsData = readFileSync(serviceDepsDataPath, 'utf-8');
    db.exec(serviceDepsData);
    const serviceEnvsDataPath = join(__dirname, 'sql', 'data', 'service_envs.sql')
    const serviceEnvsData = readFileSync(serviceEnvsDataPath, 'utf-8');
    db.exec(serviceEnvsData);
    const serviceActionsDataPath = join(__dirname, 'sql', 'data', 'service_actions.sql')
    const serviceActionsData = readFileSync(serviceActionsDataPath, 'utf-8');
    db.exec(serviceActionsData);
    log.info('Data Initialized.');
}

export function bootstrapDB() {
    try {
        init();
    } catch (e) {
        log.error(`Error bootstrapping database: ${e}`);
        throw e;
    }
}

