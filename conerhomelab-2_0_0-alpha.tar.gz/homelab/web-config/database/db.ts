import { DatabaseSync } from 'node:sqlite';
import { randomBytes, pbkdf2Sync } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { AUTHELIA_USERS_PATH, COMPOSE_PATH, ENV_PATH } from '../backend/config-utils.ts';
import { syncEnvs, syncServices, syncUsers } from './db-utils.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const db = new DatabaseSync(join(process.env.INSTALL_DIR, 'homelab.db'));
console.log('DB - Found at', join(process.env.INSTALL_DIR, 'homelab.db'));

function init() {
    console.log('DB - Initializing...');

    if (process.env.NODE_ENV !== 'production') {
        const schemaPath = join(__dirname, 'sql', 'schema.sql')
        const schema = readFileSync(schemaPath, 'utf-8');
        db.exec(schema);
        console.log('   - Syncing...')
        syncEnvs(ENV_PATH);
        syncServices(COMPOSE_PATH);
        syncUsers(AUTHELIA_USERS_PATH);
        console.log('   - Sync completed');
    }
    // initData();
    console.log('DB - initialized.');
}

function initData() {
    const depsDataPath = join(__dirname, 'sql', 'data', 'deps.sql')
    const depsData = readFileSync(depsDataPath, 'utf-8');
    db.exec(depsData);
    const servicesDataPath = join(__dirname, 'sql', 'data', 'services.sql')
    const servicesData = readFileSync(servicesDataPath, 'utf-8');
    db.exec(servicesData);
    const envsDataPath = join(__dirname, 'sql', 'data', 'envs.sql')
    const envsData = readFileSync(envsDataPath, 'utf-8');
    db.exec(envsData);
    const serviceDepsDataPath = join(__dirname, 'sql', 'data', 'service_deps.sql')
    const serviceDepsData = readFileSync(serviceDepsDataPath, 'utf-8');
    db.exec(serviceDepsData);
    const serviceEnvsDataPath = join(__dirname, 'sql', 'data', 'service_envs.sql')
    const serviceEnvsData = readFileSync(serviceEnvsDataPath, 'utf-8');
    db.exec(serviceEnvsData);
    const serviceActionsDataPath = join(__dirname, 'sql', 'data', 'service_actions.sql')
    const serviceActionsData = readFileSync(serviceActionsDataPath, 'utf-8');
    db.exec(serviceActionsData);
}

export function bootstrapDB() {
    try {
        init();
    } catch (e) {
        console.error('Error bootstrapping database:', e);
        throw e;
    }
}

