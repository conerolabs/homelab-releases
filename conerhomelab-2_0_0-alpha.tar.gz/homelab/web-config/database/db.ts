import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import os from 'node:os';
import { AUTHELIA_USERS_PATH, COMPOSE_PATH, ENV_PATH } from '../backend/config-utils.ts';
import { syncEnvs, syncServices, syncUsers } from './db-utils.ts';
import { getLogger } from '../backend/logger.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const log = getLogger('db', { msgPrefix: 'DB - ' });

export let db: DatabaseSync | null = null;

/**
 * Initialize database connection and sync the database with the environment variables and docker-compose services.
*/
function init() {

    const homelabDir = process.env.INSTALL_DIR?.replace(/^~/, os.homedir());
    const sqlDir = join(homelabDir || '', 'scripts', 'database', 'sql');

    if (!homelabDir) {
        log.error('INSTALL_DIR is not set. Cannot initialize database.');
        throw new Error('INSTALL_DIR is not set.');
    }

    const dbFile = process.env.NODE_ENV === 'production' ? 'homelab.db' : 'homelab-dev.db'
    log.info(`Opening db at ${join(homelabDir, dbFile)}`);
    db = new DatabaseSync(join(homelabDir, dbFile));

    log.info('Syncing...');

    if (process.env.NODE_ENV !== 'production') {
        const schemaPath = join(sqlDir, 'schema.sql')
        const schema = readFileSync(schemaPath, 'utf-8');
        db.exec(schema);
    }
    syncEnvs(ENV_PATH);
    syncUsers(AUTHELIA_USERS_PATH);
    if (process.env.NODE_ENV !== 'production') {
        syncServices(COMPOSE_PATH);
    }
    log.info('Sync completed');
    // initData(sqlDir);
}

function initData(sqlDir: string) {
    if (!db) {
        throw new Error('Database not initialized.');
    }
    log.info('Initializing data...');
    const depsDataPath = join(sqlDir, 'deps.sql')
    const depsData = readFileSync(depsDataPath, 'utf-8');
    db.exec(depsData);
    const servicesDataPath = join(sqlDir, 'services.sql')
    const servicesData = readFileSync(servicesDataPath, 'utf-8');
    db.exec(servicesData);
    const envsDataPath = join(sqlDir, 'envs.sql')
    const envsData = readFileSync(envsDataPath, 'utf-8');
    db.exec(envsData);
    const serviceDepsDataPath = join(sqlDir, 'service_deps.sql')
    const serviceDepsData = readFileSync(serviceDepsDataPath, 'utf-8');
    db.exec(serviceDepsData);
    const serviceEnvsDataPath = join(sqlDir, 'service_envs.sql')
    const serviceEnvsData = readFileSync(serviceEnvsDataPath, 'utf-8');
    db.exec(serviceEnvsData);
    const serviceActionsDataPath = join(sqlDir, 'service_actions.sql')
    const serviceActionsData = readFileSync(serviceActionsDataPath, 'utf-8');
    db.exec(serviceActionsData);
    log.info('Data Initialized.');
}

export function bootstrapDB() {
    try {
        init();
    } catch (e) {
        log.error(`Error bootstrapping database: ${e}`);
        throw e;
    }
}

