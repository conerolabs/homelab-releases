import { DatabaseSync } from 'node:sqlite';
import { randomBytes, pbkdf2Sync } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { AUTHELIA_USERS_PATH, COMPOSE_PATH, ENV_PATH } from '../backend/config-utils.ts';
import { syncEnvs, syncServices, syncUsers } from './db-utils.ts';
import type { UserModel } from '../commons/models.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const db = new DatabaseSync(join(__dirname, '..', '..', 'homelab.db'));

function init() {
    console.log('DB - Initializing...');
    const schemaPath = join(__dirname, 'schema.sql')
    const schema = readFileSync(schemaPath, 'utf-8');
    db.exec(schema);
    //initData();
    // TODO: serviceDeps and serviceEnvs data sql files
    console.log('   - Syncing...')
    syncEnvs(ENV_PATH);
    syncServices(COMPOSE_PATH);
    syncUsers(AUTHELIA_USERS_PATH);
    console.log('   - Sync completed');
    console.log('DB - initialized.');
}

function initData() {
    const depsDataPath = join(__dirname, 'data_deps.sql')
    const depsData = readFileSync(depsDataPath, 'utf-8');
    db.exec(depsData);
    const servicesDataPath = join(__dirname, 'data_services.sql')
    const servicesData = readFileSync(servicesDataPath, 'utf-8');
    db.exec(servicesData);
    const envsDataPath = join(__dirname, 'data_envs.sql')
    const envsData = readFileSync(envsDataPath, 'utf-8');
    db.exec(envsData);
}

export function insertUser(username: string, email: string, password: string, display_name?: string) {
    const password_salt = randomBytes(16).toString('hex');
    const password_hash = pbkdf2Sync(password, password_salt, 100000, 64, 'sha256').toString('hex');
    db?.exec(`INSERT INTO users (username, email, password_hash, password_salt, display_name) VALUES ('${username}', '${email}', '${password_hash}', '${password_salt}', '${display_name ?? username}')`);
}

export function getUser(username: string) {
    return db?.prepare(`SELECT * FROM users WHERE username = ?`).get(username) as unknown as UserModel;
}

export function bootstrapDB() {
    try {
        init();
    } catch (e) {
        console.error('Error bootstrapping database:', e);
        throw e;
    }
}

