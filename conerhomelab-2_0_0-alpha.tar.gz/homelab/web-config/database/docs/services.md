# SERVICES TABLE

## Fields:
- id (PK)
- name (unique)
- descr (optional)
- subdomain (optional)
- icon (optional)
- type (unique)
- enabled (bool)
- visible (bool)
- required (bool)
- version (FK -> envs.name)
- docker_img (text)
- start_cmd (text)
- stop_cmd (text)

## Relations
- service_envs (many-to-many: service_name FK -> services.name, env_name FK -> envs.name)
- service_deps (many-to-many: service_name FK -> services.name, dep_name FK -> deps.name)
- service_actions (one-to-many)

## Logic
- if enabled is null, service is not configured yet
- if enabled is true, service is enabled
- if enabled is false, service is disabled