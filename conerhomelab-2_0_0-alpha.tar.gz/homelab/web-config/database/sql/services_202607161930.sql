INSERT INTO services (name,descr,subdomain,icon,"type",enabled,visible,docker_img,version,required) VALUES
	 ('authelia','Single Sign-On (SSO) and authentication server with OIDC and 2FA.','auth','/images/icons/authelia.svg','docker',1,1,'authelia/authelia','AUTHELIA_VERSION',1),
	 ('caddy','Reverse proxy and web server with automatic HTTPS using Cloudflare DNS.',NULL,'/images/icons/caddy.svg','docker',1,1,'caddy','CADDY_VERSION',1),
	 ('cronicle','Distributed task scheduler and runner with a web UI.','cron','/images/icons/cronicle.svg','docker',0,1,'cronicle/edge','CRONICLE_VERSION',0),
	 ('filebrowser','Web-based file manager to browse and organize homelab files.','files','/images/icons/filebrowser.svg','docker',1,1,'filebrowser/filebrowser','FILEBROWSER_VERSION',0),
	 ('gatus','Service health dashboard and monitoring tool with notifications.','status','/images/icons/gatus.svg','docker',0,1,'twinproduction/gatus','GATUS_VERSION',0),
	 ('homepage','Sleek, customizable dashboard showing all homelab services.','home','/images/icons/homepage.svg','docker',1,1,'gethomepage/homepage','HOMEPAGE_VERSION',1),
	 ('headscale','Headscale Mesh VPN','vpn','/images/icons/headscale.svg','host',0,1,NULL,NULL,0),
	 ('headscale-ui','Web interface for managing the Headscale Tailscale coordination server.','vpn/web','/images/icons/headscale-ui.svg','docker',0,1,'ghcr.io/gurucomputing/headscale-ui','HEADSCALE_UI_VERSION',0),
	 ('navidrome','Modern music streaming server and library manager.','music','/images/icons/navidrome.svg','docker',0,1,'deluan/navidrome','NAVIDROME_VERSION',0),
	 ('pihole','Network-wide ad-blocker and recursive/upstream DNS resolver.','dns','/images/icons/pihole.svg','docker',1,1,'pihole/pihole','PIHOLE_VERSION',1);
INSERT INTO services (name,descr,subdomain,icon,"type",enabled,visible,docker_img,version,required) VALUES
	 ('portainer','Web-based container management interface for Docker.','portainer','/images/icons/portainer.svg','docker',0,1,'portainer/portainer-ce','PORTAINER_VERSION',0),
	 ('myspeed','Automated internet speed test logger and dashboard.','speedtest','/images/icons/myspeed.svg','docker',0,1,'germannewsmaker/myspeed','MYSPEED_VERSION',0),
	 ('radio-manager','Navidrome web radio management',NULL,'/images/icons/radio-manager.svg','docker',0,1,'ghcr.io/brunopiras/naviradiomanager','RADIO_MANAGER_VERSION',0),
	 ('redis','Fast in-memory database used by Authelia for session storage.',NULL,'/images/icons/redis.svg','docker',1,1,'redis','REDIS_VERSION',1),
	 ('rustical','CalDAV/CardDAV server for calendars and contacts.','calendar','/images/icons/rustical.svg','docker',0,1,'ghcr.io/lennart-k/rustical','RUSTICAL_VERSION',0),
	 ('unbound','Recursive DNS resolver',NULL,'/images/icons/unbound.svg','host',0,1,NULL,NULL,0),
	 ('vaultwarden','Lightweight Bitwarden-compatible password manager server.','vault','/images/icons/vaultwarden.svg','docker',0,1,'vaultwarden/server','VAULTWARDEN_VERSION',0),
	 ('system','Main system',NULL,NULL,'host',1,1,NULL,NULL,1),
	 ('network','Main system network infrastructure ',NULL,NULL,'host',1,1,NULL,NULL,1);
