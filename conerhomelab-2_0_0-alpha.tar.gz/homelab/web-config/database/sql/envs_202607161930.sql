INSERT INTO envs(
  name,
  value,
  descr,
  visible,
  readonly,
  created_at,
  updated_at,
  deleted_at
)
VALUES
  (
    'HOMELAB_VERSION',
    '2.0',
    '',
    0,
    1,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'SERVER_NAME',
    'conerolabs-ubuntu-1',
    'It will be assigned to the tailscale''s hostname',
    1,
    0,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'HOST_UID',
    '1000',
    'User ID dell''utente nell''host',
    1,
    1,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'HOST_GID',
    '1000',
    'Group ID dell''utente nell''host',
    1,
    1,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'INSTALL_DIR',
    '/media/andrea/Data/homelab/Nodo1/homelab',
    '',
    1,
    0,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'BACKUP_DEST',
    '/mnt/backup_usb/homelab_backups/nodo1',
    '',
    1,
    0,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'NETWORK_INTERFACE',
    'wlp3s0',
    '',
    1,
    1,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'HOST_PUBLIC_IP',
    '31.189.80.200',
    '',
    1,
    1,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'LAN_IP',
    '192.168.1.91',
    '',
    1,
    1,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'TAILSCALE_IP',
    '',
    '',
    1,
    1,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  );

INSERT INTO envs(
  name,
  value,
  descr,
  visible,
  readonly,
  created_at,
  updated_at,
  deleted_at
)
VALUES
  (
    'TAILSCALE_LOGIN_URL',
    'https://controlplane.tailscale.com',
    '',
    0,
    0,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'DOMAIN',
    'conerolabs.com',
    'Il dominio del tuo homelab. Inserisci ''''local'''' se non possiedi un dominio. Senza un dominio alcuni servizi come Headscale non potranno essere abilitati',
    1,
    0,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'DOCKER_NETWORK_GATEWAY',
    '172.20.0.1',
    '',
    1,
    1,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'BACKUP_DNS',
    '45.90.28.0#ConeroLabs--1-6986b3.dns.nextdns.io 45.90.30.0#ConeroLabs--1-6986b3.dns.nextdns.io 2a07:a8c0::#ConeroLabs--1-6986b3.dns.nextdns.io',
    'Used exclusively by the host in addition to PiHole for redundancy. Tailscale clients will use only PiHole',
    1,
    0,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'HEADSCALE_VERSION',
    '0.28.0',
    '',
    1,
    1,
    '2026-07-08 11:09:44',
    '2026-07-08 11:09:44',
    NULL
  ),
  (
    'HEADSCALE_SERVER_URL',
    'https://vpn.conerolabs.com',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'HEADSCALE_SERVER_PORT',
    '8084',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'HEADSCALE_METRICS_PORT',
    '9092',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'HEADSCALE_DNS',
    '100.64.0.1',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  );

INSERT INTO envs(
  name,
  value,
  descr,
  visible,
  readonly,
  created_at,
  updated_at,
  deleted_at
)
VALUES
  (
    'HEADSCALE_OIDC_CLIENT_ID',
    'headscale-bce0ded4ff167e38',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'AUTHELIA_VERSION',
    '4.39.20',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'CADDY_VERSION',
    '2.11.2',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'FILEBROWSER_VERSION',
    'v2.63.5',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'GATUS_VERSION',
    'stable',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'HOMEPAGE_VERSION',
    'v1.13',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'NAVIDROME_VERSION',
    'latest',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'PIHOLE_VERSION',
    '2026.05.0',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'PORTAINER_VERSION',
    'lts',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'REDIS_VERSION',
    '8-alpine',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  );

INSERT INTO envs(
  name,
  value,
  descr,
  visible,
  readonly,
  created_at,
  updated_at,
  deleted_at
)
VALUES
  (
    'RUSTICAL_VERSION',
    'latest',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'VAULTWARDEN_VERSION',
    '1.36.0',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'CADDY_EMAIL',
    'developers@conerolabs.com',
    'Used in Let''s Encrypt certificates to set the ACME email address.',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'CLOUDFLARE_API_TOKEN',
    'BS6oVTBJryCm-UtsalDZunZFLBCdz69VSWWSSfKq',
    'Used in Let''s Encrypt ACME DNS challenge to access cloudflare dns. Used also to edit Cloudflare dns record (dynamic dns)',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'CALENDAR_BASIC_AUTH',
    'YW5kcmVhOmEyOTVfcEhoazBldU9EcmxPWWVrZVBTcTZmT3ZnT2tnSWhha2lZcGkxYjVlcjkyZ1FjcU1wd3RUNnJkVHhqaXEyWHNHMQ==',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'CALENDAR_PATH',
    '/caldav/principal/andrea/056012a7-5e87-4583-b478-cdb058d27d9c',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'PIHOLE_WEBPASSWORD',
    '',
    '',
    0,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'UPSTREAM_DNS_SERVERS',
    '45.90.28.115;45.90.30.115',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'VAULTWARDEN_ADMIN_TOKEN',
    '$argon2id$v=19$m=65540,t=3,p=4$Y0hRL0VNZlFIMWpSSTZlVWVxd0paK0lXOHRhK0RkUFRYVTZBTkdCU1U5MD0$SEVah2ouZFJbNkSWsdY4bZ/tLVQkIamZs7DEzZ8W8lA',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'VAULTWARDEN_OIDC_CLIENT_ID',
    'a8aefc86abbe869ad65bf6c75079d410bceaf07a42f591714f5d9e1b6e042e9d',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  );

INSERT INTO envs(
  name,
  value,
  descr,
  visible,
  readonly,
  created_at,
  updated_at,
  deleted_at
)
VALUES
  (
    'RUSTICAL_OIDC_CLIENT_ID',
    '05a38ced37c3fb9fcd076c2bc62cb39ad8b7990b480a34fb7bf6617baa5123fb',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'RUSTICAL_OIDC_CLIENT_SECRET',
    'FMLhMcNzgeKhfAudmwLwSos8IpJt/f75Y/6XMr8kYkw=',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'WEBCONFIG_OIDC_CLIENT_ID',
    'web-config-6d766748f5c5cded',
    '',
    0,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'WEBCONFIG_OIDC_CLIENT_SECRET',
    'cjGXmCguNfulHE285bSLNaEC2emSY4/JbnZVsDmkhi8=',
    '',
    0,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'WEBCONFIG_SESSION_SECRET',
    'odxWqjVwCOe2MHZVHw/nCFccmZBNyLgCnyE2oVItOLU=',
    '',
    0,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'AUTHELIA_VAULTWARDEN_SECRET_HASH',
    '$argon2id$v=19$m=32768,t=3,p=2$ytJdyC4B9MCou4QPqkSdrA$dsi/1TTzz4q+HMvO2uj1KsRGZTXFUum4eqULlQY7Qi0',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'AUTHELIA_GATUS_SECRET_HASH',
    '$argon2id$v=19$m=32768,t=3,p=2$dJItxL3yR38no/WjgketXg$GH9fh/b7sRtMYx9vAT14KX1qyLPl/EC3DhI19u71aho',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'AUTHELIA_RUSTICAL_SECRET_HASH',
    '$argon2id$v=19$m=32768,t=3,p=2$rY5b88LXrVnJ2hYVDxPweA$mP73cyd91elY+fJa1e6wAGAnRW64PN+lCWeQqiUlxpI',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'AUTHELIA_HEADSCALE_SECRET_HASH',
    '$argon2id$v=19$m=32768,t=3,p=2$VfNawv4e7otVWL26JM9sKw$A9+84tbQkzbfx8igThfGpA3GGYBFwArkTw9hpQaRUYM',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'AUTHELIA_WEBCONFIG_SECRET_HASH',
    '$argon2id$v=19$m=32768,t=3,p=2$pRQr15pVLbd91sW/4J2u2A$DFkas4hPgTt4VML7gdgVmf28K6QpjAZ3XrEjRjt7lnU',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  );

INSERT INTO envs(
  name,
  value,
  descr,
  visible,
  readonly,
  created_at,
  updated_at,
  deleted_at
)
VALUES
  (
    'TAILSCALE_API_KEY',
    'tskey-api-k8JGMza6x311CNTRL-Se4HPbDKB88A4dMEVXQT88Vkp1DZ6riH',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'NEXTDNS_PROFILE_ID',
    '6986b3',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'NEXTDNS_API_KEY',
    'c73edda9929816b0312da052cb7229ce3a28c7ac',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'HOMEPAGE_FILEBROWSER_USER',
    'homepage',
    '',
    0,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'GATUS_OIDC_CLIENT_ID',
    '572fa50480eb779af88658f4123f2be7e5d73ae0936a6d6d8e104cb1cc6be45d',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'GATUS_TELEGRAM_BOT_TOKEN',
    '8504249856:AAEZoPrBWPSOoPiY0uXS4bMTIgvUkxm2ru4',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'GATUS_TELEGRAM_CHAT_ID',
    '107975370',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'PORTAINER_ACCESS_TOKEN',
    'ptr_hZhnDNOBaz95LFdZFC+cdsbfntvGlIW3R/3fFcqjGhI=',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'SUBSONIC_USERNAME',
    'andrea',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'SUBSONIC_PASSWORD',
    'pazz',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  );

INSERT INTO envs(
  name,
  value,
  descr,
  visible,
  readonly,
  created_at,
  updated_at,
  deleted_at
)
VALUES
  (
    'HOMEPAGE_NAVIDROME_SALT',
    'jR5YNUKVOBQ=',
    '',
    0,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'HOMEPAGE_NAVIDROME_TOKEN',
    '601a29f6c36ab34db3e5a6bc9f7a3a17',
    '',
    0,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'COMPOSE_PROFILES',
    '[object Object],[object Object],[object Object],[object Object],[object Object],[object Object]',
    '',
    1,
    0,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'HEADSCALE_UI_VERSION',
    'latest',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'RADIO_MANAGER_VERSION',
    'latest',
    '',
    1,
    1,
    '2026-07-08 11:09:45',
    '2026-07-08 11:09:45',
    NULL
  ),
  (
    'CRONICLE_VERSION',
    'latest',
    '',
    1,
    1,
    '2026-07-11 13:32:22',
    '2026-07-11 13:32:22',
    NULL
  ),
  (
    'MYSPEED_VERSION',
    'latest',
    '',
    1,
    1,
    '2026-07-11 13:32:22',
    '2026-07-11 13:32:22',
    NULL
  );
