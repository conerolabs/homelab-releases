INSERT INTO service_deps (service_id,dep_id) VALUES
	 (1,2),
	 (2,2),
	 (3,2),
	 (4,2),
	 (5,2),
	 (6,2),
	 (7,3),
	 (8,2),
	 (9,2),
	 (10,2);
INSERT INTO service_deps (service_id,dep_id) VALUES
	 (11,2),
	 (12,2),
	 (13,2),
	 (14,2),
	 (15,2),
	 (16,6),
	 (16,7),
	 (17,2),
	 (8,3),
	 (39,1);
INSERT INTO service_deps (service_id,dep_id) VALUES
	 (39,4),
	 (39,5),
	 (39,8);
