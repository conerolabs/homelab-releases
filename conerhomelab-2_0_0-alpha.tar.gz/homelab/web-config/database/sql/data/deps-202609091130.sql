INSERT INTO deps VALUES(1,'jq','apt install -y jq','command -v jq','apt remove -y jq',NULL,NULL);
INSERT INTO deps VALUES(2,'docker','docker-install.sh','command -v docker',NULL,NULL,'systemctl status docker');
INSERT INTO deps VALUES(3,'headscale','headscale-install.sh','command -v headscale',NULL,NULL,'systemctl status headscale');
INSERT INTO deps VALUES(4,'python3','apt install -y python3','command -v python3',NULL,NULL,NULL);
INSERT INTO deps VALUES(5,'python3-dotenv','apt install -y python3-dotenv','python3 -c "import dotenv"','apt remove -y python-dotenv',NULL,NULL);
INSERT INTO deps VALUES(6,'unbound','apt install -y unbound','dpkg -s unbound','apt remove -y unbound',NULL,'systemctl status unbound');
INSERT INTO deps VALUES(7,'unbound-anchor','apt install -y unbound-anchor','command -v unbound-anchor','apt remove -y unbound-anchor',NULL,NULL);
INSERT INTO deps VALUES(8,'tailscale','tailscale-install.sh','command -v tailscale',NULL,NULL,'tailscale status');
INSERT INTO deps VALUES(9,'sqlite3','apt install -y sqlite3','command -v sqlite3',NULL,NULL,NULL);