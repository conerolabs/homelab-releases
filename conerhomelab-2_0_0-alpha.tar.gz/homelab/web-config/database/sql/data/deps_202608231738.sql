INSERT INTO deps (name,install_cmd,check_cmd,remove_cmd,descr,status_cmd) VALUES
	 ('jq','apt install -y jq','command -v jq','apt remove -y jq',NULL,NULL),
	 ('docker','docker_install','command -v docker',NULL,NULL,'systemctl status docker'),
	 ('headscale','headscale_install','command -v headscale',NULL,NULL,'systemctl status headscale'),
	 ('python3','apt install -y python3','command -v python3',NULL,NULL,NULL),
	 ('python3-dotenv','apt install -y python3-dotenv','python3 -c "import dotenv"','apt remove -y python-dotenv',NULL,NULL),
	 ('unbound','apt install -y unbound','dpkg -s unbound','apt remove -y unbound',NULL,'systemctl status unbound'),
	 ('unbound-anchor','apt install -y unbound-anchor','command -v unbound-anchor','apt remove -y unbound-anchor',NULL,NULL),
	 ('tailscale','curl -fsSL https://tailscale.com/install.sh | sh','command -v tailscale',NULL,NULL,'tailscale status'),
	 ('sqlite3','apt install -y sqlite3','command -v sqlite3',NULL,NULL,NULL);
