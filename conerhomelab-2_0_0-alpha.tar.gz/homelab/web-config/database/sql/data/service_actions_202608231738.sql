INSERT INTO service_actions ("action",service,cmd,cmd_type,sudo) VALUES
	 ('setup','pihole','setup_pihole.sh','script',0),
	 ('deploy','pihole','docker compose up -d --remove-orphans pihole','cmd',0),
	 ('start','docker','systemctl start docker','cmd',1),
	 ('start','tailscale','tailscale up','cmd',1);
