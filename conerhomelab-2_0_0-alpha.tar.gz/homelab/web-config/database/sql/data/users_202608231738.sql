INSERT INTO users (username,email,display_name,groups,created_at) VALUES
	 ('conerolab-admin','admin@conerolabs.com','Admin ConeroLabs','admins,users','2026-08-23 15:00:47'),
	 ('andrea','pierdominici.andrea@proton.me','Andrea Pierdominici','users,family,vpn_users','2026-08-23 15:00:47'),
	 ('fabio','pierdominici.fabio@gmail.com','Fabio Pierdominici','users,family,vpn_users','2026-08-23 15:00:47');
