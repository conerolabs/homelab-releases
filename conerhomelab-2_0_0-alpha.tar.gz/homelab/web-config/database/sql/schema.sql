-- deps definition

CREATE TABLE deps (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	name TEXT NOT NULL,
	install_cmd TEXT NOT NULL,
	check_cmd TEXT NOT NULL,
	remove_cmd TEXT,
	descr TEXT
,
status_cmd TEXT);
-- envs definition

CREATE TABLE envs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  value TEXT,
  descr TEXT,
  visible BOOLEAN NOT NULL DEFAULT (TRUE),
  readonly BOOLEAN NOT NULL DEFAULT (FALSE),
  created_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP),
  updated_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP),
  deleted_at TIMESTAMP DEFAULT (NULL)
);
-- folders definition

CREATE TABLE folders (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"path" TEXT DEFAULT ('$INSTALL_DIR') NOT NULL,
	name TEXT NOT NULL UNIQUE,
	descr TEXT
);
-- users definition

CREATE TABLE users (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	username TEXT NOT NULL,
	email TEXT NOT NULL,
	display_name TEXT NOT NULL,
	groups TEXT DEFAULT ('users') NOT NULL,
	created_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP)
);
-- services definition

CREATE TABLE services (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	name TEXT NOT NULL,
	descr TEXT,
	subdomain TEXT,
	icon TEXT,
	"type" TEXT DEFAULT ('docker') NOT NULL,
	visible BOOLEAN DEFAULT (TRUE) NOT NULL,
	docker_img TEXT,
	version TEXT,
	required BOOLEAN DEFAULT (FALSE) NOT NULL,
enabled INTEGER,
	CONSTRAINT services_envs_FK FOREIGN KEY (version) REFERENCES envs(name)
);

CREATE UNIQUE INDEX services_name_IDX ON
services (name);
-- service_actions definition

CREATE TABLE service_actions (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	"action" TEXT NOT NULL,
	service TEXT NOT NULL,
	cmd TEXT NOT NULL,
cmd_type TEXT DEFAULT ('cmd') NOT NULL,
sudo INTEGER DEFAULT (0),
	FOREIGN KEY (service) REFERENCES services(name) ON
DELETE
    CASCADE ON
    UPDATE
        CASCADE
);
-- service_deps definition

CREATE TABLE service_deps(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_id INTEGER NOT NULL,
  dep_id INTEGER NOT NULL,
  FOREIGN KEY(service_id) REFERENCES services(id) ON DELETE CASCADE,
  FOREIGN KEY(dep_id) REFERENCES deps(id) ON DELETE CASCADE,
  UNIQUE(service_id, dep_id)
);
-- service_envs definition

CREATE TABLE service_envs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_id INTEGER NOT NULL,
    env_id INTEGER NOT NULL,
    FOREIGN KEY (service_id) REFERENCES services(id) ON
DELETE
    CASCADE,
    FOREIGN KEY (env_id) REFERENCES envs(id) ON
    DELETE
        CASCADE,
        UNIQUE(service_id, env_id)
);
