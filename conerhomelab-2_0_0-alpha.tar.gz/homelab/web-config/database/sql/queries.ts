export class DepsQueries {
    static readonly GET_REQUIRED_DEPS = `
SELECT DISTINCT d.name
FROM deps AS d
JOIN service_deps AS sd ON d.id = sd.dep_id
JOIN services AS s ON s.id = sd.service_id
WHERE s.enabled = 1
`;
    static readonly GET_ALL_DEPS = `
SELECT *
FROM deps
`;
    static readonly GET_DEP_BY_NAME = `
SELECT *
FROM deps
WHERE name = ?
`;
}