import type { Config } from "../commons/models.ts";
import { multipleUpdate } from "./db-utils.ts";
import { db } from "./db.ts";
import { getEnvs } from "./envDAO.ts";
import { getServiceListWithVarNames } from "./serviceDAO.ts";

export function loadConfigFromDB(): Config {
    const services = getServiceListWithVarNames();
    const envs = getEnvs();
    return { services, envs };
}

export function saveConfigToDB(config: Config) {
    console.log('  Saving configuration to database...');
    multipleUpdate(db, 'services', ['enabled'],
        config.services.map(s => [s.name, Number(s.enabled)]), "name");
    multipleUpdate(db, 'envs', ['value'],
        config.envs.map(e => [e.name, e.value]), "name");
    console.log('  Configuration saved to database successfully.');
}