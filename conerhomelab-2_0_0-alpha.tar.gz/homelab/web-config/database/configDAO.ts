import type { Config } from "../commons/models.ts";
import { multipleUpdate } from "./db-utils.ts";
import { db } from "./db.ts";
import { getEnvs } from "./envDAO.ts";
import { getServiceList } from "./serviceDAO.ts";
import { getLogger } from "../backend/logger.ts";

const log = getLogger("configDAO");

export function loadConfigFromDB(): Config {
    const services = getServiceList();
    const envs = getEnvs();
    return { services, envs };
}

export function saveConfigToDB(config: Config) {
    log.info('Saving configuration to database...');
    config.services.length > 0 && multipleUpdate(db, 'services', ['enabled'],
        config.services.map(s => [s.name, Number(s.enabled)]), "name");
    config.envs.length > 0 && multipleUpdate(db, 'envs', ['value'],
        config.envs.map(e => [e.name, e.value]), "name");
    if (config.services.length === 0 && config.envs.length === 0) {
        log.info('  No changes to save.');
        return;
    }
    log.info(`Configuration saved to database successfully. ${config.services.length} services updated, ${config.envs.length} envs updated.`);
}