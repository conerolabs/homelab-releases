import type { Config } from "../commons/models.ts";
import { multipleUpdate } from "./db-utils.ts";
import { db } from "./db.ts";
import { getEnvs } from "./envDAO.ts";
import { getServiceList } from "./serviceDAO.ts";

export function loadConfigFromDB(): Config {
    const services = getServiceList();
    const envs = getEnvs();
    return { services, envs };
}

export function saveConfigToDB(config: Config) {
    console.log('  Saving configuration to database...');
    config.services.length > 0 && multipleUpdate(db, 'services', ['enabled'],
        config.services.map(s => [s.name, Number(s.enabled)]), "name");
    config.envs.length > 0 && multipleUpdate(db, 'envs', ['value'],
        config.envs.map(e => [e.name, e.value]), "name");
    if (config.services.length === 0 && config.envs.length === 0) {
        console.log('  No changes to save.');
        return;
    }
    console.log(`  Configuration saved to database successfully. ${config.services.length} services updated, ${config.envs.length} envs updated.`);
}