CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  groups TEXT NOT NULL DEFAULT ('users'),
  created_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP)
);

CREATE TABLE IF NOT EXISTS envs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  value TEXT,
  descr TEXT,
  visible BOOLEAN NOT NULL DEFAULT (true),
  readonly BOOLEAN NOT NULL DEFAULT (false),
  created_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP),
  updated_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP),
  deleted_at TIMESTAMP DEFAULT (NULL)
);

CREATE TABLE IF NOT EXISTS deps(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  install_cmd TEXT NOT NULL,
  check_cmd TEXT NOT NULL,
  remove_cmd TEXT NOT NULL
);

-- service type values: docker, host
CREATE TABLE IF NOT EXISTS services(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  descr TEXT,
  subdomain TEXT,
  icon TEXT,
  "type" TEXT NOT NULL DEFAULT ('docker'),
  enabled BOOLEAN NOT NULL DEFAULT (false),
  visible BOOLEAN NOT NULL DEFAULT (true),
  required BOOLEAN NOT NULL DEFAULT (false),
  version TEXT,
  docker_img TEXT,
  start_cmd TEXT,
  stop_cmd TEXT,
  FOREIGN KEY(version) REFERENCES envs(name)
);

CREATE TABLE IF NOT EXISTS service_envs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_id INTEGER NOT NULL,
  env_id INTEGER NOT NULL,
  FOREIGN KEY(service_id) REFERENCES services(id) ON DELETE CASCADE,
  FOREIGN KEY(env_id) REFERENCES envs(id) ON DELETE CASCADE,
  UNIQUE(service_id, env_id)
);

CREATE TABLE IF NOT EXISTS service_deps(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_id INTEGER NOT NULL,
  dep_id INTEGER NOT NULL,
  FOREIGN KEY(service_id) REFERENCES services(id) ON DELETE CASCADE,
  FOREIGN KEY(dep_id) REFERENCES deps(id) ON DELETE CASCADE,
  UNIQUE(service_id, dep_id)
);

CREATE TABLE IF NOT EXISTS service_actions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  "action" TEXT NOT NULL,
  service TEXT NOT NULL,
  cmd TEXT NOT NULL,
  FOREIGN KEY(service) REFERENCES services(name) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE VIEW IF NOT EXISTS service_envs_view AS
SELECT s.name AS service_name, e.name AS var_name
FROM services AS s
LEFT JOIN service_envs AS se ON s.id = se.service_id
JOIN envs AS e ON se.env_id = e.id;

CREATE VIEW IF NOT EXISTS service_deps_view AS
SELECT s.name AS service_name, d.name AS dep_name
FROM services AS s
LEFT JOIN service_deps AS sd ON s.id = sd.service_id
JOIN deps AS d ON sd.dep_id = d.id;
