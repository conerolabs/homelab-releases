import type { DependencyModel } from "../commons/models.ts";
import { db } from "./db.ts";
import { DepsQueries } from "./sql/queries.ts";

export function getRequiredDeps() {
    return db.prepare(DepsQueries.GET_REQUIRED_DEPS).all() as DependencyModel[];
}

export function getAllDeps() {
    return db.prepare(DepsQueries.GET_ALL_DEPS).all() as DependencyModel[];
}

export function getDep(name: string) {
    return db.prepare(DepsQueries.GET_DEP_BY_NAME).get(name) as DependencyModel | undefined;
}