import type { EnvModel } from "../commons/models.ts";
import { db } from "./db.ts";

export function getEnvs(): EnvModel[] {
    try {
        return db.prepare(`SELECT * FROM envs`).all() as unknown[] as EnvModel[];
    } catch (error) {
        console.error(error);
        return [];
    }
}

export function getEnv(name: string) {
    const env = db?.prepare(`SELECT * FROM envs WHERE name = ?`).get(name);
    return env;
}

export function configureEnv(env: EnvModel) {
    try {
        const result = db.prepare(`
            INSERT INTO envs (name, value, descr, readonly, visible)
            VALUES (@name, @value, @descr, @ro, @visible)
            ON CONFLICT(name) DO UPDATE SET 
                value = excluded.value,
                descr = excluded.descr,
                readonly = envs.readonly,
                visible = envs.visible
            RETURNING id
        `).get({
            name: env.name,
            value: env.value ?? null,
            descr: env.descr ?? null,
            ro: env.readonly ? 1 : 0, // lascerà comunque il valore precedente data la query
            visible: env.visible ? 1 : 0, // lascerà comunque il valore precedente data la query
        });
        if (result?.id) {
            console.log(`DB - Env ${env.name} upserted successfully. Id: ${result.id}`);
            return result.id;
        }
        throw new Error(`DB - Failed to upsert env ${env.name}.`);
    } catch (error) {
        console.error(error);
    }
}

export function deleteEnv(name: string) {
    db.exec(`DELETE FROM envs WHERE name = '${name}'`);
}