import type { EnvModel } from "../commons/models.ts";
import { db } from "./db.ts";
import { getLogger } from "../backend/logger.ts";

const log = getLogger('envDAO');

export function getEnvs(): EnvModel[] {
    try {
        return db.prepare(`SELECT * FROM envs ORDER BY name ASC`).all() as unknown[] as EnvModel[];
    } catch (error) {
        log.error(`ERROR - ${error}`);
        return [];
    }
}

export function getEnv(name: string) {
    const env = db?.prepare(`SELECT * FROM envs WHERE name = ?`).get(name);
    return env;
}

export function configureEnv(env: EnvModel) {
    try {
        const result = db.prepare(`
            INSERT INTO envs (name, value, descr, readonly, visible)
            VALUES (@name, @value, @descr, @ro, @visible)
            ON CONFLICT(name) DO UPDATE SET 
                value = excluded.value,
                descr = excluded.descr,
                readonly = envs.readonly,
                visible = envs.visible
            RETURNING id
        `).get({
            name: env.name,
            value: env.value ?? null,
            descr: env.descr ?? null,
            ro: env.readonly ? 1 : 0, // lascerà comunque il valore precedente data la query
            visible: env.visible ? 1 : 0, // lascerà comunque il valore precedente data la query
        });
        if (result?.id) {
            log.info(`DB - Env ${env.name} upserted successfully.`);
            return result.id;
        }
        throw new Error(`DB - Failed to upsert env ${env.name}.`);
    } catch (error) {
        log.error(`ERROR - ${error}`);
    }
}

export function deleteOldEnvs(currentEnvs: string[]) {
    try {
        const result = db.prepare(`DELETE FROM envs WHERE name NOT IN (${currentEnvs.map(() => '?').join(',')})`).run(...currentEnvs);
        log.info(`DB - Deleted ${result.changes} old envs.`);
    } catch (error) {
        log.error(`ERROR - ${error}`);
    }
}

export function deleteEnv(name: string) {
    try {
        db.exec(`DELETE FROM envs WHERE name = '${name}'`);
        log.info(`DB - Env ${name} deleted successfully.`);
    } catch (error) {
        log.error(`ERROR - ${error}`);
    }
}