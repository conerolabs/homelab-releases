INSERT INTO services(
  name,
  descr,
  subdomain,
  icon,
  "type",
  enabled,
  visible,
  version,
  docker_img
)
VALUES
  (
    'authelia',
    'Single Sign-On (SSO) and authentication server with OIDC and 2FA.',
    'auth',
    NULL,
    'docker',
    1,
    1,
    '4.39.20',
    'authelia/authelia'
  ),
  (
    'caddy',
    'Reverse proxy and web server with automatic HTTPS using Cloudflare DNS.',
    NULL,
    NULL,
    'docker',
    1,
    1,
    '2.11.2',
    'caddy'
  ),
  (
    'cronicle',
    'Distributed task scheduler and runner with a web UI.',
    'cron',
    NULL,
    'docker',
    0,
    1,
    'latest',
    'cronicle/edge'
  ),
  (
    'filebrowser',
    'Web-based file manager to browse and organize homelab files.',
    'files',
    NULL,
    'docker',
    0,
    1,
    '2.63.5',
    'filebrowser/filebrowser'
  ),
  (
    'gatus',
    'Service health dashboard and monitoring tool with notifications.',
    'status',
    NULL,
    'docker',
    0,
    1,
    'stable',
    'twinproduction/gatus'
  ),
  (
    'homepage',
    'Sleek, customizable dashboard showing all homelab services.',
    'home',
    NULL,
    'docker',
    1,
    1,
    'v1.13',
    'gethomepage/homepage'
  ),
  ('headscale', 'Headscale Mesh VPN', 'vpn', NULL, 'host', 0, 1, '0.28.0', NULL),
  (
    'headscale-ui',
    'Web interface for managing the Headscale Tailscale coordination server.',
    'vpn/web',
    NULL,
    'docker',
    0,
    1,
    'latest',
    'ghcr.io/gurucomputing/headscale-ui'
  ),
  (
    'navidrome',
    'Modern music streaming server and library manager.',
    'music',
    NULL,
    'docker',
    0,
    1,
    'latest',
    'deluan/navidrome'
  ),
  (
    'pihole',
    'Network-wide ad-blocker and recursive/upstream DNS resolver.',
    'dns',
    NULL,
    'docker',
    1,
    1,
    '2026.05.0',
    'pihole/pihole'
  )
ON CONFLICT (name) DO NOTHING;

INSERT INTO services(
  name,
  descr,
  subdomain,
  icon,
  "type",
  enabled,
  visible,
  version,
  docker_img
)
VALUES
  (
    'portainer',
    'Web-based container management interface for Docker.',
    'portainer',
    NULL,
    'docker',
    0,
    1,
    'lts',
    'portainer/portainer-ce'
  ),
  (
    'myspeed',
    'Automated internet speed test logger and dashboard.',
    'speedtest',
    NULL,
    'docker',
    0,
    1,
    'latest',
    'germannewsmaker/myspeed'
  ),
  (
    'radio-manager',
    'Navidrome web radio management',
    NULL,
    NULL,
    'docker',
    0,
    1,
    'latest',
    'ghcr.io/brunopiras/naviradiomanager'
  ),
  (
    'redis',
    'Fast in-memory database used by Authelia for session storage.',
    NULL,
    NULL,
    'docker',
    1,
    0,
    '8-alpine',
    'redis'
  ),
  (
    'rustical',
    'CalDAV/CardDAV server for calendars and contacts.',
    'calendar',
    NULL,
    'docker',
    0,
    1,
    'latest',
    'ghcr.io/lennart-k/rustical'
  ),
  ('unbound', 'Recursive DNS resolver', NULL, NULL, 'host', 0, 1, NULL, NULL),
  (
    'vaultwarden',
    'Lightweight Bitwarden-compatible password manager server.',
    'vault',
    NULL,
    'docker',
    0,
    1,
    '1.36.0',
    'vaultwarden/server'
  ),
  ('SYSTEM', 'Main system', NULL, NULL, 'host', 1, 0, NULL, NULL)
ON CONFLICT (name) DO NOTHING;
