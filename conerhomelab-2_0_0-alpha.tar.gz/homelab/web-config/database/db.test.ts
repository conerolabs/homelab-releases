import test from "node:test";
import * as dbModule from "./db.ts";
import assert from "node:assert";
import { syncEnvs, syncServices, syncUsers } from "./db-utils.ts";
import { getService } from "./serviceDAO.ts";
import { configureEnv, deleteEnv, getEnv } from "./envDAO.ts";
import { AUTHELIA_USERS_PATH, COMPOSE_PATH, ENV_PATH } from "../backend/config-utils.ts";

const skip = [
    // 'db.getService',
    'db.configureEnv',
    'db.synch'
]

test('db.synch', (t) => {
    if (skip.includes(t.name)) {
        t.skip()
        return
    }
    syncEnvs(ENV_PATH);
    syncServices(COMPOSE_PATH);
    syncUsers(AUTHELIA_USERS_PATH);

})

test('db.getService', (t) => {
    if (skip.includes(t.name)) {
        t.skip()
        return
    }
    const service = getService('pihole')
    service && console.log(JSON.stringify(service, null, 2))
    assert(service, 'Service pihole not found')
    assert(service?.actions?.some(a => a.action === 'setup'), 'Service action "setup" not found')
    // assert(service?.actions?.some(a => a.action === 'start'), 'Service action "start" not found')
    // assert(service?.actions?.some(a => a.action === 'stop'), 'Service action "stop" not found')
    assert(service?.actions?.some(a => a.action === 'deploy'), 'Service action "deploy" not found')
});

test('db.configureEnv', (t) => {
    if (skip.includes(t.name)) {
        t.skip()
        return
    }
    const name = 'TEST_VAR4';
    const envId = configureEnv({
        name: name,
        value: 'test_value',
        descr: 'test_desc',
        readonly: false,
        visible: true,
    })
    assert.ok(envId)
    assert.strictEqual(envId, getEnv(name)?.id)
    assert.strictEqual(getEnv(name)?.value, 'test_value')
    const newEnv = configureEnv({
        name: name,
        value: 'test_value2',
        descr: 'test_desc2',
        readonly: true,
        visible: false,
    })
    assert.strictEqual(newEnv, envId)
    assert.strictEqual(getEnv(name)?.value, 'test_value2')
    deleteEnv(name)
    assert.strictEqual(getEnv(name), undefined)
})

// test('get env from db', () => {
//     const env = db.getEnv('TEST_VAR')
//     assert.ok(env)
//     assert.strictEqual(env.value, 'test_value')
// })

