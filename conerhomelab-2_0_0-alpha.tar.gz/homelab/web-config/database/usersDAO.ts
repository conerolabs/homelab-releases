import { db } from "./db.ts";
import type { UserModel } from "../commons/models.ts";
import { multipleInsert } from "./db-utils.ts";

export function insertUser(user: UserModel) {
    try {
        console.log(`Inserting user ${user.username}`);
        db.prepare(`INSERT INTO users (username, email, display_name, groups) VALUES (?, ?, ?, ?)`)
            .run(user.username, user.email, user.display_name, user.groups ?? 'users');
        console.log(`User ${user.username} inserted`);
    } catch (error) {
        console.error(`Error inserting user ${user.username}`, error);
        throw error;
    }
}

export function insertUsers(users: UserModel[]) {
    try {
        console.log(`DB - Inserting ${users.length} users...`);
        multipleInsert(db, 'users', ['username', 'email', 'display_name', 'groups'], users.map(user => [user.username, user.email, user.display_name, user.groups]));
        console.log(`DB - Inserted ${users.length} users`);
    } catch (error) {
        console.error('DB - Error inserting users', error);
        throw error;
    }
}

export function deleteUser(username: string) {
    try {
        console.log(`Deleting user ${username}`);
        db.prepare(`DELETE FROM users WHERE username = ?`).run(username);
        console.log(`User ${username} deleted`);
    } catch (error) {
        console.error(`Error deleting user ${username}`, error);
        throw error;
    }
}

export function getAllUsers() {
    try {
        const stmt = db.prepare(`SELECT * FROM users ORDER BY username ASC`);
        const users = stmt.all() as unknown as UserModel[];
        return users;
    } catch (error) {
        console.error('Error getting all users', error);
        throw error;
    }
}

export function deleteAllUsers() {
    try {
        console.log(`DB - Deleting all users...`);
        const result = db.prepare(`DELETE FROM users`).run();
        console.log(`DB - All users deleted (${result.changes})`);
    } catch (error) {
        console.error('Error deleting all users', error);
        throw error;
    }
}
