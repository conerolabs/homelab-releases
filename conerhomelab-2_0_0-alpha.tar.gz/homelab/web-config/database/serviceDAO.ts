import { getLogger } from "../backend/logger.ts";
import type { EnvModel, ServiceActionModel, ServiceModel } from "../commons/models.ts";
import { db } from "./db.ts";

const log = getLogger('ServiceDAO', { msgPrefix: 'DB - ' });

const SERVICE_LIST_QUERY = "SELECT * FROM services";
const GET_SERVICE_QUERY = `SELECT * FROM services WHERE name = ?`
const GET_SERVICE_ACTIONS_QUERY = `SELECT * FROM service_actions WHERE service = ?`

/**
 * Get all services from the database with relative envs and actions
 * @returns {ServiceModel[]} Array of services.
 */
export function getServiceList(): ServiceModel[] {
    try {
        const service = db.prepare(SERVICE_LIST_QUERY).all() as unknown[] as ServiceModel[];
        return service.map((s: ServiceModel) => {
            const envs = getServiceEnvs(s.name) || [];
            return {
                ...s,
                envs: envs.map(e => e.name),
                actions: getServiceActions(s.name)
            } as ServiceModel;
        });
    } catch (error) {
        console.error(error);
        return [];
    }
}

export function getService(name: string) {
    const service = db.prepare(GET_SERVICE_QUERY).get(name) as unknown as ServiceModel;
    if (service) {
        return {
            ...service,
            envs: getServiceEnvs(service.name) || [],
            actions: getServiceActions(service.name)
        };
    }
    return null;
}

export function configureService(name: string, type: 'docker' | 'host', docker_img: string | null, version: string | null, envs: string[]) {

    try {
        const row = db.prepare(`
            INSERT INTO services (name, type, docker_img, version)
            VALUES (@name, @type, @docker_img, @version)
            ON CONFLICT(name) DO UPDATE SET 
                type = excluded.type,
                docker_img = excluded.docker_img,
                version = excluded.version,
                required = services.required,
                visible = services.visible,
                enabled = services.enabled
            RETURNING id
        `).get({
            name: name,
            type: type,
            docker_img: docker_img,
            version: version
        });
        if (!row?.id) {
            throw new Error(`Failed to upsert service ${name}.`);
        }
        updateServiceEnvs(name, envs)
        log.debug(`Service ${name} [${docker_img}] configured successfully.`);
    } catch (error) {
        log.error({ type, version, envs }, `Failed to configure service ${name} [${docker_img}]. ${error}`);
    }
}

export function deleteService(name: string) {
    try {
        //delete service
        db.prepare(`DELETE FROM service_deps WHERE service_name = ?`).run(name);
        db.prepare(`DELETE FROM service_envs WHERE service_name = ?`).run(name);
        db.prepare(`DELETE FROM services WHERE name = ?`).run(name);
        log.info(`Service ${name} deleted successfully.`);
    } catch (error) {
        log.error(`Failed to delete service ${name}. ${error}`);
    }
}

export function getServiceEnvs(serviceIdentifier: string | number) {
    try {
        let serviceName: string;
        if (typeof serviceIdentifier === 'number') {
            const row = db?.prepare(`SELECT name FROM services WHERE id = ?`).get(serviceIdentifier) as { name: string } | undefined;
            if (!row) return [];
            serviceName = row.name;
        } else {
            serviceName = serviceIdentifier;
        }
        const serviceEnvs = db?.prepare(`SELECT e.* FROM envs e INNER JOIN service_envs se ON e.name = se.env_name WHERE se.service_name = ?`).all(serviceName);
        return serviceEnvs as unknown[] as EnvModel[];
    } catch (error) {
        log.error(`Failed to get service envs for service ${serviceIdentifier}. ${error}`);
        return [];
    }
}

function updateServiceEnvs(serviceName: string, envs: string[]) {
    db.prepare(`DELETE FROM service_envs WHERE service_name = ?`).run(serviceName);
    const selectEnvStmt = db.prepare(`SELECT name FROM envs WHERE name = ?`);
    const insertEnvStmt = db.prepare(`INSERT INTO envs (name) VALUES (?)`);
    const insertServiceEnvStmt = db.prepare(`INSERT INTO service_envs (service_name, env_name) VALUES (?, ?)`);

    const uniqueEnvs = Array.from(new Set(envs));
    uniqueEnvs.forEach(envName => {
        const env = selectEnvStmt.get(envName);
        if (!env) {
            log.info(`Env ${envName} not found. Creating...`);
            insertEnvStmt.run(envName);
            log.info(`Env ${envName} created successfully.`);
        }
        insertServiceEnvStmt.run(serviceName, envName);
    });
}

export function getServiceActions(serviceName: string) {
    try {
        const actions = db.prepare(GET_SERVICE_ACTIONS_QUERY).all(serviceName) as unknown[] as ServiceActionModel[];
        return actions;
    } catch (error) {
        log.error(`Failed to get service actions for service ${serviceName}. ${error}`);
        return [];
    }
}
