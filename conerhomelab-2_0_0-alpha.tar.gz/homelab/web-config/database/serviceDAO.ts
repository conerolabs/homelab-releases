import { getLogger } from "../backend/logger.ts";
import type { EnvModel, ServiceActionModel, ServiceModel } from "../commons/models.ts";
import { db } from "./db.ts";

const log = getLogger('ServiceDAO', { msgPrefix: 'DB - ' });

const SERVICE_LIST_QUERY = "SELECT * FROM services";
const GET_SERVICE_QUERY = `SELECT * FROM services WHERE name = ?`
const GET_SERVICE_ACTIONS_QUERY = `SELECT * FROM service_actions WHERE service = ?`

export function getServiceList() {
    try {
        const service = db.prepare(SERVICE_LIST_QUERY).all() as unknown[] as ServiceModel[];
        return service.map((s: ServiceModel) => {
            const envs = getServiceEnvs(s.id as number) as unknown[] as EnvModel[];
            return {
                ...s,
                envs: envs.map(e => e.name),
                actions: getServiceActions(s.name)
            } as ServiceModel;
        });
    } catch (error) {
        console.error(error);
        return [];
    }
}

export function getService(name: string) {
    const service = db.prepare(GET_SERVICE_QUERY).get(name) as unknown as ServiceModel;
    if (service) {
        return {
            ...service,
            envs: getServiceEnvs(service.id!),
            actions: getServiceActions(service.name)
        };
    }
    return null;
}

export function configureService(name: string, type: 'docker' | 'host', docker_img: string | null, version: string | null, envs: string[]) {

    try {
        const row = db.prepare(`
            INSERT INTO services (name, type, docker_img, version)
            VALUES (@name, @type, @docker_img, @version)
            ON CONFLICT(name) DO UPDATE SET 
                type = excluded.type,
                docker_img = excluded.docker_img,
                version = excluded.version,
                required = services.required,
                visible = services.visible,
                enabled = services.enabled
            RETURNING id
        `).get({
            name: name,
            type: type,
            docker_img: docker_img,
            version: version
        });
        if (!row?.id) {
            throw new Error(`Failed to upsert service ${name}.`);
        }
        updateServiceEnvs(row.id as number, envs)
        log.info(`Service ${name} [${docker_img}] configured successfully.`);
    } catch (error) {
        log.error(`Failed to configure service ${name} [${docker_img}]. ${error}`);
    }
}

export function deleteService(name: string) {
    try {
        //delete service
        db.exec(`DELETE FROM services WHERE name = '${name}'`);
        log.info(`Service ${name} deleted successfully.`);
    } catch (error) {
        log.error(`Failed to delete service ${name}.`);
    }
}

export function getServiceEnvs(serviceId: number) {
    try {
        // db.isOpen ?? db.open();
        const serviceEnvs = db?.prepare(`SELECT e.* FROM envs e INNER JOIN service_envs se ON e.id = se.env_id WHERE se.service_id = ?`).all(serviceId);
        return serviceEnvs;
    } catch (error) {
        log.error(`Failed to get service envs for service id ${serviceId}. ${error}`);
    }
    // finally {
    //     db.close();
    // }
}

function updateServiceEnvs(serviceId: number, envs: string[]) {
    // console.log(`DB - Updating envs list for service id: ${serviceId}`)
    db.exec(`DELETE FROM service_envs WHERE service_id = ${serviceId}`);
    envs.forEach(envName => {
        const env = db?.prepare(`SELECT id FROM envs WHERE name = ?`).get(envName);
        if (env) {
            db.exec(`INSERT INTO service_envs (service_id, env_id) VALUES ('${serviceId}', '${env.id}')`);
        } else {
            log.info(`Env ${envName} not found. Creating...`);
            const eid = db.prepare(`INSERT INTO envs (name) VALUES (?) RETURNING id`).get(envName);
            log.info(`Env ${envName} created successfully.`);
            db.exec(`INSERT INTO service_envs (service_id, env_id) VALUES ('${serviceId}', '${eid!.id}')`);
        }
    });
}

export function getServiceActions(serviceName: string) {
    try {
        const actions = db.prepare(GET_SERVICE_ACTIONS_QUERY).all(serviceName) as unknown[] as ServiceActionModel[];
        return actions;
    } catch (error) {
        log.error(`Failed to get service actions for service ${serviceName}. ${error}`);
        return [];
    }
}
