import type { PathLike } from "node:fs";
import fs, { existsSync } from "node:fs";
import type { EnvModel, ServiceModel } from "../commons/models.ts";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { loadYaml, parseYaml } from "../commons/yaml-utils.ts";
import type { ComposeSpecification, Service } from "./compose-types.d.ts";
import { getLogger } from "./logger.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ENV_PATH = process.env.ENV_PATH || path.join(__dirname, '../../.env');
const COMPOSE_PATH = process.env.COMPOSE_PATH || path.join(__dirname, '../../docker-compose.yml');
const AUTHELIA_CONFIG_PATH = process.env.AUTHELIA_CONFIG_PATH || path.join(__dirname, '../../authelia/config/config.yml');
const AUTHELIA_USERS_PATH = process.env.AUTHELIA_USERS_PATH || path.resolve(__dirname, '../../authelia/config/users_database.yml');

process.loadEnvFile(ENV_PATH);

export type AutheliaConfig = {
    authentication_backend: {
        file: {
            password: {
                algorithm: string,
                argon2: AutheliaHashOptions,
            }
        }
    }

}

export type AutheliaHashOptions = {
    variant: string;
    iterations: number;
    memory: number;
    parallelism: number;
    key_length: number;
    salt_length: number;
}

export type AutheliaUsersDb = {
    users: { [username: string]: AutheliaUserData };
}

export type AutheliaUserData = {
    groups: string[];
    email: string;
    password: string;
    displayname: string;
}

const log = getLogger("ConfigUtils");

// Helper to extract services and their referenced environment variables from docker-compose.yml
function parseComposeService(name: string, svc: Service) {
    if (!svc || typeof svc !== 'object') return;

    const envRegex = /\$\{([a-zA-Z0-9_]+)(?::-?[^}]*)?\}/g;

    const envVars = new Set<string>();
    const service: ServiceModel = { name, type: 'docker', envs: [] };

    // Extract image
    service.docker_img = svc.image?.split(':')[0];

    // Scan all string values in the service for ${VAR} references
    const scanForEnvRefs = (value: unknown): void => {
        if (typeof value === 'string') {
            let match: RegExpExecArray | null;
            const re = new RegExp(envRegex.source, 'g');
            while ((match = re.exec(value)) !== null) {
                envVars.add(match[1]);
            }
        } else if (Array.isArray(value)) {
            value.forEach(scanForEnvRefs);
        } else if (value && typeof value === 'object') {
            Object.values(value).forEach(scanForEnvRefs);
        }
    };
    scanForEnvRefs(svc);

    // Extract image from dockerfile_inline FROM statement
    const build = svc.build;
    if (build && typeof build !== 'string') {
        service.docker_img = build.dockerfile_inline?.match(/FROM ([\w/-]+)/)?.[1];
    }

    service.envs = Array.from(envVars);
    return service;
}

// Helper to extract services using js-yaml
function parseDockerCompose(dockerComposePath: PathLike = COMPOSE_PATH): Record<string, ServiceModel> {
    console.log("CONFIG - Parsing docker-compose (yaml) from: ", dockerComposePath);
    const doc = loadYaml<ComposeSpecification>(dockerComposePath);

    if (!doc || typeof doc !== 'object' || !doc['services']) {
        console.log("CONFIG - No services found");
        return {};
    }

    const services: Record<string, ServiceModel> = {};

    for (const [name, svc] of Object.entries(doc.services)) {
        const service = parseComposeService(name, svc);
        if (service) services[name] = service;
    }

    if (Object.keys(services).length === 0) {
        console.log("CONFIG - No services found");
    }
    return services;
}

// Helper to parse .env file
function parseEnv(envPath: PathLike = ENV_PATH) {
    console.log("CONFIG - Parsing .env from: ", envPath.toString());
    if (!fs.existsSync(envPath)) {
        throw Error(`file not found at ${envPath}`);
    }

    const content = fs.readFileSync(envPath, 'utf-8');
    const envs: Record<string, EnvModel> = {};
    const lines = content.split('\n');
    let info: string[] = [];

    for (let line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue
        if (trimmed.startsWith('##')) {
            info.push(...trimmed.substring(2).trim().split(', '));
            continue;
        }
        if (trimmed.startsWith('#')) continue;

        const eqIndex = trimmed.indexOf('=');
        if (eqIndex === -1) continue;

        const name = trimmed.substring(0, eqIndex).trim();
        let value = trimmed.substring(eqIndex + 1).trim();

        // Strip quotes if they surround the value
        if ((value.startsWith("'") && value.endsWith("'")) || (value.startsWith('"') && value.endsWith('"'))) {
            value = value.substring(1, value.length - 1);
        }

        const descr = info.filter(i => i !== 'READONLY' && i !== 'HIDDEN').join('. ');

        envs[name] = { name, value, descr };
        info = [];
    }

    return envs;
}

// Helper to write updated env variables to .env while preserving comments and layout
function saveEnvs(envs: EnvModel[], envPath: PathLike = ENV_PATH) {
    console.log("CONFIG - Saving .env to: ", envPath);
    if (envs.length === 0) {
        console.log("  --> No envs to save.");
        return;
    }
    const content = fs.existsSync(envPath) ? fs.readFileSync(envPath, 'utf-8') : '';
    const lines = content.split('\n');
    const updatedKeys = new Set();
    const resultLines = [];

    for (const line of lines) {
        const trimmed = line.trim();
        // Preserve empty lines and comments as they are
        if (!trimmed || trimmed.startsWith('#')) {
            resultLines.push(line);
            continue;
        }

        const eqIndex = line.indexOf('=');
        if (eqIndex === -1) {
            resultLines.push(line);
            continue;
        }

        const key = line.substring(0, eqIndex).trim();

        const env = envs.find(env => env.name === key);
        if (env) {
            resultLines.push(`${key}='${env.value}'`);
            updatedKeys.add(key);
        } else {
            resultLines.push(line);
        }
    }

    // Add any new keys that were not in the original file
    envs.filter(env => !updatedKeys.has(env.name)).forEach(env => {
        resultLines.push(`${env.name}='${env.value}'`);
    });

    fs.writeFileSync(envPath, resultLines.join('\n'), 'utf-8');
    console.log(`CONFIG - .env file updated successfully with ${envs.length} entries.`);
}

function parseAutheliaUsers(path: PathLike = AUTHELIA_USERS_PATH): AutheliaUsersDb {
    log.info(`CONFIG - Parsing Authelia users from: ${path}`);
    if (!existsSync(path)) {
        log.warn(`  --> File not found, returning empty users`);
        return { users: {} };
    }
    const data = loadYaml<AutheliaUsersDb>(path);
    log.info(`  --> Found ${Object.keys(data.users).length} users`);
    return data;
}

function parseAutheliaConfig(path: PathLike = AUTHELIA_CONFIG_PATH) {
    log.info(`CONFIG - Parsing Authelia config from: ${path}`);
    // Leggi il contenuto del file template
    const templateContent: string = fs.readFileSync(path, 'utf8');

    // Regex per catturare {{ env "VAR" }} o {{ mustEnv "VAR" }}
    // Cattura: 1. il nome della funzione (env o mustEnv), 2. il nome della variabile
    const regex = /{{\s*(env|mustEnv)\s+"([^"]+)"\s*}}/g;

    const renderedContent = templateContent.replace(regex, (match: string, funcName: string, varName: string) => {
        const value = process.env[varName];

        if (value === undefined) {
            if (funcName === 'mustEnv') {
                throw new Error(`Errore critico: la variabile d'ambiente richiesta '${varName}' non è definita.`);
            }
            // Per 'env', se manca, ritorna stringa vuota (comportamento standard di Go template)
            log.warn(`Attenzione: la variabile d'ambiente '${varName}' non è definita. Sostituita con stringa vuota.`);
            return '';
        }

        return value;
    });

    // Parsing con js-yaml per ottenere i modelli per le classi
    const autheliaConfig = parseYaml<AutheliaConfig>(renderedContent);
    return autheliaConfig;
}

export {
    ENV_PATH,
    COMPOSE_PATH,
    AUTHELIA_USERS_PATH,
    AUTHELIA_CONFIG_PATH,
    parseDockerCompose,
    parseEnv,
    saveEnvs,
    parseAutheliaConfig,
    parseAutheliaUsers,
};