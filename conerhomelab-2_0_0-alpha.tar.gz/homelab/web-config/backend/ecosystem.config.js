export const apps = [
    {
        name: "web-config-app",
        script: "./server.ts",
        env_production: {
            NODE_ENV: "production",
            LOG_LEVEL: "info"
        },
        env_development: {
            NODE_ENV: "development",
            LOG_LEVEL: "debug"
        }
    },
];
