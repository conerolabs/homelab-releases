export const apps = [
    {
        name: "web-config-app",
        script: "./server.ts",
        interpreter: "node",
        max_memory_restart: "384M",
        node_args: '--max-old-space-size=512',
        env_production: {
            NODE_ENV: "production",
            LOG_LEVEL: "info"
        },
        env_development: {
            NODE_ENV: "development",
            LOG_LEVEL: "debug"
        }
    },
];
