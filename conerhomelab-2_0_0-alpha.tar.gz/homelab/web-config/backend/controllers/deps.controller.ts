import type { Request, Response, NextFunction } from 'express';
import { DepsService } from '../services/deps.service.ts';
import { createSSEResponse } from '../middleware/sse.middleware.ts';
import { SystemService } from '../services/system.service.ts';
import { getLogger } from '../logger.ts';

export class DepsController {

    private static log = getLogger('DepsController');

    public static async getStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        DepsController.log.info('ROUTE - GET /api/deps/status: querying dependency installation statuses...');
        const sse = req.query?.sse === 'true';
        let sseClient = sse ? res.sse || createSSEResponse(res.req as any, res) : null;
        try {
            const deps = DepsService.getRequiredDependencies();
            const requiredDepsStatus = await Promise.all(deps.map(async (dep) => {
                const status = await DepsService.getDepStatus(dep.name);
                sseClient?.send('dep', status);
                return status;
            }));
            sseClient && sseClient.send('done', { code: 0 });
            sseClient ? res.end() : res.json(requiredDepsStatus);
        } catch (err) {
            if (sse) sseClient?.send('error', { code: 1, text: String(err) });
            else next(err);
        }
    }

    public static async getDepStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            const name = req.params.name as string;
            DepsController.log.info(`ROUTE - GET /api/deps/status/${name}: querying ${name} status...`);
            const status = await DepsService.getDepStatus(name);
            DepsController.log.info(`  -> ${status.name} status: ${status.installed ? '' : 'not '}installed`);
            if (status.error) {
                DepsController.log.error(`  --> ${status.name} error: ${status.error}`);
            }
            res.json(status);
        } catch (err) {
            next(err);
        }
    }

    public static async getRequiredDepsStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            DepsController.log.info('ROUTE - GET /api/deps/required/status: querying required dependencies statuses...');
            const deps = await DepsService.getRequiredDependenciesStatus();
            res.json(deps);
        } catch (err) {
            next(err);
        }
    }

    public static async getInstalledDeps(req: Request, res: Response, next: NextFunction): Promise<void> {
        DepsController.log.info('ROUTE - GET /api/deps/installed: querying installed dependencies...');
        try {
            const deps = await DepsService.getAllDependenciesStatus();
            res.json(deps.filter(dep => dep.installed).map(dep => dep.name));
        } catch (err) {
            next(err);
        }
    }

    public static async install(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            const deps = (req.params?.deps ?? []) as string[];
            const sse = res.sse || createSSEResponse(res.req as any, res);
            await DepsService.installSequentially(
                deps,
                (child, taskName, onClose) => {
                    if (child) {
                        sse.streamChildProcess(child, taskName, code => onClose ? onClose(code) : sse.send('done', { code }))
                    } else {
                        sse.send('log', { text: `No need for ${taskName} as dependency is already installed. Skipping.` });
                        onClose ? onClose(0) : sse.send('done', { code: 0 })
                    }
                }
            );
        } catch (err) {
            if (SystemService.getSudoCounter() === 0) SystemService.setSudoPassword('');
            next(err);
        }
    }

    public static async installSingle(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            const name = req.params.name as string;
            const child = await DepsService.installSingle(name);
            const sse = res.sse || createSSEResponse(res.req as any, res);
            if (child) {
                sse.streamChildProcess(child, `${name} installation`, code => sse.send('done', { code }));
            } else {
                sse.send('log', { text: `DEPS - dependency ${name} is already installed. Skipping.` });
                sse.send('done', { code: 0 });
            }
        } catch (err) {
            if (SystemService.getSudoCounter() === 0) SystemService.setSudoPassword('');
            next(err);
        }
    }

    public static async uninstall(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            const name = req.params.name as string;
            const child = await DepsService.uninstall(name);
            const sse = res.sse || createSSEResponse(res.req as any, res);
            sse.streamChildProcess(child, `${name} uninstallation`, code => sse.send('done', { code }));
        } catch (err) {
            if (SystemService.getSudoCounter() === 0) SystemService.setSudoPassword('');
            next(err);
        }
    }
}
