import type { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { DepsService } from '../services/deps.service.ts';
import { ShellService } from '../services/shell.service.ts';
import { SystemController } from './system.controller.ts';
import { createSSEResponse } from '../middleware/sse.middleware.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const INSTALL_SCRIPT_PATH = path.resolve(__dirname, '../../../../install/scripts/1-deps-install.sh');
const MANAGER_SCRIPT_PATH = path.resolve(__dirname, '../../../../install/scripts/deps-manager.sh');


export class DepsController {

    public static async getStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        console.log('ROUTE - GET /api/deps/status: querying dependency installation statuses...');
        const sse = req.query?.sse === 'true';
        const noCache = req.query?.noCache === 'true';
        let sseClient = sse ? res.sse || createSSEResponse(res.req as any, res) : null;
        try {
            const deps = DepsService.getAllDependencies();
            const requiredDepsStatus = await Promise.all(deps.map(async (dep) => {
                const status = await DepsService.checkDependency(dep.name, noCache);
                sseClient?.send('dep', status);
                return status;
            }));
            sseClient && sseClient.send('done', { code: 0 });
            sseClient ? res.end() : res.json(requiredDepsStatus);
        } catch (err) {
            if (sse) sseClient?.send('error', { code: 1, text: String(err) });
            else next(err);
        }
    public static async getRequiredDepsStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        console.log('ROUTE - GET /api/deps/required/status: querying required dependencies statuses...');
        const deps = DepsService.getRequiredDependenciesStatus();
        res.json(deps);
    }

    public static getInstalledDeps(req: Request, res: Response, next: NextFunction): void {
        console.log('ROUTE - GET /api/deps/installed: querying installed dependencies...');
        try {
            const deps = DepsService.getAllDependenciesStatus();
            res.json(deps.filter(dep => dep.installed).map(dep => dep.name));
        } catch (err) {
            next(err);
        }
    }

    public static installAll(req: Request, res: Response, next: NextFunction): void {
        try {
            const child = ShellService.runScript(INSTALL_SCRIPT_PATH, [], SystemController.getSudoPassword());
            child.on('close', code => code === 0 && DepsService.setAllInstalled());
            const sse = res.sse || createSSEResponse(res.req as any, res);
            sse.streamChildProcess(child, 'dependencies installation');
        } catch (err) {
            if (SystemController.getSudoCounter() === 0) SystemController.setSudoPassword('');
            next(err);
        }
    }

    public static installSingle(req: Request, res: Response, next: NextFunction): void {
        try {
            const name = req.params.name as string;
            const child = ShellService.runScript(MANAGER_SCRIPT_PATH, ['install', name], SystemController.getSudoPassword());
            child.on('close', code => code === 0 && DepsService.setInstalled(name));
            const sse = res.sse || createSSEResponse(res.req as any, res);
            sse.streamChildProcess(child, `${name} installation`);
        } catch (err) {
            if (SystemController.getSudoCounter() === 0) SystemController.setSudoPassword('');
            next(err);
        }
    }

    public static uninstall(req: Request, res: Response, next: NextFunction): void {
        try {
            const name = req.params.name as string;
            const child = ShellService.runScript(MANAGER_SCRIPT_PATH, ['remove', name], SystemController.getSudoPassword());
            child.on('close', code => code === 0 && DepsService.setInstalled(name, false));
            const sse = res.sse || createSSEResponse(res.req as any, res);
            sse.streamChildProcess(child, `${name} uninstallation`);
        } catch (err) {
            if (SystemController.getSudoCounter() === 0) SystemController.setSudoPassword('');
            next(err);
        }
    }
}
