import type { Request, Response, NextFunction } from 'express';
import { DepsService } from '../services/deps.service.ts';
import { createSSEResponse } from '../middleware/sse.middleware.ts';
import { SystemService } from '../services/system.service.ts';

export class DepsController {

    public static async getStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        console.log('ROUTE - GET /api/deps/status: querying dependency installation statuses...');
        const sse = req.query?.sse === 'true';
        const noCache = req.query?.noCache === 'true';
        let sseClient = sse ? res.sse || createSSEResponse(res.req as any, res) : null;
        try {
            const deps = DepsService.getAllDependencies();
            const requiredDepsStatus = await Promise.all(deps.map(async (dep) => {
                const status = await DepsService.checkDependency(dep.name, noCache);
                sseClient?.send('dep', status);
                return status;
            }));
            sseClient && sseClient.send('done', { code: 0 });
            sseClient ? res.end() : res.json(requiredDepsStatus);
        } catch (err) {
            if (sse) sseClient?.send('error', { code: 1, text: String(err) });
            else next(err);
        }
    }

    public static async getDepStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            const name = req.params.name as string;
            console.log(`ROUTE - GET /api/deps/status/${name}: querying ${name} status...`);
            const status = await DepsService.checkDependency(name);
            console.log(`  -> ${status.name} status: ${status.installed ? '' : 'not '}installed`);
            if (status.error) {
                console.log(`  --> ${status.name} error: ${status.error}`);
            }
            res.json(status);
        } catch (err) {
            next(err);
        }
    }

    public static async getRequiredDepsStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            console.log('ROUTE - GET /api/deps/required/status: querying required dependencies statuses...');
            const deps = await DepsService.getRequiredDependenciesStatus();
            res.json(deps);
        } catch (err) {
            next(err);
        }
    }

    public static getInstalledDeps(req: Request, res: Response, next: NextFunction): void {
        console.log('ROUTE - GET /api/deps/installed: querying installed dependencies...');
        try {
            const deps = DepsService.getAllDependenciesStatus();
            res.json(deps.filter(dep => dep.installed).map(dep => dep.name));
        } catch (err) {
            next(err);
        }
    }

    public static install(req: Request, res: Response, next: NextFunction): void {
        try {
            const deps = req.params?.deps as string[];
            const sse = res.sse || createSSEResponse(res.req as any, res);
            DepsService.installSequentially(
                deps,
                sse.streamChildProcess
            );
        } catch (err) {
            if (SystemService.getSudoCounter() === 0) SystemService.setSudoPassword('');
            next(err);
        }
    }

    public static installSingle(req: Request, res: Response, next: NextFunction): void {
        try {
            const name = req.params.name as string;
            const child = DepsService.installSingle(name);
            const sse = res.sse || createSSEResponse(res.req as any, res);
            sse.streamChildProcess(child, `${name} installation`);
        } catch (err) {
            if (SystemService.getSudoCounter() === 0) SystemService.setSudoPassword('');
            next(err);
        }
    }

    public static uninstall(req: Request, res: Response, next: NextFunction): void {
        try {
            const name = req.params.name as string;
            const child = DepsService.uninstall(name);
            const sse = res.sse || createSSEResponse(res.req as any, res);
            sse.streamChildProcess(child, `${name} uninstallation`);
        } catch (err) {
            if (SystemService.getSudoCounter() === 0) SystemService.setSudoPassword('');
            next(err);
        }
    }
}
