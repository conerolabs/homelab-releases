import type { Request, Response, NextFunction } from 'express';
import { ConfigService } from '../services/config.service.ts';
import { ShellService } from '../services/shell.service.ts';
import { ServicesService, type RuntimeStatus } from '../services/hlservices/services.service.ts';
import type Stream from 'node:stream';
import { type ChildProcessByStdio } from 'node:child_process';
import { SystemService } from '../services/system.service.ts';
import type { JobResult } from '../../commons/dto.ts';
import { getLogger } from '../logger.ts';

type ServiceStatusResponse = (RuntimeStatus & { service: string; }) | { error: string };

export class ServicesController {

    private static log = getLogger('ServicesController')
    public static deploy(req: Request, res: Response, next: NextFunction): void {
        try {
            const job = ShellService.spawnCommand(ServicesService.getDeployCommandArgs());

            res.sse?.streamChildProcess(job, `Deploy`, (code) =>
                res.sse?.send('done', { code })
            );
        } catch (err) {
            next(err);
        }
    }

    /**
     * GET /api/services/:name/setup
     */
    public static async setupService(req: Request, res: Response, next: NextFunction): Promise<void> {
        ServicesController.log.info(`ROUTE - ${req.method} ${req.baseUrl}${req.path}: setting up ${req.params.name} service ...`);
        const sse = req.query.sse === 'true';
        const params = Object.fromEntries(Object.entries(req.query).filter(([k, _v]) => k !== 'sse'));
        try {
            const serviceName = req.params.name as string;
            sse && res.sse.send('info', { message: `Setting up ${serviceName} service ...` })
            const onTaskCompleted = sse ? (result: JobResult, percentage: number) => {
                res.sse?.send(`task`, { result, percentage });
            } : () => { };
            const setupParams = { serviceName, params, onTaskCompleted };
            const result = await ServicesService.setupService(setupParams);
            sse && res.sse?.send('done', { code: 0 })
            sse && res.end()
            sse || res.json(result);
        } catch (err) {
            sse && res.sse?.send('done', { code: 1 })
            sse && res.end()
            sse || res.status(500).json({ error: 'Internal server error' });
            next(err);
        }
    }

    public static getServiceStatus(req: Request, res: Response<ServiceStatusResponse>, next: NextFunction): void {
        ServicesController.log.info(`ROUTE - ${req.method} ${req.baseUrl}${req.path}: getting ${req.params.name} service status...`);
        try {
            const serviceName = req.params.name as string;
            const config = ConfigService.getConfig();
            const service = config.services.find(s => s.name === serviceName);
            if (!service) {
                res.status(404).json({ error: `Service ${serviceName} not found` });
                return;
            }

            const runtime = ServicesService.getRuntimeStatus(serviceName);
            res.json({
                service: serviceName,
                ...runtime,
            });
        } catch (err) {
            next(err);
        }
    }

    /**
     * Execute a service action streaming the command output
     * 
     * GET /api/services/:name/:action
     * 
     * @param req 
     * @param res 
     * @param next 
     */
    public static executeServiceAction(req: Request, res: Response, next: NextFunction): void {
        try {
            ServicesController.log.info(`ROUTE - ${req.method} ${req.baseUrl}${req.path}: executing action ${req.params.action} on service ${req.params.name}...`);
            const serviceName = req.params.name as string;
            const action = req.params.action as string;

            const config = ConfigService.getConfig();
            const service = config.services.find(s => s.name === serviceName);
            const serviceAction = service?.actions.find(a => a.action === action);

            if (!service) {
                res.status(400).json({ error: 'Invalid or missing service name' });
                return;
            }
            if (!serviceAction) {
                res.status(400).json({ error: `Invalid service action (must be one of ${service.actions.map(a => a.action).join(', ')})` });
                return;
            }

            const sudo = serviceAction.sudo;
            let job: ChildProcessByStdio<Stream.Writable | null, Stream.Readable | null, Stream.Readable | null>;

            const cmdArray = ServicesService.resolveActionCommand(service, action) as string[];
            job = sudo ?
                ShellService.spawnCommandWithSudo(cmdArray, SystemService.getSudoPassword()) :
                ShellService.spawnCommand(cmdArray);
            res.sse?.streamChildProcess(job, `${action} ${serviceName}`, (code) => {
                res.sse?.send('done', { code })
            });
        } catch (err) {
            next(err);
        }
    }
}
