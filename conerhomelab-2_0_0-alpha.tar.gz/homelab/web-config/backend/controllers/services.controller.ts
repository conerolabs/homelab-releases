import type { Request, Response, NextFunction } from 'express';
import { ConfigService } from '../services/config.service.ts';
import { ShellService } from '../services/shell.service.ts';
import { SERVICE_ACTIONS, ServicesService, type RuntimeStatus } from '../services/hlservices/services.service.ts';
import type Stream from 'node:stream';
import { type ChildProcessByStdio } from 'node:child_process';
import type { ServiceAction } from '../services/hlservices/services.service.ts';
import { SystemService } from '../services/system.service.ts';

type ServiceStatusResponse = (RuntimeStatus & { service: string; }) | { error: string };

export class ServicesController {
    public static deploy(req: Request, res: Response, next: NextFunction): void {
        try {
            const job = ShellService.executeCommand(ServicesService.getDeployCommandArgs());
            res.sse?.streamChildProcess(job, `Deploy`);
        } catch (err) {
            next(err);
        }
    }

    public static async setupService(req: Request, res: Response, next: NextFunction): Promise<void> {
        console.log(`ROUTE - POST ${req.baseUrl}${req.path}: setting up ${req.params.name} service ...`);
        try {
            const serviceName = req.params.name as string;
            const result = await ServicesService.setupService(serviceName);
            res.json(result);
        } catch (err) {
            next(err);
        }
    }

    public static getServiceStatus(req: Request, res: Response<ServiceStatusResponse>, next: NextFunction): void {
        console.log(`ROUTE - GET ${req.baseUrl}${req.path}: getting ${req.params.name} service status...`);
        try {
            const serviceName = req.params.name as string;
            const config = ConfigService.getConfig();
            const service = config.services.find(s => s.name === serviceName);
            if (!service) {
                res.status(404).json({ error: `Service ${serviceName} not found` });
                return;
            }

            const runtime = ServicesService.getRuntimeStatus(serviceName);
            res.json({
                service: serviceName,
                ...runtime,
            });
        } catch (err) {
            next(err);
        }
    }

    public static executeServiceAction(req: Request, res: Response, next: NextFunction): void {
        try {
            const serviceName = req.params.name as string;
            const action = req.params.action as ServiceAction;

            const config = ConfigService.getConfig();
            const service = config.services.find(s => s.name === serviceName);

            if (!service) {
                res.status(400).json({ error: 'Invalid or missing service name' });
                return;
            }
            if (!SERVICE_ACTIONS.includes(action)) {
                res.status(400).json({ error: `Invalid service action (must be one of ${SERVICE_ACTIONS.join(', ')})` });
                return;
            }

            const sudo = service?.actions.find(a => a.action === action)?.sudo || false;
            let job: ChildProcessByStdio<Stream.Writable | null, Stream.Readable | null, Stream.Readable | null>;

            const cmdArray = ServicesService.resolveActionCommand(service, action);
            job = sudo ?
                ShellService.executeCommandWithSudo(cmdArray, SystemService.getSudoPassword()) :
                ShellService.executeCommand(cmdArray);
            res.sse?.streamChildProcess(job, `${action} ${serviceName}`);
        } catch (err) {
            next(err);
        }
    }
}
