import type { NextFunction, Request, Response } from "express";
import { UsersService } from "../services/users.service.ts";

export class UsersController {
    static async register(req: Request, res: Response, next: NextFunction) {
        console.log('ROUTE - POST /api/user/register: user creation');
        try {
            const { username, password, email, display_name, isAdmin } = req.body;
            console.log(`  --> creating ${username}, admin: ${isAdmin}`);
            if (!username || !password || !email) {
                res.status(400).json({ error: 'Missing username, email or password' });
                return;
            }
            const user = await UsersService.register({ username, password, email, display_name }, isAdmin);
            console.log(`  --> user created successfully`);
            console.log('WARN - Remember to restart Authelia container or reload its configuration');
            res.json({ user });
        } catch (error) {
            next(error);
        }
    }
}