import type { NextFunction, Request, Response } from "express";
import { UsersService } from "../services/users.service.ts";
import { getLogger } from "../logger.ts";

export class UsersController {

    private static log = getLogger('UsersController')
    static async register(req: Request, res: Response, next: NextFunction) {
        UsersController.log.info('ROUTE - POST /api/user/register: user creation');
        try {
            const { username, password, email, display_name, isAdmin } = req.body;
            UsersController.log.info(`  --> creating ${username}, admin: ${isAdmin}`);
            if (!username || !password || !email) {
                res.status(400).json({ error: 'Missing username, email or password' });
                return;
            }
            const user = await UsersService.register({ username, password, email, display_name }, isAdmin);
            UsersController.log.info(`  --> user created successfully`);
            UsersController.log.warn('Remember to restart Authelia container or reload its configuration');
            res.json({ user });
        } catch (error) {
            next(error);
        }
    }
}