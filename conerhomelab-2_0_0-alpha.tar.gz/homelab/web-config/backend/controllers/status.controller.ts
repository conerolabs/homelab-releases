import type { Request, Response, NextFunction } from "express";
import { StatusService } from "../services/status/status.service.ts";
import { createSSEResponse } from "../middleware/sse.middleware.ts";
import type { AdminCheckResult, DepsCheckResult, ServicesCheckResult } from "../../commons/dto.ts";

export class StatusController {

    private static async checkAdmin(res: Response, sse: boolean = false): Promise<AdminCheckResult> {
        try {
            const result = await StatusService.checkAdmin();
            sse && res.sse?.send('status', { admin: result });
            return result;
        } catch (error) {
            console.error('ERROR - Checking admin:', error);
            return { success: false, message: String(error) };
        }
    }

    private static async checkDeps(res: Response, sse: boolean = false): Promise<DepsCheckResult> {
        try {
            const result = await StatusService.checkDeps();
            sse && res.sse?.send('status', { deps: result });
            return result;
        } catch (error) {
            console.error('ERROR - Checking dependencies:', error);
            return { success: false, missing: ["Error checking dependencies"] };
        }
    }

    private static async checkServicesSetup(res: Response, sse: boolean = false): Promise<ServicesCheckResult> {
        try {
            const configured = await StatusService.checkServicesSetup();
            sse && res.sse?.send('status', { services: configured });
            return configured;
        } catch (error) {
            console.error('ERROR - Checking services:', error);
            return { success: false, notConfigured: [{ name: 'Error', success: false, message: "Error checking services" + String(error) }] };
        }
    }

    public static async getStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        console.log('ROUTE - GET /api/status: getting homelab status...');
        const sse = req.query?.sse === 'true';
        let sseClient = sse ? res.sse || createSSEResponse(res.req as any, res) : null;
        try {
            const [deps, admin, services] = await Promise.all([
                StatusController.checkDeps(res, sse),
                StatusController.checkAdmin(res, sse),
                StatusController.checkServicesSetup(res, sse)
            ]);
            sse && sseClient!.send('done', { code: 0 });
            sse ? res.end() : res.json({ deps, admin, services });
        } catch (err) {
            sse && sseClient!.send('error', { code: 1, text: String(err) });
            next(err);
        }
    }

    public static async getAdminStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        console.log('ROUTE - GET /api/status/admin: getting homelab admin status...');
        try {
            const admin = await StatusController.checkAdmin(res);
            res.json({ admin });
        } catch (err) {
            next(err);
        }
    }

    public static async getDepsStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        console.log('ROUTE - GET /api/status/deps: getting homelab dependencies status...');
        try {
            const deps = await StatusController.checkDeps(res);
            res.json({ deps });
        } catch (err) {
            next(err);
        }
    }

    public static async getServicesStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        console.log('ROUTE - GET /api/status/services: getting homelab services status...');
        try {
            const services = await StatusController.checkServicesSetup(res);
            res.json({ services });
        } catch (err) {
            next(err);
        }
    }

    public static async getServiceStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        const serviceName = req.params.name as string;
        console.log(`ROUTE - GET /api/status/service/${serviceName}: getting ${serviceName} status...`);
        try {
            const service = await StatusService.checkServiceSetup(serviceName);
            res.json({ service });
        } catch (err) {
            next(err);
        }
    }
}