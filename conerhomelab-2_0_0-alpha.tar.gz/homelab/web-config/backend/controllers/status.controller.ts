import type { Request, Response, NextFunction } from "express";
import { StatusService } from "../services/status/status.service.ts";
import { createSSEResponse } from "../middleware/sse.middleware.ts";
import type { AdminCheckResult, DepsCheckResult, ServicesCheckResult } from "../../commons/dto.ts";
import { ConfigService } from "../services/config.service.ts";
import { getLogger } from "../logger.ts";

export class StatusController {

    public static readonly log = getLogger('StatusController');

    private static async checkAdmin(res: Response, sse: boolean = false): Promise<AdminCheckResult> {
        try {
            const result = await StatusService.checkAdmin();
            sse && res.sse?.send('status', { admin: result });
            return result;
        } catch (error) {
            console.error('ERROR - Checking admin:', error);
            return { success: false, message: String(error) };
        }
    }

    private static async checkDeps(res: Response, noCache: boolean = false, sse: boolean = false): Promise<DepsCheckResult> {
        try {
            const result = await StatusService.checkDeps(noCache);
            sse && res.sse?.send('status', { deps: result });
            return result;
        } catch (error) {
            console.error('ERROR - Checking dependencies:', error);
            return { success: false, missing: ["Error checking dependencies"] };
        }
    }

    private static async checkServicesSetup(req: Request, res: Response, sse: boolean = false): Promise<ServicesCheckResult> {
        try {
            const services = req.query.services ? (req.query.services as string[]).map(decodeURIComponent) : undefined;
            const configured = await StatusService.checkServicesSetup(services);
            sse && res.sse?.send('status', { services: configured });
            return configured;
        } catch (error) {
            console.error('ERROR - Checking services:', error);
            return { success: false, config: [{ name: 'Error', success: false, message: "Error checking services" + String(error) }] };
        }
    }

    // SSE mode to be tested....
    public static async getStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        StatusController.log.info('ROUTE - GET /api/status: getting homelab status...');
        const sse = req.query?.sse === 'true';
        let sseClient = sse ? res.sse || createSSEResponse(res.req as any, res) : null;
        try {
            const [deps, admin, services] = await Promise.allSettled([
                StatusController.checkDeps(res, false, sse),
                StatusController.checkAdmin(res, sse),
                StatusController.checkServicesSetup(req, res, sse)
            ]);
            const serverName = ConfigService.getEnv('SERVER_NAME');
            sse && sseClient.send('status', { name: serverName })
            const domain = ConfigService.getEnv('DOMAIN');
            sse && sseClient.send('status', { domain });
            const vpn = ConfigService.getEnv('VPN_MODE');
            sse && sseClient.send('status', { vpn });
            sse && sseClient!.send('done', { code: 0 });
            const response = {
                serverName,
                domain,
                vpn,
                deps: deps.status == 'fulfilled' ? deps.value : { success: false, missing: [String(deps.reason)] },
                admin: admin.status == 'fulfilled' ? admin.value : { success: false, message: String(admin.reason) },
                services: services.status == 'fulfilled' ? services.value : { success: false, config: [{ name: 'Error', success: false, message: String(services.reason) }] }
            }
            sse ? res.end() : res.json(response);
            StatusController.log.debug({ status: response }, 'STATUS - Homelab status retrieved');
        } catch (err) {
            sse && sseClient!.send('error', { code: 1, text: String(err) });
            next(err);
        }
    }

    public static async getAdminStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        StatusController.log.info('ROUTE - GET /api/status/admin: getting homelab admin status...');
        try {
            const admin = await StatusController.checkAdmin(res);
            res.json({ admin });
        } catch (err) {
            next(err);
        }
    }

    public static async getDepsStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        console.log('ROUTE - GET /api/status/deps: getting homelab dependencies status...');
        const noCache = req.query?.noCache === 'true';
        const sse = req.query?.sse === 'true';
        try {
            const deps = await StatusController.checkDeps(res, noCache, sse);
            res.json({ deps });
        } catch (err) {
            next(err);
        }
    }

    public static async getServicesStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        console.log('ROUTE - GET /api/status/services: getting homelab services status...');
        try {
            const services = await StatusController.checkServicesSetup(req, res);
            res.json({ services });
        } catch (err) {
            next(err);
        }
    }

    public static async getServiceStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        const serviceName = req.params.name as string;
        console.log(`ROUTE - GET /api/status/service/${serviceName}: getting ${serviceName} status...`);
        try {
            const service = await StatusService.checkServiceSetup(serviceName);
            res.json({ service });
        } catch (err) {
            next(err);
        }
    }
}