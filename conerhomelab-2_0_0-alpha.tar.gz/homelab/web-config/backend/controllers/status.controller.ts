import type { Request, Response, NextFunction } from "express";
import { StatusService } from "../services/status/status.service.ts";
import { createSSEResponse } from "../middleware/sse.middleware.ts";
import type { AdminCheckResult, DependencyStatus, DepsCheckResult, JobResult, ServicesCheckResult, StatusResponse, VpnMode } from "../../commons/dto.ts";
import { ConfigService } from "../services/config.service.ts";
import { getLogger } from "../logger.ts";
import { DepsService } from "../services/deps.service.ts";
import { NetworkService } from "../services/network.service.ts";

export class StatusController {

    public static readonly log = getLogger('StatusController');

    private static async checkAdmin(res: Response, sse: boolean = false): Promise<AdminCheckResult> {
        try {
            const result = await StatusService.checkAdmin();
            sse && res.sse?.send('status', { admin: result });
            return result;
        } catch (error) {
            StatusController.log.error({ task: 'checkAdmin' }, '[ERROR] - Checking admin: ' + error);
            return { success: false, message: String(error) };
        }
    }

    private static async checkDeps(res: Response, sse: boolean = false): Promise<DepsCheckResult> {
        try {
            const result = await StatusService.checkDeps();
            sse && res.sse?.send('status', { deps: result });
            return result;
        } catch (error) {
            StatusController.log.error({ task: 'checkDeps' }, '[ERROR] - Checking dependencies: ' + error);
            return { success: false, missing: ["Error checking dependencies"] };
        }
    }

    private static async checkDep(name: string, res: Response, sse: boolean = false): Promise<DependencyStatus> {
        try {
            const result = await DepsService.checkDependency(name);
            sse && res.sse?.send('status', { dep: result });
            return result;
        } catch (error) {
            StatusController.log.error({ task: 'checkDep', name }, '[ERROR] - Checking dependency: ' + error);
            return { name: name, installed: false, error: String(error) };
        }
    }

    private static async checkServicesSetup(req: Request, res: Response, sse: boolean = false): Promise<ServicesCheckResult> {
        try {
            const services = req.query.services ? (req.query.services as string[]).map(decodeURIComponent) : undefined;
            const result = await StatusService.checkServicesSetup(services);
            sse && res.sse?.send('status', { services: result });
            return result;
        } catch (error) {
            StatusController.log.error({ task: 'checkServicesSetup' }, '[ERROR] - Checking services: ' + error);
            return { success: false, results: [{ name: 'Error', service: '', success: false, message: "Error checking services" + String(error) }] };
        }
    }

    // SSE mode to be tested....
    public static async getStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        StatusController.log.info('ROUTE - GET /api/status: getting homelab status...');
        const sse = req.query?.sse === 'true';
        let sseClient = sse ? res.sse || createSSEResponse(res.req as any, res) : null;
        try {
            const [deps, admin, services] = await Promise.allSettled([
                StatusController.checkDeps(res, sse),
                StatusController.checkAdmin(res, sse),
                StatusController.checkServicesSetup(req, res, sse)
            ]);
            const serverName = ConfigService.getEnv('SERVER_NAME');
            const domain = ConfigService.getEnv('DOMAIN');
            const vpn = await NetworkService.getVpnInfo();
            const dns = ConfigService.getEnv('UPSTREAM_DNS_SERVERS');
            sse && sseClient!.send('status', { serverName, domain, vpn, dns });
            sse && sseClient!.send('done', { code: 0 });
            const response: StatusResponse = {
                serverName,
                domain,
                dns,
                vpn,
                deps: deps.status == 'fulfilled' ? deps.value : { success: false, missing: [String(deps.reason)] },
                admin: admin.status == 'fulfilled' ? admin.value : { success: false, message: String(admin.reason) },
                services: services.status == 'fulfilled' ? services.value : {
                    success: false,
                    results: [{
                        name: 'Error', service: 'Error', success: false, message: String(services.reason)
                    }]
                }
            }
            sse ? res.end() : res.json(response);
            StatusController.log.debug({ status: response }, 'STATUS - Homelab status retrieved');
        } catch (err) {
            sse && sseClient!.send('error', { code: 1, text: String(err) });
            next(err);
        }
    }

    public static async getAdminStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        StatusController.log.info('ROUTE - GET /api/status/admin: getting homelab admin status...');
        try {
            const admin = await StatusController.checkAdmin(res);
            res.json({ admin });
        } catch (err) {
            next(err);
        }
    }

    /**
     * Check homelab dependencies status. SSE mode is work in progress...
     * @param req 
     * @param res 
     * @param next 
     */
    public static async getDepsStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        StatusController.log.info('ROUTE - GET /api/status/deps: getting homelab dependencies status...');
        const sse = req.query?.sse === 'true';
        try {
            const deps = await StatusController.checkDeps(res, sse);
            sse && res.sse?.send('done', { code: 0 });
            sse ? res.end() : res.json({ deps });
        } catch (err) {
            next(err);
        }
    }

    /**
     * Get a specific dependency status, always executes the check, no cache is used
     * @param req 
     * @param res 
     * @param next 
     */
    public static async getDepStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        const depName = req.params.name as string;
        StatusController.log.info(`ROUTE - GET /api/status/dep/${depName}: getting ${depName} status...`);
        const sse = req.query?.sse === 'true';
        try {
            const dep = await StatusController.checkDep(depName, res, sse);
            sse && res.sse?.send('done', { code: 0 });
            sse ? res.end() : res.json(dep);
        } catch (err) {
            next(err);
        }
    }

    public static async getServicesStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        StatusController.log.info('ROUTE - GET /api/status/services: getting homelab services status...');
        try {
            const services = await StatusController.checkServicesSetup(req, res);
            res.json({ services });
        } catch (err) {
            next(err);
        }
    }

    // SSE mode to be tested....
    public static async getServiceStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        const serviceName = req.params.name as string;
        StatusController.log.info(`ROUTE - GET /api/status/service/${serviceName}: getting ${serviceName} status...`);
        const sse = req.query?.sse === 'true';
        let sseClient = sse ? res.sse || createSSEResponse(res.req as any, res) : null;
        let progress = 0;
        const onTaskCompleted = (result: JobResult, percentage: number) => {
            progress += percentage;
            StatusController.log.info(`  --> ${result.name}: ${result.success ? 'OK' : 'ERROR'} (${percentage}%)`);
            sse && sseClient!.send('status', { service: result });
        }
        try {
            const service = await StatusService.checkServiceSetup(serviceName, onTaskCompleted);
            sse && sseClient!.send('done', { code: 0 });
            sse ? res.end() : res.json({ service });
        } catch (err) {
            sse && sseClient!.send('error', { code: 1, text: String(err) });
            next(err);
        }
    }
}