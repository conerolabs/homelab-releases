import type { Request, Response, NextFunction } from "express";
import { StatusService } from "../services/status/status.service.ts";
import { createSSEResponse } from "../middleware/sse.middleware.ts";
import type { AdminCheckResult, DepsCheckResult, JobResult, ServicesCheckResult } from "../../commons/dto.ts";
import { ConfigService } from "../services/config.service.ts";
import { getLogger } from "../logger.ts";

export class StatusController {

    public static readonly log = getLogger('StatusController');

    private static async checkAdmin(res: Response, sse: boolean = false): Promise<AdminCheckResult> {
        try {
            const result = await StatusService.checkAdmin();
            sse && res.sse?.send('status', { admin: result });
            return result;
        } catch (error) {
            StatusController.log.error({ task: 'checkAdmin' }, '[ERROR] - Checking admin: ' + error);
            return { success: false, message: String(error) };
        }
    }

    private static async checkDeps(res: Response, noCache: boolean = false, sse: boolean = false): Promise<DepsCheckResult> {
        try {
            const result = await StatusService.checkDeps(noCache);
            sse && res.sse?.send('status', { deps: result });
            return result;
        } catch (error) {
            StatusController.log.error({ task: 'checkDeps' }, '[ERROR] - Checking dependencies: ' + error);
            return { success: false, missing: ["Error checking dependencies"] };
        }
    }

    private static async checkServicesSetup(req: Request, res: Response, sse: boolean = false): Promise<ServicesCheckResult> {
        try {
            const services = req.query.services ? (req.query.services as string[]).map(decodeURIComponent) : undefined;
            const result = await StatusService.checkServicesSetup(services);
            sse && res.sse?.send('status', { services: result });
            return result;
        } catch (error) {
            StatusController.log.error({ task: 'checkServicesSetup' }, '[ERROR] - Checking services: ' + error);
            return { success: false, results: [{ name: 'Error', success: false, message: "Error checking services" + String(error) }] };
        }
    }

    // SSE mode to be tested....
    public static async getStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        StatusController.log.info('ROUTE - GET /api/status: getting homelab status...');
        const sse = req.query?.sse === 'true';
        let sseClient = sse ? res.sse || createSSEResponse(res.req as any, res) : null;
        try {
            const [deps, admin, services] = await Promise.allSettled([
                StatusController.checkDeps(res, false, sse),
                StatusController.checkAdmin(res, sse),
                StatusController.checkServicesSetup(req, res, sse)
            ]);
            const serverName = ConfigService.getEnv('SERVER_NAME');
            const domain = ConfigService.getEnv('DOMAIN');
            const vpn = ConfigService.getEnv('VPN_MODE');
            const dns = ConfigService.getEnv('UPSTREAM_DNS_SERVERS');
            sse && sseClient!.send('status', { serverName, domain, vpn, dns });
            sse && sseClient!.send('done', { code: 0 });
            const response = {
                serverName,
                domain,
                dns,
                vpn,
                deps: deps.status == 'fulfilled' ? deps.value : { success: false, missing: [String(deps.reason)] },
                admin: admin.status == 'fulfilled' ? admin.value : { success: false, message: String(admin.reason) },
                services: services.status == 'fulfilled' ? services.value : { success: false, config: [{ name: 'Error', success: false, message: String(services.reason) }] }
            }
            sse ? res.end() : res.json(response);
            StatusController.log.debug({ status: response }, 'STATUS - Homelab status retrieved');
        } catch (err) {
            sse && sseClient!.send('error', { code: 1, text: String(err) });
            next(err);
        }
    }

    public static async getAdminStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        StatusController.log.info('ROUTE - GET /api/status/admin: getting homelab admin status...');
        try {
            const admin = await StatusController.checkAdmin(res);
            res.json({ admin });
        } catch (err) {
            next(err);
        }
    }

    public static async getDepsStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        StatusController.log.info('ROUTE - GET /api/status/deps: getting homelab dependencies status...');
        const noCache = req.query?.noCache === 'true';
        const sse = req.query?.sse === 'true';
        try {
            const deps = await StatusController.checkDeps(res, noCache, sse);
            res.json({ deps });
        } catch (err) {
            next(err);
        }
    }

    public static async getServicesStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        StatusController.log.info('ROUTE - GET /api/status/services: getting homelab services status...');
        try {
            const services = await StatusController.checkServicesSetup(req, res);
            res.json({ services });
        } catch (err) {
            next(err);
        }
    }

    // SSE mode to be tested....
    public static async getServiceStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
        const serviceName = req.params.name as string;
        StatusController.log.info(`ROUTE - GET /api/status/service/${serviceName}: getting ${serviceName} status...`);
        const sse = req.query?.sse === 'true';
        let sseClient = sse ? res.sse || createSSEResponse(res.req as any, res) : null;
        let progress = 0;
        const onTaskCompleted = (result: JobResult, percentage: number) => {
            progress += percentage;
            StatusController.log.info(`  --> ${result.name}: ${result.success ? 'OK' : 'ERROR'} (${percentage}%)`);
            sse && sseClient!.send('status', { service: result });
        }
        try {
            const service = await StatusService.checkServiceSetup(serviceName, onTaskCompleted);
            sse && sseClient!.send('done', { code: 0 });
            sse ? res.end() : res.json({ service });
        } catch (err) {
            sse && sseClient!.send('error', { code: 1, text: String(err) });
            next(err);
        }
    }
}