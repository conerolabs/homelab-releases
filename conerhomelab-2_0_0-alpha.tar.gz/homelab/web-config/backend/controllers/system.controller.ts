import type { Request, Response, NextFunction } from "express";
import { getIp } from "../services/ip.service.ts";
import type { NetworkInfo } from "../../commons/dto.ts";
import { ConfigService } from "../services/config.service.ts";
import { SystemService } from "../services/system.service.ts";

export class SystemController {

    public static handleSudoPost(req: Request, res: Response, next: NextFunction): void {
        console.log('ROUTE - POST /api/system/sudo: caching sudo password...');
        try {
            const { password } = req.body;
            if (!password) {
                res.status(400).json({ error: 'Missing password' });
                return;
            }
            SystemService.setSudoPassword(password);
            console.log('  --> password cached: true');
            res.json({ success: true });
        } catch (err) {
            next(err);
        }
    }

    public static handleSudoGet(req: Request, res: Response, next: NextFunction): void {
        try {
            const action = req.query.action as string;
            const service = req.query.service as string;
            console.log(`ROUTE - GET /api/system/sudo: checking if sudo password is needed for ${action} on ${service}...`);
            const needPassword = SystemService.isPasswordNeeded(action, service);
            console.log(`  --> need to prompt for password: ${needPassword}`);
            res.json({ needPassword });
        } catch (err) {
            next(err);
        }
    }

    public static async getNetworkInfo(req: Request, res: Response, next: NextFunction): Promise<void> {
        console.log('ROUTE - GET /api/system/network: getting network information...');

        try {
            const lanIp = await getIp('lan');
            const tailscaleIp = await getIp('tailscale');
            const publicIp = await getIp('public');
            const domain = ConfigService.getEnv('DOMAIN') || 'localhost';
            const networkInfo: NetworkInfo = {
                lanIp,
                tailscaleIp,
                publicIp,
                domain
            };
            res.json(networkInfo);
        } catch (err) {
            next(err);
        }
    }
}