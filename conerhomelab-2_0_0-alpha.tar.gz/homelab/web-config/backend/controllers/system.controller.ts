import type { Request, Response, NextFunction } from "express";
import type { NetworkInfo } from "../../commons/dto.ts";
import { ConfigService } from "../services/config.service.ts";
import { SystemService } from "../services/system.service.ts";
import { NetworkService } from "../services/ip.service.ts";
import { getLogger } from "../logger.ts";

export class SystemController {

    private static log = getLogger('SystemController')

    public static handleSudoPost(req: Request, res: Response, next: NextFunction): void {
        SystemController.log.info('ROUTE - POST /api/system/sudo: caching sudo password...');
        try {
            const { password } = req.body;
            if (!password) {
                res.status(400).json({ error: 'Missing password' });
                return;
            }
            SystemService.setSudoPassword(password);
            SystemController.log.info('  --> password cached: true');
            res.json({ success: true });
        } catch (err) {
            next(err);
        }
    }

    public static handleSudoGet(req: Request, res: Response, next: NextFunction): void {
        SystemController.log.info('ROUTE - GET /api/system/sudo: checking if sudo password is needed...');
        try {
            const action = req.query.action as string;
            const service = req.query.service as string;
            const needPassword = SystemService.isPasswordNeeded(action, service);
            SystemController.log.info(`  --> need to prompt for password: ${needPassword}`);
            res.json({ needPassword });
        } catch (err) {
            next(err);
        }
    }

    public static async getNetworkInfo(req: Request, res: Response, next: NextFunction): Promise<void> {
        SystemController.log.info('ROUTE - GET /api/system/network: getting network information...');

        try {
            const lanIp = await NetworkService.getIp('lan');
            const tailscaleIp = await NetworkService.getIp('tailscale');
            const publicIp = await NetworkService.getIp('public');
            const domain = ConfigService.getEnv('DOMAIN') || 'localhost';
            const dns = ConfigService.getEnv('DNS_PROVIDER');
            const ddns = ConfigService.getEnv('DDNS_ENABLED') === 'true';
            const networkInfo: NetworkInfo = {
                lanIp,
                tailscaleIp,
                publicIp,
                domain,
                dns,
                ddns
            };
            res.json(networkInfo);
        } catch (err) {
            next(err);
        }
    }
}