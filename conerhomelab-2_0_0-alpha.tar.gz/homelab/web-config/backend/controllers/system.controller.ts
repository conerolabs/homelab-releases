import type { Request, Response, NextFunction } from "express";
import { getIp } from "../services/ip.service.ts";
import type { NetworkInfo } from "../../commons/dto.ts";
import { ConfigService } from "../services/config.service.ts";

const SUDO_ACTIONS = ['install', 'remove', 'service_setup'];

export class SystemController {
    private static sudoPassword = process.env.SUDO_PASSWORD || '';
    private static sudoCounter = 0;
    private static maxSudoRequests = 10;

    public static incrementSudoCounter() {
        SystemController.sudoCounter++;
        if (SystemController.sudoCounter >= SystemController.maxSudoRequests) {
            SystemController.setSudoPassword('');
            SystemController.sudoCounter = 0;
        }
    }
    public static setSudoPassword(password: string) {
        SystemController.sudoPassword = password;
    }
    public static getSudoPassword(): string {
        SystemController.incrementSudoCounter();
        return SystemController.sudoPassword;
    }
    public static getSudoCounter(): number {
        return SystemController.sudoCounter;
    }

    public static handleSudoPost(req: Request, res: Response, next: NextFunction): void {
        console.log('ROUTE - POST /api/system/sudo: caching sudo password...');
        try {
            const { password } = req.body;
            if (!password) {
                res.status(400).json({ error: 'Missing password' });
                return;
            }
            SystemController.setSudoPassword(password);
            console.log('  --> password cached: true');
            res.json({ success: true });
        } catch (err) {
            next(err);
        }
    }

    public static handleSudoGet(req: Request, res: Response, next: NextFunction): void {
        console.log('ROUTE - GET /api/system/sudo: checking if sudo password is needed...');
        try {
            const action = req.query.action as string;
            const isSudoAction = SUDO_ACTIONS.includes(action);
            const needPassword = isSudoAction && !SystemController.sudoPassword;
            console.log(`  --> [${action}] needs sudo: ${isSudoAction}`);
            console.log(`  --> password cached: ${!!SystemController.sudoPassword}`);
            console.log(`  --> need to prompt for password: ${needPassword}`);
            res.json({ needPassword });
        } catch (err) {
            next(err);
        }
    }

    public static async getNetworkInfo(req: Request, res: Response, next: NextFunction): void {
        console.log('ROUTE - GET /api/system/network: getting network information...');

        try {
            const lanIp = await getIp('lan');
            const tailscaleIp = await getIp('tailscale');
            const publicIp = await getIp('public');
            const domain = ConfigService.getInstance().getEnv('DOMAIN') || 'localhost';
            const networkInfo: NetworkInfo = {
                lanIp,
                tailscaleIp,
                publicIp,
                domain
            };
            res.json(networkInfo);
        } catch (err) {
            next(err);
        }
    }
}