import type { Request, Response, NextFunction } from 'express';
import { ConfigService } from '../services/config.service.ts';
import { getLogger } from '../logger.ts';

export class ConfigController {
    private static log = getLogger('ConfigController');
    public static getConfig(req: Request, res: Response, next: NextFunction): void {
        try {
            ConfigController.log.info('ROUTE - GET /api/config: getting homelab environment configuration...');
            const config = ConfigService.getConfig();
            res.json(config);
        } catch (err) {
            next(err);
        }
    }

    public static saveConfig(req: Request, res: Response, next: NextFunction): void {
        try {
            ConfigController.log.info('ROUTE - POST /api/config: saving homelab environment configuration...');
            const payload = req.body;
            if (!payload || !payload.envs || !Array.isArray(payload.services)) {
                res.status(400).json({ error: 'Invalid payload format' });
                return;
            }

            ConfigService.saveConfig(payload);
            ConfigController.log.info('ROUTE - POST /api/config: configuration saved successfully.');
            res.json({ success: true });
        } catch (err) {
            next(err);
        }
    }

    public static reloadConfig(req: Request, res: Response, next: NextFunction): void {
        try {
            ConfigController.log.info('ROUTE - GET /api/config/reload: reloading homelab environment configuration from database...');
            const config = ConfigService.reloadConfig();
            res.json({ success: true, config });
        } catch (err) {
            next(err);
        }
    }
}
