import type { Request, Response, NextFunction } from 'express';
import { ConfigService } from '../services/config.service.ts';

export class ConfigController {
    public static getConfig(req: Request, res: Response, next: NextFunction): void {
        try {
            console.log('ROUTE - GET /api/config: getting homelab environment configuration...');
            const config = ConfigService.getInstance().getConfig();
            res.json(config);
        } catch (err) {
            next(err);
        }
    }

    public static saveConfig(req: Request, res: Response, next: NextFunction): void {
        try {
            console.log('ROUTE - POST /api/config: saving homelab environment configuration...');
            const payload = req.body;
            if (!payload || !payload.envs || !Array.isArray(payload.services)) {
                res.status(400).json({ error: 'Invalid payload format' });
                return;
            }

            ConfigService.getInstance().saveConfig(payload);
            console.log('ROUTE - POST /api/config: configuration saved successfully.');
            res.json({ success: true });
        } catch (err) {
            next(err);
        }
    }

    public static reloadConfig(req: Request, res: Response, next: NextFunction): void {
        try {
            console.log('ROUTE - GET /api/config/reload: reloading homelab environment configuration from database...');
            const config = ConfigService.getInstance().reloadConfig();
            res.json({ success: true, config });
        } catch (err) {
            next(err);
        }
    }
}
