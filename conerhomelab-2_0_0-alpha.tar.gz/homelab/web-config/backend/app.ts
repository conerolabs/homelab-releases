import express from 'express';
import oidc from 'express-openid-connect';
import path from 'path';
import { fileURLToPath } from 'url';
import { loadOIDCConfig, auth, checkAccessToken } from './oidc-utils.ts';
import { ApiRouter } from './routes/index.ts';
import { errorHandler } from './middleware/error.middleware.ts';
import { sseMiddleware } from './middleware/sse.middleware.ts';

const { auth: oidcAuth } = oidc;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PUBLIC_ROOT = process.env.PUBLIC_ROOT || path.resolve(__dirname, '../frontend/dist');

const oidcconf = loadOIDCConfig();

export const app = express();

if (oidcconf.authRequired) {
    app.use(oidcAuth({
        authRequired: false,
        baseURL: oidcconf.baseURL.href,
        clientID: oidcconf.clientId,
        clientSecret: oidcconf.secret,
        issuerBaseURL: oidcconf.issuerBaseURL.href,
        secret: oidcconf.sessionSecret,
        authorizationParams: {
            response_type: 'code',
            scope: 'openid profile email groups offline_access',
        },
    }));

    app.use(checkAccessToken);
}

// CORS Headers for development flexibility
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        res.sendStatus(204);
        return;
    }
    next();
});

app.use(express.json());
app.use(sseMiddleware());

// Bind Router under /api prefix to match original endpoints
app.use('/api', ApiRouter.getInstance(oidcconf.authRequired).router);

// Serve static UI assets
if (process.env.NODE_ENV === 'production') {
    app.use(auth(oidcconf.authRequired), express.static(PUBLIC_ROOT));
    // Serve index.html for all other routes to allow client-side routing
    app.get('*', auth(oidcconf.authRequired), (req, res) => {
        res.sendFile(path.join(PUBLIC_ROOT, 'index.html'));
    });
}

// Fallback 404 handler
app.use((req, res) => {
    res.status(404).send('Not Found');
});

// Global Error Handler
app.use(errorHandler);
