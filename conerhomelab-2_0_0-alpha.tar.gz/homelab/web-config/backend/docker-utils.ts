import { exec } from "node:child_process";

interface ImageInfo {
    ID: string;
    ContainerName: string;
    Repository: string;
    Tag: string;
    Platform: string;
    Size: number;
    LastTagTime: string;
}

/**
 * Returns the image info for a given container name.
 * 
 * @param name The name of the container.
 * @returns The image info for the given container name, null if not found.
 */
export function getDockerImageInfo(name: string): Promise<ImageInfo | null> {
    return new Promise<ImageInfo | null>((resolve, reject) => {
        exec(`docker compose images --format json`, (error, stdout, stderr) => {
            if (error) {
                console.error(`Could not get image info for ${name}: ${stderr}`);
                reject(error);
            } else {
                const images: ImageInfo[] = JSON.parse(stdout);
                resolve(images.find(i => i.ContainerName === name) ?? null);
            }
        });
    });
}