import { exec } from "node:child_process";

export type DockerImageInfo = {
    Containers: string;
    CreatedAt: string;
    CreatedSince: string;
    Digest: string;
    ID: string;
    Repository: string;
    SharedSize: string;
    Size: string;
    Tag: string;
    UniqueSize: string;
    VirtualSize: string;
}

/**
 * Returns the image info for a given container name.
 * 
 * @param name The name of the container.
 * @returns The image info for the given container name, null if not found.
 */
export function getDockerImageInfo(name: string): Promise<DockerImageInfo | null> {
    return new Promise<DockerImageInfo | null>((resolve, reject) => {
        // todo: use docker images instead of docker compose images because compose shows only running containers
        exec(`docker images --filter "reference=${name}" --format json`, (error, stdout, stderr) => {
            if (error) {
                reject(new Error(`Could not get image info for ${name}: ${stderr}`, { cause: error }));
            } else {
                try {
                    const image: DockerImageInfo = JSON.parse(stdout);
                    resolve(image);
                }
                catch (e) {
                    resolve(null)
                }
            }
        });
    });
}

export function buildDockerImage(name: string): Promise<void> {
    return new Promise<void>((resolve, reject) => {
        exec(`docker compose build ${name}`, (error, stdout, stderr) => {
            if (error) {
                reject(new Error(`Could not build image for ${name}: ${stderr}`, { cause: error }));
            } else {
                resolve();
            }
        });
    });
}