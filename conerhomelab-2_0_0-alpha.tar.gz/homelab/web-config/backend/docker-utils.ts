import { exec } from "node:child_process";
import { getService } from "../database/serviceDAO.ts";
import { getLogger } from "./logger.ts";
import { ConfigService } from "./services/config.service.ts";

export type DockerImageInfo = {
    Containers: string;
    CreatedAt: string;
    CreatedSince: string;
    Digest: string;
    ID: string;
    Repository: string;
    SharedSize: string;
    Size: string;
    Tag: string;
    UniqueSize: string;
    VirtualSize: string;
}

const log = getLogger('docker-utils');

/**
 * Returns the image info for a given container name.
 * 
 * @param name The name of the container.
 * @returns The image info for the given container name, null if not found.
 */
export function getDockerImageInfo(name: string): Promise<DockerImageInfo | null> {
    const service = getService(name)
    const version = ConfigService.getEnv(service.version);
    log.info(`Getting docker image info for ${name} [${service.docker_img}:${version}]`);
    return new Promise<DockerImageInfo | null>((resolve, reject) => {
        // todo: use docker images instead of docker compose images because compose shows only running containers
        exec(`docker images --filter "reference=${service.docker_img}" --format json | jq -s .`, (error, stdout, stderr) => {
            if (error) {
                log.error(`Could not get image info for ${name}: ${stderr}`)
                reject(new Error(`Could not get image info for ${name}: ${stderr}`, { cause: error }));
            } else {
                try {
                    const images: DockerImageInfo[] = JSON.parse(stdout);
                    const image: DockerImageInfo = images.find((image) => image.Tag === version);
                    if (!image) {
                        log.warn(`Could not find image ${service.docker_img}:${version}. Available tags for ${service.docker_img}: ${images.map(img => img.Tag).join(', ') || 'none'}`)
                        resolve(null)
                    } else {
                        log.info(`Image version ${image.Tag} found for ${service.docker_img}`)
                        resolve(image);
                    }
                }
                catch (e) {
                    log.warn(`Could not find image for ${name}: ${e.message} ${stderr}`)
                    resolve(null)
                }
            }
        });
    });
}

export function buildDockerImage(name: string): Promise<void> {
    return new Promise<void>((resolve, reject) => {
        exec(`docker compose build ${name}`, (error, stdout, stderr) => {
            if (error) {
                reject(new Error(`Could not build image for ${name}: ${stderr}`, { cause: error }));
            } else {
                resolve();
            }
        });
    });
}