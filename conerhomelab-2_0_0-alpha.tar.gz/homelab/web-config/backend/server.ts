import { app } from './app.ts';
import { bootstrapDB } from '../database/db.ts';
import { ENV_PATH } from './config-utils.ts'; // load env file variables
import { DepsService } from './services/deps.service.ts';
import { UsersService } from './services/users.service.ts';
import { ConfigService } from './services/config.service.ts';
import { SystemService } from './services/system.service.ts';
import { AutheliaConfigHelper } from './services/hlservices/AutheliaConfigHelper.ts';
import { getLanIp } from '../commons/utils.ts';
import { getLogger } from './logger.ts';
import { CaddyConfigHelper } from './services/hlservices/CaddyConfigHelper.ts';

// Explicit environment loading at entry point
process.loadEnvFile(ENV_PATH);

const PORT = process.env.PORT || 8090;
const log = getLogger('server')

async function bootstrap(): Promise<void> {
  try {
    log.info('SERVER - Starting bootstrap process...');
    const serverIp = getLanIp();

    bootstrapDB(); // Sync db with .env vars and docker-compose services
    await ConfigService.init(); // Load the config from db and set host env vars
    SystemService.init(); // Set services sudo actions
    await DepsService.init(); // Load deps from db and refresh cache with actual installation status for each dependency
    await UsersService.init(); // Load users from Authelia files and update db
    // Config Helpers
    AutheliaConfigHelper.init(); // Initialize authelia config helper with current paths
    CaddyConfigHelper.init(); // Initialize caddy config helper with current paths


    app.listen(PORT, () => {
      log.info(`SERVER - Running [${process.env.NODE_ENV ?? 'development'}] at ${serverIp}:${PORT} ${process.env.DOMAIN ? `or https://config.${process.env.DOMAIN}` : ''}`);
    });
    log.info(`SERVER - Memory usage: ${process.memoryUsage().rss / 1024 / 1024} MB`);
  } catch (err) {
    log.error(`SERVER - Failed to bootstrap server: ${err}`);
    process.exit(1);
  }
}

bootstrap();
