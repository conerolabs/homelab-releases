import { app } from './app.ts';
import { bootstrapDB } from '../database/db.ts';
import { ENV_PATH } from './config-utils.ts'; // load env file variables
import { DepsService } from './services/deps.service.ts';
import { UsersService } from './services/users.service.ts';
import { ConfigService } from './services/config.service.ts';
import { SystemService } from './services/system.service.ts';

// Explicit environment loading at entry point
process.loadEnvFile(ENV_PATH);

const PORT = process.env.PORT || 8090;

async function bootstrap(): Promise<void> {
  try {
    console.log('SERVER - Starting bootstrap process...');

    bootstrapDB(); // First of all
    ConfigService.init(); // Then load the config
    SystemService.init();
    await DepsService.init();
    await UsersService.init();

    app.listen(PORT, () => {
      console.log(`SERVER - Running [${process.env.NODE_ENV ?? 'development'}] at http://localhost:${PORT} ${process.env.DOMAIN ? `or https://config.${process.env.DOMAIN}` : ''}`);
    });
  } catch (err) {
    console.error('SERVER - Failed to bootstrap server:', err);
    process.exit(1);
  }
}

bootstrap();
