import { spawn } from "child_process";
import type { Response } from "express";

export const onData = (res: Response) => (data: any) => {
    const payload = { type: 'log', text: data.toString() };
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
}
export const onClose = (res: Response) => (code: number | null) => {
    const payload = { type: 'done', code };
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
    res.end();
}
export const onError = (res: Response, msg?: string) => (error: Error) => {
    const payload = { type: 'error', text: `${msg ?? "Error"}: ${error.message}` };
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
    res.end();
}

export const run = (scriptPath: string, args: string[], callbacks: { onData: (data: any) => void, onClose: (code: number | null) => void, onError: (error: Error) => void }) => {
    const child = spawn('bash', [scriptPath, ...args]);

    child.stdout.on('data', callbacks.onData);
    child.stderr.on('data', callbacks.onData);
    child.on('close', callbacks.onClose);
    child.on('error', callbacks.onError);
}