import assert from 'node:assert';
import * as cfg from './config-utils.ts';
import { test } from 'node:test';

process.loadEnvFile(cfg.ENV_PATH);

test('parse docker-compose', () => {
    const services = cfg.parseDockerCompose(cfg.COMPOSE_PATH);
    assert.ok(services);
    assert.ok(services.caddy);
    assert.strictEqual(services.caddy.name, 'caddy');
    assert.strictEqual(services.caddy.type, 'docker');
    assert.strictEqual(services.caddy.docker_img, 'caddy');
    assert.strictEqual(services.cronicle.docker_img, 'cronicle/edge');
    // assert.deepEqual(services.caddy.envs, ['CADDYFILE_PATH']);
    // console.log(JSON.stringify(services, null, 2))
})

test('parse envs', () => {
    const envs = cfg.parseEnv(cfg.ENV_PATH)
    assert.ok(envs);
    console.log(JSON.stringify(envs, null, 2))
})