import type { NextFunction, Request, Response } from "express";
import oidc from "express-openid-connect"

const { requiresAuth } = oidc;

export type OIDCConfig = {
    authRequired: boolean;
    clientId: string;
    secret: string;
    issuerBaseURL: URL;
    baseURL: URL;
    sessionSecret: string;
}

export const loadOIDCConfig = (): OIDCConfig => {

    const clientId = process.env.WEBCONFIG_OIDC_CLIENT_ID || '';
    const secret = process.env.WEBCONFIG_OIDC_CLIENT_SECRET || '';
    const issuerBaseURL = `https://auth.${process.env.DOMAIN}`;
    const baseURL = `https://config.${process.env.DOMAIN}`;
    const sessionSecret = process.env.WEBCONFIG_SESSION_SECRET || '';
    const authRequired = process.env.NODE_ENV === 'production';
    console.log("=================================")
    console.log("OIDC - Auth required: " + (process.env.NODE_ENV === 'production'))
    console.log("OIDC - Client ID: " + clientId);
    console.log("OIDC - Client Secret: " + (secret.length > 0 ? "[ENCRYPTED]" : "MISSING"));
    console.log("OIDC - Issuer Base URL: " + issuerBaseURL);
    console.log("OIDC - Base URL: " + baseURL);
    console.log("OIDC - Session Secret: " + (sessionSecret.length > 0 ? "[ENCRYPTED]" : "MISSING"));
    console.log("=================================")

    return {
        authRequired,
        clientId,
        secret,
        issuerBaseURL: new URL(issuerBaseURL),
        baseURL: new URL(baseURL),
        sessionSecret
    }
}

export const auth = (authRequired: boolean) => {
    if (authRequired) {
        return requiresAuth();
    }
    return (req: Request, res: Response, next: NextFunction) => {
        next();
    };
}

export const checkAccessToken = async (req: Request, res: Response, next: NextFunction) => {
    if (req.oidc.isAuthenticated() && req.oidc.accessToken) {
        if (req.oidc.accessToken.isExpired()) {
            try {
                await req.oidc.accessToken.refresh();
                console.log("Access token refreshed successfully");
            } catch (err) {
                console.error("Error refreshing access token", err);
            }
        }
    }
    next();
}