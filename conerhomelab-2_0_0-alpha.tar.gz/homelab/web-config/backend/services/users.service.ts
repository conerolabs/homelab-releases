import type { UserModel } from "../../commons/models.ts";
import { insertUser } from "../../database/usersDAO.ts";
import { saveYaml } from "../../commons/yaml-utils.ts";
import { cpSync, existsSync } from "node:fs";
import { AUTHELIA_USERS_PATH, type AutheliaConfig, type AutheliaUsersDb, parseAutheliaConfig, parseAutheliaUsers } from "../config-utils.ts";
import { AutheliaConfigHelper } from "./hlservices/AutheliaConfigHelper.ts";

export class UsersService {
    private static AUTHELIA_CONFIG: AutheliaConfig | null = null;
    private static AUTHELIA_USERS: AutheliaUsersDb | null = null;

    public static async init(): Promise<void> {
        UsersService.AUTHELIA_CONFIG = parseAutheliaConfig();
        UsersService.AUTHELIA_USERS = parseAutheliaUsers();
    }

    public static async register(user: UserModel, isAdmin: boolean = false, usersPath?: string) {
        try {
            const path = usersPath ?? AUTHELIA_USERS_PATH;
            if (Object.keys(UsersService.AUTHELIA_USERS.users).includes(user.username)) {
                throw new Error('User already exists');
            }
            if (!user.password) {
                throw new Error('Missing password');
            }
            if (isAdmin) {
                user.groups = 'users,admins';
            } else {
                user.groups = 'users';
            }
            // insert on db
            insertUser(user);
            const hashedPassword = await AutheliaConfigHelper.generateAutheliaHash(user.password, UsersService.AUTHELIA_CONFIG);

            UsersService.AUTHELIA_USERS.users[user.username] = {
                password: hashedPassword,
                email: user.email,
                displayname: user.display_name,
                groups: (user.groups ?? 'users').split(',')
            }

            existsSync(path) && cpSync(path, path + '.old.' + Date.now());
            saveYaml(path, UsersService.AUTHELIA_USERS);
            return user;
        } catch (error) {
            throw error;
        }
    }
}