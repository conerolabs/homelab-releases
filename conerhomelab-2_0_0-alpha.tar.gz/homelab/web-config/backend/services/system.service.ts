import { getLogger } from "../logger.ts";
import { ConfigService } from "./config.service.ts";

export class SystemService {

    private static readonly SUDO_ACTIONS = new Map<string, string[]>([
        ['all', ['install', 'remove', 'setup']], // TODO fine grained setup with db records
    ]);

    private static log = getLogger('SystemService', { msgPrefix: 'SYSTEM - ' });

    private static sudoPassword = process.env.SUDO_PASSWORD || '';
    private static sudoCounter = 0;
    private static maxSudoRequests = 10;

    public static init() {
        const services = ConfigService.getServices();
        services.forEach(service => {
            const actions = service.actions.filter(a => a.sudo)
                .map(a => a.action);
            SystemService.SUDO_ACTIONS.set(service.name, actions);
        });
        SystemService.log.info({ task: 'init' }, `
    sudo actions:
    ${JSON.stringify(Object.fromEntries(SystemService.SUDO_ACTIONS.entries()), null, 2)}`);
    }

    private static incrementSudoCounter() {
        SystemService.sudoCounter++;
        if (SystemService.sudoCounter >= SystemService.maxSudoRequests) {
            SystemService.setSudoPassword('');
            SystemService.sudoCounter = 0;
        }
    }

    public static setSudoPassword(password: string) {
        SystemService.sudoPassword = password;
    }
    public static getSudoPassword(): string {
        SystemService.incrementSudoCounter();
        const psw = SystemService.sudoPassword;
        if (!psw) {
            SystemService.log.warn({ task: 'getSudoPassword' }, 'sudo password not set');
        }
        return psw;
    }
    public static getSudoCounter(): number {
        return SystemService.sudoCounter;
    }

    public static isPasswordNeeded(action: string, service?: string) {
        const isSudoAction = SystemService.SUDO_ACTIONS.get('all').includes(action) || SystemService.SUDO_ACTIONS.get(service)?.includes(action);
        const needPassword = isSudoAction && !SystemService.sudoPassword;
        return needPassword;
    }
}