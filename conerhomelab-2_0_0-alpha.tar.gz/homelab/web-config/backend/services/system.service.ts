import { ConfigService } from "./config.service.ts";
import { DepsService } from "./deps.service.ts";

export class SystemService {

    private static readonly SUDO_ACTIONS = new Map<string, string[]>([
        ['all', ['install', 'remove']],
    ]);

    private static sudoPassword = process.env.SUDO_PASSWORD || '';
    private static sudoCounter = 0;
    private static maxSudoRequests = 10;

    public static init() {
        const services = ConfigService.getServices();
        services.forEach(service => {
            service.actions.filter(a => a.sudo).forEach(a => {
                const actions = SystemService.SUDO_ACTIONS.get(service.name) || [];
                actions.push(a.action);
                SystemService.SUDO_ACTIONS.set(service.name, actions);
            });
        });
        console.log(`SYSTEM - init() - sudo actions: \n${JSON.stringify(Object.fromEntries(SystemService.SUDO_ACTIONS.entries()), null, 2)}`);
    }

    private static incrementSudoCounter() {
        SystemService.sudoCounter++;
        if (SystemService.sudoCounter >= SystemService.maxSudoRequests) {
            SystemService.setSudoPassword('');
            SystemService.sudoCounter = 0;
        }
    }

    public static setSudoPassword(password: string) {
        SystemService.sudoPassword = password;
    }
    public static getSudoPassword(): string {
        SystemService.incrementSudoCounter();
        return SystemService.sudoPassword;
    }
    public static getSudoCounter(): number {
        return SystemService.sudoCounter;
    }

    public static isPasswordNeeded(action: string, service?: string) {
        const isSudoAction = SystemService.SUDO_ACTIONS.get('all').includes(action) || SystemService.SUDO_ACTIONS.get(service)?.includes(action);
        const needPassword = isSudoAction && !SystemService.sudoPassword;
        return needPassword;
    }
}