import { exec } from 'child_process';

export const getIp = (network: "public" | "lan" | "tailscale"): Promise<string> => {
    return new Promise((resolve, reject) => {
        switch (network) {
            case 'public':
                fetch('https://ipinfo.io/ip')
                    .then(response => {
                        if (!response.ok) {
                            reject(new Error(`Failed to fetch public IP: HTTP ${response.status}`));
                            return;
                        }
                        return response.text();
                    })
                    .then(text => {
                        if (text) resolve(text.trim());
                    })
                    .catch(err => {
                        reject(new Error(`Failed to fetch public IP: ${err.message}`));
                    });
                break;
            case 'lan':
                const networkInterface = process.env.NETWORK_INTERFACE || 'eth0';
                // Validate network interface name to prevent shell injection
                if (!/^[a-zA-Z0-9.-]+$/.test(networkInterface)) {
                    reject(new Error(`Invalid NETWORK_INTERFACE configuration: "${networkInterface}"`));
                    return;
                }
                const lanCmd = `ip -4 -o addr show ${networkInterface} | awk '{printf $4}' | sed 's/\\/.*//'`;
                exec(lanCmd, (error, stdout, stderr) => {
                    if (error || stderr) {
                        reject(new Error(`Command failed: ${lanCmd} - ${error?.message || stderr}`));
                        return;
                    }
                    resolve(stdout.trim());
                });
                break;
            case 'tailscale':
                const tailscaleCmd = `tailscale ip -4`;
                exec(tailscaleCmd, (error, stdout, stderr) => {
                    if (error || stderr) {
                        reject(new Error(`Command failed: ${tailscaleCmd} - ${error?.message || stderr}`));
                        return;
                    }
                    resolve(stdout.trim());
                });
                break;
            default:
                reject(new Error(`Invalid network parameter: "${network}"`));
        }
    });
}