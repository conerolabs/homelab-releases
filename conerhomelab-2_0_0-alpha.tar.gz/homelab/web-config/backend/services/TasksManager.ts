import type { Logger } from "pino";
import type { JobResult } from "../../commons/dto.ts";
import { getLogger } from "../logger.ts";

export interface HLTask<C extends Record<string, any>> {
    name: string;
    description: string;
    action: (context: C) => Promise<JobResult> | JobResult; // action to be performed
    skip: (context: C) => Promise<{ skip: boolean, reason?: string, fail?: boolean }>; // return the skipping reason, if empty task will be performed
    weight: number; // weight of the task in the overall setup progress
}

/** A job is made of tasks. It can be run only once and it's identified by the job name and the service name */
export abstract class TasksManager<C extends Record<string, any>> {
    public jobName: string;
    public service: string;
    public log: Logger;

    constructor(jobName: string, service: string) {
        this.jobName = jobName;
        this.service = service;
        this.log = getLogger(jobName.replaceAll(/\s/g, '-'));
    }

    /**
     * Runs all the tasks sequentially.
     * @param onTaskCompleted callback called after each task completion: `(result: JobResult, percentage: number) => void`
     * @param onJobCompleted callback called after job completion: `(result?: JobResult) => void`
     * @returns `JobResult` with the overall result of the job
     */
    public async runTasks(
        context: C,
        onTaskCompleted?: (result: JobResult, percentage: number) => void,
        onJobCompleted?: (result?: JobResult) => void): Promise<JobResult> {
        this.log.info(`Starting ${this.jobName}...`);

        const allTasks = this.getTasks();
        const skipInfo = await Promise.all(allTasks.map(async task => task.skip(context)))
        skipInfo.forEach((sk, i) => {
            if (sk.skip) this.log.warn(sk, `Skipping task ${allTasks[i].name}: ${sk.reason}`)
        });
        const tasks = allTasks.filter((_, index) => !(skipInfo[index].skip));
        const results: JobResult[] = [];
        const totalWeight = tasks.reduce((sum, task) => sum + task.weight, 0);
        let jobProgress = 0;
        let jobResult: JobResult | null = null;

        if (tasks.length === 0) {
            this.log.info(`No tasks for ${this.jobName}`);
            jobResult = {
                name: this.jobName,
                service: this.service,
                success: true,
                message: 'Nothing to do...'
            };
            return jobResult;
        }

        try {
            for (const task of tasks) {
                const result = await task.action(context);
                jobProgress += task.weight;
                onTaskCompleted?.(result, jobProgress / totalWeight * 100);
                results.push(result);
            }
            if (results.some(r => !r.success)) {
                jobResult = {
                    name: this.jobName,
                    service: this.service,
                    success: false,
                    message: `${this.jobName} completed with errors`,
                    successfullTasks: results.filter(r => r.success),
                    failedTasks: results.filter(r => !r.success)
                };
                this.log.warn({ failedTasks: jobResult.failedTasks }, `${this.jobName} completed with errors`);
                return jobResult;
            }
            this.log.info(`${this.jobName} completed successfully`);
            jobResult = {
                name: this.jobName,
                service: this.service,
                success: true,
                message: `${this.jobName} completed successfully`,
            };
            return jobResult;
        } catch (error) {
            this.log.error({ error }, `${this.jobName} failed`);
            jobResult = {
                name: this.jobName,
                service: this.service,
                success: false,
                message: error?.message || String(error),
            };
            return jobResult;
        } finally {
            onJobCompleted?.(jobResult);
        }
    }

    public abstract getTasks(): HLTask<C>[]
}