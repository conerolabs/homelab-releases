import { spawn, type ChildProcessByStdio } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'node:url';
import type Stream from 'node:stream';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SERVICE_ROOT = path.resolve(__dirname, '../../..');

type ConsoleSSE = {
    type: 'log' | 'stdout' | 'stderr' | 'done' | 'error';
    code?: number;
    text: string;
}

export class ShellService {

    /**
     * Executes a command and streams its output via SSE to the client.
     */
    public static executeCommand(
        command: string[],
        cwd: string = SERVICE_ROOT
    ): ChildProcessByStdio<Stream.Writable | null, Stream.Readable | null, Stream.Readable | null> {
        console.log(`SHELL - Executing: ${command.join(' ')}`);

        return spawn(command[0], command.slice(1), {
            cwd,
            stdio: ['ignore', 'pipe', 'pipe'],
        });
    }

    public static executeCommandWithSudo(
        command: string[],
        password: string,
        cwd: string = SERVICE_ROOT
    ): ChildProcessByStdio<Stream.Writable | null, Stream.Readable | null, Stream.Readable | null> {
        console.log(`SHELL - Executing: sudo ${command.join(' ')}`);
        const child = spawn('sudo', ['-S', ...command], {
            cwd,
            stdio: ['pipe', 'pipe', 'pipe'],
        });
        child.stdin.write(password + '\n');
        child.stdin.end();

        return child;
    }

    /**
     * Runs a bash script.
     */
    public static runScript(
        scriptPath: string,
        args: string[],
        password?: string
    ): ChildProcessByStdio<Stream.Writable | null, Stream.Readable | null, Stream.Readable | null> {
        const command = ['bash', scriptPath, ...args];
        if (password) {
            return this.executeCommandWithSudo(command, password);
        } else {
            return this.executeCommand(command);
        }
    }
}
