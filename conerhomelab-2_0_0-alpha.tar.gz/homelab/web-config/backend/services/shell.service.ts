import { spawn, type ChildProcessByStdio } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'node:url';
import type Stream from 'node:stream';
import { getLogger } from '../logger.ts';
import { ChildProcess, exec, type ExecException, type ExecOptionsWithStringEncoding, type SpawnOptions } from 'node:child_process';
import { promisify } from 'node:util';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SERVICE_ROOT = path.resolve(__dirname, '../../..');

export class ShellService {

    private static readonly log = getLogger("ShellService", { msgPrefix: 'SHELL - ' });

    public static execCommand(cmd: string, sudoPassword?: string, ignoreErrors: boolean = false): { child: ChildProcess; result: Promise<{ stdout: string; stderr: string, exitCode: number }> } {
        const isRoot = typeof process.getuid === 'function' && process.getuid() === 0;

        const commandToExec = (!isRoot && sudoPassword)
            ? `echo "${sudoPassword}" | sudo -S ${cmd}`
            : cmd;

        const execAsync = promisify(exec);

        const execPromise = execAsync(commandToExec, { shell: '/bin/bash' })
        const child = execPromise.child;
        const result = execPromise.then(
            (result) => ({ stdout: result.stdout.trim(), stderr: result.stderr.trim(), exitCode: 0 }),
            (error: ExecException) => {
                if (!ignoreErrors) {
                    throw new Error(`Command "${cmd}" failed: ${error.message}`);
                }
                return {
                    stdout: error.stdout,
                    stderr: error.stderr,
                    exitCode: error.code ?? 1
                }
            }
        );

        // return new Promise((resolve, reject) => {
        //     exec(commandToExec, { shell: '/bin/bash' }, (error, stdout, stderr) => {
        //         const exitCode = error ? (error.code ?? 1) : 0;
        //         if (error && !ignoreErrors) {
        //             reject(new Error(`Command "${cmd}" failed: ${error.message}`));
        //         } else {
        //             resolve({ stdout: stdout.trim(), stderr: stderr.trim(), exitCode });
        //         }
        //     });
        // });

        return { result, child };
    }


    /**
     * Executes a command and streams its output via SSE to the client.
     */
    public static spawnCommand(
        command: string[],
        options: SpawnOptions = {
            cwd: SERVICE_ROOT,
            stdio: ['ignore', 'pipe', 'pipe'],
        }
    ) {

        const job = spawn(command[0], command.slice(1), options);
        const cmd = command.join(' ');
        ShellService.log.info({ pid: job.pid, cmd }, `Executing: ${cmd}`);
        ShellService.configureLogEvents(job, cmd);
        return job;
    }

    public static spawnCommandWithSudo(
        command: string[],
        password: string,
        options: SpawnOptions = {
            cwd: SERVICE_ROOT,
            stdio: ['pipe', 'pipe', 'pipe'],
        }
    ) {
        const job = spawn('sudo', ['-S', ...command], options);
        job.stdin.write(password + '\n');
        job.stdin.end();
        const cmd = command.join(' ');
        ShellService.log.info({ pid: job.pid, cmd }, `Executing: ${cmd}`);
        ShellService.configureLogEvents(job, cmd);
        return job;
    }

    /**
     * Runs a bash script.
     */
    public static runScript(
        scriptPath: string,
        args: string[],
        password?: string
    ): ChildProcessByStdio<Stream.Writable | null, Stream.Readable | null, Stream.Readable | null> {
        const command = ['bash', scriptPath, ...args];
        if (password) {
            return ShellService.spawnCommandWithSudo(command, password);
        } else {
            return ShellService.spawnCommand(command);
        }
    }

    private static configureLogEvents(job: ChildProcess, cmd: string) {
        job.on('error', (error) => {
            ShellService.log.error({ pid: job.pid, cmd }, `Command error: ${error.message}`);
        });
        job.stderr && job.stderr.on('data', (data: Buffer) => {
            ShellService.log.error({ pid: job.pid, cmd }, `${data.toString()}`);
        });
        job.stdout && job.stdout.on('data', (data: Buffer) => {
            ShellService.log.info({ pid: job.pid, cmd }, `${data.toString()}`);
        });
        job.on('close', (code, signal) => {
            if (code === 0) {
                ShellService.log.info({ pid: job.pid, cmd }, `Command executed successfully`);
            } else if (code === null) {
                ShellService.log.error({ pid: job.pid, cmd }, `Command exited with signal ${signal}`);
            } else {
                ShellService.log.error({ pid: job.pid, cmd }, `Command exited with code ${code}`);
            }
        });
    }
}
