import { spawn, type ChildProcessByStdio } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'node:url';
import type Stream from 'node:stream';
import { getLogger } from '../logger.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SERVICE_ROOT = path.resolve(__dirname, '../../..');

export class ShellService {

    private static readonly log = getLogger("ShellService");

    /**
     * Executes a command and streams its output via SSE to the client.
     */
    public static executeCommand(
        command: string[],
        cwd: string = SERVICE_ROOT
    ): ChildProcessByStdio<Stream.Writable | null, Stream.Readable | null, Stream.Readable | null> {

        const job = spawn(command[0], command.slice(1), {
            cwd,
            stdio: ['ignore', 'pipe', 'pipe'],
        });
        ShellService.log.info({ pid: job.pid }, `SHELL - Executing: ${command.join(' ')}`);
        ShellService.configureLogEvents(job);
        return job;
    }

    public static executeCommandWithSudo(
        command: string[],
        password: string,
        cwd: string = SERVICE_ROOT
    ): ChildProcessByStdio<Stream.Writable | null, Stream.Readable | null, Stream.Readable | null> {
        const job = spawn('sudo', ['-S', ...command], {
            cwd,
            stdio: ['pipe', 'pipe', 'pipe'],
        });
        job.stdin.write(password + '\n');
        job.stdin.end();
        ShellService.configureLogEvents(job);
        ShellService.log.info({ pid: job.pid }, `SHELL - Executing: sudo ${command.join(' ')}`);
        return job;
    }

    /**
     * Runs a bash script.
     */
    public static runScript(
        scriptPath: string,
        args: string[],
        password?: string
    ): ChildProcessByStdio<Stream.Writable | null, Stream.Readable | null, Stream.Readable | null> {
        const command = ['bash', scriptPath, ...args];
        if (password) {
            return ShellService.executeCommandWithSudo(command, password);
        } else {
            return ShellService.executeCommand(command);
        }
    }

    private static configureLogEvents(job: ChildProcessByStdio<Stream.Writable | null, Stream.Readable | null, Stream.Readable | null>) {
        job.on('close', (code) => {
            if (code === 0) {
                ShellService.log.info({ pid: job.pid }, `SHELL - Command executed successfully`);
            } else {
                ShellService.log.error({ pid: job.pid }, `SHELL - Command exited with code ${code}`);
            }
        });
        job.on('error', (error) => {
            ShellService.log.error({ pid: job.pid }, `SHELL - Command error: ${error.message}`);
        });
        job.stderr.on('data', (data: Buffer) => {
            ShellService.log.error({ pid: job.pid }, `SHELL - Command stderr: ${data.toString()}`);
        });
    }
}
