import test from 'node:test';
import assert from 'node:assert';
import { bootstrapDB } from '../../database/db.ts';
import { ConfigService } from './config.service.ts';

test('ConfigService - bootstrap and get configuration', () => {
    // Bootstrap database first
    bootstrapDB();

    const configService = ConfigService.getInstance();
    const config = configService.getConfig();
    assert.ok(config);
    assert.ok(config.services);
    assert.ok(config.envs);
    console.log('Successfully retrieved configurations via ConfigService');
});
