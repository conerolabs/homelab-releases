import test from "node:test";
import { UsersService } from "./users.service.ts";
import { loadYaml } from "../../commons/yaml-utils.ts";
import assert from "node:assert";
import { getUser } from "../../database/db.ts";
import { deleteUser } from "../../database/usersDAO.ts";
import type { UserModel } from "../../commons/models.ts";
import type { AutheliaUsersDb } from "../config-utils.ts";
import { rmSync } from "node:fs";

test('Register user with admin role', async () => {
    const user = {
        username: 'andrea_test',
        email: 'EMAIL_ADDRESS',
        password: 'password',
        display_name: 'Andrea',
    }

    const isAdmin = true;
    const usersPath = 'test_users.yml';

    let dbUser: UserModel | null = null;

    try {

        await UsersService.register(user, isAdmin, usersPath);
        const content = loadYaml<AutheliaUsersDb>(usersPath);
        assert.strictEqual(content.users[user.username].email, user.email);
        assert.strictEqual(content.users[user.username].displayname, user.display_name);
        assert.deepStrictEqual(content.users[user.username].groups, ['users', 'admins']);
        assert.ok(content.users[user.username].password.startsWith('$argon2id$'));

        const dbUser = getUser(user.username);
        assert.strictEqual(dbUser?.email, user.email);
        assert.strictEqual(dbUser?.display_name, user.display_name);
        assert.ok(dbUser?.groups === 'admins,users' || dbUser?.groups === 'users,admins');

    } catch (err) {
        console.error(err);
        throw err;
    } finally {
        dbUser && deleteUser(user.username);
        rmSync(usersPath);
    }
})