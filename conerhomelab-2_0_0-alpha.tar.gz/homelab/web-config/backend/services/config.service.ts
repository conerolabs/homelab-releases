import { loadConfigFromDB, saveConfigToDB } from '../../database/configDAO.ts';
import { saveEnvs, ENV_PATH } from '../config-utils.ts';
import type { Config, ServiceModel } from '../../commons/models.ts';
import { NetworkService } from './ip.service.ts';
import { getLogger } from '../logger.ts';

export class ConfigService {

    private static readonly log = getLogger(ConfigService.name);

    private static config: Config | null = null;

    private static toSave: Config = { services: [], envs: [] };

    public static async init(): Promise<void> {
        try {
            ConfigService.log.info("CONFIG - Initializing configuration...");
            ConfigService.reloadConfig(); // from db
        } catch (error) {
            ConfigService.log.error(`CONFIG - Error initializing configuration: ${error}`);
        }

        ConfigService.log.info(`  --> uid: ${process.getuid()}`);
        ConfigService.setEnv('HOST_UID', process.getuid().toString());

        ConfigService.log.info(`  --> gid: ${process.getgid()}`);
        ConfigService.setEnv('HOST_GID', process.getgid().toString());

        const nic = NetworkService.getNic();
        const lanIp = await NetworkService.getIp("lan");
        ConfigService.log.info(`  --> LAN IP address on ${nic}: ${lanIp}`);
        ConfigService.setEnv('LAN_IP', lanIp)
        const publicIp = await NetworkService.getIp("public");
        ConfigService.log.info(`  --> Public IP address: ${publicIp}`);
        ConfigService.setEnv('HOST_PUBLIC_IP', publicIp);
        const tailscaleIp = await NetworkService.getIp("tailscale");
        ConfigService.log.info(`  --> Tailscale IP address: ${tailscaleIp}`);
        ConfigService.setEnv('TAILSCALE_IP', tailscaleIp);
        ConfigService.log.info(`  --> Homelab installation directory: ${ConfigService.getEnv('INSTALL_DIR')}`);

        ConfigService.saveConfig();
    }

    public static getConfig(): Config {
        if (!ConfigService.config) {
            this.reloadConfig();
        }
        return structuredClone(this.config!);
    }

    public static getServices(): ServiceModel[] {
        return ConfigService.config?.services || [];
    }

    public static getService(name: string): ServiceModel | undefined {
        return ConfigService.getServices().find(s => s.name === name);
    }

    public static getEnv(name: string): string | null {
        return ConfigService.config?.envs.find((env) => env.name === name)?.value || null;
    }

    public static setEnv(name: string, value: string, save: boolean = false): void {
        if (!ConfigService.config) {
            ConfigService.reloadConfig();
        }
        const env = ConfigService.config!.envs.find((env) => env.name === name);
        if (env) {
            env.value = value;
        }
        else {
            ConfigService.config?.envs.push({ name, value });
            ConfigService.log.info("CONFIG --> Added new env var: " + name);
        }
        if (save) {
            ConfigService.saveConfig({ envs: [{ name, value }], services: [] });
        }
        else {
            ConfigService.toSave.envs.push({ name, value });
        }
    }

    public static getInstallDir(): string {
        return ConfigService.getEnv('INSTALL_DIR');
    }

    public static getScriptsDir(): string {
        return ConfigService.getInstallDir() + '/scripts';
    }

    public static reloadConfig(): Config {
        ConfigService.config = loadConfigFromDB();
        return structuredClone(ConfigService.config);
    }

    /**
     * Saves only the changes from payload
     * @param payload Optional payload with the configuration
     * @returns 
     */
    public static saveConfig(payload?: Config): void {
        ConfigService.log.info("CONFIG - Saving configuration changes...");
        const p = payload ?? ConfigService.config!;
        const changedPayload: Config = {
            // save services if changed or new added
            services: p.services.filter(s => (ConfigService.config?.services.find(x => x.name === s.name)?.enabled ?? !s.enabled) !== s.enabled),
            // save envs if changed or new added
            envs: p.envs.filter(e => (ConfigService.config?.envs.find(x => x.name === e.name)?.value ?? "") !== e.value),
        }
        ConfigService.toSave = {
            services: [...ConfigService.toSave.services.filter(s => !changedPayload.services.map(x => x.name).includes(s.name)), ...changedPayload.services],
            envs: [...ConfigService.toSave.envs.filter(e => !changedPayload.envs.map(x => x.name).includes(e.name)), ...changedPayload.envs]
        }
        ConfigService.log.info({ changes: ConfigService.toSave }, '  -->');
        saveConfigToDB(ConfigService.toSave);
        saveEnvs(ConfigService.toSave.envs, ENV_PATH);

        // Update in-memory configuration cache
        ConfigService.config = {
            services: [
                ...changedPayload.services,
                ...ConfigService.config.services.filter(s => !changedPayload.services.map(cps => cps.name).includes(s.name))
            ],
            envs: [
                ...changedPayload.envs,
                ...ConfigService.config.envs.filter(e => !changedPayload.envs.map(cpe => cpe.name).includes(e.name))
            ]
        }
        ConfigService.toSave = { services: [], envs: [] };
    }
}
