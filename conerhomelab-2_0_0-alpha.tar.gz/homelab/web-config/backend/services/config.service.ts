import { loadConfigFromDB, saveConfigToDB } from '../../database/configDAO.ts';
import { saveEnvs, ENV_PATH } from '../config-utils.ts';
import type { Config, ServiceModel } from '../../commons/models.ts';
import { NetworkService } from './ip.service.ts';
import { getLogger } from '../logger.ts';

export class ConfigService {

    private static readonly log = getLogger(ConfigService.name, { msgPrefix: 'CONFIG - ' });

    private static config: Config | null = null;

    private static toSave: Config = { services: [], envs: [] };

    /**
     * Initialize the configuration service by loading the configuration from the database.  
     * Env vars set up:
     *  - host uid and gid
     *  - lan, public and tailscale IP addresses
     */
    public static async init(): Promise<void> {
        try {
            ConfigService.log.info("Initializing configuration...");
            ConfigService.reloadConfig(); // from db
        } catch (error) {
            ConfigService.log.error(`Error initializing configuration: ${error}`);
        }

        ConfigService.log.info(`  --> uid: ${process.getuid()}`);
        ConfigService.setEnv('HOST_UID', process.getuid().toString());

        ConfigService.log.info(`  --> gid: ${process.getgid()}`);
        ConfigService.setEnv('HOST_GID', process.getgid().toString());

        const nic = NetworkService.getNic();
        const lanIp = await NetworkService.getIp("lan");
        ConfigService.log.info(`  --> LAN IP address on ${nic}: ${lanIp}`);
        ConfigService.setEnv('LAN_IP', lanIp)
        const publicIp = await NetworkService.getIp("public");
        ConfigService.log.info(`  --> Public IP address: ${publicIp}`);
        ConfigService.setEnv('HOST_PUBLIC_IP', publicIp);
        const tailscaleIp = await NetworkService.getIp("tailscale");
        ConfigService.log.info(`  --> Tailscale IP address: ${tailscaleIp}`);
        ConfigService.setEnv('TAILSCALE_IP', tailscaleIp);
        ConfigService.log.info(`  --> Homelab installation directory: ${ConfigService.getEnv('INSTALL_DIR')}`);

        ConfigService.saveConfig();
    }

    public static getConfig(): Config {
        if (!ConfigService.config) {
            ConfigService.reloadConfig();
        }
        return structuredClone(ConfigService.config!);
    }

    public static getServices(): ServiceModel[] {
        return ConfigService.config?.services || [];
    }

    public static getEnabledServices(): ServiceModel[] {
        return ConfigService.getServices().filter(s => s.enabled);
    }

    public static getService(name: string): ServiceModel | undefined {
        return ConfigService.getServices().find(s => s.name === name);
    }

    public static getEnv(name: string): string | null {
        const env = ConfigService.config?.envs.find((env) => env.name === name)?.value || null;
        if (!env) {
            ConfigService.log.warn(`Environment variable ${name} not found`);
        }
        return env;
    }

    /**
     * Sets an environment variable in the configuration.
     * If the variable already exists, it updates its value.
     * If the variable does not exist, it adds it to the configuration.
     * @param name The name of the environment variable.
     * @param value The value of the environment variable.
     * @param save Whether to save the configuration to the database.
     */
    public static setEnv(name: string, value: string, save: boolean = false): void {
        if (!ConfigService.config) {
            ConfigService.reloadConfig();
        }
        const env = ConfigService.config!.envs.find((env) => env.name === name);
        if (env) {
            env.value = value;
        }
        else {
            ConfigService.config?.envs.push({ name, value });
            ConfigService.log.info({ task: 'setEnv' }, `Added new env var: ${name}`);
        }
        if (save) {
            ConfigService.saveConfig({ envs: [{ name, value }], services: [] });
        }
        else {
            ConfigService.toSave.envs.push({ name, value });
        }
    }

    /**
     * Returns the installation directory of the homelab, 
     * that is the directory where the scripts and the services are located.
     */
    public static getInstallDir(): string {
        return ConfigService.getEnv('INSTALL_DIR');
    }

    public static getHomelabConfigDir(): string {
        return ConfigService.getInstallDir() + '/homelab_config';
    }

    public static getScriptsDir(): string {
        return ConfigService.getInstallDir() + '/scripts';
    }

    public static reloadConfig(): Config {
        ConfigService.config = loadConfigFromDB();
        return structuredClone(ConfigService.config);
    }

    /**
     * Saves only the changes from payload
     * @param payload Optional payload with the configuration
     * @returns 
     */
    public static saveConfig(payload?: Config): void {
        ConfigService.log.info("Saving configuration changes...");
        const p = payload ?? ConfigService.config!;
        const changedPayload: Config = {
            // save services if changed or new added
            services: p.services.filter(ps => {
                const service = ConfigService.config?.services.find(s => s.name === ps.name);
                const isNewlyAdded = !service;
                const isChanged = !isNewlyAdded && service!.enabled !== ps.enabled
                return isNewlyAdded || isChanged;
            }),
            // save envs if changed or new added
            envs: p.envs.filter(pe => {
                const env = ConfigService.config?.envs.find(e => e.name === pe.name);
                const isNewlyAdded = !env;
                const isChanged = !isNewlyAdded && env!.value !== pe.value
                return isNewlyAdded || isChanged;
            }),
        }
        ConfigService.toSave = {
            services: [...ConfigService.toSave.services.filter(s => !changedPayload.services.map(x => x.name).includes(s.name)), ...changedPayload.services],
            envs: [...ConfigService.toSave.envs.filter(e => !changedPayload.envs.map(x => x.name).includes(e.name)), ...changedPayload.envs]
        }
        ConfigService.log.info({ changes: ConfigService.toSave }, '  -->');
        saveConfigToDB(ConfigService.toSave);
        saveEnvs(ConfigService.toSave.envs, ENV_PATH);

        // Update in-memory configuration cache
        ConfigService.config = {
            services: [
                ...changedPayload.services,
                ...ConfigService.config.services.filter(s => !changedPayload.services.map(cps => cps.name).includes(s.name))
            ],
            envs: [
                ...changedPayload.envs,
                ...ConfigService.config.envs.filter(e => !changedPayload.envs.map(cpe => cpe.name).includes(e.name))
            ]
        }
        ConfigService.toSave = { services: [], envs: [] };
    }
}
