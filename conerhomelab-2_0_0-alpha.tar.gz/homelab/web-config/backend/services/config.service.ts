import { loadConfigFromDB, saveConfigToDB } from '../../database/configDAO.ts';
import { saveEnvs, ENV_PATH } from '../config-utils.ts';
import type { Config, ServiceModel } from '../../commons/models.ts';

export class ConfigService {
    private static config: Config | null = null;

    private static toSave: Config = { services: [], envs: [] };

    public static init(): void {
        ConfigService.reloadConfig();
    }

    public static getConfig(): Config {
        if (!ConfigService.config) {
            this.reloadConfig();
        }
        return structuredClone(this.config!);
    }

    public static getServices(): ServiceModel[] {
        return this.config?.services || [];
    }

    public static getEnv(name: string): string | null {
        return this.config?.envs.find((env) => env.name === name)?.value || null;
    }

    public static setEnv(name: string, value: string, save: boolean = false): void {
        if (!this.config) {
            this.reloadConfig();
        }
        const env = this.config!.envs.find((env) => env.name === name);
        if (env) {
            env.value = value;
        }
        else {
            this.config?.envs.push({ name, value });
            console.log("CONFIG --> Added new env var: ", name);
        }
        if (save) {
            ConfigService.saveConfig({ envs: [{ name, value }], services: [] });
        }
        else {
            ConfigService.toSave.envs.push({ name, value });
        }
    }

    public static reloadConfig(): Config {
        ConfigService.config = loadConfigFromDB();
        return structuredClone(ConfigService.config);
    }

    public static saveConfig(payload?: Config): void {
        console.log("CONFIG - Saving configuration changes...");
        const p = payload ?? ConfigService.config!;
        const changedPayload: Config = {
            // save services if changed or new added
            services: p.services.filter(s => (ConfigService.config?.services.find(x => x.name === s.name)?.enabled ?? !s.enabled) !== s.enabled),
            // save envs if changed or new added
            envs: p.envs.filter(e => (ConfigService.config?.envs.find(x => x.name === e.name)?.value ?? "") !== e.value),
            // save domain if changed
        }
        ConfigService.toSave = {
            services: [...ConfigService.toSave.services.filter(s => !changedPayload.services.map(x => x.name).includes(s.name)), ...changedPayload.services],
            envs: [...ConfigService.toSave.envs.filter(e => !changedPayload.envs.map(x => x.name).includes(e.name)), ...changedPayload.envs]
        }
        console.log("  --> changes: ", ConfigService.toSave);
        saveConfigToDB(ConfigService.toSave);
        saveEnvs(ConfigService.toSave.envs, ENV_PATH);

        // Update in-memory configuration cache
        ConfigService.config = p;
    }
}
