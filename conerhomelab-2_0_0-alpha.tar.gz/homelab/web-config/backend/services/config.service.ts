import { loadConfigFromDB, saveConfigToDB } from '../../database/configDAO.ts';
import { saveEnvs, ENV_PATH } from '../config-utils.ts';
import type { Config } from '../../commons/models.ts';

export class ConfigService {
    private static instance: ConfigService;
    private config: Config | null = null;

    private constructor() { }

    public static getInstance(): ConfigService {
        if (!ConfigService.instance) {
            ConfigService.instance = new ConfigService();
        }
        return ConfigService.instance;
    }

    public getConfig(): Config {
        if (!this.config) {
            this.reloadConfig();
        }
        return structuredClone(this.config!);
    }

    public getEnv(name: string): string | null {
        return this.config?.envs.find((env) => env.name === name)?.value || null;
    }

    public reloadConfig(): Config {
        this.config = loadConfigFromDB();
        return structuredClone(this.config);
    }

    public saveConfig(payload: Config): void {
        saveConfigToDB(payload);
        saveEnvs(payload.envs, ENV_PATH);

        // Update in-memory configuration cache
        this.config = payload;
    }
}
