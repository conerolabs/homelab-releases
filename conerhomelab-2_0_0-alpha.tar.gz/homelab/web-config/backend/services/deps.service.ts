import { exec } from 'child_process';
import { getAllDeps, getDep, getRequiredDeps } from '../../database/depsDAO.ts';
import type { DependencyStatus } from '../../commons/dto.ts';
import type { DependencyModel } from '../../commons/models.ts';

export class DepsService {

    private static cache = {
        data: new Map<string, { model: DependencyModel, status: DependencyStatus }>(),
        lastUpdate: 0,
        ttl: 1000 * 60 * 5, // ignored for now
    };

    private static setCacheEntry(model: DependencyModel | null, status?: DependencyStatus) {
        if (!model && !status) {
            console.warn('DEPS - neither dependency model nor status where provided for cache entry');
            return;
        } else if (!model && status) {
            const data = DepsService.cache.data.get(status.name);
            if (data?.model) {
                DepsService.cache.data.set(status.name, { model: data.model, status: status });
            } else {
                console.warn(`DEPS - dependency ${status.name} not found. Cache entry cannot be updated.`);
            }
        } else if (model) {
            DepsService.cache.data.set(
                model.name,
                {
                    model: model,
                    status: status ?? { name: model.name, installed: false, error: 'Not checked yet' }
                }
            );
        }
    }

    public static setAllInstalled() {
        DepsService.cache.data.forEach(value => {
            DepsService.setCacheEntry(value.model, { name: value.status.name, installed: true });
        });
    }

    public static setInstalled(name: string, installed: boolean = true) {
        const data = DepsService.cache.data.get(name);
        if (data?.model) {
            DepsService.setCacheEntry(data.model, { name, installed });
        } else {
            console.warn(`DEPS - dependency ${name} not found. Cache entry cannot be updated.`);
        }
    }

    public static async init(): Promise<void> {
        console.log('DEPS - loading dependencies data...');
        await DepsService.reloadCache();
    }

    public static getAllDependencies(): DependencyModel[] {
        return Array.from(DepsService.cache.data.values()).map(d => d.model);
    }

    private static async reloadCache(): Promise<void> {
        console.log('DEPS - reloading cache...');
        DepsService.cache.data.clear();
        const allDeps = getAllDeps();
        const cacheData = await Promise.all(
            allDeps.map(async d => {
                const status = await DepsService.execCheck(d.name, d.check_cmd);
                return { model: d, status };
            })
        );
        cacheData.forEach(d => DepsService.setCacheEntry(d.model, d.status));
        DepsService.cache.lastUpdate = Date.now();
    }

    public static getDependencyNames(): string[] {
        return Array.from(DepsService.cache.data.keys());
    }

    public static getRequiredDependencies(): DependencyModel[] {
        return getRequiredDeps();
    }

    public static async checkRequiredDeps(): Promise<DependencyStatus[]> {
        const requiredDeps = getRequiredDeps();
        return await DepsService.checkDependenciesStatus(requiredDeps);
    }

    public static getDepStatus(name: string): DependencyStatus {
        const status = DepsService.cache.data.get(name)?.status;
        return status ?? { name, installed: false, error: 'Not found in DB' };
    }

    private static async execCheck(name: string, cmd: string): Promise<DependencyStatus> {
        return new Promise((resolve) => {
            console.log(`DEPS - checking ${name} with command: ${cmd}`);
            exec(cmd, (error, stdout) => {
                if (error) {
                    console.log(`DEPS - ${name} is installed: `, false);
                    resolve({ name, installed: false, error: error.message || 'Unknown error' });
                } else {
                    console.log(`DEPS - ${name} is installed: `, true);
                    resolve({ name, installed: true });
                }
            });
        });
    }

    public static async checkDependency(name: string, noCache: boolean = false): Promise<DependencyStatus> {
        let data = DepsService.cache.data.get(name);
        let dep = data?.model;
        let status = data?.status;

        if (!data && !noCache) {
            console.warn(`DEPS - dependency ${name} not found`);
            return Promise.resolve({ name, installed: false, error: 'Not found in DB' });
        }
        else if (data && !noCache) {
            if (status && status.error !== 'Not checked yet') return Promise.resolve(status); // happy path
            if (status && status.error === 'Not checked yet') return DepsService.execCheck(name, dep!.check_cmd);
        }

        if (noCache) {
            dep = getDep(name);
            if (!dep) {
                console.warn(`DEPS - dependency ${name} not found`);
                return Promise.resolve({ name, installed: false, error: 'Not found in DB' });
            }
            else {
                DepsService.setCacheEntry(dep);
                const status = await DepsService.execCheck(name, dep.check_cmd);
                DepsService.setCacheEntry(dep, status);
                return status;
            }
        }
        throw new Error('Should not happen');
    }

    public static getAllDependenciesStatus(): DependencyStatus[] {
        return Array.from(DepsService.cache.data.values()).map(d => d.status);
    }

    public static getDependenciesStatus(deps?: string[]): DependencyStatus[] {
        if (!deps || deps.length === 0) return DepsService.getAllDependenciesStatus();
        return deps.map(name => DepsService.getDepStatus(name));
    }

    public static getRequiredDependenciesStatus(): DependencyStatus[] {
        const requiredDeps = getRequiredDeps();
        return requiredDeps.map(dep => DepsService.getDepStatus(dep.name));
    }

    /**
     * Retrieves status of selected dependencies concurrently.
     */
    public static async checkDependenciesStatus(deps: string[] | DependencyModel[], noCache: boolean = false): Promise<DependencyStatus[]> {
        if (deps.length === 0) return [];
        const names =
            typeof deps[0] === 'string' ?
                deps as string[] :
                (deps as DependencyModel[]).map(d => d.name);
        return Promise.all(
            names.map(name => DepsService.checkDependency(name, noCache))
        );
    }
}
