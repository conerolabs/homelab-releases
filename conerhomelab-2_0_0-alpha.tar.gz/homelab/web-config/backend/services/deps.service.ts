import { ChildProcess, exec } from 'child_process';
import { getAllDeps, getDep, getRequiredDeps } from '../../database/depsDAO.ts';
import type { DependencyStatus } from '../../commons/dto.ts';
import type { DependencyModel } from '../../commons/models.ts';
import { ShellService } from './shell.service.ts';
import { SystemService } from './system.service.ts';
import { getLogger } from '../logger.ts';
import { ConfigService } from './config.service.ts';

export class DepsService {

    private static readonly log = getLogger('DepsService', { msgPrefix: 'DEPS - ' });

    private static cache = {
        data: new Map<string, { model: DependencyModel, status: DependencyStatus }>(),
        lastUpdate: 0,
        ttl: 1000 * 60 * 5, // ignored for now
    };

    /**
     * Loads dependencies data from db and refresh cache with installation status for each dependency
     */
    public static async init(): Promise<void> {
        DepsService.log.info('loading dependencies data...');
        await DepsService.reloadCache();
    }

    private static setCacheEntry(model: DependencyModel | null, status?: DependencyStatus) {
        if (!model && !status) {
            DepsService.log.warn('neither dependency model nor status where provided for cache entry');
            return;
        } else if (!model && status) {
            const data = DepsService.cache.data.get(status.name);
            if (data?.model) {
                DepsService.cache.data.set(status.name, { model: data.model, status: status });
            } else {
                DepsService.log.warn(`dependency ${status.name} not found. Cache entry cannot be updated.`);
            }
        } else if (model) {
            DepsService.cache.data.set(
                model.name,
                {
                    model: model,
                    status: status ?? { name: model.name, installed: false, error: 'Not checked yet' }
                }
            );
        }
    }

    /**
     * Retrieves a dependency from the cache.
     * @param name dependency name.
     * @returns The dependency model and its status, or null if not found.
     */
    private static getDep(name: string) {
        const dep = DepsService.cache.data.get(name);
        if (!dep) {
            DepsService.log.warn(`dependency ${name} not found. Cannot install.`);
            return null;
        }
        return dep;
    }

    /**
     * Installs a single dependency.
     * @param name The name of the dependency to install.
     * @returns The child process of the installation command.
     * If the dependency is already installed, it returns null.
     */
    public static installSingle(name: string): ChildProcess | null {
        const dep = DepsService.getDep(name);
        if (dep?.status.installed) {
            DepsService.log.info(`${name} is already installed. Skipping.`);
            return null;
        }
        let job: ChildProcess = null;
        const isScript = dep?.model.install_cmd.endsWith('.sh');
        if (isScript) {
            const scriptDir = ConfigService.getScriptsDir();
            job = ShellService.runScript(scriptDir + '/deps/' + dep?.model.install_cmd, [], SystemService.getSudoPassword());
        } else {
            job = ShellService.spawnCommandWithSudo(dep?.model.install_cmd.split(' '), SystemService.getSudoPassword());
        }
        job.on('close', code => code === 0 && DepsService.setInstalled(name));
        return job;
    }

    public static uninstall(name: string) {
        const dep = DepsService.getDep(name);
        if (!dep?.status.installed) {
            DepsService.log.info(`dependency ${name} is not installed. Skipping.`);
            return null;
        }
        const child = ShellService.spawnCommandWithSudo(dep?.model.remove_cmd.split(' '), SystemService.getSudoPassword());
        child.on('close', code => code === 0 && DepsService.setInstalled(name, false));
        return child;
    }

    /**
     * Installs dependencies sequentially.
     * If no names are provided, installs all required dependencies.
     * @param names Names of the dependencies to install.
     * @param streamConfig Configuration for streaming the output of the installation process.
     * @returns A promise that resolves to an array of dependency installation results.
     */
    public static async installSequentially(names: string[], streamConfig?: (child: ChildProcess, taskName: string, onClose?: (exitCode: number | null) => void) => void) {
        const deps = names.length === 0 ? DepsService.getRequiredDependencies().map(d => d.name) : names;
        const results: Array<{ name: string, isSuccess: boolean, code: number | null }> = [];
        for (let i = 0; i < deps.length; i++) {
            DepsService.log.info(`Installing ${deps[i]}...`);
            const name = deps[i];
            const child = DepsService.installSingle(name);
            // Close response only at the end of the last installation (no args call)
            i === deps.length - 1 ?
                streamConfig?.(child, name) :
                streamConfig?.(child, name, () => { });
            const result = await DepsService.waitForInstallation(child);
            result.isSuccess ?
                DepsService.log.info(`  --> ${name} installed.`) :
                DepsService.log.error(`  --> ${name} installation FAILED.`);
            results.push({ ...result, name });
        }
        return results;
    }

    public static async waitForInstallation(child: ChildProcess | null) {
        if (!child) {
            return Promise.resolve({ isSuccess: true, code: 0 });
        }
        return new Promise<{ isSuccess: boolean, code: number | null }>((resolve) => {
            child.on('close', code => resolve({ isSuccess: code === 0, code: code }));
        });
    }

    public static setInstalled(name: string, installed: boolean = true) {
        const data = DepsService.cache.data.get(name);
        if (data?.model) {
            DepsService.setCacheEntry(data.model, { name, installed });
        } else {
            DepsService.log.warn(`dependency ${name} not found. Cache entry cannot be updated.`);
        }
    }

    public static setRunning(name: string, running: boolean = true) {
        const data = DepsService.cache.data.get(name);
        if (data?.model) {
            DepsService.setCacheEntry(data.model, { ...data.status, running });
        } else {
            DepsService.log.warn(`dependency ${name} not found. Cache entry cannot be updated.`);
        }
    }


    public static getAllDependencies(): DependencyModel[] {
        return Array.from(DepsService.cache.data.values()).map(d => d.model);
    }

    /**
     * Load deps list and refresh cache with actual installation status for each dependency. 
     */
    private static async reloadCache(): Promise<void> {
        DepsService.log.info('checking deps status and updating cache...');
        DepsService.cache.data.clear();
        const allDeps = getAllDeps();
        const cacheData = await Promise.all(
            allDeps.map(async d => {
                const status = await DepsService.execCheck(d);
                return { model: d, status };
            })
        );
        cacheData.forEach(d => DepsService.setCacheEntry(d.model, d.status));
        DepsService.cache.lastUpdate = Date.now();
    }

    public static getDependencyNames(): string[] {
        return Array.from(DepsService.cache.data.keys());
    }

    public static getRequiredDependencies(): DependencyModel[] {
        return getRequiredDeps();
    }

    public static async checkRequiredDeps(noCache: boolean = false): Promise<DependencyStatus[]> {
        const requiredDeps = getRequiredDeps();
        return await DepsService.checkDependenciesStatus(requiredDeps, noCache);
    }

    public static async getDepStatus(name: string): Promise<DependencyStatus> {
        const cachedDep = DepsService.cache.data.get(name);
        if (cachedDep?.status.installed && (cachedDep.status.running !== undefined)) {
            const status = await DepsService.checkRunningStatus(cachedDep.model);
            DepsService.setCacheEntry(cachedDep.model, status);
            return status;
        }
        return cachedDep?.status ?? { name, installed: false, error: 'Not found in DB' };
    }

    private static async checkRunningStatus(dep: DependencyModel) {
        const statusCheck = new Promise<DependencyStatus>((resolve) => {
            DepsService.log.info({ cmd: dep.status_cmd, task: 'checkRunningStatus' }, `checking if ${dep.name} is running`);
            exec(dep.status_cmd!, (error, stdout) => {
                if (error) {
                    resolve({ name: dep.name, installed: true, running: false, error: error.message || 'Unknown error' });
                } else {
                    resolve({ name: dep.name, installed: true, running: true });
                }
                DepsService.log.info(`${dep.name} is running: ${!error}`,);
            });
        });
        return await statusCheck
    }

    private static async execCheck(dep: DependencyModel): Promise<DependencyStatus> {
        const installCheck = new Promise<DependencyStatus>(resolve => {
            DepsService.log.info(`checking ${dep.name} installation with command: ${dep.check_cmd}`);
            exec(dep.check_cmd, (error, stdout) => {
                if (error) {
                    resolve({ name: dep.name, installed: false, error: error.message || 'Unknown error' });
                } else {
                    resolve({ name: dep.name, installed: true });
                }
                DepsService.log.info(`${dep.name} is installed: ${!error}`);
            });
        });
        const installResult = await installCheck;
        if (installResult.installed && dep.status_cmd) {
            const runResult = await DepsService.checkRunningStatus(dep);
            return runResult;
        }
        else {
            return installResult;
        }
    }

    /**
     * Checks the status of a specific dependency.
     * @param name The name of the dependency to check.
     * @param noCache If true, bypasses the cache and performs a fresh check. Default behavior is to use cache if available.
     * If installed, always check if it is running (no caching of running status).
     * @returns The status of the dependency.
     */
    public static async checkDependency(name: string, noCache: boolean = false): Promise<DependencyStatus> {
        let data = DepsService.cache.data.get(name);
        let dep = data?.model;
        let status = data?.status;

        if (!data && !noCache) {
            DepsService.log.warn(`dependency ${name} not found`);
            return Promise.resolve({ name, installed: false, error: 'Not found in DB' });
        }
        else if (data && !noCache) {
            if (status?.installed && status.running !== undefined) return DepsService.checkRunningStatus(dep!) // happy path
            else if (status?.error !== 'Not checked yet') return Promise.resolve(status) // cached and don't need to check if running
            else {
                const status = await DepsService.execCheck(dep!);
                DepsService.cache.data.set(dep.name, { model: dep, status });
                return status;
            }
        }

        if (noCache) {
            dep = getDep(name);
            if (!dep) {
                console.warn(`dependency ${name} not found`);
                return Promise.resolve({ name, installed: false, error: 'Not found in DB' });
            }
            else {
                DepsService.setCacheEntry(dep);
                const status = await DepsService.execCheck(dep);
                DepsService.setCacheEntry(dep, status);
                return status;
            }
        }
        throw new Error('Should not happen');
    }

    public static getAllDependenciesStatus(): DependencyStatus[] {
        return Array.from(DepsService.cache.data.values()).map(d => d.status);
    }

    public static async getDependenciesStatus(deps?: string[]): Promise<DependencyStatus[]> {
        if (!deps || deps.length === 0) return Promise.resolve(DepsService.getAllDependenciesStatus());
        return Promise.all(deps.map(name => DepsService.getDepStatus(name)));
    }

    public static async getRequiredDependenciesStatus(): Promise<DependencyStatus[]> {
        const requiredDeps = getRequiredDeps();
        return await DepsService.getDependenciesStatus(requiredDeps.map(dep => dep.name));
    }

    /**
     * Retrieves status of selected dependencies concurrently.
     * @param deps Array of dependency names or dependency models to check.
     * @param noCache If true, bypasses the cache and performs a fresh check. Default behavior is to use cache if available.
     * @returns An array of dependency statuses.
     */
    public static async checkDependenciesStatus(deps: string[] | DependencyModel[], noCache: boolean = false): Promise<DependencyStatus[]> {
        if (deps.length === 0) return [];
        const names =
            typeof deps[0] === 'string' ?
                deps as string[] :
                (deps as DependencyModel[]).map(d => d.name);
        return Promise.all(
            names.map(name => DepsService.checkDependency(name, noCache))
        );
    }
}
