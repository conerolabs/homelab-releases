import { ChildProcess, exec } from 'child_process';
import { getAllDeps, getDep, getRequiredDeps } from '../../database/depsDAO.ts';
import type { DependencyStatus, JobResult } from '../../commons/dto.ts';
import type { DependencyModel } from '../../commons/models.ts';
import { ShellService } from './shell.service.ts';
import { SystemService } from './system.service.ts';
import { getLogger } from '../logger.ts';
import { ConfigService } from './config.service.ts';
import type { ServiceSetupChecker } from './status/status.service.ts';
import { VpnSetupChecker } from './status/VpnSetupChecker.ts';
import { Cache } from '../cache.ts';

export interface DepInfos {
    model: DependencyModel;
    status: DependencyStatus;
}

export class DepsService {

    private static readonly log = getLogger('DepsService', { msgPrefix: 'DEPS - ' });
    private static readonly DEPS_SETUP_CHECKERS: Map<string, ServiceSetupChecker> = new Map([
        ['tailscale', new VpnSetupChecker()],
        ['headscale', new VpnSetupChecker()],
    ]);

    private static cache = new Cache<string, DepInfos>({
        ttl: 1000 * 60 * 20 // 20 minutes
    });

    /**
     * Loads dependencies data from db and refresh cache with installation status for each dependency
     */
    public static async init(): Promise<void> {
        DepsService.log.info('loading dependencies data...');
        await DepsService.reloadCache();
    }

    private static setCacheEntry(model: DependencyModel | null, status?: DependencyStatus) {
        if (!model && !status) {
            DepsService.log.warn('neither dependency model nor status where provided for cache entry');
            return;
        } else if (!model && status) {
            const data = DepsService.cache.peek(status.name);
            if (data?.model) {
                DepsService.cache.set(status.name, { model: data.model, status: status });
            } else {
                DepsService.log.warn(`dependency ${status.name} not found. Cache entry cannot be updated.`);
            }
        } else if (model) {
            const hasValidStatus = Boolean(status && status.error !== 'Not checked yet');
            DepsService.cache.set(
                model.name,
                {
                    model,
                    status: status ?? { name: model.name, installed: false, error: 'Not checked yet' }
                },
                { expired: !hasValidStatus }
            );
        }
    }

    /**
     * Retrieves a dependency from the cache. If the cache entry is expired, it will be updated.
     * @param name dependency name.
     * @returns The dependency model and its status, or null if not found.
     */
    private static async getDep(name: string): Promise<DepInfos | null> {
        const dep = DepsService.cache.peek(name);
        if (!dep) {
            DepsService.log.warn(`dependency ${name} not found in cache.`);
            return null;
        }
        if (DepsService.cache.isExpired(name)) {
            DepsService.log.info(`dependency ${name} expired from cache, triggering update.`);
            await DepsService.reloadCacheEntry(name);
            return DepsService.getDep(name);
        }
        DepsService.log.debug(`dependency ${name}'s info found in cache.`);
        return dep;
    }

    /**
     * Installs a single dependency.
     * @param name The name of the dependency to install.
     * @returns The child process of the installation command.
     * If the dependency is already installed, it returns null.
     */
    public static async installSingle(name: string): Promise<ChildProcess | null> {
        const dep = await DepsService.getDep(name);
        if (dep?.status.installed) {
            DepsService.log.info(`${name} is already installed. Skipping.`);
            return null;
        }
        let job: ChildProcess = null;
        const isScript = dep?.model.install_cmd.endsWith('.sh');
        if (isScript) {
            const scriptDir = ConfigService.getScriptsDir();
            job = ShellService.runScript(scriptDir + '/deps/' + dep?.model.install_cmd, [], SystemService.getSudoPassword());
        } else {
            job = ShellService.spawnCommandWithSudo(dep?.model.install_cmd.split(' '), SystemService.getSudoPassword());
        }
        job.on('close', code => code === 0 && DepsService.setInstalled(name));
        return job;
    }

    /**
     * Uninstalls a single dependency.
     * @param name The name of the dependency to uninstall.
     * @returns The child process of the uninstallation command.
     * If the dependency is already uninstalled, it returns null.
     */
    public static async uninstall(name: string): Promise<ChildProcess | null> {
        const dep = await DepsService.getDep(name);
        if (!dep?.status.installed) {
            DepsService.log.info(`dependency ${name} is not installed. Skipping.`);
            return null;
        }
        const child = ShellService.spawnCommandWithSudo(dep?.model.remove_cmd.split(' '), SystemService.getSudoPassword());
        child.on('close', code => code === 0 && DepsService.setInstalled(name, false));
        return child;
    }

    /**
     * Installs dependencies sequentially.
     * If no names are provided, installs all required dependencies.
     * @param names Names of the dependencies to install.
     * @param streamConfig Configuration for streaming the output of the installation process.
     * @returns A promise that resolves to an array of dependency installation results.
     */
    public static async installSequentially(names: string[], streamConfig?: (child: ChildProcess, taskName: string, onClose?: (exitCode: number | null) => void) => void) {
        const deps = names.length === 0 ? DepsService.getRequiredDependencies().map(d => d.name) : names;
        const results: Array<{ name: string, isSuccess: boolean, code: number | null }> = [];
        for (let i = 0; i < deps.length; i++) {
            DepsService.log.info(`Installing ${deps[i]}...`);
            const name = deps[i];
            const child = await DepsService.installSingle(name);
            // Close response only at the end of the last installation (no args call)
            i === deps.length - 1 ?
                streamConfig?.(child, name) :
                streamConfig?.(child, name, () => { });
            const result = await DepsService.waitForInstallation(child);
            result.isSuccess ?
                DepsService.log.info(`  --> ${name} installed.`) :
                DepsService.log.error(`  --> ${name} installation FAILED.`);
            results.push({ ...result, name });
        }
        return results;
    }

    public static async waitForInstallation(child: ChildProcess | null) {
        if (!child) {
            return Promise.resolve({ isSuccess: true, code: 0 });
        }
        return new Promise<{ isSuccess: boolean, code: number | null }>((resolve) => {
            child.on('close', code => resolve({ isSuccess: code === 0, code: code }));
        });
    }

    public static setInstalled(name: string, installed: boolean = true) {
        const data = DepsService.cache.peek(name);
        if (data?.model) {
            DepsService.setCacheEntry(data.model, { name, installed });
        } else {
            DepsService.log.warn(`dependency ${name} not found. Cache entry cannot be updated.`);
        }
    }

    public static setRunning(name: string, running: boolean = true) {
        const data = DepsService.cache.peek(name);
        if (data?.model) {
            DepsService.setCacheEntry(data.model, { ...data.status, running });
        } else {
            DepsService.log.warn(`dependency ${name} not found. Cache entry cannot be updated.`);
        }
    }


    public static getAllDependencies(): DependencyModel[] {
        if (DepsService.cache.size === 0) {
            const allDeps = getAllDeps();
            allDeps.forEach(d => DepsService.setCacheEntry(d));
        }
        return DepsService.cache.values().map(d => d.model);
    }

    /**
     * Load deps list and refresh cache with actual installation status for each dependency. 
     */
    private static async reloadCache(): Promise<void> {
        DepsService.log.info('checking deps status and updating cache...');
        DepsService.cache.clear();
        const allDeps = getAllDeps();
        const cacheData = await Promise.all(
            allDeps.map(async d => {
                const status = await DepsService.checkDependency(d);
                return { model: d, status };
            })
        );
        cacheData.forEach(d => DepsService.setCacheEntry(d.model, d.status));
    }

    private static async reloadCacheEntry(name: string) {
        const dep = getDep(name);
        if (dep) {
            const status = await DepsService.checkDependency(dep);
            DepsService.setCacheEntry(dep, status);
        } else {
            DepsService.log.warn(`dependency ${name} not found. Cache entry cannot be updated.`);
        }
    }

    public static getDependencyNames(): string[] {
        if (DepsService.cache.size === 0) {
            const allDeps = getAllDeps();
            allDeps.forEach(d => DepsService.setCacheEntry(d));
        }
        return DepsService.cache.keys();
    }

    public static getRequiredDependencies(): DependencyModel[] {
        return getRequiredDeps();
    }

    public static async checkRequiredDeps(): Promise<DependencyStatus[]> {
        const requiredDeps = DepsService.getRequiredDependencies();
        return await DepsService.checkDependenciesStatus(requiredDeps);
    }

    /**
     * Refreshes the cache entry for a single dependency and returns its status.
      */
    public static async getDepStatus(name: string): Promise<DependencyStatus> {
        const cachedDep = await DepsService.getDep(name);
        if (!cachedDep) {
            return { name, installed: false, error: `${name} is not an homelab dependency` };
        }
        let status = cachedDep.status;
        if (status.installed) {
            const isJustCached = Date.now() - DepsService.cache.lastUpdate < 5000;
            if (status.running !== undefined && !isJustCached) {
                const runningCheckResult = await DepsService.checkRunningStatus(cachedDep.model);
                status = { ...status, ...runningCheckResult };
            }
            DepsService.setCacheEntry(cachedDep.model, status);
        }
        return status;
    }

    private static async checkRunningStatus(dep: DependencyModel): Promise<{ running: boolean, error?: string }> {
        const statusCheck = new Promise<{ running: boolean, error?: string }>((resolve) => {
            DepsService.log.info({ cmd: dep.status_cmd, task: 'checkRunningStatus' }, `checking if ${dep.name} is running`);
            exec(dep.status_cmd!, (error, stdout, stderr) => {
                if (error) {
                    DepsService.log.error(`${dep.name} is not running: ${error}`,);
                    resolve({ running: false, error: error.message || 'Unknown error' });
                } else {
                    DepsService.log.info(`${dep.name} is running: ${!error}`,);
                    resolve({ running: true });
                }
            });
        });
        return await statusCheck
    }

    private static async checkSetupStatus(dep: DependencyModel, onTaskCompleted: (result: JobResult, percentage: number) => void): Promise<JobResult> {
        const setupChecker = DepsService.DEPS_SETUP_CHECKERS.get(dep.name);
        if (!setupChecker) {
            DepsService.log.warn(`No setup checker available for ${dep.name}. Considering as setup completed.`);
            return { name: `${dep.name} setup check`, service: dep.name, success: true, message: 'No setup checker available' };
        }
        DepsService.log.info({ task: 'checkSetupStatus' }, `checking ${dep.name} setup...`);
        const result = await setupChecker.check(onTaskCompleted);
        return result;
    }

    public static async checkDependency(dep: DependencyModel | string): Promise<DependencyStatus> {
        const depModel = typeof dep === 'string' ? getDep(dep) : dep;
        const name = typeof dep === 'string' ? dep : dep.name;
        if (!depModel) {
            return { name, installed: false, error: 'Dependency not found' };
        }
        let result: DependencyStatus = { name, installed: false };
        const installCheck = new Promise<DependencyStatus>(resolve => {
            DepsService.log.info({ cmd: depModel.check_cmd, task: 'execCheck' }, `checking ${name} installation`);
            exec(depModel.check_cmd, (error, stdout) => {
                if (error) {
                    resolve({ name, installed: false, error: error.message || 'Unknown error' });
                } else {
                    resolve({ name, installed: true });
                }
                DepsService.log.info(`${name} is installed: ${!error}`);
            });
        });
        result = await installCheck;
        if (result.installed) {
            const setupCheckResult = await DepsService.checkSetupStatus(depModel, () => { });
            const scr = setupCheckResult;
            const setupResult = { setup: scr.success, error: !scr.success ? scr.message : undefined }
            result = { ...result, ...setupResult }
            if (result.setup && depModel.status_cmd) {
                const runningCheckResult = await DepsService.checkRunningStatus(depModel);
                result = { ...result, ...runningCheckResult };
            }
        }
        return result;
    }

    public static async getAllDependenciesStatus(): Promise<DependencyStatus[]> {
        return Promise.all(DepsService.cache.keys().map(DepsService.getDepStatus));
    }

    public static async getDependenciesStatus(deps?: string[]): Promise<DependencyStatus[]> {
        if (!deps || deps.length === 0) return await DepsService.getAllDependenciesStatus();
        return Promise.all(deps.map(name => DepsService.getDepStatus(name)));
    }

    public static async getRequiredDependenciesStatus(): Promise<DependencyStatus[]> {
        const requiredDeps = getRequiredDeps();
        return await DepsService.getDependenciesStatus(requiredDeps.map(dep => dep.name));
    }

    /**
     * Retrieves status of selected dependencies concurrently.
     * @param deps Array of dependency names or dependency models to check.
     * @returns An array of dependency statuses.
     */
    public static async checkDependenciesStatus(deps: string[] | DependencyModel[]): Promise<DependencyStatus[]> {
        if (deps.length === 0) return [];
        const names =
            typeof deps[0] === 'string' ?
                deps as string[] :
                (deps as DependencyModel[]).map(d => d.name);
        return Promise.all(
            names.map(name => DepsService.getDepStatus(name))
        );
    }
}
