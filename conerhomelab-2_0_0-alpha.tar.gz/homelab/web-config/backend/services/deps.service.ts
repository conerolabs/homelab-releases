import { ChildProcess, exec } from 'child_process';
import { getAllDeps, getDep, getRequiredDeps } from '../../database/depsDAO.ts';
import type { DependencyStatus } from '../../commons/dto.ts';
import type { DependencyModel } from '../../commons/models.ts';
import { ShellService } from './shell.service.ts';
import { fileURLToPath } from 'url';
import path from 'path';
import { SystemService } from './system.service.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export class DepsService {

    private static readonly INSTALL_SCRIPT_PATH = path.resolve(__dirname, '../../../scripts/deps/deps-install-all.sh');
    private static readonly MANAGER_SCRIPT_PATH = path.resolve(__dirname, '../../../scripts/deps/deps-manager.sh');

    private static cache = {
        data: new Map<string, { model: DependencyModel, status: DependencyStatus }>(),
        lastUpdate: 0,
        ttl: 1000 * 60 * 5, // ignored for now
    };

    public static async init(): Promise<void> {
        console.log('DEPS - loading dependencies data...');
        await DepsService.reloadCache();
    }

    private static setCacheEntry(model: DependencyModel | null, status?: DependencyStatus) {
        if (!model && !status) {
            console.warn('DEPS - neither dependency model nor status where provided for cache entry');
            return;
        } else if (!model && status) {
            const data = DepsService.cache.data.get(status.name);
            if (data?.model) {
                DepsService.cache.data.set(status.name, { model: data.model, status: status });
            } else {
                console.warn(`DEPS - dependency ${status.name} not found. Cache entry cannot be updated.`);
            }
        } else if (model) {
            DepsService.cache.data.set(
                model.name,
                {
                    model: model,
                    status: status ?? { name: model.name, installed: false, error: 'Not checked yet' }
                }
            );
        }
    }

    public static installAll() {
        const child = ShellService.runScript(DepsService.INSTALL_SCRIPT_PATH, [], SystemService.getSudoPassword());
        child.on('close', code => code === 0 && DepsService.setAllInstalled());
        return child;
    }

    public static installSingle(name: string) {
        const child = ShellService.runScript(DepsService.MANAGER_SCRIPT_PATH, ['install', name], SystemService.getSudoPassword());
        child.on('close', code => code === 0 && DepsService.setInstalled(name));
        return child;
    }

    public static uninstall(name: string) {
        const child = ShellService.runScript(DepsService.MANAGER_SCRIPT_PATH, ['remove', name], SystemService.getSudoPassword());
        child.on('close', code => code === 0 && DepsService.setInstalled(name, false));
        return child;
    }

    public static async installSequentially(names: string[], streamConfig: (child: ChildProcess, taskName: string, endOnClose: boolean) => void) {
        const results: Array<{ name: string, isSuccess: boolean, code: number | null }> = [];
        for (let i = 0; i < names.length; i++) {
            const name = names[i];
            const child = DepsService.installSingle(name);
            if (streamConfig) streamConfig(child, name, i === names.length - 1);
            const result = await DepsService.waitForInstallation(child);
            results.push({ ...result, name });
        }
        return results;
    }

    public static async waitForInstallation(child: ChildProcess) {
        return new Promise<{ isSuccess: boolean, code: number | null }>((resolve) => {
            child.on('close', code => resolve({ isSuccess: code === 0, code: code }));
        });
    }

    public static async waitForInstallations(children: ChildProcess[]) {
        const results = await Promise.all(children.map(child => {
            return new Promise<{ isSuccess: boolean, code: number | null }>((resolve) => {
                child.on('close', code => resolve({ isSuccess: code === 0, code: code }));
            });
        }));

        results.forEach(result => {
            if (result.isSuccess) {
                DepsService.setAllInstalled();
            }
        });
    }

    public static setAllInstalled() {
        DepsService.cache.data.forEach(value => {
            DepsService.setCacheEntry(value.model, { name: value.status.name, installed: true });
        });
    }

    public static setInstalled(name: string, installed: boolean = true) {
        const data = DepsService.cache.data.get(name);
        if (data?.model) {
            DepsService.setCacheEntry(data.model, { name, installed });
        } else {
            console.warn(`DEPS - dependency ${name} not found. Cache entry cannot be updated.`);
        }
    }


    public static getAllDependencies(): DependencyModel[] {
        return Array.from(DepsService.cache.data.values()).map(d => d.model);
    }

    private static async reloadCache(): Promise<void> {
        console.log('DEPS - reloading cache...');
        DepsService.cache.data.clear();
        const allDeps = getAllDeps();
        const cacheData = await Promise.all(
            allDeps.map(async d => {
                const status = await DepsService.execCheck(d);
                return { model: d, status };
            })
        );
        cacheData.forEach(d => DepsService.setCacheEntry(d.model, d.status));
        DepsService.cache.lastUpdate = Date.now();
    }

    public static getDependencyNames(): string[] {
        return Array.from(DepsService.cache.data.keys());
    }

    public static getRequiredDependencies(): DependencyModel[] {
        return getRequiredDeps();
    }

    public static async checkRequiredDeps(noCache: boolean = false): Promise<DependencyStatus[]> {
        const requiredDeps = getRequiredDeps();
        return await DepsService.checkDependenciesStatus(requiredDeps, noCache);
    }

    public static async getDepStatus(name: string): Promise<DependencyStatus> {
        const cachedDep = DepsService.cache.data.get(name);
        if (cachedDep?.status.installed && (cachedDep.status.running !== undefined)) {
            const status = await DepsService.checkRunningStatus(cachedDep.model);
            DepsService.setCacheEntry(cachedDep.model, status);
            return status;
        }
        return cachedDep?.status ?? { name, installed: false, error: 'Not found in DB' };
    }

    private static async checkRunningStatus(dep: DependencyModel) {
        const statusCheck = new Promise<DependencyStatus>((resolve) => {
            console.log(`DEPS - checking if ${dep.name} is running with command: ${dep.status_cmd}`);
            exec(dep.status_cmd!, (error, stdout) => {
                if (error) {
                    console.log(`DEPS - ${dep.name} is running: `, false);
                    resolve({ name: dep.name, installed: true, running: false, error: error.message || 'Unknown error' });
                } else {
                    console.log(`DEPS - ${dep.name} is running: `, true);
                    resolve({ name: dep.name, installed: true, running: true });
                }
            });
        });
        return await statusCheck
    }

    private static async execCheck(dep: DependencyModel): Promise<DependencyStatus> {
        const installCheck = new Promise<DependencyStatus>(resolve => {
            console.log(`DEPS - checking ${dep.name} installation with command: ${dep.check_cmd}`);
            exec(dep.check_cmd, (error, stdout) => {
                if (error) {
                    console.log(`DEPS - ${dep.name} is installed: `, false);
                    resolve({ name: dep.name, installed: false, error: error.message || 'Unknown error' });
                } else {
                    console.log(`DEPS - ${dep.name} is installed: `, true);
                    resolve({ name: dep.name, installed: true });
                }
            });
        });
        const installResult = await installCheck;
        if (installResult.installed && dep.status_cmd) {
            const runResult = await DepsService.checkRunningStatus(dep);
            return runResult;
        }
        else {
            return installResult;
        }
    }

    public static async checkDependency(name: string, noCache: boolean = false): Promise<DependencyStatus> {
        let data = DepsService.cache.data.get(name);
        let dep = data?.model;
        let status = data?.status;

        if (!data && !noCache) {
            console.warn(`DEPS - dependency ${name} not found`);
            return Promise.resolve({ name, installed: false, error: 'Not found in DB' });
        }
        else if (data && !noCache) {
            if (status?.installed && status.running !== undefined) return DepsService.checkRunningStatus(dep!) // happy path
            else if (status?.error !== 'Not checked yet') return Promise.resolve(status) // cached and don't need to check if running
            else {
                const status = await DepsService.execCheck(dep!);
                DepsService.cache.data.set(dep.name, { model: dep, status });
                return status;
            }
        }

        if (noCache) {
            dep = getDep(name);
            if (!dep) {
                console.warn(`DEPS - dependency ${name} not found`);
                return Promise.resolve({ name, installed: false, error: 'Not found in DB' });
            }
            else {
                DepsService.setCacheEntry(dep);
                const status = await DepsService.execCheck(dep);
                DepsService.setCacheEntry(dep, status);
                return status;
            }
        }
        throw new Error('Should not happen');
    }

    public static getAllDependenciesStatus(): DependencyStatus[] {
        return Array.from(DepsService.cache.data.values()).map(d => d.status);
    }

    public static async getDependenciesStatus(deps?: string[]): Promise<DependencyStatus[]> {
        if (!deps || deps.length === 0) return Promise.resolve(DepsService.getAllDependenciesStatus());
        return Promise.all(deps.map(name => DepsService.getDepStatus(name)));
    }

    public static async getRequiredDependenciesStatus(): Promise<DependencyStatus[]> {
        const requiredDeps = getRequiredDeps();
        return await DepsService.getDependenciesStatus(requiredDeps.map(dep => dep.name));
    }

    /**
     * Retrieves status of selected dependencies concurrently.
     */
    public static async checkDependenciesStatus(deps: string[] | DependencyModel[], noCache: boolean = false): Promise<DependencyStatus[]> {
        if (deps.length === 0) return [];
        const names =
            typeof deps[0] === 'string' ?
                deps as string[] :
                (deps as DependencyModel[]).map(d => d.name);
        return Promise.all(
            names.map(name => DepsService.checkDependency(name, noCache))
        );
    }
}
