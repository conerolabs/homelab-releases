import type { JobResult } from "../../../commons/dto.ts";
import { BaseConfigHelper } from "./BaseConfigHelper.ts";
import { ConfigService } from "../config.service.ts";
import { SystemService } from "../system.service.ts";
import type { HLTask } from "../TasksManager.ts";
import { getLogger } from "../../logger.ts";
import { existsSync } from "node:fs";
import path from "node:path";
import { ShellService } from "../shell.service.ts";

export class UnboundConfigHelper extends BaseConfigHelper {

    protected static override readonly log = getLogger('UnboundConfigHelper');

    public static readonly UNBOUND_LIB_DIR = '/var/lib/unbound';
    public static readonly ROOT_KEY_FILE = '/var/lib/unbound/root.key';
    public static readonly UNBOUND_CONF_DIR = '/etc/unbound/unbound.conf.d';
    public static readonly UNBOUND_CONF_FILE = '/etc/unbound/unbound.conf.d/homelab.conf';

    private static setupTasks: HLTask[] = [
        {
            name: 'unbound.dnssec',
            description: 'Enabling DNSSEC validation root trust anchor',
            action: () => UnboundConfigHelper.enableDnssecValidation(),
            skip: () => Promise.resolve({ skip: false }),
            weight: 2,
        },
        {
            name: 'unbound.user',
            description: 'Creating unbound user and setting permissions',
            action: () => UnboundConfigHelper.createUnboundUser(),
            skip: () => Promise.resolve({ skip: false }),
            weight: 2,
        },
        {
            name: 'unbound.disable-resolvconf',
            description: 'Disabling unbound-resolvconf service',
            action: () => UnboundConfigHelper.disableUnboundResolvconf(),
            skip: () => Promise.resolve({ skip: false }),
            weight: 2,
        },
        {
            name: 'unbound.configure',
            description: 'Configuring Unbound server and restarting service',
            action: () => UnboundConfigHelper.configureUnbound(),
            skip: () => Promise.resolve({ skip: false }),
            weight: 4,
        },
    ];

    constructor() {
        super('unbound', 1);
    }

    public override getTasks(): HLTask[] {
        return UnboundConfigHelper.setupTasks;
    }

    /**
     * Executes a shell command with sudo privileges.
     */
    private static async runCommand(cmd: string, ignoreErrors: boolean = false): Promise<{ stdout: string; stderr: string; exitCode: number }> {
        const sudoPassword = SystemService.getSudoPassword();
        return ShellService.execCommand(cmd, sudoPassword, ignoreErrors);
    }

    /**
     * Resolves the source homelab.conf template file path.
     */
    public static getSourceConfPath(): string {
        return path.join(ConfigService.getHomelabConfigDir(), 'unbound', 'homelab.conf');
    }

    /**
     * Enables DNSSEC validation by fetching root zone's public key using unbound-anchor.
     */
    public static async enableDnssecValidation(): Promise<JobResult> {
        const log = UnboundConfigHelper.log.child({ task: 'enableDnssecValidation' });
        try {
            log.info('- Enabling DNSSEC validation by fetching root zone\'s public key...');
            await UnboundConfigHelper.runCommand(`mkdir -p "${UnboundConfigHelper.UNBOUND_LIB_DIR}"`);

            // unbound-anchor exits 0 on success/no-update, or 1 if updated via certificate/builtin anchor.
            // Both are considered successful anchor initializations.
            const { exitCode, stderr } = await UnboundConfigHelper.runCommand(
                `unbound-anchor -a "${UnboundConfigHelper.ROOT_KEY_FILE}"`,
                true
            );

            if (exitCode === 0 || exitCode === 1 || existsSync(UnboundConfigHelper.ROOT_KEY_FILE)) {
                log.info(`  --> [OK] DNSSEC root key initialized at ${UnboundConfigHelper.ROOT_KEY_FILE}`);
                return {
                    name: 'unbound.dnssec',
                    success: true,
                    message: 'DNSSEC root key fetched and validated'
                };
            }

            throw new Error(`unbound-anchor failed with exit code ${exitCode}: ${stderr}`);
        } catch (error: any) {
            log.error('  --> [ERROR] Failed to enable DNSSEC validation: ' + error.message);
            return {
                name: 'unbound.dnssec',
                success: false,
                message: error.message
            };
        }
    }

    /**
     * Creates the system unbound user (if not exists) and sets permissions for /var/lib/unbound.
     */
    public static async createUnboundUser(): Promise<JobResult> {
        const log = UnboundConfigHelper.log.child({ task: 'createUnboundUser' });
        try {
            log.info('- Creating unbound user and setting permissions for /var/lib/unbound...');

            const { exitCode } = await UnboundConfigHelper.runCommand('id -u unbound', true);
            if (exitCode !== 0) {
                log.info('  --> Creating system user unbound...');
                await UnboundConfigHelper.runCommand('useradd -r -s /sbin/nologin unbound');
            } else {
                log.info('  --> System user unbound already exists');
            }

            await UnboundConfigHelper.runCommand(`mkdir -p "${UnboundConfigHelper.UNBOUND_LIB_DIR}"`);
            await UnboundConfigHelper.runCommand(`chown -R unbound:unbound "${UnboundConfigHelper.UNBOUND_LIB_DIR}"`);
            log.info('  --> [OK] unbound user and permissions verified');
            return {
                name: 'unbound.user',
                success: true,
                message: 'Unbound user and directory permissions configured'
            };
        } catch (error: any) {
            log.error('  --> [ERROR] Failed to configure unbound user and permissions: ' + error.message);
            return {
                name: 'unbound.user',
                success: false,
                message: error.message
            };
        }
    }

    /**
     * Disables unbound-resolvconf service if active.
     */
    public static async disableUnboundResolvconf(): Promise<JobResult> {
        const log = UnboundConfigHelper.log.child({ task: 'disableUnboundResolvconf' });
        try {
            const { exitCode } = await UnboundConfigHelper.runCommand('systemctl is-active --quiet unbound-resolvconf', true);
            if (exitCode === 0) {
                log.info('- Disabling service unbound-resolvconf...');
                await UnboundConfigHelper.runCommand('systemctl disable --now unbound-resolvconf 2>/dev/null || true');
                log.info('  --> [OK] Service unbound-resolvconf disabled');
                return {
                    name: 'unbound.disable-resolvconf',
                    success: true,
                    message: 'Service unbound-resolvconf disabled'
                };
            } else {
                log.info('- Service unbound-resolvconf is already disabled.');
                return {
                    name: 'unbound.disable-resolvconf',
                    success: true,
                    message: 'Service unbound-resolvconf is already disabled'
                };
            }
        } catch (error: any) {
            log.error('  --> [ERROR] Failed to disable unbound-resolvconf: ' + error.message);
            return {
                name: 'unbound.disable-resolvconf',
                success: false,
                message: error.message
            };
        }
    }

    /**
     * Configures Unbound with homelab.conf, validates config using unbound-checkconf,
     * and restarts the service.
     */
    public static async configureUnbound(): Promise<JobResult> {
        const log = UnboundConfigHelper.log.child({ task: 'configureUnbound' });
        try {
            const sourceConf = UnboundConfigHelper.getSourceConfPath();
            if (!existsSync(sourceConf)) {
                throw new Error(`Source unbound configuration file not found at: ${sourceConf}`);
            }

            if (existsSync(UnboundConfigHelper.UNBOUND_CONF_FILE)) {
                const { exitCode } = await UnboundConfigHelper.runCommand(
                    `diff -BEZq "${UnboundConfigHelper.UNBOUND_CONF_FILE}" "${sourceConf}"`,
                    true
                );
                if (exitCode === 0) {
                    const msg = `Unbound configuration file ${UnboundConfigHelper.UNBOUND_CONF_FILE} is already set.`;
                    log.info(`  --> [OK] ${msg}`);
                    return {
                        name: 'unbound.configure',
                        success: true,
                        message: msg
                    };
                }
            }

            log.info(`- Configuring file ${UnboundConfigHelper.UNBOUND_CONF_FILE}...`);
            await UnboundConfigHelper.runCommand(`mkdir -p "${UnboundConfigHelper.UNBOUND_CONF_DIR}"`);
            await UnboundConfigHelper.runCommand(`cp "${sourceConf}" "${UnboundConfigHelper.UNBOUND_CONF_FILE}"`);

            log.info('- Checking unbound configuration (unbound-checkconf)...');
            await UnboundConfigHelper.runCommand('unbound-checkconf');

            log.info('- Restarting unbound service...');
            await UnboundConfigHelper.runCommand('systemctl restart unbound || service unbound restart');

            log.info('  --> [OK] Unbound configuration completed and service restarted');
            return {
                name: 'unbound.configure',
                success: true,
                message: 'Unbound configuration completed and service restarted'
            };
        } catch (error: any) {
            log.error('  --> [ERROR] Failed to configure Unbound: ' + error.message);
            return {
                name: 'unbound.configure',
                success: false,
                message: error.message
            };
        }
    }
}
