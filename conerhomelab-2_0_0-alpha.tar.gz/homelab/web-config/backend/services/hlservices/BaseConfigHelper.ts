import type { JobResult } from "../../../commons/dto.ts";
import { ConfigService } from "../config.service.ts";
import type { ServiceConfigHelper } from "./services.service.ts";
import { TasksManager, type HLTask } from "../TasksManager.ts";
import { buildDockerImage, getDockerImageInfo } from "../../docker-utils.ts";
import { getLogger } from "../../logger.ts";

export abstract class BaseConfigHelper extends TasksManager implements ServiceConfigHelper {
    public readonly name: string; // docker compose service name
    public readonly order: number;
    protected static readonly log = getLogger('BaseConfigHelper', { msgPrefix: 'SETUP - ' });

    constructor(name: string, order: number) {
        super(`${name} setup`);
        this.name = name;
        this.order = order;
    }

    public getServiceDir(): string {
        return `${ConfigService.getInstallDir()}/${this.name}`;
    }

    public abstract getTasks(): HLTask[];

    public async setup(onTaskCompleted: (result: JobResult, percentage: number) => void): Promise<JobResult> {
        return this.runTasks(onTaskCompleted, () => ConfigService.saveConfig());
    }

    private static getDockerImageBuildAction(name: string): HLTask['action'] {
        return async function () {
            try {
                BaseConfigHelper.log.info(`building ${name} docker image ...`);
                await buildDockerImage(name);
                BaseConfigHelper.log.info(`${name} docker image build completed`);
                const result = { name: name + '.docker-image.build', success: true };
                return result;
            } catch (error) {
                BaseConfigHelper.log.error(`Error building ${name} docker image: ${error}`);
                const result = { name: name + '.docker-image.build', success: false, message: error.toString() };
                return result;
            }
        }
    }

    public static getBuildDockerImageTask(name: string, weight?: number): HLTask {
        return {
            name: `${name}.docker-image.build`,
            description: `Building ${name} docker image`,
            action: BaseConfigHelper.getDockerImageBuildAction(name),
            skip: async () => {
                const imageInfo = await getDockerImageInfo(name);
                if (imageInfo) {
                    return { skip: true, reason: `${name} docker image already exists` };
                }
                return { skip: false, reason: `${name} docker image is not available` };
            },
            weight: weight ?? 1
        }
    }


}