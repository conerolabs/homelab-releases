import type { JobResult } from "../../../commons/dto.ts";
import { ConfigService } from "../config.service.ts";
import type { ServiceConfigHelper, SetupParams } from "./services.service.ts";
import { TasksManager, type HLTask } from "../TasksManager.ts";
import { buildDockerImage, getDockerImageInfo } from "../../docker-utils.ts";
import { getLogger } from "../../logger.ts";

export abstract class BaseConfigHelper<V extends Record<string, any>> extends TasksManager<V> implements ServiceConfigHelper<V> {
    public readonly order: number;
    public static readonly log = getLogger('BaseConfigHelper', { msgPrefix: 'SETUP - ' });

    constructor(service: string, order: number) {
        super(`${service} setup`, service);
        this.order = order;
    }

    public getServiceDir(): string {
        return `${ConfigService.getInstallDir()}/${this.service}`;
    }

    public abstract getTasks(): HLTask<V>[];

    public async setup(setup: SetupParams<V>): Promise<JobResult> {
        return this.runTasks(setup.params, setup.onTaskCompleted, () => ConfigService.saveConfig());
    }

    private static getDockerImageBuildAction(service: string): HLTask<{}>['action'] {
        return async function () {
            try {
                BaseConfigHelper.log.info(`building ${service} docker image ...`);
                await buildDockerImage(service);
                BaseConfigHelper.log.info(`${service} docker image build completed`);
                const result = { name: service + '.docker-image.build', service: service, success: true };
                return result;
            } catch (error) {
                BaseConfigHelper.log.error(`Error building ${service} docker image: ${error}`);
                const result = { name: service + '.docker-image.build', service, success: false, message: error.toString() };
                return result;
            }
        }
    }

    public static getBuildDockerImageTask(name: string, weight?: number): HLTask<{}> {
        return {
            name: `${name}.docker-image.build`,
            description: `Building ${name} docker image`,
            action: BaseConfigHelper.getDockerImageBuildAction(name),
            skip: async () => {
                const imageInfo = await getDockerImageInfo(name);
                if (imageInfo) {
                    return { skip: true, reason: `${name} docker image already exists` };
                }
                return { skip: false, reason: `${name} docker image is not available` };
            },
            weight: weight ?? 1
        }
    }


}