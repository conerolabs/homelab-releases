import type { JobResult } from "../../../commons/dto.ts";
import { ConfigService } from "../config.service.ts";
import type { ServiceConfigHelper } from "./services.service.ts";
import { TasksManager, type HLTask } from "../TasksManager.ts";
import { buildDockerImage, getDockerImageInfo } from "../../docker-utils.ts";
import { getLogger } from "../../logger.ts";

export abstract class BaseConfigHelper extends TasksManager implements ServiceConfigHelper {
    public readonly name: string; // docker compose service name
    protected static readonly log = getLogger('BaseConfigHelper', { msgPrefix: 'SETUP - ' });

    constructor(name: string) {
        super(`${name} setup`);
        this.name = name;
    }

    public abstract getTasks(): HLTask[];

    public async setup(onTaskCompleted: (result: JobResult, percentage: number) => void): Promise<JobResult> {
        return this.runTasks(onTaskCompleted, () => ConfigService.saveConfig());
    }

    private static async setupDockerImage(name: string): Promise<JobResult> {
        try {
            BaseConfigHelper.log.info(`building ${name} docker image ...`);
            await buildDockerImage(name);
            BaseConfigHelper.log.info(`${name} docker image build completed`);
            const result = { name: name + '-docker-image', success: true };
            return result;
        } catch (error) {
            BaseConfigHelper.log.error(`Error building ${name} docker image: ${error}`);
            const result = { name: name + '-docker-image', success: false, message: error.toString() };
            return result;
        }
    }

    public static getBuildDockerImageTask(name: string, weight?: number): HLTask {
        return {
            name: `${name}.docker-image`,
            description: `Building ${name} docker image`,
            action: () => BaseConfigHelper.setupDockerImage(name),
            skip: async () => {
                const imageInfo = await getDockerImageInfo(name);
                if (imageInfo) {
                    return { skip: false };
                }
                return { skip: true, reason: `${name} docker image is not available` };
            },
            weight: weight ?? 1
        }
    }


}