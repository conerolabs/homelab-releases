import type { SetupResult } from "../../../commons/dto.ts";
import type { ServiceConfigHelper } from "./services.service.ts";

export class PiholeConfigHelper implements ServiceConfigHelper {
    public readonly name: string = 'pihole';

    setup(): Promise<SetupResult> {
        return Promise.resolve({ name: PiholeConfigHelper.name, success: false, message: 'Not implemented' });
    }
}