import type { JobResult, VpnMode } from "../../../commons/dto.ts";
import { envSubst, getLanIp } from "../../../commons/utils.ts";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import path, { basename } from "node:path";
import { exec } from "node:child_process";
import os from "node:os";
import { buildDockerImage } from "../../docker-utils.ts";
import { BaseConfigHelper } from "./BaseConfigHelper.ts";
import { SystemService } from "../system.service.ts";
import { ConfigService } from "../config.service.ts";
import type { HLTask } from "../TasksManager.ts";
import { ShellService } from "../shell.service.ts";

export class DnsRecord {
    ip: string;
    name: string;

    constructor(ip: string, name: string) {
        this.ip = ip;
        this.name = name;
    }

    public toString() {
        return `${this.ip} ${this.name}`
    }
}

type DnsTable = DnsRecord[]

export class PiholeConfigHelper extends BaseConfigHelper<{}> {

    private static CONFIG_TEMPLATE_DIR: string;
    private static readonly RESOLVED_CONF_DIR = '/etc/systemd/resolved.conf.d';
    private static readonly DISABLE_STUB_FILE = path.join(PiholeConfigHelper.RESOLVED_CONF_DIR, 'disable-stub.conf');
    private static readonly HOMELAB_RESOLVED_FILE = path.join(PiholeConfigHelper.RESOLVED_CONF_DIR, 'homelab.conf');
    private static readonly RESOLV_CONF_FILE = '/etc/resolv.conf';
    private static readonly RESOLV_CONF_TARGET = '/run/systemd/resolve/resolv.conf';
    private static readonly NETWORK_CONF_DIR = '/etc/systemd/network';


    private static readonly setupTasks: HLTask<{}>[] = [
        {
            name: 'Disable DNS Stub Resolver',
            description: 'Disables the systemd DNS Stub resolver',
            action: PiholeConfigHelper.disableDnsStubResolver,
            skip: () => Promise.resolve({ skip: false }),
            weight: 8
        },
        {
            name: 'Configure DNS Resolver',
            description: 'Configures the systemd DNS resolver to use Pi-Hole',
            action: PiholeConfigHelper.configureHomelabDnsResolver,
            skip: () => Promise.resolve({ skip: false }),
            weight: 8
        },
        {
            name: 'Restart systemd-resolved',
            description: 'Restarts the systemd-resolved service',
            action: PiholeConfigHelper.restartSystemdResolved,
            skip: () => Promise.resolve({ skip: false }),
            weight: 8
        },
        {
            name: 'Disable DHCP DNS',
            description: 'Disables DNS assigned by Router DHCP on the network interface',
            action: PiholeConfigHelper.disableDhcpDns,
            skip: () => Promise.resolve({ skip: false }),
            weight: 8
        },
        {
            name: 'Disable dnsmasq',
            description: 'Disable dnsmasq service, no longer needed',
            action: PiholeConfigHelper.disableDnsmasq,
            skip: () => Promise.resolve({ skip: false }),
            weight: 8
        },
        {
            name: 'Configure local DNS Table',
            description: 'Create the local DNS records used by Pi-Hole for local domains resolution',
            action: PiholeConfigHelper.configureLocalDnsTable,
            skip: () => Promise.resolve({ skip: false }),
            weight: 8
        },
        BaseConfigHelper.getBuildDockerImageTask('pihole', 52)

    ];

    public static init(): void {
        PiholeConfigHelper.log.info('STARTUP - Initializing PiHole Config Helper...');
        PiholeConfigHelper.CONFIG_TEMPLATE_DIR = path.join(ConfigService.getHomelabConfigDir().replace(/^~/, os.homedir()), 'pihole');
        PiholeConfigHelper.log.debug(`  --> CONFIG_TEMPLATE_DIR = ${PiholeConfigHelper.CONFIG_TEMPLATE_DIR}`)
    }

    constructor() {
        super('pihole', 2);
        PiholeConfigHelper.log.info(`PiHole config template directory: ${PiholeConfigHelper.CONFIG_TEMPLATE_DIR}`);
    }

    public override getTasks(): HLTask<{}>[] {
        return PiholeConfigHelper.setupTasks;
    }

    /**
     * Executes a shell command with sudo privileges.
     */
    private static async runCommand(cmd: string): Promise<{ stdout: string; stderr: string; exitCode: number }> {
        const sudoPassword = SystemService.getSudoPassword();
        return ShellService.execCommand(cmd, sudoPassword).result;
    }

    /**
     * Writes configuration files to privileged directories using sudo tee.
     * @param sourcePath The path to the source file directory (not the file itself).
     * @param destPath The path to the destination file (directory or file).
     */
    private static async copyFileWithSudo(sourcePath: string, destPath: string): Promise<void> {
        try {
            const filename = path.basename(destPath);
            const dir = path.dirname(destPath);
            PiholeConfigHelper.log.info(`Writing file: ${destPath}`);
            const commandsResult1 = await PiholeConfigHelper.runCommand(`mkdir -p "${dir}"`);
            const commandsResult2 = await PiholeConfigHelper.runCommand(`cp "${sourcePath}/${filename}" "${destPath}"`);
            if (commandsResult1.exitCode !== 0 || commandsResult2.exitCode !== 0) {
                throw new Error(`Failed to write file: ${destPath} - ${commandsResult1.stderr} ${commandsResult2.stderr}`);
            }
        } catch (e) {
            PiholeConfigHelper.log.error(`Failed to write file: ${destPath} - ${e}`);
            throw e as Error;
        }
    }

    /**
     * Disables the systemd DNS Stub resolver and updates /etc/resolv.conf.
     */
    private static async disableDnsStubResolver(): Promise<JobResult> {
        const log = PiholeConfigHelper.log.child({ task: 'disableDnsStubResolver' });

        if (existsSync(PiholeConfigHelper.DISABLE_STUB_FILE)) {
            const content = readFileSync(PiholeConfigHelper.DISABLE_STUB_FILE, 'utf-8');
            if (content.includes('DNSStubListener=no')) {
                log.info('- DNS Stub resolver already disabled');
                return { name: 'Disable DNS Stub Resolver', service: 'pihole', success: true, message: 'DNS Stub resolver already disabled' };
            }
        }

        log.info('- Disabling DNS Stub resolver...');
        await PiholeConfigHelper.copyFileWithSudo(PiholeConfigHelper.CONFIG_TEMPLATE_DIR, PiholeConfigHelper.DISABLE_STUB_FILE);
        await PiholeConfigHelper.runCommand(`ln -sf "${PiholeConfigHelper.RESOLV_CONF_TARGET}" "${PiholeConfigHelper.RESOLV_CONF_FILE}"`);
        log.info('  --> [OK] DNS Stub resolver disabled and /etc/resolv.conf updated');
        return { name: 'Disable DNS Stub Resolver', service: 'pihole', success: true, message: 'DNS Stub resolver disabled and /etc/resolv.conf updated' };
    }

    /**
     * Adds Pi-Hole and optional backup DNS to systemd-resolved.
     */
    private static async configureHomelabDnsResolver(): Promise<JobResult> {
        const log = PiholeConfigHelper.log.child({ task: 'configureHomelabDnsResolver' });

        if (existsSync(PiholeConfigHelper.HOMELAB_RESOLVED_FILE)) {
            const content = readFileSync(PiholeConfigHelper.HOMELAB_RESOLVED_FILE, 'utf-8');
            if (content.includes('DNS=127.0.0.1')) {
                log.info('  --> [OK] Homelab DNS resolver already configured');
                return { name: 'Configure DNS Resolver', service: 'pihole', success: true, message: 'Homelab DNS resolver already configured' };
            }
        }

        log.info('- Adding Pi-Hole as DNS resolver...');
        const contentTemplate = readFileSync(PiholeConfigHelper.CONFIG_TEMPLATE_DIR + '/template-homelab.conf', 'utf-8');
        const homelabConfig = envSubst(contentTemplate, ConfigService);
        writeFileSync(PiholeConfigHelper.CONFIG_TEMPLATE_DIR + '/homelab.conf', homelabConfig);

        await PiholeConfigHelper.copyFileWithSudo(PiholeConfigHelper.CONFIG_TEMPLATE_DIR, PiholeConfigHelper.HOMELAB_RESOLVED_FILE);
        log.info('  --> [OK] Homelab DNS resolver configured');
        return { name: 'Configure DNS Resolver', service: 'pihole', success: true, message: 'Homelab DNS resolver configured' };
    }

    /**
     * Restarts the systemd-resolved service.
     */
    private static async restartSystemdResolved(): Promise<JobResult> {
        PiholeConfigHelper.log.info('- Restarting systemd-resolved...');
        await PiholeConfigHelper.runCommand('systemctl restart systemd-resolved');
        PiholeConfigHelper.log.info('  --> [OK] systemd-resolved restarted');
        return { name: 'Restart systemd-resolved', service: 'pihole', success: true, message: 'systemd-resolved restarted' };
    }

    /**
     * Disables DNS assigned by Router DHCP on the network interface.
     */
    private static async disableDhcpDns(): Promise<JobResult> {
        const log = PiholeConfigHelper.log.child({ task: 'disableDhcpDns' });
        log.info('- Disabling DNS assigned by Router DHCP...');

        const networkInterface = ConfigService.getEnv('NETWORK_INTERFACE');
        if (!networkInterface) {
            log.warn('  --> [WARN] No network interface configured');
            return { name: 'Disable DHCP DNS', service: 'pihole', success: false, message: 'No network interface configured' };
        }
        const networkFilePath = path.join(PiholeConfigHelper.NETWORK_CONF_DIR, `01-${networkInterface}.network`);

        if (existsSync(networkFilePath)) {
            const content = readFileSync(networkFilePath, 'utf-8');
            if (content.includes('DHCP=yes') && (content.includes('UseDNS=false') || content.includes('UseDNS=no'))) {
                log.info(`  Network interface ${networkInterface} already configured`);
                return { name: 'Disable DHCP DNS', service: 'pihole', success: true, message: `Network interface ${networkInterface} already configured` };
            }
        }

        const networkConfigTemplate = readFileSync(PiholeConfigHelper.CONFIG_TEMPLATE_DIR + '/template-network.conf', 'utf-8');
        const networkConfig = envSubst(networkConfigTemplate, ConfigService);
        writeFileSync(PiholeConfigHelper.CONFIG_TEMPLATE_DIR + basename(networkFilePath), networkConfig);
        await PiholeConfigHelper.copyFileWithSudo(PiholeConfigHelper.CONFIG_TEMPLATE_DIR, networkFilePath);
        log.info(`  --> [OK] Written network configuration for ${networkInterface}`);

        log.info('- Restarting systemd-networkd...');
        await PiholeConfigHelper.runCommand('systemctl restart systemd-networkd');
        log.info('  --> [OK] systemd-networkd restarted');
        return { name: 'Disable DHCP DNS', service: 'pihole', success: true, message: 'DNS assigned by Router DHCP disabled' };
    }

    /**
     * Disables dnsmasq service if active.
     */
    private static async disableDnsmasq(): Promise<JobResult> {
        const log = PiholeConfigHelper.log.child({ task: 'disableDnsmasq' });

        const isDnsmasqActive = await new Promise<boolean>((resolve) => {
            exec('systemctl is-active dnsmasq', (error, stdout) => {
                resolve(stdout.trim() === 'active');
            });
        });

        if (isDnsmasqActive) {
            log.info('- Disabling dnsmasq...');
            try {
                await PiholeConfigHelper.runCommand('systemctl stop dnsmasq && systemctl disable dnsmasq');
                log.info('  --> [OK] dnsmasq stopped and disabled');
                return { name: 'Disable dnsmasq', service: 'pihole', success: true, message: 'dnsmasq disabled' };
            } catch (err: any) {
                log.error(`  --> [ERROR] Failed to stop/disable dnsmasq: ${err.message}`);
                return { name: 'Disable dnsmasq', service: 'pihole', success: false, message: `Failed to stop/disable dnsmasq: ${err.message}` };
            }
        } else {
            log.info('  --> [OK] Service dnsmasq is already disabled');
            return { name: 'Disable dnsmasq', service: 'pihole', success: true, message: 'dnsmasq is already disabled' };
        }
    }

    /**
     * Generates the local DNS table list file.
     */
    static configureLocalDnsTable(): JobResult {
        const log = PiholeConfigHelper.log.child({ task: 'configureLocalDnsTable' });
        try {
            log.info('- Generating local DNS table for Pi-hole...');
            const homelabDir = (ConfigService.getEnv('INSTALL_DIR') || '').replace(/^~/, process.env.HOME || '');
            const dnsTable = PiholeConfigHelper.createDnsTable();
            const listPath = path.join(homelabDir, 'local-dns-table.list');
            writeFileSync(listPath, PiholeConfigHelper.printDnsTable(dnsTable), 'utf-8');
            log.info(`  --> [OK] Local DNS table saved to ${listPath}`);
            return { name: 'Configure Local DNS Table', service: 'pihole', success: true, message: 'Local DNS table configured' };
        } catch (err: any) {
            log.error(`  --> [ERROR] Failed to configure local dns table: ${err.message}`);
            return { name: 'Configure Local DNS Table', service: 'pihole', success: false, message: `Failed to configure local dns table: ${err.message}` };
        }
    }

    static printDnsTable(dnsTable: DnsTable) {
        return dnsTable.map(record => record.toString()).join('\n')
    }

    static createDnsTable(): DnsTable {
        const mode = (ConfigService.getEnv('VPN_MODE') || 'none') as VpnMode; // headscale, tailscale, none
        const tailscaleIp = ConfigService.getEnv('TAILSCALE_IP');
        const lanIp = ConfigService.getEnv('LAN_IP') || getLanIp();
        const domain = ConfigService.getEnv('DOMAIN');
        const defaultDomain = "home.lab"
        if (!domain) {
            console.warn("No domain is defined. Configuring local dns table with default local domain: home.lab")
        }
        const dnsDomain = domain || defaultDomain;
        const ip = (tailscaleIp || lanIp).trim();

        const publicHosts = ['auth'];
        let hosts = ['bookmarks', 'calendar', 'dns', 'home', 'portainer', 'speedtest', 'status', 'vault', 'music', 'files'];
        const hostsLan = ['cron', 'config'];

        if (mode !== 'headscale') {
            hosts = [...publicHosts, ...hosts];
        }

        const dnsTable: DnsTable = [
            ...hosts.map(h => new DnsRecord(ip, `${h}.${dnsDomain}`)),
            ...hostsLan.map(h => new DnsRecord(lanIp, `${h}.${dnsDomain}`))
        ];

        return dnsTable;
    }

    public static async setupPiholeDockerImage(): Promise<JobResult> {
        try {
            await buildDockerImage(PiholeConfigHelper.name);
            PiholeConfigHelper.log.info("SETUP - Pihole docker image setup completed");
            const result = { name: this.name + '-docker-image', service: 'pihole', success: true };
            return result;
        } catch (error) {
            PiholeConfigHelper.log.error("SETUP - Error setting up Pihole docker image: " + error);
            const result = { name: this.name + '-docker-image', service: 'pihole', success: false, message: error.toString() };
            return result;
        }
    }
}