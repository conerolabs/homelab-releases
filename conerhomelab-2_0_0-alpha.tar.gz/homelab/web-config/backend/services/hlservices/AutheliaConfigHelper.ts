import { ConfigService } from "../config.service.ts";
import type { ServiceConfigHelper } from "./services.service.ts";
import { parseAutheliaConfig } from '../../config-utils.ts';
import type { AutheliaHashOptions, AutheliaConfig } from '../../config-utils.ts';
import { mapFields, type TransformationMap } from '../../../commons/utils.ts';
import { decryptSystemdCredential, generateArgon2idHash, generateRsaKeyPair, PROFILES } from "../../../commons/hlCrypto.ts";
import type { HashOptions } from "argon2";
import { readFileSync, writeFileSync } from "fs";
import { randomBytes } from "crypto";
import os from "node:os";
import type { SetupResult } from "../../../commons/dto.ts";
import { existsSync } from "node:fs";

type ClientSecret = {
    clientId: string;
    path: string;
    type: 'txt' | 'cred';
    hashEnvVar: string;
}

type FileSecret = {
    name: string;
    path: string;
    type: 'txt' | 'rsa';
}


export class AutheliaConfigHelper implements ServiceConfigHelper {
    public readonly name: string = 'authelia';
    private static HOMELAB_DIR: string = '';
    private static AUTHELIA_SECRETS_DIR: string = '';

    public static CLIENT_SECRETS: ClientSecret[] = [
        {
            clientId: 'vaultwarden',
            path: `${AutheliaConfigHelper.HOMELAB_DIR}/vaultwarden/secrets/oidc_client_secret.txt`,
            type: 'txt',
            hashEnvVar: 'AUTHELIA_VAULTWARDEN_SECRET_HASH',
        },
        {
            clientId: 'gatus',
            path: `${AutheliaConfigHelper.HOMELAB_DIR}/gatus/secrets/oidc_client_secret.txt`,
            type: 'txt',
            hashEnvVar: 'AUTHELIA_GATUS_SECRET_HASH',
        },
        {
            clientId: 'rustical',
            path: `${AutheliaConfigHelper.HOMELAB_DIR}/rustical/secrets/oidc_client_secret.txt`,
            type: 'txt',
            hashEnvVar: 'AUTHELIA_RUSTICAL_SECRET_HASH',
        },
        {
            clientId: 'web-config',
            path: `${AutheliaConfigHelper.HOMELAB_DIR}/web-config/secrets/oidc_client_secret.txt`,
            type: 'txt',
            hashEnvVar: 'AUTHELIA_WEBCONFIG_SECRET_HASH',
        },
        {
            clientId: 'headscale',
            path: `${AutheliaConfigHelper.HOMELAB_DIR}/headscale/secrets/oidc_client_secret.cred`,
            type: 'cred',
            hashEnvVar: 'AUTHELIA_HEADSCALE_SECRET_HASH',
        },
    ];

    public static AUTHELIA_SECRETS: FileSecret[] = [
        {
            name: 'JWT_SECRET',
            path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/JWT_SECRET`,
            type: 'txt',
        },
        {
            name: 'SESSION_SECRET',
            path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/SESSION_SECRET`,
            type: 'txt',
        },
        {
            name: 'STORAGE_ENCRYPTION_KEY',
            path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/storage_encryption_key.txt`,
            type: 'txt',
        },
        {
            name: 'OIDC_HMAC_SECRET',
            path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/OIDC_HMAC_SECRET`,
            type: 'txt',
        },
        {
            name: 'OIDC_JWKS_KEY',
            path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/oidc_jwks_key.pem`,
            type: 'rsa',
        },
    ];

    public static init(): void {
        console.log('STARTUP - Initializing Authelia Config Helper...');
        AutheliaConfigHelper.HOMELAB_DIR = ConfigService.getEnv('INSTALL_DIR').replace(/^~/, os.homedir());
        AutheliaConfigHelper.AUTHELIA_SECRETS_DIR = `${AutheliaConfigHelper.HOMELAB_DIR}/authelia/secrets`;
        console.log('STARTUP - Authelia Config Helper initialized');
    }


    public async setup(): Promise<SetupResult> {
        return Promise.all([
            AutheliaConfigHelper.hashAllClientSecrets(),
            AutheliaConfigHelper.generateAutheliaSecrets(),
        ]).then(
            (_) => {
                console.log("SETUP - Authelia setup completed");
                return Promise.resolve({ success: true });
            },
            (reason) => {
                console.error("SETUP - Error setting up Authelia: ", reason);
                return Promise.resolve({ success: false, error: reason.toString() });
            }
        )
    }

    private static async hashAllClientSecrets(): Promise<void> {
        for (const clientSecret of AutheliaConfigHelper.CLIENT_SECRETS) {
            const hashedSecret = ConfigService.getEnv(clientSecret.hashEnvVar);
            if (!hashedSecret) {
                let secret = '';
                try {
                    switch (clientSecret.type) {
                        case 'txt':
                            secret = readFileSync(clientSecret.path).toString().trim();
                            break;
                        case 'cred':
                            secret = decryptSystemdCredential(clientSecret.path, 'oidc_client_secret');
                            break;
                    }
                } catch (error) {
                    console.error(`SETUP - Error reading client secret for ${clientSecret.clientId}: `, error);
                    continue;
                }
                const hash = await AutheliaConfigHelper.generateAutheliaHash(secret);
                ConfigService.setEnv(clientSecret.hashEnvVar, hash);
            }
            else {
                console.log(`SETUP - Client secret for ${clientSecret.clientId} already exists`);
            }
        }
        ConfigService.saveConfig();
    }

    private static generateAutheliaSecrets(size: number = 64) {
        AutheliaConfigHelper.AUTHELIA_SECRETS.map(s => {
            if (existsSync(s.path)) {
                console.log(`SETUP - Authelia secret ${s.name} already exists`);
                return;
            }
            if (s.type === 'txt') {
                const secret = randomBytes(size).toString('base64').slice(0, size);
                writeFileSync(s.path, secret);
            }
            else if (s.type === 'rsa') {
                const { privateKey } = generateRsaKeyPair();
                writeFileSync(s.path, privateKey);
            }
        })
    }

    private static hashOptionsTransformer: TransformationMap<AutheliaHashOptions, HashOptions> = new Map([
        ['variant', {
            field: 'type',
            transformer: (value: string | number) => ['argon2d', 'argon2i', 'argon2id'].indexOf(String(value).toLowerCase()) as HashOptions['type']
        }],
        ['iterations', { field: 'timeCost' }],
        ['memory', { field: 'memoryCost' }],
        ['parallelism', { field: 'parallelism' }],
        ['key_length', { field: 'hashLength' }],
    ]);

    private static loadAutheliaHashOptions(config?: AutheliaConfig): HashOptions {
        let hashOptions: HashOptions;
        console.log("CONFIG - Loading Authelia hash options");
        try {
            const data = config ?? parseAutheliaConfig();
            const options: AutheliaHashOptions = data.authentication_backend.file.password.argon2;
            hashOptions = mapFields(options, AutheliaConfigHelper.hashOptionsTransformer);
        } catch (error) {
            console.error("  --> WARNING - Error loading Authelia hash options: ", error);
            console.log("  --> Using default Authelia profile");
            hashOptions = PROFILES['authelia'];
        }
        console.log("  --> Authelia hash options: ", JSON.stringify(hashOptions, null, 2));
        return hashOptions;
    }

    public static async generateAutheliaHash(secret: string, config?: AutheliaConfig): Promise<string> {
        const hashOptions = AutheliaConfigHelper.loadAutheliaHashOptions(config);
        const hashedPassword = await generateArgon2idHash(secret, hashOptions);
        return hashedPassword;
    }
}