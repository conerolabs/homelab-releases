import { ConfigService } from "../config.service.ts";
import type { ServiceConfigHelper } from "./services.service.ts";
import { parseAutheliaConfig } from '../../config-utils.ts';
import type { AutheliaHashOptions, AutheliaConfig } from '../../config-utils.ts';
import { mapFields, type TransformationMap } from '../../../commons/utils.ts';
import { decryptSystemdCredential, generateArgon2idHash, generateRsaKeyPair, PROFILES } from "../../../commons/hlCrypto.ts";
import type { HashOptions } from "argon2";
import { readFileSync, writeFileSync } from "fs";
import { randomBytes } from "crypto";
import os from "node:os";
import type { SetupResult } from "../../../commons/dto.ts";
import { existsSync } from "node:fs";
import { getLogger } from "../../logger.ts";

type ClientSecret = {
    clientId: string;
    path: string;
    type: 'txt' | 'cred';
    hashEnvVar: string;
}

type FileSecret = {
    name: string;
    path: string;
    type: 'txt' | 'rsa';
}


export class AutheliaConfigHelper implements ServiceConfigHelper {
    public readonly name: string = 'authelia';
    private static log = getLogger('AutheliaConfigHelper');
    private static HOMELAB_DIR: string = '';
    private static AUTHELIA_SECRETS_DIR: string = '';

    public static CLIENT_SECRETS: ClientSecret[] = [];

    public static AUTHELIA_SECRETS: FileSecret[] = [];

    public static init(): void {
        AutheliaConfigHelper.log.info('STARTUP - Initializing Authelia Config Helper...');
        AutheliaConfigHelper.HOMELAB_DIR = ConfigService.getEnv('INSTALL_DIR').replace(/^~/, os.homedir());
        AutheliaConfigHelper.log.info(`  --> setting HOMELAB_DIR = ${AutheliaConfigHelper.HOMELAB_DIR}`)
        AutheliaConfigHelper.AUTHELIA_SECRETS_DIR = `${AutheliaConfigHelper.HOMELAB_DIR}/authelia/secrets`;
        AutheliaConfigHelper.log.info(`  --> setting AUTHELIA_SECRETS_DIR = ${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}`)

        AutheliaConfigHelper.AUTHELIA_SECRETS = [
            {
                name: 'JWT_SECRET',
                path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/JWT_SECRET`,
                type: 'txt',
            },
            {
                name: 'SESSION_SECRET',
                path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/SESSION_SECRET`,
                type: 'txt',
            },
            {
                name: 'STORAGE_ENCRYPTION_KEY',
                path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/storage_encryption_key.txt`,
                type: 'txt',
            },
            {
                name: 'OIDC_HMAC_SECRET',
                path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/OIDC_HMAC_SECRET`,
                type: 'txt',
            },
            {
                name: 'OIDC_JWKS_KEY',
                path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/oidc_jwks_key.pem`,
                type: 'rsa',
            },
        ];

        AutheliaConfigHelper.CLIENT_SECRETS = [
            {
                clientId: 'vaultwarden',
                path: `${AutheliaConfigHelper.HOMELAB_DIR}/vaultwarden/secrets/oidc_client_secret.txt`,
                type: 'txt',
                hashEnvVar: 'AUTHELIA_VAULTWARDEN_SECRET_HASH',
            },
            {
                clientId: 'gatus',
                path: `${AutheliaConfigHelper.HOMELAB_DIR}/gatus/secrets/oidc_client_secret.txt`,
                type: 'txt',
                hashEnvVar: 'AUTHELIA_GATUS_SECRET_HASH',
            },
            {
                clientId: 'rustical',
                path: `${AutheliaConfigHelper.HOMELAB_DIR}/rustical/secrets/oidc_client_secret.txt`,
                type: 'txt',
                hashEnvVar: 'AUTHELIA_RUSTICAL_SECRET_HASH',
            },
            {
                clientId: 'web-config',
                path: `${AutheliaConfigHelper.HOMELAB_DIR}/web-config/secrets/oidc_client_secret.txt`,
                type: 'txt',
                hashEnvVar: 'AUTHELIA_WEBCONFIG_SECRET_HASH',
            },
            {
                clientId: 'headscale',
                path: `${AutheliaConfigHelper.HOMELAB_DIR}/headscale/secrets/oidc_client_secret.cred`,
                type: 'cred',
                hashEnvVar: 'AUTHELIA_HEADSCALE_SECRET_HASH',
            },
        ];
        AutheliaConfigHelper.log.info('STARTUP - Authelia Config Helper initialized');
    }

    /**
     * Sets up Authelia by hashing all client secrets and generating all authelia secrets.
     * It hashes client secrets from environment variables and generates missing secrets in the secrets directory.
     * Creation of admin user is not part of this setup as it is done through the web interface.
     * Note: Even if setup result is ok, Authelia could be misconfigured. Run AutheliaSetupChecker for a better overview.
     * @returns the setup result
     */
    public async setup(): Promise<SetupResult> {
        return Promise.all([
            AutheliaConfigHelper.hashAllClientSecrets(),
            AutheliaConfigHelper.generateAutheliaSecrets(),
        ]).then(
            (_) => {
                AutheliaConfigHelper.log.info("SETUP - Authelia setup completed");
                return Promise.resolve({ name: AutheliaConfigHelper.name, success: true });
            },
            (reason) => {
                AutheliaConfigHelper.log.error("SETUP - Error setting up Authelia: " + reason);
                return Promise.resolve({ name: AutheliaConfigHelper.name, success: false, message: reason.toString() });
            }
        )
    }

    private static async hashAllClientSecrets(): Promise<void> {
        const log = AutheliaConfigHelper.log.child({ task_id: 'hashAllClientSecrets' })
        log.info(`SETUP - Hashing Authelia clients secrets...`)
        for (const clientSecret of AutheliaConfigHelper.CLIENT_SECRETS) {
            log.info(`  --> hashing ${clientSecret.clientId}'s secret...`)
            const hashedSecret = ConfigService.getEnv(clientSecret.hashEnvVar);
            if (!hashedSecret) {
                let secret = '';
                try {
                    switch (clientSecret.type) {
                        case 'txt':
                            secret = readFileSync(clientSecret.path).toString().trim();
                            break;
                        case 'cred':
                            secret = decryptSystemdCredential(clientSecret.path, 'oidc_client_secret');
                            break;
                    }
                } catch (error) {
                    log.error(`  --> Error reading client secret for ${clientSecret.clientId}: ` + error);
                    continue;
                }
                const hash = await AutheliaConfigHelper.generateAutheliaHash(secret);
                ConfigService.setEnv(clientSecret.hashEnvVar, hash);
                log.info(`  --> ${clientSecret.clientId}'s secret hash generated successfully`)
            }
            else {
                log.info(`  --> Client secret for ${clientSecret.clientId} already exists`);
            }
        }
        ConfigService.saveConfig();
    }

    private static generateAutheliaSecrets(size: number = 64) {
        try {
            AutheliaConfigHelper.AUTHELIA_SECRETS.map(s => {
                if (existsSync(s.path)) {
                    console.log(`SETUP - Authelia secret ${s.name} already exists`);
                    return;
                }
                if (s.type === 'txt') {
                    const secret = randomBytes(size).toString('base64').slice(0, size);
                    writeFileSync(s.path, secret);
                }
                else if (s.type === 'rsa') {
                    const { privateKey } = generateRsaKeyPair();
                    writeFileSync(s.path, privateKey);
                }
            })
        }
        catch (error) {
            throw new Error("Error generating Authelia secret", { cause: error })
        }
    }

    private static hashOptionsTransformer: TransformationMap<AutheliaHashOptions, HashOptions> = new Map([
        ['variant', {
            field: 'type',
            transformer: (value: string | number) => ['argon2d', 'argon2i', 'argon2id'].indexOf(String(value).toLowerCase()) as HashOptions['type']
        }],
        ['iterations', { field: 'timeCost' }],
        ['memory', { field: 'memoryCost' }],
        ['parallelism', { field: 'parallelism' }],
        ['key_length', { field: 'hashLength' }],
    ]);

    private static loadAutheliaHashOptions(config?: AutheliaConfig): HashOptions {
        let hashOptions: HashOptions;
        AutheliaConfigHelper.log.debug("CONFIG - Loading Authelia hash options");
        try {
            const data = config ?? parseAutheliaConfig();
            const options: AutheliaHashOptions = data.authentication_backend.file.password.argon2;
            hashOptions = mapFields(options, AutheliaConfigHelper.hashOptionsTransformer);
        } catch (error) {
            AutheliaConfigHelper.log.debug("  --> WARNING - Error loading Authelia hash options: " + error);
            AutheliaConfigHelper.log.debug("  --> Using default Authelia profile");
            hashOptions = PROFILES['authelia'];
        }
        AutheliaConfigHelper.log.debug("  --> Authelia hash options: " + JSON.stringify(hashOptions, null, 2));
        return hashOptions;
    }

    public static async generateAutheliaHash(secret: string, config?: AutheliaConfig): Promise<string> {
        const hashOptions = AutheliaConfigHelper.loadAutheliaHashOptions(config);
        const hashedPassword = await generateArgon2idHash(secret, hashOptions);
        return hashedPassword;
    }
}