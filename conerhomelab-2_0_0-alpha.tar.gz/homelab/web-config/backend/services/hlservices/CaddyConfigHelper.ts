import type { JobResult } from "../../../commons/dto.ts";
import { BaseConfigHelper } from "./BaseConfigHelper.ts";
import type { HLTask } from "../TasksManager.ts";
import { ConfigService } from "../config.service.ts";
import { copyFileSync, existsSync, rmSync, type PathLike } from "node:fs";
import { dnsProviders } from "../../../commons/dnsProviders.ts";
import type { ServiceModel } from "../../../commons/models.ts";
import { copySync } from "fs-extra/esm";

export class CaddyConfigHelper extends BaseConfigHelper {

    public static readonly DEFAULT_ENABLED_SERVICES: ServiceModel[] = [];

    private static setupTasks: HLTask[] = [
        {
            name: 'configure-caddyfile-global',
            description: 'Configure global section in caddyfile',
            action: () => CaddyConfigHelper.configureGlobalSection(),
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'configure-caddyfile-tls',
            description: 'Configure tls section in caddyfile',
            action: () => CaddyConfigHelper.configureTlsSection(),
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'configure-caddyfile-sites',
            description: 'Configure sites in caddyfile',
            action: () => CaddyConfigHelper.configureSitesSection(),
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        BaseConfigHelper.getBuildDockerImageTask('caddy', 30),
    ];

    private static GLOBAL_CONFIG_AVAILABLE_PATH: string;
    public static GLOBAL_CONFIG_ENABLED_PATH: string;
    private static GLOBAL_CONFIG_LOCAL: string;
    private static GLOBAL_CONFIG_PUBLIC_DDNS: string;
    private static GLOBAL_CONFIG_PUBLIC_NO_DDNS: string;
    // TLS paths
    private static TLS_AVAILABLE_PATH: string;
    public static TLS_ENABLED_PATH: string;
    private static TLS_INTERNAL: string;
    private static TLS_DNS01_APITOKEN: string;
    // Sites paths
    private static SITES_AVAILABLE_PATH: string;
    public static SITES_ENABLED_PATH: string;

    constructor() {
        super('caddy', 3);
    }

    public static init() {
        CaddyConfigHelper.log.info('STARTUP - Initializing Caddy Config Helper...');
        const INSTALL_DIR = ConfigService.getInstallDir();
        CaddyConfigHelper.GLOBAL_CONFIG_AVAILABLE_PATH = `${INSTALL_DIR}/caddy/etc/caddy/global-available`;
        CaddyConfigHelper.GLOBAL_CONFIG_ENABLED_PATH = `${INSTALL_DIR}/caddy/etc/caddy/global-enabled`;
        CaddyConfigHelper.GLOBAL_CONFIG_LOCAL = `${CaddyConfigHelper.GLOBAL_CONFIG_AVAILABLE_PATH}/local.caddy`;
        CaddyConfigHelper.GLOBAL_CONFIG_PUBLIC_DDNS = `${CaddyConfigHelper.GLOBAL_CONFIG_AVAILABLE_PATH}/public-ddns.caddy`;
        CaddyConfigHelper.GLOBAL_CONFIG_PUBLIC_NO_DDNS = `${CaddyConfigHelper.GLOBAL_CONFIG_AVAILABLE_PATH}/public-no-ddns.caddy`;
        // TLS paths
        CaddyConfigHelper.TLS_AVAILABLE_PATH = `${INSTALL_DIR}/caddy/etc/caddy/tls-available`;
        CaddyConfigHelper.TLS_ENABLED_PATH = `${INSTALL_DIR}/caddy/etc/caddy/tls-enabled`;
        CaddyConfigHelper.TLS_INTERNAL = `${CaddyConfigHelper.TLS_AVAILABLE_PATH}/tls-internal.caddy`;
        CaddyConfigHelper.TLS_DNS01_APITOKEN = `${CaddyConfigHelper.TLS_AVAILABLE_PATH}/tls-dns01-apitoken.caddy`;
        // Sites paths
        CaddyConfigHelper.SITES_AVAILABLE_PATH = `${INSTALL_DIR}/caddy/etc/caddy/sites-available`;
        CaddyConfigHelper.SITES_ENABLED_PATH = `${INSTALL_DIR}/caddy/etc/caddy/sites-enabled`;

        const defaultEnabledServices = ['pihole', 'authelia', 'homepage', 'webconfig']
        const services = ConfigService.getEnabledServices().filter(s => defaultEnabledServices.includes(s.name));
        CaddyConfigHelper.DEFAULT_ENABLED_SERVICES.push(...services)

        CaddyConfigHelper.log.info('STARTUP - Caddy Config Helper initialized');
    }

    public override getTasks(): HLTask[] {
        return CaddyConfigHelper.setupTasks;
    }

    public override async setup(onTaskCompleted: (result: JobResult, percentage: number) => void): Promise<JobResult> {
        return await super.setup(onTaskCompleted);
    }

    private static isLocalDomain() {
        return ConfigService.getEnv('DOMAIN') === ConfigService.getEnv('LOCAL_DOMAIN');
    }

    private static resolveServiceSiteDomain(service: ServiceModel) {
        if (service.subdomain) {
            return `${service.subdomain}.${ConfigService.getEnv('DOMAIN')}`;
        } else {
            CaddyConfigHelper.log.warn(`Service ${service.name} has no subdomain defined`);
            return null;
        }
    }

    public static resolveGlobalSectionFile(): string {
        if (CaddyConfigHelper.isLocalDomain()) {
            return CaddyConfigHelper.GLOBAL_CONFIG_LOCAL;
        } else {
            const dnsProvider = dnsProviders.find(p => p.name === ConfigService.getEnv('DNS_PROVIDER'));
            const ddnsEnabled = ConfigService.getEnv('DDNS_ENABLED') === 'true';
            if (ddnsEnabled) {
                return CaddyConfigHelper.GLOBAL_CONFIG_PUBLIC_DDNS;
            } else {
                return CaddyConfigHelper.GLOBAL_CONFIG_PUBLIC_NO_DDNS;
            }
        }
    }

    private static configureGlobalSection() {
        const task = CaddyConfigHelper.setupTasks[0];
        const log = CaddyConfigHelper.log.child({ task: 'configureGlobalSection' });
        log.info(`${task.name}...`);
        try {
            const toEnable = CaddyConfigHelper.resolveGlobalSectionFile();
            CaddyConfigHelper.configureSectionInCaddyfile(CaddyConfigHelper.GLOBAL_CONFIG_ENABLED_PATH, toEnable);
            log.info(`[OK] ${task.name} successfully`);
            return { name: task.name, success: true, message: 'Caddyfile global section configured successfully' };
        } catch (error) {
            log.error(`[ERROR] Error executing ${task.name}: ${error}`);
            return { name: task.name, success: false, message: error.toString() };
        }
    }

    public static resolveTlsSectionFile(): string | null {
        const dnsProvider = dnsProviders.find(p => p.name === ConfigService.getEnv('DNS_PROVIDER'));
        let toEnable: PathLike | null = null;
        if (CaddyConfigHelper.isLocalDomain()) {
            toEnable = CaddyConfigHelper.TLS_INTERNAL;
        } else {
            // if only api_token needed
            if (dnsProvider?.params.length === 1 && dnsProvider?.params[0] === 'api_token') {
                toEnable = CaddyConfigHelper.TLS_DNS01_APITOKEN;
            } else {
                // for the moment fallback to internal tls
                toEnable = CaddyConfigHelper.TLS_INTERNAL;
            }
        }
        return toEnable;
    }

    private static configureTlsSection() {
        const task = CaddyConfigHelper.setupTasks[1];
        CaddyConfigHelper.log.info(`${task.name}...`);
        try {
            const toEnable = CaddyConfigHelper.resolveTlsSectionFile();
            CaddyConfigHelper.configureSectionInCaddyfile(CaddyConfigHelper.TLS_ENABLED_PATH, toEnable);
            return { name: task.name, success: true, message: 'Caddyfile TLS section configured successfully' };
        } catch (error) {
            CaddyConfigHelper.log.error(`Error executing ${task.name}: ${error}`);
            return { name: task.name, success: false, message: error.toString() };
        }
    }

    public static resolveSitesSectionFiles(): string[] {
        const caddyServices = ConfigService.getEnabledServices().filter(s => !!s.subdomain);
        const defaultEnabledServicesNames = CaddyConfigHelper.DEFAULT_ENABLED_SERVICES.map(s => s.name);

        const toEnable = caddyServices
            .filter(service => !defaultEnabledServicesNames.includes(service.name))
            .map(service => `${CaddyConfigHelper.SITES_AVAILABLE_PATH}/${service.subdomain}.caddy`);
        return toEnable;
    }

    private static configureSitesSection() {
        const task = CaddyConfigHelper.setupTasks[2];
        CaddyConfigHelper.log.info(`${task.name}...`);
        try {
            const toEnable = CaddyConfigHelper.resolveSitesSectionFiles();
            CaddyConfigHelper.configureSectionInCaddyfile(CaddyConfigHelper.SITES_ENABLED_PATH, ...toEnable);
            return { name: task.name, success: true, message: 'Sites configured successfully' };
        } catch (error) {
            CaddyConfigHelper.log.error(`Error configuring ${task.name}: ${error.message}`);
            return { name: task.name, success: false, message: error.toString() };
        }
    }

    private static configureSectionInCaddyfile(enabledDirPath: string, ...sectionFilesPath: string[]) {
        const backupPath = `${enabledDirPath}.bak`
        try {
            // create a backup copy of the caddy file config before cleaning it and restore it in case of failure
            copySync(enabledDirPath, backupPath, { overwrite: true, errorOnExist: false });
            CaddyConfigHelper.log.info(`Cleaning caddyfile ${enabledDirPath} config...`);
            rmSync(enabledDirPath + '/*', { recursive: true, force: true });
            sectionFilesPath.forEach(filePath => {
                const filename = filePath.split('/').pop();
                CaddyConfigHelper.log.info(`Enabling caddyfile section: ${filename}`)
                copyFileSync(filePath, enabledDirPath + `/${filename}`);
            });
        } catch (error) {
            CaddyConfigHelper.log.error(error.message);
            // restore backup copy of the caddy file config if it exists
            CaddyConfigHelper.log.warn(`Restoring previous version of the caddyfile section ${enabledDirPath}...`);
            if (existsSync(backupPath)) {
                copySync(backupPath, enabledDirPath, { overwrite: true, errorOnExist: false });
            }
            throw error;
        } finally {
            // remove backup copy of the caddy file config if it exists
            if (existsSync(backupPath)) {
                rmSync(backupPath, { recursive: true, force: true });
            }
        }
    }
}