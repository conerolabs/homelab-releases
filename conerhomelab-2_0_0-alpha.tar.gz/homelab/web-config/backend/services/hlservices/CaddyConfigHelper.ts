import type { SetupResult } from "../../../commons/dto.ts";
import { getLogger } from "../../logger.ts";
import type { ServiceConfigHelper } from "./services.service.ts";

export class CaddyConfigHelper implements ServiceConfigHelper {
    public readonly name: string = 'caddy';
    private static log = getLogger('CaddyConfigHelper');

    setup(): Promise<SetupResult> {
        CaddyConfigHelper.log.info('SETUP - Starting caddy setup...')
        return Promise.resolve({ name: CaddyConfigHelper.name, success: true, message: 'Nothing to do...' });
    }
}