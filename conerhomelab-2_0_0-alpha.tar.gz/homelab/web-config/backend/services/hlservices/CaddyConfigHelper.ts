import type { JobResult } from "../../../commons/dto.ts";
import { BaseConfigHelper } from "./BaseConfigHelper.ts";
import type { HLTask } from "../TasksManager.ts";

export class CaddyConfigHelper extends BaseConfigHelper {

    private static setupTasks: HLTask[] = [
        BaseConfigHelper.getBuildDockerImageTask('caddy'),
    ];

    constructor() {
        super('caddy');
    }

    public override getTasks(): HLTask[] {
        return CaddyConfigHelper.setupTasks;
    }

    public override async setup(onTaskCompleted: (result: JobResult, percentage: number) => void): Promise<JobResult> {
        return await super.setup(onTaskCompleted);
    }
}