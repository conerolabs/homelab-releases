import type { Logger } from 'pino';
import { getLogger } from '../../logger.ts';
import { ConfigService } from '../config.service.ts';
import { ShellService } from '../shell.service.ts';
import { SystemService } from '../system.service.ts';
import { NetworkService } from '../network.service.ts';
import { BaseConfigHelper } from './BaseConfigHelper.ts';
import type { JobResult, VpnConfigParams, VpnMode } from '../../../commons/dto.ts';
import type { HLTask } from '../TasksManager.ts';
import type { ChildProcess } from 'node:child_process';

/**
 * BackendState can be one of these seven values:
 * - NoState — no state reported yet; may be transient during startup.
 * - InUseOtherUser — another local user/profile is using Tailscale.
 * - NeedsLogin — this device needs to be authenticated.
 * - NeedsMachineAuth — the device needs machine approval.
 * - Stopped — Tailscale is stopped.
 * - Starting — Tailscale is starting.
 * - Running — Tailscale is running.
 */
export type BackendState = 'NoState' | 'InUseOtherUser' | 'NeedsLogin' | 'NeedsMachineAuth' | 'Stopped' | 'Starting' | 'Running';

type DnsPreferences = {
    magicDNS: boolean;
    overrideLocalDNS?: boolean;
};

type DnsNameServers = {
    dns: string[];
};

export class TailscaleApiClient {
    private static log: Logger = getLogger('TailscaleApiClient', { msgPrefix: `TAILSCALE API - ` });
    private static baseUrl = `https://api.tailscale.com/api/v2/tailnet/-/dns`;


    private static getApiKey() {
        const apiKey = ConfigService.getTailscaleApiKey();
        if (!apiKey) {
            TailscaleApiClient.log.warn('No API key found, TailscaleApiClient will not be able to query the Tailscale API. Please set the API key in the config.');
            return null;
        }
        return apiKey;
    }

    private static async getErrorMessage(response: Response): Promise<string | null> {
        if (response.ok) {
            return null;
        }
        return (await response.json() as { message?: string }).message || `HTTP ${response.status} ${response.statusText}`;
    }

    private static async api<T>(path: string, init: RequestInit = {}): Promise<T> {
        TailscaleApiClient.log.info(`Calling Tailscale API: ${path}`);
        const response = await fetch(`${TailscaleApiClient.baseUrl}/${path}`, {
            ...init,
            headers: {
                Authorization: `Bearer ${TailscaleApiClient.getApiKey()}`,
                "Content-Type": "application/json",
                ...init.headers,
            },
        });
        if (!response.ok) {
            throw new Error(
                `Tailscale API error ${response.status}: ${await TailscaleApiClient.getErrorMessage(response)}`
            );
        }
        return response.json() as Promise<T>;
    }

    public static async getDnsPreferences(): Promise<DnsPreferences> {
        return await TailscaleApiClient.api<DnsPreferences>('preferences');
    }

    public static async setDnsPreferences(dnsPreferences: Partial<DnsPreferences>): Promise<void> {
        await TailscaleApiClient.api('preferences', {
            method: 'POST',
            body: JSON.stringify(dnsPreferences),
        });
    }

    public static async listDnsNameServers(): Promise<DnsNameServers> {
        return await TailscaleApiClient.api<DnsNameServers>('nameservers');
    }
    public static async setDnsNameServers(dnsNameServers: DnsNameServers): Promise<void> {
        await TailscaleApiClient.api('nameservers', {
            method: 'POST',
            body: JSON.stringify(dnsNameServers),
        });
    }
    public static async addDnsNameServers(servers: string[]) {
        const current = await TailscaleApiClient.listDnsNameServers();
        const newServers = Array.from(new Set([...current.dns, ...servers]));
        await TailscaleApiClient.setDnsNameServers({ dns: newServers });
    }
    public static async removeDnsNameServers(servers: string[]) {
        const current = await TailscaleApiClient.listDnsNameServers();
        const newServers = current.dns.filter(server => !servers.includes(server));
        await TailscaleApiClient.setDnsNameServers({ dns: newServers });
    }
}

export class VpnConfigHelper extends BaseConfigHelper<VpnConfigParams> {
    static log: Logger = getLogger('VpnConfigHelper', { msgPrefix: 'VPN SETUP - ' });
    private static tasks: HLTask<VpnConfigParams>[] = [
        {
            name: 'tailnet-operator-user',
            description: 'Ensure Tailnet operator user is set',
            action: VpnConfigHelper.setOperator,
            skip: VpnConfigHelper.skip,
            weight: 1,
        },
        {
            name: 'tailnet-node-ip',
            description: 'Ensure Tailnet node ip is set',
            action: VpnConfigHelper.setIp,
            skip: VpnConfigHelper.skip,
            weight: 1,
        },
        {
            name: 'tailnet-api-key',
            description: 'Ensure Tailscale API key is set',
            action: VpnConfigHelper.setApiKey,
            skip: VpnConfigHelper.skip,
            weight: 1,
        },
        {
            name: 'tailnet-dns-preferences',
            description: 'Ensure Tailscale DNS preferences are set',
            action: VpnConfigHelper.setDnsPreferences,
            skip: VpnConfigHelper.skip,
            weight: 1,
        },
        {
            name: 'tailnet-dns-nameservers',
            description: 'Ensure Tailscale DNS name servers are set',
            action: VpnConfigHelper.setDnsNameServers,
            skip: VpnConfigHelper.skip,
            weight: 1,
        },
    ];

    constructor() {
        super('tailscale', 1)
    }

    private static async skip(c: VpnConfigParams) {
        if (!c.mode) return { skip: true, reason: 'No mode set' }
        if (c.mode === 'none') return { skip: true, reason: 'Local network only mode' }
        return { skip: false }
    }

    public getTasks(): HLTask<VpnConfigParams>[] {
        return VpnConfigHelper.tasks;
    }

    public static async getOperator(): Promise<string | null> {
        const result = await ShellService.execCommand('tailscale debug prefs | jq -r ".OperatorUser"', undefined, true).result;
        const operator = result.stdout.trim();
        return operator === 'null' ? null : operator;
    }

    public static async setOperator(config: VpnConfigParams): Promise<JobResult> {
        const name = VpnConfigHelper.tasks[0].name;
        const operator = await VpnConfigHelper.getOperator();
        let message = '';
        if (operator === process.env.USER) {
            message = `Operator already set to: ${operator}`
            VpnConfigHelper.log.info(message);
            return { name, message, success: true, service: config.mode };
        }
        const sudoPassword = SystemService.getSudoPassword();
        const { exitCode, stderr } = await ShellService.execCommand(`tailscale set --operator ${process.env.USER}`, sudoPassword).result;
        if (stderr) {
            message = `Failed to set operator: ${stderr}`
            VpnConfigHelper.log.error(message);
            return { name, message, success: false, service: config.mode };
        }
        message = `Operator set to: ${process.env.USER}`
        VpnConfigHelper.log.info(message);
        return { name, message, success: exitCode === 0, service: config.mode };
    }

    public static async setIp(config: VpnConfigParams): Promise<JobResult> {
        const name = VpnConfigHelper.tasks[1].name;
        let message = 'Tailscale IP is not initialized yet in .env';
        const ip = NetworkService.getTailscaleIp();
        if (!ip) {
            VpnConfigHelper.log.warn(message);
            return { name, message, success: false, service: config.mode };
        }
        if (ConfigService.getTailscaleIp() === ip) {
            message = `IP already in config: ${ip}`
            VpnConfigHelper.log.info(message);
            return { name, message, success: true, service: config.mode };
        }
        ConfigService.setTailscaleIp(ip);
        message = `IP set to config: ${ip}`
        VpnConfigHelper.log.info(message);
        return { name, message, success: true, service: config.mode };
    }

    public static async setApiKey(config: VpnConfigParams): Promise<JobResult> {
        const name = VpnConfigHelper.tasks[2].name;
        let message = 'Tailscale API key is not available, it needs to be provided by the user.';
        if (!config.apiKey) {
            VpnConfigHelper.log.warn(message);
            return { name, message, success: false, service: config.mode };
        }
        if (ConfigService.getTailscaleApiKey() === config.apiKey) {
            message = `API key already in config.`
            VpnConfigHelper.log.info(message);
            return { name, message, success: true, service: config.mode };
        }
        ConfigService.setTailscaleApiKey(config.apiKey);
        message = `API key set to config.`
        VpnConfigHelper.log.info(message);
        return { name, message, success: true, service: config.mode };
    }

    // TODO: should i restart tailscale?
    public static async setDnsPreferences(config: VpnConfigParams): Promise<JobResult> {
        const name = VpnConfigHelper.tasks[3].name;
        try {
            let message = '';
            await TailscaleApiClient.setDnsPreferences({
                magicDNS: true,
                overrideLocalDNS: true, // check in api docs if field is available
            });
            message = `DNS preferences set into admin panel via API.`
            VpnConfigHelper.log.info(message);
            return { name, message, success: true, service: config.mode };
        } catch (error) {
            let message = `Failed to set DNS preferences. ${error instanceof Error ? error.message : String(error)}`;
            VpnConfigHelper.log.error(message);
            return { name, message, success: false, service: config.mode };
        }
    }

    // TODO: should i restart tailscale? 
    public static async setDnsNameServers(config: VpnConfigParams): Promise<JobResult> {
        const name = VpnConfigHelper.tasks[4].name;
        try {
            let message = '';
            if (!config.apiKey) {
                message = 'Tailscale API key is required to set DNS name servers.';
                VpnConfigHelper.log.warn(message);
                return { name, message, success: false, service: config.mode };
            }
            if (!ConfigService.getTailscaleIp()) {
                message = `Tailscale IP is required to set DNS name servers.`
                VpnConfigHelper.log.warn(message);
                return { name, message, success: false, service: config.mode };
            }
            await TailscaleApiClient.setDnsNameServers({ dns: [ConfigService.getTailscaleIp()] })
            message = `DNS name servers set into admin panel via API.`
            VpnConfigHelper.log.info(message);
            return { name, message, success: true, service: config.mode };
        } catch (error) {
            let message = `Failed to set DNS name servers. ${error instanceof Error ? error.message : String(error)}`;
            VpnConfigHelper.log.error(message);
            return { name, message, success: false, service: config.mode };
        }
    }

    /**
     * Try to retrieve the Tailscale login url
     * 
     * @returns The login url if found, null if already logged in
     * @throws Error if no login action found
     * @throws Error if login url not found after retries
     */
    public static async getLoginUrl(startProcess?: ChildProcess): Promise<string | null> {

        const mode = ConfigService.getVpnMode();
        if (mode === 'none') {
            return null;
        }

        const { AuthURL, BackendState } = JSON.parse(await VpnConfigHelper.getStatus())
        if (AuthURL) {
            VpnConfigHelper.log.info('Login here: ' + AuthURL);
            return AuthURL;
        }
        if (BackendState !== "NeedsLogin") {
            VpnConfigHelper.log.warn(`Not logged out; state is ${BackendState}. No need to login.`);
            return null;
        }

        // Repeatedly check for the auth url
        for (let i = 0; i < 10; i++) {
            const loginUrl = JSON.parse(await VpnConfigHelper.getStatus('AuthURL')) as string;
            if (loginUrl) {
                VpnConfigHelper.log.info('Login here: ' + loginUrl);
                startProcess.kill();
                return loginUrl;
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
        if (startProcess && startProcess.exitCode === null && startProcess.signalCode === null) {
            startProcess.kill();
        }
        throw new Error(`Auth URL not found in ${mode} status after ${10 * 1000}ms`);
    }

    /**
     * Get status of tailscale
     * 
     * @param field Optional field to get status of
     * @returns Status of tailscale in json format (to be parsed)
     */
    public static async getStatus(field?: 'BackendState' | 'AuthURL'): Promise<string> {
        const cmd = `tailscale status --json | jq .${field ?? ''}`;
        const status = await ShellService.execCommand(cmd).result.then(result => result.stdout || result.stderr);
        VpnConfigHelper.log.debug({ [field ?? 'status']: JSON.parse(status) }, 'Status of tailscale');
        return status;
    }

}