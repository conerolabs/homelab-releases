import type { JobResult } from "../../../commons/dto.ts";
import type { HLTask } from "../TasksManager.ts";
import { BaseConfigHelper } from "./BaseConfigHelper.ts";
import type { SetupParams } from "./services.service.ts";

export class HomepageConfigHelper extends BaseConfigHelper<{}> {

    private static readonly tasks: HLTask<{}>[] = [
        BaseConfigHelper.getBuildDockerImageTask('homepage')
    ];

    constructor() {
        super('homepage', 99);
    }

    public override getTasks(): HLTask<{}>[] {
        return HomepageConfigHelper.tasks;
    }

    public override async setup(setupParams: SetupParams<{}>): Promise<JobResult> {
        return await super.setup(setupParams);
    }
}