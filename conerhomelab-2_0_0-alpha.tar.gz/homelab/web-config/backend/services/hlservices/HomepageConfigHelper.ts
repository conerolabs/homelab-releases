import type { HLTask } from "../TasksManager.ts";
import { BaseConfigHelper } from "./BaseConfigHelper.ts";

export class HomepageConfigHelper extends BaseConfigHelper<{}> {

    private static readonly tasks: HLTask<{}>[] = [
        BaseConfigHelper.getBuildDockerImageTask('homepage')
    ];

    constructor() {
        super('homepage', 99);
    }

    public override getTasks(): HLTask<{}>[] {
        return HomepageConfigHelper.tasks;
    }
}