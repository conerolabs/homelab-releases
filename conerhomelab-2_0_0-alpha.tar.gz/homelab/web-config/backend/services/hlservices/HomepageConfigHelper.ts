import type { JobResult } from "../../../commons/dto.ts";
import type { HLTask } from "../TasksManager.ts";
import { BaseConfigHelper } from "./BaseConfigHelper.ts";

export class HomepageConfigHelper extends BaseConfigHelper {

    private static readonly tasks: HLTask[] = [
        BaseConfigHelper.getBuildDockerImageTask('homepage')
    ];

    constructor() {
        super('homepage');
    }

    public override getTasks(): HLTask[] {
        return HomepageConfigHelper.tasks;
    }

    public override async setup(onTaskCompleted: (task: JobResult, percentage: number) => void): Promise<JobResult> {
        return await super.setup(onTaskCompleted);
    }
}