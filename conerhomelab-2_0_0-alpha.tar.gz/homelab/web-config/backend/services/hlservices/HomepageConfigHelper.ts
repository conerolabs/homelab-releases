import type { SetupResult } from "../../../commons/dto.ts";
import { getLogger } from "../../logger.ts";
import type { ServiceConfigHelper } from "./services.service.ts";

export class HomepageConfigHelper implements ServiceConfigHelper {
    public readonly name: string = 'homepage';
    private static log = getLogger('HomepageConfigHelper');

    setup(): Promise<SetupResult> {
        HomepageConfigHelper.log.info('SETUP - Starting homepage setup...');
        return Promise.resolve({
            name: HomepageConfigHelper.name,
            success: true,
            message: 'Nothing to do...'
        });
    }
}