import { spawnSync } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'node:url';
import { StatusService } from '../status/status.service.ts';
import { AutheliaConfigHelper } from './AutheliaConfigHelper.ts';
import { PiholeConfigHelper } from './PiholeConfigHelper.ts';
import type { SetupResult } from '../../../commons/dto.ts';
import { getServiceActions } from '../../../database/serviceDAO.ts';
import { getLogger } from '../../logger.ts';
import { HomepageConfigHelper } from './HomepageConfigHelper.ts';
import { CaddyConfigHelper } from './CaddyConfigHelper.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SERVICE_ROOT = path.join(__dirname, '../..');

export interface ServiceConfigHelper {
  name: string;
  setup: () => Promise<SetupResult>;
}

const SERVICES_CONFIGURATORS: Map<string, ServiceConfigHelper> = new Map([
  ['authelia', new AutheliaConfigHelper()],
  ['caddy', new CaddyConfigHelper()],
  ['pihole', new PiholeConfigHelper()],
  ['homepage', new HomepageConfigHelper()],
]);

export const SERVICE_ACTIONS = ['deploy', 'start', 'stop', 'setup'] as const;
export type ServiceAction = typeof SERVICE_ACTIONS[number];

export type RuntimeStatus = {
  running: boolean;
  status: string;
  health: 'healthy' | 'unhealthy' | 'starting' | 'none' | 'unknown';
  healthDetail?: string | null;
  containerId?: string | null;
  rawStatus?: string | null;
};

export class ServicesService {

  public static async setupService(serviceName: string): Promise<SetupResult> {
    const configurator = SERVICES_CONFIGURATORS.get(serviceName);
    if (!configurator) {
      return { name: serviceName, success: false, message: `Configurator for service '${serviceName}' not found` };
    }
    const result = await configurator.setup();
    if (result.success) {
      StatusService.setServiceConfigured(serviceName);
    }
    return result;
  }

  public static getDockerServiceCommand(
    serviceName: string,
    action: ServiceAction
  ): string[] {
    if (action === 'start') {
      return ['docker', 'compose', 'up', '-d', '--remove-orphans', serviceName];
    } else if (action === 'stop') {
      // TODO: think about down instead of stop
      return ['docker', 'compose', 'stop', serviceName];
    } else {
      throw new Error(`Invalid service action: ${action}`);
    }
  }

  public static getServiceActionCommand(service: string, action: string): string[] {
    const serviceActions = getServiceActions(service);
    if (!serviceActions) {
      throw new Error(`No action found for '${service}' service`);
    }
    const actionCommand = serviceActions.find((actionCommand: any) => actionCommand.action === action);
    if (!actionCommand) {
      throw new Error(`Action '${action}' not found for '${service}' service`);
    }
    return actionCommand.cmd.split(' ');
  }

  public static getRuntimeStatus(serviceName: string): RuntimeStatus {
    const containerIdResult = spawnSync('docker', ['compose', 'ps', '-q', serviceName], {
      cwd: SERVICE_ROOT,
      encoding: 'utf-8',
    });

    if (containerIdResult.error) {
      throw containerIdResult.error;
    }

    const containerId = containerIdResult.stdout.trim();
    if (!containerId) {
      return {
        running: false,
        status: 'stopped',
        health: 'none',
        healthDetail: 'No container exists for this service.',
        containerId: null,
        rawStatus: null,
      };
    }

    const inspectResult = spawnSync('docker', ['inspect', '--format', '{{json .State}}', containerId], {
      cwd: SERVICE_ROOT,
      encoding: 'utf-8',
    });

    if (inspectResult.error) {
      throw inspectResult.error;
    }

    const stateOutput = inspectResult.stdout.trim();
    if (!stateOutput) {
      return {
        running: true,
        status: 'unknown',
        health: 'unknown',
        healthDetail: 'Unable to parse container state.',
        containerId,
        rawStatus: null,
      };
    }

    let parsedState: any = null;
    try {
      parsedState = JSON.parse(stateOutput);
    } catch {
      parsedState = null;
    }

    const status = parsedState?.Status ?? 'unknown';
    const running = status === 'running';
    let health: RuntimeStatus['health'] = 'unknown';
    let healthDetail: string | null = null;

    if (parsedState?.Health) {
      health = parsedState.Health.Status || 'unknown';
      healthDetail = Array.isArray(parsedState.Health.Log)
        ? parsedState.Health.Log.map((entry: any) => entry.Output).filter(Boolean).join(' | ')
        : null;
    } else {
      health = running ? 'unknown' : 'none';
    }

    console.log(`SERVICE - ${serviceName}: ${JSON.stringify({ status, health })}`);

    return {
      running,
      status,
      health,
      healthDetail,
      containerId,
      rawStatus: stateOutput,
    };
  }

  public static async setup(name: string): Promise<boolean> {
    // TODO: setup service by querying the database and execute setup action
    const result = false;
    if (result) {
      StatusService.setServiceConfigured(name);
    }
    return result;
  }

  public static getDeployCommandArgs(): string[] {
    return ['docker', 'compose', 'up', '-d', '--remove-orphans'];
  }

}
