import { spawnSync } from 'child_process';
import { StatusService } from '../status/status.service.ts';
import { AutheliaConfigHelper } from './AutheliaConfigHelper.ts';
import { PiholeConfigHelper } from './PiholeConfigHelper.ts';
import type { JobResult } from '../../../commons/dto.ts';
import { getLogger } from '../../logger.ts';
import { HomepageConfigHelper } from './HomepageConfigHelper.ts';
import { CaddyConfigHelper } from './CaddyConfigHelper.ts';
import { UnboundConfigHelper } from './UnboundConfigHelper.ts';
import type { ServiceModel } from '../../../commons/models.ts';
import { ConfigService } from '../config.service.ts';
import { VpnConfigHelper } from './VpnConfigHelper.ts';

export interface ServiceConfigHelper<V extends Record<string, any>> {
  service: string;
  setup: (setup: SetupParams<V>) => Promise<JobResult>;
}

const SERVICES_CONFIGURATORS: Map<string, ServiceConfigHelper<any>> = new Map([
  ['authelia', new AutheliaConfigHelper()],
  ['caddy', new CaddyConfigHelper()],
  ['pihole', new PiholeConfigHelper()],
  ['homepage', new HomepageConfigHelper()],
  ['unbound', new UnboundConfigHelper()],
  ['tailscale', new VpnConfigHelper()],
]);

export type RuntimeStatus = {
  running: boolean;
  status: string;
  health: 'healthy' | 'unhealthy' | 'starting' | 'none' | 'unknown';
  healthDetail?: string | null;
  containerId?: string | null;
  rawStatus?: string | null;
};

export type SetupParams<V extends Record<string, any>> = {
  serviceName: string,
  params: V,
  onTaskCompleted: (task: JobResult, percentage: number) => void
};

export class ServicesService {

  private static log = getLogger('ServicesService');

  public static async setupService<V extends Record<string, any>>(setup: SetupParams<V>): Promise<JobResult> {
    const { serviceName, params, onTaskCompleted } = setup;
    const configurator = SERVICES_CONFIGURATORS.get(serviceName);
    if (!configurator) {
      const msg = `No configurator found for service ${serviceName}`;
      ServicesService.log.warn({ task: 'setupService' }, msg);
      return { name: `Setup ${serviceName}`, service: serviceName, success: false, message: msg };
    }
    const result = await configurator.setup(setup);
    if (result.success) {
      StatusService.setServiceConfigured(serviceName);
    }
    return result;
  }

  public static getDockerServiceCommand(
    serviceName: string,
    action: string
  ): string[] {
    if (action === 'start') {
      return ['docker', 'compose', 'up', '-d', '--remove-orphans', serviceName];
    } else if (action === 'stop') {
      // TODO: think about down instead of stop
      return ['docker', 'compose', 'stop', serviceName];
    } else {
      throw new Error(`Invalid service action: ${action}`);
    }
  }

  public static getRuntimeStatus(serviceName: string): RuntimeStatus {
    const containerIdResult = spawnSync('docker', ['compose', 'ps', '-q', serviceName], {
      cwd: ConfigService.getInstallDir(),
      encoding: 'utf-8',
    });

    if (containerIdResult.error) {
      throw containerIdResult.error;
    }

    const containerId = containerIdResult.stdout.trim();
    if (!containerId) {
      return {
        running: false,
        status: 'stopped',
        health: 'none',
        healthDetail: 'No container exists for this service.',
        containerId: null,
        rawStatus: null,
      };
    }

    const inspectResult = spawnSync('docker', ['inspect', '--format', '{{json .State}}', containerId], {
      cwd: ConfigService.getInstallDir(),
      encoding: 'utf-8',
    });

    if (inspectResult.error) {
      throw inspectResult.error;
    }

    const stateOutput = inspectResult.stdout.trim();
    if (!stateOutput) {
      return {
        running: true,
        status: 'unknown',
        health: 'unknown',
        healthDetail: 'Unable to parse container state.',
        containerId,
        rawStatus: null,
      };
    }

    let parsedState: any = null;
    try {
      parsedState = JSON.parse(stateOutput);
    } catch {
      parsedState = null;
    }

    const status = parsedState?.Status ?? 'unknown';
    const running = status === 'running';
    let health: RuntimeStatus['health'] = 'unknown';
    let healthDetail: string | null = null;

    if (parsedState?.Health) {
      health = parsedState.Health.Status || 'unknown';
      healthDetail = Array.isArray(parsedState.Health.Log)
        ? parsedState.Health.Log.map((entry: any) => entry.Output).filter(Boolean).join(' | ')
        : null;
    } else {
      health = running ? 'unknown' : 'none';
    }

    console.log(`SERVICE - ${serviceName}: ${JSON.stringify({ status, health })}`);

    return {
      running,
      status,
      health,
      healthDetail,
      containerId,
      rawStatus: stateOutput,
    };
  }

  public static getDeployCommandArgs(): string[] {
    return ['docker', 'compose', 'up', '-d', '--remove-orphans'];
  }

  /**
   * Resolve the command to execute for a specific service action.
   * If no command is found in the database, it will use the default docker compose command.
   * If command require args from db, it will replace them with the corresponding environment variables.
   * 
   * @param service The service to resolve the command for.
   * @param action The action to resolve the command for.
   * @returns The command to execute.
   */
  public static resolveActionCommand(service: ServiceModel, action: string, format: 'array' | 'string' = 'array'): string[] | string {
    const { cmd, args } = service?.actions.find(a => a.action === action) || { cmd: undefined, args: undefined };
    if (cmd) {
      let currentCmd = cmd;
      const cmdArgs = args ? args.split(',').map(arg => arg.trim()) : [];
      cmdArgs.forEach(arg => {
        currentCmd = currentCmd.replaceAll(`$${arg}`, ConfigService.getEnv(arg) || process.env[arg] || arg);
      })
      const cmdArray = currentCmd.split(' ');
      return format === 'array' ? cmdArray : currentCmd;
    }
    ServicesService.log.warn({ service, action }, `No command found for ${action} action of ${service.name} service.`);
    if (service.type === 'docker') {
      ServicesService.log.warn({ service, action }, `Using default docker compose command. Explicitly add this docker compose command to service action on db to remove this warning.`);
      return ServicesService.getDockerServiceCommand(service.name, action);
    }
    return []
  }

}
