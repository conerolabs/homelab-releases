import { execSync } from 'child_process';
import { getLogger } from '../logger.ts';
import { VpnConfigHelper, type BackendState } from './hlservices/VpnConfigHelper.ts';
import type { StartVpnOutput, VpnInfo, VpnMode } from '../../commons/dto.ts';
import { ConfigService } from './config.service.ts';
import { ShellService } from './shell.service.ts';
import { SystemService } from './system.service.ts';

const GET_NIC_COMMAND = `ip -d -j link | jq -r '.[] | select(.operstate == "UP" or .operstate == "UNKNOWN") | select(.linkinfo?.info_kind == null and .link_type != "loopback").ifname'`

export type NetworkType = "public" | "lan" | "tailscale"

export class NetworkService {

    private static log = getLogger(NetworkService.name);

    public static async getIp(network: NetworkType): Promise<string> {
        try {
            const result = await new Promise<string>((resolve, reject) => {
                switch (network) {
                    case 'public': NetworkService.getPublicIp().then(resolve).catch(reject); break;
                    case 'lan':
                        const networkInterface = process.env.NETWORK_INTERFACE || NetworkService.getNic();
                        resolve(NetworkService.getLanIp(networkInterface));
                        break;
                    case 'tailscale': resolve(NetworkService.getTailscaleIp()); break;
                    default:
                        reject(new Error(`Invalid network parameter: "${network}"`));
                }
            });
            return result;
        } catch (error) {
            NetworkService.log.error(`Failed to get IP for ${network} network: ${error.message}`);
            return '';
        }
    }

    private static async getPublicIp(ipService?: string, count: number = 1): Promise<string> {
        const ipServices: string[] = [
            'https://ipinfo.io/ip',
            'https://ifconfig.me/ip',
            'https://api.ipify.org'
        ]
        const ipServiceIndex = Math.floor(Math.random() * ipServices.length);
        let url = ipService || ipServices[ipServiceIndex];
        return fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }
                return response.text();
            })
            .then(text => text.trim())
            .catch(err => {
                if (count > ipServices.length) {
                    NetworkService.log.error(`Failed to fetch public IP with ${url}: ${err.message}`);
                    throw new Error(`Failed to fetch public IP with ${url}: ${err.message}`);
                }
                NetworkService.log.error(`Failed to fetch public IP with ${url}: ${err.message}`);
                return NetworkService.getPublicIp(ipServices[(ipServices.indexOf(url) + 1) % ipServices.length], ++count);
            });
    }

    public static getTailscaleIp(): string | null {
        const tailscaleCmd = `tailscale ip -4`;
        try {
            const ip = execSync(tailscaleCmd, { encoding: 'utf-8' }).trim();
            NetworkService.log.info(`Tailscale IP: ${ip}`);
            return ip;
        } catch (error) {
            NetworkService.log.error({ cmd: tailscaleCmd }, `Failed to get tailscale ip: ${error.stdout} - ${error.stderr}`);
            return null;
        }
    }

    /**
     * Get vpn mode, login status and api key existence
     * 
     * @returns Object with BackendState and AuthURL
     */
    public static async getVpnInfo(): Promise<VpnInfo | null> {
        const mode = ConfigService.getVpnMode();
        if (!mode || mode === 'none') {
            return null;
        }
        const status = await VpnConfigHelper.getStatus('BackendState') as BackendState;
        return {
            mode,
            status,
            apiKey: !!ConfigService.getEnv(`${mode.toUpperCase()}_API_KEY`)
        };
    }

    public static async startVpn(vpnMode?: VpnMode): Promise<StartVpnOutput> {
        try {
            const mode = vpnMode || ConfigService.getVpnMode();
            if (mode === 'none') {
                return { success: false, error: 'No VPN configured' };
            }
            const service = ConfigService.getService(mode);
            const startAction = service.actions.find(a => a.action === 'start');
            if (!startAction) {
                NetworkService.log.error(`No start action found for ${mode}`);
                throw new Error('No start action found');
            }

            const setOperatorCmd = `tailscale set --operator "${process.env.USER}"`;
            const { stderr: operatorStderr, stdout: operatorStdout, exitCode: operatorExitCode } = await ShellService.execCommand(setOperatorCmd, SystemService.getSudoPassword()).result;
            NetworkService.log.info(`Set ${mode} operator to ${process.env.USER}: ${!operatorExitCode} ${operatorStdout} ${operatorStderr}`);

            const startCmd = service.actions.find(a => a.action === 'start')?.cmd;
            NetworkService.log.info({ cmd: startCmd }, `Starting ${mode}...`);
            const { child, result: startResult } = ShellService.execCommand(startCmd, null, true);
            const loginUrl = await VpnConfigHelper.getLoginUrl(child);
            const { exitCode: startExitCode, stderr: startStderr } = await startResult;
            if (startExitCode === 0) {
                const tailscaleIp = NetworkService.getTailscaleIp();
                return { success: true, tailscaleIp };
            } else if (loginUrl) {
                return { success: true, loginUrl };
            }
            return { success: false, error: `Failed to start ${mode}: ${startStderr}` };
        } catch (error) {
            NetworkService.log.error(`Failed to start VPN: ${error.message}`);
            return { success: false, error: error.message };
        }
    }

    /**
     * Disconnect the node from tailscaleVPN. Coordination server will stay up.
     * @param vpnMode 
     * @returns Object with success status and optional error
     */
    public static async stopVpn(vpnMode?: VpnMode): Promise<{ success: boolean, error?: string }> {
        try {
            const mode = vpnMode || ConfigService.getVpnMode();
            if (mode === 'none') {
                return { success: false, error: 'No VPN configured' };
            }
            const service = ConfigService.getService('tailscale');
            const stopAction = service.actions.find(a => a.action === 'stop');
            if (!stopAction) {
                NetworkService.log.error(`No stop action found for ${mode}`);
                throw new Error('No stop action found');
            }

            const stopCmd = service.actions.find(a => a.action === 'stop')?.cmd;
            NetworkService.log.info({ cmd: stopCmd }, `Stopping ${mode}...`);
            const { exitCode: stopExitCode, stderr: stopStderr } = await ShellService.execCommand(stopCmd, null, true).result;
            if (stopExitCode === 0) {
                return { success: true };
            }
            return { success: false, error: `Failed to stop ${mode}: ${stopStderr}` };
        } catch (error) {
            NetworkService.log.error(`Failed to stop VPN: ${error.message}`);
            return { success: false, error: error.message };
        }
    }

    private static getLanIp(networkInterface: string): string {
        // Validate network interface name to prevent shell injection
        if (!/^[a-zA-Z0-9.-]+$/.test(networkInterface)) {
            throw (new Error(`Invalid NETWORK_INTERFACE configuration: "${networkInterface}"`));
        }
        const lanCmd = `ip -4 -o addr show ${networkInterface} | awk '{printf $4}' | sed 's/\\/.*//'`;
        try {
            return execSync(lanCmd, { encoding: 'utf-8' }).trim();
        } catch (error) {
            throw new Error(`Failed to get LAN ip with command: ${lanCmd} - ${error.stdout} - ${error.stderr}`);
        }
    }

    public static getNic(): string {
        try {
            return execSync(GET_NIC_COMMAND, { encoding: 'utf-8' }).trim();
        } catch (error) {
            throw new Error(`Failed to get network interface: ${error.stdout} - ${error.stderr}`);
        }
    }

}