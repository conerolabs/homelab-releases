import test from 'node:test';
import assert from 'node:assert';
import { DepsService } from './deps.service.ts';

test('DepsService - getDependencyNames should return a list of dependency names', () => {
    const names = DepsService.getDependencyNames();
    assert.ok(Array.isArray(names));
    console.log('Found dependencies:', names);
});

test('DepsService - checkDependency invalid characters should return false', async () => {
    const isValid = await DepsService.checkDependency('invalid; rm -rf /');
    assert.strictEqual(isValid, false);
});
