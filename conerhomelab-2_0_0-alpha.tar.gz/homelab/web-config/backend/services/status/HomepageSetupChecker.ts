import type { SetupCheckResult } from "../../../commons/dto.ts";
import { getLogger } from "../../logger.ts";
import type { ServiceSetupChecker } from "./status.service.ts";

export class HomepageSetupChecker implements ServiceSetupChecker {

    public name = 'homepage'
    private static log = getLogger('HomepageSetupChecker')
    public check = (): Promise<SetupCheckResult> => {
        HomepageSetupChecker.log.info('STATUS - Checking homepage setup...')
        return Promise.resolve({
            name: HomepageSetupChecker.name,
            success: true,
            failedChecks: [],
            message: 'Nothing to check...'

        })
    }

}