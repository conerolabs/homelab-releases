import type { JobResult } from "../../../commons/dto.ts";
import { type HLTask } from "../TasksManager.ts";
import { BaseSetupChecker } from "./BaseSetupChecker.ts";

export class HomepageSetupChecker extends BaseSetupChecker {

    constructor() {
        super('homepage');
    }

    public override getTasks(): HLTask[] {
        return [];
    }

}