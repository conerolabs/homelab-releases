import type { JobResult } from "../../../commons/dto.ts";
import { TasksManager, type HLTask } from "../TasksManager.ts";
import type { ServiceSetupChecker } from "./status.service.ts";

export abstract class BaseSetupChecker extends TasksManager implements ServiceSetupChecker {
    public readonly name: string;

    constructor(name: string) {
        super(`${name}`);
        this.name = name;
    }

    public abstract override getTasks(): HLTask[];

    public async check(onTaskCompleted: (result: JobResult, percentage: number) => void): Promise<JobResult> {
        return this.runTasks(onTaskCompleted);
    }
}