import type { JobResult } from "../../../commons/dto.ts";
import { TasksManager, type HLTask } from "../TasksManager.ts";
import type { ServiceSetupChecker } from "./status.service.ts";
import { getLogger } from "../../logger.ts";
import { getDockerImageInfo } from "../../docker-utils.ts";

export abstract class BaseSetupChecker extends TasksManager<{}> implements ServiceSetupChecker {
    public readonly name: string;
    public override readonly log = getLogger('BaseSetupChecker', { msgPrefix: 'SETUP CHECK - ' });

    constructor(name: string) {
        super(`${name} setup checks`, name);
        this.name = name;
    }

    public abstract override getTasks(): HLTask<{}>[];

    public async check(onTaskCompleted: (result: JobResult, percentage: number) => void): Promise<JobResult> {
        return this.runTasks(onTaskCompleted);
    }

    public static getDockerImageCheckerTask(name: string, weight?: number, skip?: () => Promise<{ skip: boolean, reason?: string }>): HLTask<{}> {
        return {
            name: `${name}-docker-image`,
            description: `Checks if ${name} docker image is available`,
            action: async () => {
                try {
                    const img = await getDockerImageInfo(name);
                    return {
                        name: `${name}-docker-image`,
                        service: name,
                        success: !!img,
                        message: `${name} docker image is ${!img ? 'not ' : ''}available`
                    }
                } catch (error) {
                    return {
                        name: `${name}-docker-image`,
                        service: name,
                        success: false,
                        message: `Error checking ${name} docker image: ${error}`
                    }
                }
            },
            skip: skip ?? (async () => ({ skip: false })),
            weight: weight ?? 1
        }
    }
}