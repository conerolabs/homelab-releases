import { DepsService } from "../deps.service.ts";
import { getAllUsers } from "../../../database/usersDAO.ts";
import { AutheliaSetupChecker } from "./AutheliaSetupChecker.ts";
import { CaddySetupChecker } from "./CaddySetupChecker.ts";
import { getServiceList } from "../../../database/serviceDAO.ts";
import { PiholeSetupChecker } from "./PiholeSetupChecker.ts";
import type { DepsCheckResult, AdminCheckResult, ServicesCheckResult, SetupCheckResult } from "../../../commons/dto.ts";

export interface ServiceSetupChecker {
    name: string;
    check(): Promise<SetupCheckResult>;
}

export class StatusService {

    // Cached values (so we don't have to check every time)
    private static adminStatus: AdminCheckResult | null = null;
    private static servicesStatus: ServicesCheckResult | null = null;

    private static SERVICES_CHECKERS: Map<string, ServiceSetupChecker> = new Map([
        ['authelia', new AutheliaSetupChecker()],
        ['caddy', new CaddySetupChecker()],
        ['pihole', new PiholeSetupChecker()],
        ['unbound', {
            name: 'unbound',
            check: async () => {
                return { name: 'unbound', success: true };
            }
        }],
        ['tailscale', {
            name: 'tailscale',
            check: async () => {
                return { name: 'tailscale', success: true };
            }
        }]
    ]);

    private static ADMIN_GROUP: string = 'admins';

    public static async checkAdmin(noCache: boolean = false): Promise<AdminCheckResult> {
        if (!noCache && StatusService.adminStatus?.success) return StatusService.adminStatus;
        try {
            const users = getAllUsers();
            const admins = users.filter(user => {
                const groups = user?.groups?.split(',');
                return groups?.some(
                    (g: string) => g.toLowerCase() === StatusService.ADMIN_GROUP.toLowerCase()
                );
            });
            console.log(`USERS - found ${admins.length} admin(s):\n  --> ${admins.map(u => u.username).join('\n  --> ')}`);
            const hasAdmin = admins.length > 0;
            StatusService.adminStatus = { success: hasAdmin };
            return StatusService.adminStatus;
            // return { success: false, message: 'Test' };
        } catch (error) {
            console.error('[ERROR] STATUS - Checking admin:', error);
            return { success: false, message: 'Error checking admin' + String(error) };
        }
    }

    public static async checkDeps(noCache: boolean = false): Promise<DepsCheckResult> {
        let missing: string[] = [];
        let notRunning: string[] = [];
        try {
            const depsStatus = await DepsService.checkRequiredDeps(noCache)
            const installed = depsStatus.every(s => s.installed);
            if (!installed) {
                missing = depsStatus.filter(r => !r.installed).map(d => d.name);
                console.log('STATUS - Dependencies not installed:');
                console.log(missing);
            } else {
                console.log('STATUS - Dependencies are installed');
            }
            const running = depsStatus.every(s => s.running ?? true);
            if (!running) {
                notRunning = depsStatus.filter(r => !(r.running ?? true)).map(d => d.name);
                console.log('STATUS - Dependencies not running:');
                console.log(notRunning);
            } else {
                console.log('STATUS - Dependencies are running');
            }
            const success = installed && running;
            return { success, missing, notRunning };
            // return { success: false, missing: ['test'] };
        } catch (error) {
            console.error('[ERROR] STATUS - Checking dependencies:', error);
            return { success: false, missing: ["Error checking dependencies"] };
        }
    }

    public static async checkServiceSetup(service: string, noCache: boolean = false): Promise<SetupCheckResult> {
        if (!noCache && StatusService.servicesStatus) return {
            name: service,
            success: StatusService.servicesStatus.success,
        };

        const checker = StatusService.SERVICES_CHECKERS.get(service);
        if (!checker) {
            return { name: service, success: false, message: 'Service not found' };
        }
        return checker.check();
    }

    public static async checkServicesSetup(services: string[] | undefined = undefined, noCache: boolean = false): Promise<ServicesCheckResult> {
        if (!noCache && StatusService.servicesStatus) {
            if (!services || StatusService.servicesStatus.success) return StatusService.servicesStatus;
            const serviceFilter = (s: SetupCheckResult) => services.includes(s.name);
            const filtered = StatusService.servicesStatus.config?.filter(serviceFilter) ?? [];
            const success = filtered.every(r => r.success);
            return { success, config: filtered };
        }

        const servicesToCheck: string[] = services ? services : getServiceList().filter(s => s.enabled).map(s => s.name);
        const checkers = servicesToCheck
            .filter(s => StatusService.SERVICES_CHECKERS.has(s))
            .map(s => StatusService.SERVICES_CHECKERS.get(s)!);
        return Promise.all(checkers.map(s => s.check()))
            .then(results => {
                const success = results.map(r => r.success).every(r => r);
                if (success) {
                    console.log('STATUS - Services setup is complete');
                    StatusService.servicesStatus = { success: true, config: [] };
                    return StatusService.servicesStatus;
                }
                console.log('STATUS - Services setup is not complete');
                console.log('STATUS - Services not properly configured:');
                const config = results.filter(r => !r.success);
                results.filter(r => !r.success).forEach(r => console.log(`  --> ${r.name}: ${r.message}`));
                StatusService.servicesStatus = { success: false, config };
                return StatusService.servicesStatus;
            })
            .catch(reason => {
                console.error('[ERROR] STATUS - Checking services:', reason);
                return { success: false, notConfigured: [{ name: 'Error', success: false, message: "Error checking services" + String(reason) }] };
            });
    }

    public static async getNotConfiguredServices() {
        const notConfiguredServices: string[] = await StatusService.checkServicesSetup().then(r => r.config?.map(r => r.name) || []);
        return notConfiguredServices;
    }

    public static async setServiceConfigured(service: string) {
        if (!StatusService.servicesStatus) return;
        const config = StatusService.servicesStatus.config?.filter(r => r.name !== service);
        if (config?.length === 0) {
            StatusService.servicesStatus.success = true;
        }
        StatusService.servicesStatus.config = config;
    }
}
