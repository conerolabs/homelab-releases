import { DepsService } from "../deps.service.ts";
import { getAllUsers } from "../../../database/usersDAO.ts";
import { AutheliaSetupChecker } from "./AutheliaSetupChecker.ts";
import { CaddySetupChecker } from "./CaddySetupChecker.ts";
import { getServiceList } from "../../../database/serviceDAO.ts";
import { PiholeSetupChecker } from "./PiholeSetupChecker.ts";
import type { DepsCheckResult, AdminCheckResult, ServicesCheckResult, SetupCheckResult } from "../../../commons/dto.ts";

export interface ServiceSetupChecker {
    name: string;
    check(): Promise<SetupCheckResult>;
}

export class StatusService {

    // Cached values (so we don't have to check every time)
    private static adminStatus: AdminCheckResult | null = null;
    private static servicesStatus: ServicesCheckResult | null = null;

    private static SERVICES_CHECKERS: Map<string, ServiceSetupChecker> = new Map([
        ['authelia', new AutheliaSetupChecker()],
        ['caddy', new CaddySetupChecker()],
        ['pihole', new PiholeSetupChecker()],
        ['unbound', {
            name: 'unbound',
            check: async () => {
                return { name: 'unbound', success: true };
            }
        }],
        ['tailscale', {
            name: 'tailscale',
            check: async () => {
                return { name: 'tailscale', success: true };
            }
        }]
    ]);

    private static ADMIN_GROUP: string = 'admins';

    public static async checkAdmin(noCache: boolean = false): Promise<AdminCheckResult> {
        if (!noCache && StatusService.adminStatus) return StatusService.adminStatus;
        try {
            const users = getAllUsers();
            const admins = users.filter(user => {
                const groups = user?.groups?.split(',');
                return groups?.some(
                    (g: string) => g.toLowerCase() === StatusService.ADMIN_GROUP.toLowerCase()
                );
            });
            console.log(`USERS - found ${admins.length} admin(s):\n  --> ${admins.map(u => u.username).join('\n  --> ')}`);
            const hasAdmin = admins.length > 0;
            StatusService.adminStatus = { success: hasAdmin };
            return StatusService.adminStatus;
        } catch (error) {
            console.error('[ERROR] STATUS - Checking admin:', error);
            return { success: false, message: 'Error checking admin' + String(error) };
        }
    }

    public static async checkDeps(noCache: boolean = false): Promise<DepsCheckResult> {
        let missing: string[] = [];
        try {
            const depsStatus = await DepsService.checkRequiredDeps(noCache)
            const installed = depsStatus.every(s => s.installed);
            if (!installed) {
                missing = depsStatus.filter(r => !r.installed).map(d => d.name);
                console.log('STATUS - Dependencies not installed:');
                console.log(missing);
            } else {
                console.log('STATUS - Dependencies are installed');
            }
            return { success: installed, missing };
            // return { success: false, missing: ['test'] };
        } catch (error) {
            console.error('[ERROR] STATUS - Checking dependencies:', error);
            return { success: false, missing: ["Error checking dependencies"] };
        }
    }

    public static async checkServiceSetup(service: string, noCache: boolean = false): Promise<SetupCheckResult> {
        if (!noCache && StatusService.servicesStatus) return {
            name: service,
            success: StatusService.servicesStatus.success,
        };

        const checker = StatusService.SERVICES_CHECKERS.get(service);
        if (!checker) {
            return { name: service, success: false, message: 'Service not found' };
        }
        return checker.check();
    }

    public static async checkServicesSetup(noCache: boolean = false): Promise<ServicesCheckResult> {
        if (!noCache && StatusService.servicesStatus) return StatusService.servicesStatus;

        const enabledServices = getServiceList().filter(s => s.enabled);
        const checkers = enabledServices
            .filter(s => StatusService.SERVICES_CHECKERS.has(s.name))
            .map(s => StatusService.SERVICES_CHECKERS.get(s.name)!);
        return Promise.all(checkers.map(s => s.check()))
            .then(results => {
                const success = results.map(r => r.success).every(r => r);
                if (success) {
                    console.log('STATUS - Services setup is complete');
                    StatusService.servicesStatus = { success: true, notConfigured: [] };
                    return StatusService.servicesStatus;
                }
                console.log('STATUS - Services setup is not complete');
                console.log('STATUS - Services not properly configured:');
                const notConfigured = results.filter(r => !r.success);
                results.filter(r => !r.success).forEach(r => console.log(`  --> ${r.name}: ${r.message}`));
                StatusService.servicesStatus = { success: false, notConfigured };
                return StatusService.servicesStatus;
            })
            .catch(reason => {
                console.error('[ERROR] STATUS - Checking services:', reason);
                return { success: false, notConfigured: [{ name: 'Error', success: false, message: "Error checking services" + String(reason) }] };
            });
    }

    public static async getNotConfiguredServices() {
        const notConfiguredServices: string[] = await StatusService.checkServicesSetup().then(r => r.notConfigured?.map(r => r.name) || []);
        return notConfiguredServices;
    }

    public static async setServiceConfigured(service: string) {
        if (!StatusService.servicesStatus) return;
        const notConfigured = StatusService.servicesStatus.notConfigured?.filter(r => r.name !== service);
        if (notConfigured?.length === 0) {
            StatusService.servicesStatus.success = true;
        }
        StatusService.servicesStatus.notConfigured = notConfigured;
    }
}
