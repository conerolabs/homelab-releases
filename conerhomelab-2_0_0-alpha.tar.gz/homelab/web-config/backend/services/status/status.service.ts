import { DepsService } from "../deps.service.ts";
import { getAllUsers } from "../../../database/usersDAO.ts";
import { AutheliaSetupChecker } from "./AutheliaSetupChecker.ts";
import { CaddySetupChecker } from "./CaddySetupChecker.ts";
import { getServiceList } from "../../../database/serviceDAO.ts";
import { PiholeSetupChecker } from "./PiholeSetupChecker.ts";
import type { DepsCheckResult, AdminCheckResult, ServicesCheckResult, JobResult } from "../../../commons/dto.ts";
import { getLogger } from "../../logger.ts";

export interface ServiceSetupChecker {
    name: string;
    check: (onTaskCompleted: (result: JobResult, percentage: number) => void) => Promise<JobResult> | JobResult;
}

export class StatusService {

    private static log = getLogger("StatusService");

    // Cached values (so we don't have to check every time)
    private static adminStatus: AdminCheckResult | null = null;
    private static servicesStatus: ServicesCheckResult | null = null;

    private static SERVICES_CHECKERS: Map<string, ServiceSetupChecker> = new Map([
        ['authelia', new AutheliaSetupChecker()],
        ['caddy', new CaddySetupChecker()],
        ['pihole', new PiholeSetupChecker()],
        ['unbound', {
            name: 'unbound',
            check: () => ({ name: 'unbound', success: true })
        } as ServiceSetupChecker],
        ['tailscale', {
            name: 'tailscale',
            check: () => ({ name: 'tailscale', success: true })
        } as ServiceSetupChecker]
    ]);

    private static ADMIN_GROUP: string = 'admins';

    public static async checkAdmin(noCache: boolean = false): Promise<AdminCheckResult> {
        const log = StatusService.log.child({ task_id: 'checkAdmin' })
        if (!noCache && StatusService.adminStatus?.success) return StatusService.adminStatus;
        try {
            const users = getAllUsers();
            const admins = users.filter(user => {
                const groups = user?.groups?.split(',');
                return groups?.some(
                    (g: string) => g.toLowerCase() === StatusService.ADMIN_GROUP.toLowerCase()
                );
            });
            log.info(`USERS - found ${admins.length} admin(s):\n  --> ${admins.map(u => u.username).join('\n  --> ')}`);
            const hasAdmin = admins.length > 0;
            StatusService.adminStatus = { success: hasAdmin };
            return StatusService.adminStatus;
        } catch (error) {
            log.error({ task: 'checkAdmin' }, '[ERROR] STATUS - Checking admin: ' + error);
            return { success: false, message: 'Error checking admin' + String(error) };
        }
    }

    public static async checkDeps(noCache: boolean = false): Promise<DepsCheckResult> {
        const log = StatusService.log.child({ task_id: 'checkDeps' })

        let missing: string[] = [];
        let notRunning: string[] = [];
        try {
            const depsStatus = await DepsService.checkRequiredDeps(noCache)
            const installed = depsStatus.every(s => s.installed);
            if (!installed) {
                missing = depsStatus.filter(r => !r.installed).map(d => d.name);
                log.warn('STATUS - Dependencies not installed:');
                log.warn(missing);
            } else {
                log.info('STATUS - Dependencies are installed');
            }
            const running = depsStatus.every(s => s.running ?? true);
            if (!running) {
                notRunning = depsStatus.filter(r => !(r.running ?? true)).map(d => d.name);
                log.warn({ deps: notRunning }, 'STATUS - Dependencies not running');
            } else {
                log.info('STATUS - Dependencies are running');
            }
            const success = installed && running;
            return { success, missing, notRunning };
            // return { success: false, missing: ['test'] };
        } catch (error) {
            log.error('[ERROR] STATUS - Checking dependencies: ' + error);
            return { success: false, missing: ["Error checking dependencies"] };
        }
    }

    public static async checkServiceSetup(service: string, onTaskCompleted: (result: JobResult, percentage: number) => void, noCache: boolean = false): Promise<JobResult> {
        if (!noCache && StatusService.servicesStatus) return {
            name: service,
            success: StatusService.servicesStatus.success,
        };

        const checker = StatusService.SERVICES_CHECKERS.get(service);
        if (!checker) {
            return { name: service, success: false, message: 'Service not found' };
        }
        return checker.check(onTaskCompleted);
    }

    public static async checkServicesSetup(services?: string[], onTaskCompleted: (result: JobResult, percentage: number) => void = () => { }, noCache: boolean = false): Promise<ServicesCheckResult> {
        if (!noCache && StatusService.servicesStatus) {
            if (!services || StatusService.servicesStatus.success) return StatusService.servicesStatus;
            const serviceFilter = (s: JobResult) => services.includes(s.name);
            const filtered = StatusService.servicesStatus.results?.filter(serviceFilter) ?? [];
            const success = filtered.every(r => r.success);
            return { success, results: filtered };
        }

        const servicesToCheck: string[] = services ? services : getServiceList().filter(s => s.enabled).map(s => s.name);
        const checkers = servicesToCheck
            .filter(s => StatusService.SERVICES_CHECKERS.has(s))
            .map(s => StatusService.SERVICES_CHECKERS.get(s)!);
        return await Promise.allSettled(checkers.map(s => s.check(onTaskCompleted)))
            .then(results => {
                const rejected = results.filter(r => r.status === 'rejected');
                const success = results.every(r => r.status === 'fulfilled' && r.value.success);
                if (success) {
                    StatusService.log.info('STATUS - Services setup is complete');
                    StatusService.servicesStatus = { success: true, results: [] };
                    return StatusService.servicesStatus;
                }
                StatusService.log.warn('STATUS - Services setup is not complete');
                StatusService.log.warn('STATUS - Services not properly configured:');
                const config = results.filter(r => r.status === 'fulfilled' && !r.value.success)
                    .map(r => r.status === 'fulfilled' && r.value);
                rejected.forEach(r => StatusService.log.warn(`  --> ${r.reason}`));
                config.forEach(r => StatusService.log.warn(`  --> ${r.name}: ${r.message}`));
                StatusService.servicesStatus = { success: false, results: config };
                return StatusService.servicesStatus;
            })
            .catch(reason => {
                StatusService.log.error(`[ERROR] STATUS - Checking services: ${reason}`);
                return { success: false, notConfigured: [{ name: 'Error', success: false, message: "Error checking services" + String(reason) }] };
            });
    }

    public static async getNotConfiguredServices() {
        const notConfiguredServices: string[] = await StatusService.checkServicesSetup().then(r => r.results?.map(r => r.name) || []);
        return notConfiguredServices;
    }

    public static async setServiceConfigured(service: string) {
        if (!StatusService.servicesStatus) return;
        const config = StatusService.servicesStatus.results?.filter(r => r.name !== service);
        if (config?.length === 0) {
            StatusService.servicesStatus.success = true;
        }
        StatusService.servicesStatus.results = config;
    }
}
