import type { ServiceSetupChecker } from "./status.service.ts";
import { existsSync, readFileSync, readlinkSync } from "node:fs";
import path from "node:path";
import { exec } from "node:child_process";
import { getLogger } from "../../logger.ts";
import type { JobResult } from "../../../commons/dto.ts";
import type { HLTask } from "../TasksManager.ts";
import { BaseSetupChecker } from "./BaseSetupChecker.ts";

export class PiholeSetupChecker extends BaseSetupChecker {

    private static log = getLogger('PiholeSetupChecker');

    private static readonly DNS_CONFIG_FILE = process.env.NODE_ENV == 'production' ? 'homelab.conf' : 'pi-hole.conf';
    private static readonly SYSTEMD_RESOLVED_DISABLE_STUB_PATH = path.join('/etc/systemd/resolved.conf.d', 'disable-stub.conf');
    private static readonly SYSTEMD_RESOLVED_HOMELAB_PATH = path.join('/etc/systemd/resolved.conf.d', PiholeSetupChecker.DNS_CONFIG_FILE);
    private static readonly SYSTEMD_NETWORK_PATH = path.join('/etc/systemd/network', `01-${process.env.NETWORK_INTERFACE}.network`);
    private static readonly ETC_RESOLV_CONF_TARGET = '/run/systemd/resolve/resolv.conf'


    constructor() {
        super('pihole');
    }

    private static checkTasks: HLTask[] = [
        {
            name: 'systemd-resolved configuration',
            description: 'Checks systemd-resolved configuration',
            action: PiholeSetupChecker.checkSystemdConfig,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'Check dnsmasq',
            description: 'Checks dnsmasq status',
            action: PiholeSetupChecker.checkDnsMasq,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        }
    ]

    public override getTasks(): HLTask[] {
        return PiholeSetupChecker.checkTasks;
    }

    private static checkSystemdConfig(): JobResult {
        const log = PiholeSetupChecker.log.child({ task_id: 'checkSystemdConfig' });
        const taskName = PiholeSetupChecker.checkTasks[0].name;
        log.info(`  --> Checking ${taskName}...`)
        if (!existsSync(PiholeSetupChecker.SYSTEMD_RESOLVED_DISABLE_STUB_PATH)) {
            const msg = `systemd-resolved configuration file not found at ${PiholeSetupChecker.SYSTEMD_RESOLVED_DISABLE_STUB_PATH}`
            log.warn(`  --> [FAIL] ${msg}`)
            return { name: taskName, success: false, message: msg };
        }
        if (!existsSync(PiholeSetupChecker.SYSTEMD_RESOLVED_HOMELAB_PATH)) {
            const msg = `systemd-resolved configuration file not found at ${PiholeSetupChecker.SYSTEMD_RESOLVED_HOMELAB_PATH}`
            log.warn(`  --> [FAIL] ${msg}`)
            return { name: taskName, success: false, message: msg };
        }

        const disableStubContent = readFileSync(PiholeSetupChecker.SYSTEMD_RESOLVED_DISABLE_STUB_PATH, 'utf-8')
        if (!disableStubContent.includes('DNSStubListener=no')) {
            const msg = `systemd-resolved configuration is not set to disable stub listener in ${PiholeSetupChecker.SYSTEMD_RESOLVED_DISABLE_STUB_PATH}`
            log.warn(`  --> [FAIL] ${msg}`)
            return { name: taskName, success: false, message: msg };
        }

        const homelabContent = readFileSync(PiholeSetupChecker.SYSTEMD_RESOLVED_HOMELAB_PATH, 'utf-8')
        if (!homelabContent.includes('DNS=127.0.0.1')) {
            const msg = `systemd-resolved DNS not set to Pi-hole (127.0.0.1) in ${PiholeSetupChecker.SYSTEMD_RESOLVED_HOMELAB_PATH}`
            log.warn(`  --> [FAIL] ${msg}`)
            return { name: taskName, success: false, message: msg };
        }

        const etcResolvConfTarget = readlinkSync('/etc/resolv.conf')
        if (etcResolvConfTarget !== PiholeSetupChecker.ETC_RESOLV_CONF_TARGET) {
            const msg = `/etc/resolv.conf is not systemd-resolved managed`
            log.warn(`  --> [FAIL] ${msg}`)
            return { name: taskName, success: false, message: msg };
        }

        if (process.env.NODE_ENV === 'production') {

            if (!existsSync(PiholeSetupChecker.SYSTEMD_NETWORK_PATH)) {
                const msg = `systemd network configuration file not found at ${PiholeSetupChecker.SYSTEMD_NETWORK_PATH}`
                log.warn(`  --> [FAIL] ${msg}`)
                return { name: taskName, success: false, message: msg };
            }
            const networkContent = readFileSync(PiholeSetupChecker.SYSTEMD_NETWORK_PATH, 'utf-8')
            if (!networkContent.includes('DHCP=yes')) {
                const msg = `systemd network configuration is not set to enable DHCP`
                log.warn(`  --> [FAIL] ${msg}`)
                return { name: taskName, success: false, message: msg };
            }
            if (!networkContent.includes('[DHCP]\nUseDNS=false')) {
                const msg = `systemd network configuration is not set to disable DHCP DNS`
                log.warn(`  --> [FAIL] ${msg}`)
                return { name: taskName, success: false, message: msg };
            }
        }

        log.info('  --> [OK] systemd configuration is correct')
        return { name: taskName, success: true, message: 'systemd configuration is correct' };
    }

    private static async checkDnsMasq(): Promise<JobResult> {
        const log = PiholeSetupChecker.log.child({ task_id: 'checkDnsMasq' })
        log.info('  --> Checking dnsmasq status...')
        return await new Promise<JobResult>((resolve) => {
            exec(`systemctl is-active dnsmasq.service`, (error, stdout, stderr) => {
                if (stdout.trim() === 'inactive') {
                    log.info('  --> [OK] dnsmasq is not active')
                    resolve({ name: 'Check dnsmasq', success: true, message: 'dnsmasq is not active' });
                } else if (stdout.trim() === 'active') {
                    log.warn('  --> [FAIL] dnsmasq is active, it should be disabled')
                    resolve({ name: 'Check dnsmasq', success: false, message: 'dnsmasq is active, it should be disabled' });
                } else {
                    log.warn('  --> [FAIL] dnsmasq error ' + error?.message)
                    resolve({ name: 'Check dnsmasq', success: false, message: 'dnsmasq error ' + error?.message });
                }
            });
        })
    }
}