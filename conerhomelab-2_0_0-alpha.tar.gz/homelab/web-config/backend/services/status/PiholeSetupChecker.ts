import type { ServiceSetupChecker } from "./status.service.ts";
import { existsSync, readFileSync, readlinkSync } from "node:fs";
import path from "node:path";
import { exec } from "node:child_process";
import type { SetupCheckResult } from "../../../commons/dto.ts";

export class PiholeSetupChecker implements ServiceSetupChecker {
    public readonly name: string = 'pihole';

    private static readonly DNS_CONFIG_FILE = process.env.NODE_ENV == 'production' ? 'homelab.conf' : 'pi-hole.conf';
    private static readonly SYSTEMD_RESOLVED_DISABLE_STUB_PATH = path.join('/etc/systemd/resolved.conf.d', 'disable-stub.conf');
    private static readonly SYSTEMD_RESOLVED_HOMELAB_PATH = path.join('/etc/systemd/resolved.conf.d', PiholeSetupChecker.DNS_CONFIG_FILE);
    private static readonly SYSTEMD_NETWORK_PATH = path.join('/etc/systemd/network', `01-${process.env.NETWORK_INTERFACE}.network`);
    private static readonly ETC_RESOLV_CONF_TARGET = '/run/systemd/resolve/resolv.conf'

    private static checkSystemdConfig(): boolean {
        console.log('  - Checking systemd-resolved configuration...')
        if (!existsSync(PiholeSetupChecker.SYSTEMD_RESOLVED_DISABLE_STUB_PATH)) {
            console.log(`    --> systemd-resolved configuration file not found at ${PiholeSetupChecker.SYSTEMD_RESOLVED_DISABLE_STUB_PATH}`)
            return false;
        }
        if (!existsSync(PiholeSetupChecker.SYSTEMD_RESOLVED_HOMELAB_PATH)) {
            console.log(`    --> systemd-resolved configuration file not found at ${PiholeSetupChecker.SYSTEMD_RESOLVED_HOMELAB_PATH}`)
            return false;
        }

        const disableStubContent = readFileSync(PiholeSetupChecker.SYSTEMD_RESOLVED_DISABLE_STUB_PATH, 'utf-8')
        if (!disableStubContent.includes('DNSStubListener=no')) {
            console.log(`    --> systemd-resolved configuration is not set to disable stub listener in ${PiholeSetupChecker.SYSTEMD_RESOLVED_DISABLE_STUB_PATH}`)
            return false;
        }

        const homelabContent = readFileSync(PiholeSetupChecker.SYSTEMD_RESOLVED_HOMELAB_PATH, 'utf-8')
        if (!homelabContent.includes('DNS=127.0.0.1')) {
            console.log(`    --> systemd-resolved DNS not set to Pi-hole (127.0.0.1) in ${PiholeSetupChecker.SYSTEMD_RESOLVED_HOMELAB_PATH}`)
            return false;
        }

        const etcResolvConfTarget = readlinkSync('/etc/resolv.conf')
        if (etcResolvConfTarget !== PiholeSetupChecker.ETC_RESOLV_CONF_TARGET) {
            console.log('    --> /etc/resolv.conf is not systemd-resolved managed')
            return false;
        }

        if (process.env.NODE_ENV === 'production') {

            if (!existsSync(PiholeSetupChecker.SYSTEMD_NETWORK_PATH)) {
                console.log(`    --> systemd network configuration file not found at ${PiholeSetupChecker.SYSTEMD_NETWORK_PATH}`)
                return false;
            }
            const networkContent = readFileSync(PiholeSetupChecker.SYSTEMD_NETWORK_PATH, 'utf-8')
            if (!networkContent.includes('DHCP=yes')) {
                console.log('    --> systemd network configuration is not set to enable DHCP')
                return false;
            }
            if (!networkContent.includes('[DHCP]\nUseDNS=false')) {
                console.log('    --> systemd network configuration is not set to disable DHCP DNS')
                return false;
            }
        }

        console.log('    --> [OK] systemd configuration is correct')
        return true;
    }

    private static async checkDnsMasq(): Promise<boolean> {
        console.log('  - Checking dnsmasq status...')
        // const sudoPassword = SystemController.getSudoPassword();
        // if (!sudoPassword) {
        //     console.log('    --> [WARNING] sudo password not set')
        //     return false;
        // }
        return new Promise((resolve) => {
            exec(`systemctl is-active dnsmasq.service`, (error, stdout, stderr) => {
                if (stdout.trim() === 'inactive') {
                    console.log('    --> [OK] dnsmasq is not active')
                    resolve(true);
                } else if (stdout.trim() === 'active') {
                    console.log('    --> dnsmasq is active, it should be disabled')
                    resolve(false);
                } else {
                    console.log('    --> dnsmasq error', error?.message)
                    resolve(false);
                }
            });
        })
    }

    public async check(): Promise<SetupCheckResult> {

        console.log('STATUS - Checking pihole setup...')

        const success = await Promise.all([
            PiholeSetupChecker.checkSystemdConfig(),
            PiholeSetupChecker.checkDnsMasq(),
        ])
            .then(results => {
                const success = results.every(r => r);
                console.log('STATUS - Pi-Hole setup is complete:', success);
                return success;
            })
            .catch(reason => {
                console.error('[ERROR] STATUS - Checking Pi-Hole setup:', reason);
                return false;
            });
        return { name: this.name, success, message: success ? 'Pi-Hole setup is complete' : 'Pi-Hole setup is incomplete' };
    }
}