import { exec } from "node:child_process";
import type { JobResult } from "../../../commons/dto.ts";
import { getDockerImageInfo } from "../../docker-utils.ts";
import { getLogger } from "../../logger.ts";
import { BaseSetupChecker } from "./BaseSetupChecker.ts";
import type { HLTask } from "../TasksManager.ts";

export class CaddySetupChecker extends BaseSetupChecker {

    private static readonly log = getLogger('CaddySetupChecker');

    constructor() {
        super('caddy');
    }

    private static checkTasks: HLTask[] = [
        {
            name: 'Caddyfile validation',
            description: 'Check caddy configuration',
            action: CaddySetupChecker.validateCaddyFile,
            skip: async () => {
                return await getDockerImageInfo('caddy').then(
                    imageInfo => imageInfo ? { skip: false } : { skip: true, reason: 'Caddy docker image is not available' }
                ).catch(error => ({ skip: true, reason: error.message }))
            },
            weight: 1
        }
    ];

    public override getTasks(): HLTask[] {
        return CaddySetupChecker.checkTasks;
    }

    private static async validateCaddyFile(): Promise<JobResult> {
        const log = CaddySetupChecker.log.child({ task: 'validateCaddyFile' });
        log.info('  --> Checking caddy configuration...');
        const imageInfo = await getDockerImageInfo('caddy');
        if (!imageInfo) {
            log.warn('  --> [ERROR] Caddy docker image is not available, skipping caddyfile validation');
            return {
                name: 'Caddyfile validation',
                success: false,
                message: 'Caddy docker image not available, skipping caddyfile validation'
            };
        }
        return await new Promise<JobResult>((resolve, reject) => {
            exec('docker compose run --no-deps --rm caddy caddy validate --config /etc/caddy/Caddyfile', (error, stdout, stderr) => {
                if (error) {
                    log.error('  --> [ERROR] Caddyfile is not valid');
                    log.error(stderr);
                    resolve({ name: 'Caddyfile validation', success: false, message: 'Caddyfile is not valid: ' + stderr });
                } else {
                    log.info('  --> [OK] Caddyfile is valid');
                    resolve({ name: 'Caddyfile validation', success: true, message: 'Caddyfile is valid' });
                }
            });
        });
    }
}