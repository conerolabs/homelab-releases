import { exec } from "node:child_process";
import type { JobResult } from "../../../commons/dto.ts";
import { getDockerImageInfo } from "../../docker-utils.ts";
import { getLogger } from "../../logger.ts";
import { BaseSetupChecker } from "./BaseSetupChecker.ts";
import type { HLTask } from "../TasksManager.ts";
import { CaddyConfigHelper } from "../hlservices/CaddyConfigHelper.ts";
import { readdirSync } from "node:fs";

export class CaddySetupChecker extends BaseSetupChecker {

    private static readonly log = getLogger('CaddySetupChecker');

    constructor() {
        super('caddy');
    }

    private static checkTasks: HLTask[] = [
        {
            name: 'caddyfile-global-section',
            description: 'Check global section in caddyfile',
            action: CaddySetupChecker.checkGlobalSection,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'caddyfile-tls-section',
            description: 'Check tls section in caddyfile',
            action: CaddySetupChecker.checkTlsSection,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'caddyfile-sites-section',
            description: 'Check sites section in caddyfile',
            action: CaddySetupChecker.checkSitesSection,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'caddyfile-validation',
            description: 'Check caddy configuration',
            action: CaddySetupChecker.validateCaddyFile,
            skip: async () => {
                return await getDockerImageInfo('caddy').then(
                    imageInfo => imageInfo ? { skip: false } : { skip: true, reason: 'Caddy docker image is not available' }
                ).catch(error => ({ skip: true, reason: error.message }))
            },
            weight: 3
        }
    ];

    public override getTasks(): HLTask[] {
        return CaddySetupChecker.checkTasks;
    }

    private static checkGlobalSection(): JobResult | Promise<JobResult> {
        const log = CaddySetupChecker.log.child({ task: 'checkGlobalSection' });
        log.info('  --> Checking global section in caddyfile...');
        const name = CaddySetupChecker.checkTasks[0].name;
        let success = false;
        let message = '';
        const enabledFiles = readdirSync(CaddyConfigHelper.GLOBAL_CONFIG_ENABLED_PATH);
        const file = CaddyConfigHelper.resolveGlobalSectionFile().split('/').pop();
        if (enabledFiles.length === 0) {
            message = 'No global section enabled in caddyfile';
            log.warn(`  --> [ERROR] ${message}`);
        } else if (enabledFiles.length > 1) {
            message = 'Multiple global sections enabled in caddyfile';
            log.warn(`  --> [ERROR] ${message}`);
        } else {
            if (enabledFiles[0] === file) {
                message = `${file} global section correctly enabled in caddyfile`;
                log.info(`  --> [OK] ${message}`);
                success = true;
            } else {
                message = `Wrong global section enabled in caddyfile: expected ${file}, got ${enabledFiles[0]}`;
                log.warn(`  --> [ERROR] ${message}`);
                success = false;
            }
        }
        return { name, success, message };
    }

    private static checkTlsSection(): JobResult | Promise<JobResult> {
        const name = CaddySetupChecker.checkTasks[1].name;
        const log = CaddySetupChecker.log.child({ task: 'checkTlsSection' });
        log.info('  --> Checking tls section in caddyfile...');
        const enabledFiles = readdirSync(CaddyConfigHelper.TLS_ENABLED_PATH);
        const file = CaddyConfigHelper.resolveTlsSectionFile().split('/').pop();
        let success = false;
        let message = '';
        if (enabledFiles.length === 0) {
            message = 'No tls section in caddyfile';
            log.warn(`  --> [ERROR] ${message}`);
        } else if (enabledFiles.length > 1) {
            message = 'Multiple tls sections in caddyfile';
            log.warn(`  --> [ERROR] ${message}`);
        } else {
            if (enabledFiles[0] === file) {
                message = 'Tls section in caddyfile is valid';
                log.info('  --> [OK] Tls section in caddyfile is valid');
                success = true;
            } else {
                message = `Wrong tls section in caddyfile: expected ${file}, got ${enabledFiles[0]}`;
                log.warn(`  --> [ERROR] ${message}`);
                success = false;
            }
        }

        return { name, success, message };
    }

    private static checkSitesSection(): JobResult | Promise<JobResult> {
        const log = CaddySetupChecker.log.child({ task: 'checkSitesSection' });
        log.info('  --> Checking sites section in caddyfile...');
        const name = CaddySetupChecker.checkTasks[2].name;
        let success = false;
        let messages: string[] = [];
        const enabledSites = readdirSync(CaddyConfigHelper.SITES_ENABLED_PATH);
        const expectedEnabledSites = CaddyConfigHelper.resolveSitesSectionFiles();

        const missingSites = expectedEnabledSites.filter(site => !enabledSites.includes(site));
        const extraSites = enabledSites.filter(site => !expectedEnabledSites.includes(site));
        if (missingSites.length > 0) {
            const message = `Missing sites in caddyfile: ${missingSites.join(', ')}`;
            messages.push(message);
            log.warn(`  --> [ERROR] ${message}`);
        }
        if (extraSites.length > 0) {
            const message = `Extra sites in caddyfile: ${extraSites.join(', ')}`;
            messages.push(message);
            log.warn(`  --> [ERROR] ${messages[messages.length - 1]}`);
        }
        if (messages.length === 0) {
            messages.push('Sites section in caddyfile is valid');
            log.info('  --> [OK] Sites section in caddyfile is valid');
            success = true;
        }
        return { name, success, message: messages.join('\n') };
    }

    private static async validateCaddyFile(): Promise<JobResult> {
        const log = CaddySetupChecker.log.child({ task: 'validateCaddyFile' });
        log.info('  --> Checking caddy configuration...');
        const imageInfo = await getDockerImageInfo('caddy');
        if (!imageInfo) {
            log.warn('  --> [ERROR] Caddy docker image is not available, skipping caddyfile validation');
            return {
                name: 'Caddyfile validation',
                success: false,
                message: 'Caddy docker image not available, skipping caddyfile validation'
            };
        }
        return await new Promise<JobResult>((resolve, reject) => {
            exec('docker compose run --no-deps --rm caddy caddy validate --config /etc/caddy/Caddyfile', (error, stdout, stderr) => {
                if (error) {
                    log.error('  --> [ERROR] Caddyfile is not valid');
                    log.error(stderr);
                    resolve({ name: 'Caddyfile validation', success: false, message: 'Caddyfile is not valid: ' + stderr });
                } else {
                    log.info('  --> [OK] Caddyfile is valid');
                    resolve({ name: 'Caddyfile validation', success: true, message: 'Caddyfile is valid' });
                }
            });
        });
    }
}