import { exec } from "node:child_process";
import type { ServiceSetupChecker } from "./status.service.ts";
import type { SetupCheckResult } from "../../../commons/dto.ts";

export class CaddySetupChecker implements ServiceSetupChecker {
    public readonly name: string = 'caddy';

    private static validateCaddyFile(): Promise<SetupCheckResult> {
        console.log('  --> Checking caddy configuration...');
        return new Promise((resolve, reject) => {
            exec('docker compose run --no-deps --rm caddy caddy validate --config /etc/caddy/Caddyfile', (error, stdout, stderr) => {
                if (error) {
                    console.error('  --> [ERROR] Caddyfile is not valid');
                    console.error(stderr);
                    resolve({ name: 'Caddyfile validation', success: false, message: 'Caddyfile is not valid: ' + stderr });
                } else {
                    console.log('  --> [OK] Caddyfile is valid');
                    resolve({ name: 'Caddyfile validation', success: true, message: 'Caddyfile is valid' });
                }
            });
        });
    }

    public async check(): Promise<SetupCheckResult> {

        console.log('STATUS - Checking caddy setup...')

        const { success, failedChecks } = await Promise.all([
            CaddySetupChecker.validateCaddyFile(),
        ])
            .then(results => {
                const success = results.every(r => r.success);
                const failedChecks = results.filter(r => !r.success);
                console.log('STATUS - Caddy setup is complete:', success);
                failedChecks.length && console.log('STATUS - Caddy setup failed checks:', failedChecks);
                return { success, failedChecks };
            })
            .catch(reason => {
                console.error('[ERROR] STATUS - Checking Caddy setup:', reason);
                return { success: false, failedChecks: ['Unexpected error: ' + reason] };
            });
        return {
            name: this.name,
            success: success,
            message: success ? 'Caddy setup is complete' : 'Caddy setup is incomplete',
            failedChecks
        };
    }
}