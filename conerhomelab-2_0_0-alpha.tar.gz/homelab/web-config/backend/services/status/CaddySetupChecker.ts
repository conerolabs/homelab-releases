import { exec } from "node:child_process";
import type { ServiceSetupChecker } from "./status.service.ts";
import type { SetupCheckResult } from "../../../commons/dto.ts";
import { getDockerImageInfo } from "../../docker-utils.ts";
import { getLogger } from "../../logger.ts";

export class CaddySetupChecker implements ServiceSetupChecker {
    public readonly name: string = 'caddy';

    private static readonly log = getLogger('CaddySetupChecker');

    private static async validateCaddyFile(): Promise<SetupCheckResult> {
        const log = CaddySetupChecker.log.child({ task: 'validateCaddyFile' });
        log.info('  --> Checking caddy configuration...');
        const imageInfo = await getDockerImageInfo('caddy');
        if (!imageInfo) {
            log.warn('  --> [ERROR] Caddy docker image is not available, skipping caddyfile validation');
            return {
                name: 'Caddyfile validation',
                success: false,
                message: 'Caddy docker image not available, skipping caddyfile validation'
            };
        }
        return await new Promise<SetupCheckResult>((resolve, reject) => {
            exec('docker compose run --no-deps --rm caddy caddy validate --config /etc/caddy/Caddyfile', (error, stdout, stderr) => {
                if (error) {
                    log.error('  --> [ERROR] Caddyfile is not valid');
                    log.error(stderr);
                    resolve({ name: 'Caddyfile validation', success: false, message: 'Caddyfile is not valid: ' + stderr });
                } else {
                    log.info('  --> [OK] Caddyfile is valid');
                    resolve({ name: 'Caddyfile validation', success: true, message: 'Caddyfile is valid' });
                }
            });
        });
    }

    public async check(): Promise<SetupCheckResult> {

        console.log('STATUS - Checking caddy setup...')

        const { success, failedChecks } = await Promise.all([
            CaddySetupChecker.validateCaddyFile(),
        ])
            .then(results => {
                const success = results.every(r => r.success);
                const failedChecks = results.filter(r => !r.success);
                CaddySetupChecker.log.info({ task: 'check' }, `STATUS - Caddy setup is complete: ${success}`);
                failedChecks.length && CaddySetupChecker.log.warn({ task: 'check' }, `STATUS - Caddy setup failed checks: ${failedChecks}`);
                return { success, failedChecks };
            })
            .catch(reason => {
                CaddySetupChecker.log.error({ task: 'check' }, `STATUS - Checking Caddy setup failed: ${reason}`);
                return { success: false, failedChecks: ['Unexpected error: ' + reason] };
            });
        return {
            name: this.name,
            success: success,
            message: success ? 'Caddy setup is complete' : 'Caddy setup is incomplete',
            failedChecks
        };
    }
}