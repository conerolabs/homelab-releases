import { exec } from "node:child_process";
import type { ServiceSetupChecker, SetupCheckResult } from "./status.service.ts";

export class CaddySetupChecker implements ServiceSetupChecker {
    public readonly name: string = 'caddy';

    private static validateCaddyFile(): Promise<boolean> {
        console.log('  --> Checking caddy configuration...');
        return new Promise((resolve, reject) => {
            exec('docker compose run --no-deps --rm caddy caddy validate --config /etc/caddy/Caddyfile', (error, stdout, stderr) => {
                if (error) {
                    console.error('  --> [ERROR] Caddyfile is not valid');
                    console.error(stderr);
                    resolve(false);
                } else {
                    console.log('  --> [OK] Caddyfile is valid');
                    resolve(true);
                }
            });
        });
    }

    public async check(): Promise<SetupCheckResult> {

        console.log('STATUS - Checking caddy setup...')

        const success = await Promise.all([
            CaddySetupChecker.validateCaddyFile(),
        ])
            .then(results => {
                const success = results.every(r => r);
                console.log('STATUS - Caddy setup is complete:', success);
                return success;
            })
            .catch(reason => {
                console.error('[ERROR] STATUS - Checking Caddy setup:', reason);
                return false;
            });
        return { name: this.name, success, message: success ? 'Caddy setup is complete' : 'Caddy setup is incomplete' };
    }
}