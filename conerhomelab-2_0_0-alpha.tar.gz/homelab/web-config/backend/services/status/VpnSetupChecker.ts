import { exec, execSync } from "child_process";
import type { JobResult } from "../../../commons/dto.ts";
import { ConfigService } from "../config.service.ts";
import type { HLTask } from "../TasksManager.ts";
import { BaseSetupChecker } from "./BaseSetupChecker.ts";
import { getLogger } from "../../logger.ts";

interface DnsStatus {
    TailscaleDNS: boolean;
    CurrentTailnet: {
        MagicDNSEnabled: boolean;
        MagicDNSSuffix: string;
        SelfDNSName: string;
    };
    Resolvers: {
        Addr: string;
    }[];
    SplitDNSRoutes: {
        [key: string]: {
            Addr: string;
        }[];
    };
    SearchDomains: string[];
    CertDomains: string[];
    ExitNodeFilteredSet: string[];
    SystemDNSError: string | null;
}

export class VpnSetupChecker extends BaseSetupChecker {

    private static log = getLogger('VpnSetupChecker')

    private static tasks: HLTask<{}>[] = [
        BaseSetupChecker.getDockerImageCheckerTask('headscale-ui', 1, () => Promise.resolve({
            skip: ConfigService.getVpnMode() !== 'headscale',
            reason: 'VPN mode is not headscale'
        })),
        {
            name: 'check-operator',
            description: 'Check tailscale operator',
            action: VpnSetupChecker.checkOperator,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'check-login-url',
            description: 'Check tailscale login url',
            action: VpnSetupChecker.checkLoginUrl,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'check-api-key',
            description: 'Check tailscale api key',
            action: VpnSetupChecker.checkApiKey,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'check-dns-status',
            description: 'Check tailscale dns status',
            action: VpnSetupChecker.checkDnsStatus,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        }
    ];

    constructor() {
        super('tailscale');
    }

    override getTasks(): HLTask<{}>[] {
        return VpnSetupChecker.tasks;
    }

    private static async checkOperator(): Promise<JobResult> {
        const name = VpnSetupChecker.tasks[0].name;
        const log = VpnSetupChecker.log.child({ task: name });
        try {
            const operator = execSync("tailscale debug prefs | jq -r '.OperatorUser'", { encoding: 'utf-8' }).trim();
            if (operator === process.env.USER) {
                log.info(`  --> [OK] Tailscale operator is ${operator}`);
                return { name, service: 'vpn', success: true, message: `Tailscale operator is ${operator}` };
            } else {
                const msg = `Tailscale operator is ${operator}, but should be ${process.env.USER}`;
                log.warn(`  --> [ERROR] ${msg}`);
                return { name, service: 'vpn', success: false, message: msg };
            }
        } catch (e) {
            const msg = `Error checking tailscale operator: ${JSON.stringify(e)}`;
            log.warn(`  --> [ERROR] ${msg}`);
            return { name, service: 'vpn', success: false, message: msg };
        }
    }

    private static async checkLoginUrl(): Promise<JobResult> {
        const name = VpnSetupChecker.tasks[1].name;
        const log = VpnSetupChecker.log.child({ task_id: name })
        let msg = '';
        const vpnMode = ConfigService.getVpnMode();
        if (!vpnMode) {
            return { name, service: 'vpn', success: false, message: 'Vpn mode is not configured' };
        }
        if (vpnMode === 'none') {
            return { name, service: 'vpn', success: true, message: 'VPN is disabled (local network only)' };
        }
        try {
            const controlUrl = JSON.parse(execSync("tailscale debug prefs | jq .ControlURL", { encoding: 'utf-8' }));
            if (vpnMode === 'tailscale') {
                const tailscaleControlUrl = ConfigService.getEnv('TAILSCALE_LOGIN_URL');
                if (controlUrl && controlUrl != tailscaleControlUrl) {
                    msg = `Tailscale is configured on ${controlUrl} control plane, but should be ${tailscaleControlUrl} (VPN_MODE=${vpnMode})`;
                    log.warn('  --> [ERROR] ' + msg);
                    return { name, service: 'vpn', success: false, message: msg };
                }
            } else if (vpnMode === 'headscale') {
                const headscaleControlUrl = ConfigService.getEnv('HEADSCALE_SERVER_URL');
                if (controlUrl && controlUrl != headscaleControlUrl) {
                    msg = `Tailscale is configured on ${controlUrl} control plane, but should be ${headscaleControlUrl} (VPN_MODE=${vpnMode})`;
                    log.warn('  --> [ERROR] ' + msg);
                    return { name, service: 'vpn', success: false, message: msg };
                }
            }
            log.info(`  --> [OK] Tailscale control plane url: ${controlUrl || '[not set yet]'} (VPN_MODE=${vpnMode})`);
            return { name, service: 'vpn', success: true, message: `Tailscale is running on ${controlUrl || '[not set yet]'} control plane (VPN_MODE=${vpnMode})` };
        } catch (e) {
            msg = `Error checking tailscale control plane url: ${JSON.stringify(e)}`;
            log.warn('  --> [ERROR] ' + msg);
            return { name, service: 'vpn', success: false, message: msg };
        }
    }

    private static checkApiKey(): JobResult {
        const name = VpnSetupChecker.tasks[2].name;
        const log = VpnSetupChecker.log.child({ task_id: name });
        const vpnMode = ConfigService.getVpnMode();
        if (!vpnMode) {
            const msg = `Vpn mode is not configured`;
            log.warn(`  --> [ERROR] ${msg}`);
            return { name, service: 'vpn', success: false, message: msg };
        }
        if (vpnMode === 'none') {
            return { name, service: 'vpn', success: true, message: 'VPN is disabled (local network only)' };
        }
        const apiKey = ConfigService.getEnv(`${vpnMode.toUpperCase()}_API_KEY`)
        if (!apiKey) {
            const msg =
                `API key for ${vpnMode} is not configured.` +
                ` Homepage needs it to login into ${vpnMode} to get your devices and to check their status.` +
                (vpnMode === 'tailscale' ? ` You can get it from https://console.tailscale.com/admin/settings/keys` : '')
            log.warn(`  --> [ERROR] ${msg}`)
            return { name, service: 'vpn', success: false, message: msg };
        }
        log.info(`  --> [OK] API key for ${vpnMode} is configured`)
        return { name, service: 'vpn', success: true, message: `API key for ${vpnMode} is configured` };
    }

    private static checkDnsStatus(): JobResult {
        const name = VpnSetupChecker.tasks[3].name;
        const log = VpnSetupChecker.log.child({ task_id: name });
        const vpnMode = ConfigService.getVpnMode();
        if (!vpnMode) {
            const msg = `Vpn mode is not configured`;
            log.warn(`  --> [ERROR] ${msg}`)
            return { name, service: 'vpn', success: false, message: msg };
        }
        if (vpnMode === 'none') {
            return { name, service: 'vpn', success: true, message: 'VPN is disabled (local network only)' };
        }
        let dnsStatus: Partial<DnsStatus> | null = null;
        try {
            const stdout = execSync('tailscale dns status --json', { encoding: 'utf-8' }).trim();
            dnsStatus = JSON.parse(stdout);
        } catch (error) {
            const msg = `Error checking tailscale dns status: ${error}`;
            log.warn('  --> [ERROR] ' + msg);
            return { name, service: vpnMode, success: false, message: msg };
        }

        const tailscaleIp = ConfigService.getEnv('TAILSCALE_IP');

        if (!tailscaleIp) {
            const msg = `Tailscale IP not available. (Did you already log in?)`
            log.warn(`  --> [ERROR] ${msg}`)
            return { name, service: vpnMode, success: false, message: msg };
        }

        if (dnsStatus?.TailscaleDNS === true) {
            const msg =
                `Tailscale DNS is enabled for this node.` +
                ` This is the dns resolver node, it should not have it enabled.`
            log.warn(`  --> [ERROR] ${msg}`)
            return { name, service: vpnMode, success: false, message: msg };
        }

        const resolvers = dnsStatus?.Resolvers || [];
        if (resolvers.length === 0) {
            const msg =
                `Tailscale DNS nameservers are not configured. ` +
                (vpnMode === 'tailscale' ? `Configure it on https://console.tailscale.com/admin/dns` : '')
            log.warn(`  --> [ERROR] ${msg}`)
            return { name, service: vpnMode, success: false, message: msg };
        }
        if (resolvers[0].Addr !== tailscaleIp) {
            const msg =
                `Tailscale DNS nameservers are not configured with the local tailscale ip.` +
                (vpnMode === 'tailscale' ? ` Configure it on https://console.tailscale.com/admin/dns` : '');
            log.warn(`  --> [ERROR] ${msg}`)
            return { name, service: vpnMode, success: false, message: msg };
        }

        log.info(`  --> [OK] Tailscale DNS nameservers are configured with the local tailscale ip`)
        log.info(`  --> [OK] Tailscale DNS for this node is not enabled`)
        return { name, service: vpnMode, success: true, message: `Tailscale DNS is ${dnsStatus?.TailscaleDNS ? 'enabled' : 'not enabled'}` };
    }
}