import { exec } from "node:child_process";
import { existsSync } from "node:fs";
import type { JobResult } from "../../../commons/dto.ts";
import { ConfigService } from "../config.service.ts";
import { AutheliaConfigHelper } from "../hlservices/AutheliaConfigHelper.ts";
import { getLogger } from "../../logger.ts";
import { getDockerImageInfo } from "../../docker-utils.ts";
import { type HLTask } from "../TasksManager.ts";
import { BaseSetupChecker } from "./BaseSetupChecker.ts";

export class AutheliaSetupChecker extends BaseSetupChecker {
    private static log = getLogger('AutheliaSetupChecker');

    private static CLIENTS_HASHED_SECRETS = AutheliaConfigHelper.CLIENT_SECRETS.map(s => s.hashEnvVar);

    constructor() {
        super('authelia');
    }

    private static checkTasks: HLTask[] = [
        {
            name: 'secrets',
            description: 'Check authelia secrets',
            action: AutheliaSetupChecker.checkSecretFiles,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'clients-secrets',
            description: 'Check authelia clients secrets',
            action: AutheliaSetupChecker.checkCliSecrets,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'client-ids',
            description: 'Check authelia client ids',
            action: AutheliaSetupChecker.checkClientIds,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        },
        {
            name: 'authelia-config',
            description: 'Check authelia config',
            action: AutheliaSetupChecker.configFilesValidation,
            skip: async () => {
                return await getDockerImageInfo('authelia').then(
                    imageInfo => imageInfo ? { skip: false } : { skip: true, reason: 'Authelia docker image is not available' }
                ).catch(error => ({ skip: true, reason: error.message }))
            },
            weight: 1
        },
        {
            name: 'clients-secret-hash',
            description: 'Check authelia clients secret hash',
            action: AutheliaSetupChecker.checkClientsSecretHash,
            skip: () => Promise.resolve({ skip: false }),
            weight: 1
        }
    ];

    public override getTasks(): HLTask[] {
        return AutheliaSetupChecker.checkTasks;
    }

    private static checkSecretFiles(): JobResult {
        const log = AutheliaSetupChecker.log.child({ task_id: 'autheliaCheckSecrets' })
        try {
            log.info('  --> Checking authelia secrets...');
            const result = AutheliaConfigHelper.AUTHELIA_SECRETS.every(s => existsSync(s.path));
            if (result) {
                log.info('  --> [OK] All authelia secrets are present');
                return { name: 'secrets', success: true, message: 'All authelia secrets are present' };
            } else {
                const missingFiles = AutheliaConfigHelper.AUTHELIA_SECRETS.filter(s => !existsSync(s.path)).map(s => s.path);
                log.warn('  --> [ERROR] Some authelia secrets are missing: ' + missingFiles);
                return {
                    name: 'secrets',
                    success: false,
                    message: 'Some authelia secrets are missing',
                    failedTasks: missingFiles
                };
            }
        } catch (error) {
            log.error('  --> [ERROR] Checking authelia secrets: ' + error);
            return {
                name: 'secrets',
                success: false,
                message: 'Error checking authelia secrets' + String(error)
            };
        }
    }

    private static checkCliSecrets(): JobResult {
        const log = AutheliaSetupChecker.log.child({ task_id: 'checkClientSecrets' })
        try {
            log.info('  --> Checking authelia clients secrets...');
            const result = AutheliaConfigHelper.CLIENT_SECRETS.every(s => existsSync(s.path));
            if (result) {
                log.info('  --> [OK] All authelia clients secrets are present');
                return { name: 'clients-secrets', success: true, message: 'All authelia clients secrets are present' };
            } else {
                const missingClients = AutheliaConfigHelper.CLIENT_SECRETS.filter(s => !existsSync(s.path)).map(s => s.client);
                log.warn({ missing: missingClients }, '  --> [ERROR] Some authelia clients secrets are missing');
                return {
                    name: 'clients-secrets',
                    success: false,
                    message: 'Some authelia clients secrets are missing',
                    failedTasks: missingClients
                };
            }
        } catch (error) {
            log.error('  --> [ERROR] Checking authelia clients secrets: ' + error);
            return {
                name: 'clients-secrets',
                success: false,
                message: 'Error checking authelia clients secrets' + String(error)
            };
        }
    }

    private static checkClientIds(): JobResult {
        const clientIdEnvVar = (c: string) => c.toUpperCase().replaceAll('-', '') + '_OIDC_CLIENT_ID';

        const log = AutheliaSetupChecker.log.child({ task_id: 'checkClientIds' })
        try {
            log.info('  --> Checking authelia client ids...');
            const result = AutheliaConfigHelper.CLIENTS.every(c => ConfigService.getEnv(clientIdEnvVar(c)));
            if (result) {
                log.info('  --> [OK] All authelia client ids are present');
                return { name: 'client-ids', success: true, message: 'All authelia client ids are present' };
            } else {
                const missingClients = AutheliaConfigHelper.CLIENTS.filter(c => !ConfigService.getEnv(clientIdEnvVar(c)));
                log.warn({ missing: missingClients }, '  --> [ERROR] Some authelia client ids are missing');
                return {
                    name: 'client-ids',
                    success: false,
                    message: 'Some authelia client ids are missing',
                    failedTasks: missingClients
                };
            }
        } catch (error) {
            log.error('  --> [ERROR] Checking authelia client ids: ' + error);
            return {
                name: 'client-ids',
                success: false,
                message: 'Error checking authelia client ids' + String(error)
            };
        }
    }

    private static async configFilesValidation(): Promise<JobResult> {
        const log = AutheliaSetupChecker.log.child({ task_id: 'autheliaConfigValidation' });
        log.info('  --> Checking authelia configuration...');
        return await new Promise<JobResult>((resolve, reject) => {
            exec('docker compose run --no-deps --rm authelia authelia config validate --config /config/config.yml --config /config/config.oidc.yml', (error, stdout, stderr) => {
                if (error) {
                    log.error('  --> [ERROR] Authelia config is not valid');
                    log.error(stderr);
                    resolve({
                        name: 'authelia-config',
                        success: false,
                        message: 'Authelia config is not valid - ' + stderr
                    });
                } else {
                    log.info('  --> [OK] Authelia config is valid');
                    resolve({
                        name: 'authelia-config',
                        success: true,
                        message: 'Authelia config is valid'
                    });
                }
            });
        });
    }

    private static checkClientsSecretHash(): JobResult {
        const log = AutheliaSetupChecker.log.child({ task_id: 'cliSecretHashCheck' })
        log.info('  --> Checking authelia clients secret hash...');
        const result = AutheliaSetupChecker.CLIENTS_HASHED_SECRETS
            .map(env => ConfigService.getEnv(env))
            .every(hash => !!hash); //TODO: implement real validation
        if (result) {
            log.info('  --> [OK] All authelia clients secrets hashes are present');
            return { name: 'clients-secrets', success: true, message: 'All authelia clients secrets hashes are present' };
        } else {
            log.warn('  --> [ERROR] Some authelia clients secrets hashes are missing');
            const missingClients = AutheliaSetupChecker.CLIENTS_HASHED_SECRETS.filter(env => !ConfigService.getEnv(env));
            log.warn('  --> [ERROR] Missing clients secrets hashes: ' + missingClients);
            return {
                name: 'clients-secrets-hashes',
                success: false,
                message: 'Some authelia clients secrets hashes are missing',
                failedTasks: missingClients
            };
        }
    }
}