import { exec } from "node:child_process";
import { existsSync } from "node:fs";
import type { ServiceSetupChecker } from "./status.service.ts";
import type { SetupCheckResult } from "../../../commons/dto.ts";
import { ConfigService } from "../config.service.ts";
import { AutheliaConfigHelper } from "../hlservices/AutheliaConfigHelper.ts";
import { getLogger } from "../../logger.ts";

export class AutheliaSetupChecker implements ServiceSetupChecker {
    public readonly name: string = 'authelia';
    private static log = getLogger('AutheliaSetupChecker');

    private static CLIENTS_HASHED_SECRETS = AutheliaConfigHelper.CLIENT_SECRETS.map(s => s.hashEnvVar);

    private static checkSecretFiles(): SetupCheckResult {
        const log = AutheliaSetupChecker.log.child({ task_id: 'autheliaCheckSecrets' })
        try {
            log.info('  --> Checking authelia secrets...');
            const result = AutheliaConfigHelper.AUTHELIA_SECRETS.every(s => existsSync(s.path));
            if (result) {
                log.info('  --> [OK] All authelia secrets are present');
                return { name: 'secrets', success: true, message: 'All authelia secrets are present' };
            } else {
                const missingFiles = AutheliaConfigHelper.AUTHELIA_SECRETS.filter(s => !existsSync(s.path)).map(s => s.path);
                log.warn('  --> [ERROR] Some authelia secrets are missing: ' + missingFiles);
                return {
                    name: 'secrets',
                    success: false,
                    message: 'Some authelia secrets are missing',
                    failedChecks: missingFiles
                };
            }
        } catch (error) {
            log.error('  --> [ERROR] Checking authelia secrets: ' + error);
            return {
                name: 'secrets',
                success: false,
                message: 'Error checking authelia secrets' + String(error)
            };
        }
    }

    private static autheliaConfigFilesValidation(): Promise<SetupCheckResult> {
        const log = AutheliaSetupChecker.log.child({ task_id: 'autheliaConfigValidation' });
        log.info('  --> Checking authelia configuration...');
        return new Promise((resolve, reject) => {
            exec('docker compose run --no-deps --rm authelia authelia config validate --config /config/config.yml --config /config/config.oidc.yml', (error, stdout, stderr) => {
                if (error) {
                    log.error('  --> [ERROR] Authelia config is not valid');
                    log.error(stderr);
                    resolve({
                        name: 'config',
                        success: false,
                        message: 'Authelia config is not valid - ' + stderr
                    });
                } else {
                    log.info('  --> [OK] Authelia config is valid');
                    resolve({
                        name: 'config',
                        success: true,
                        message: 'Authelia config is valid'
                    });
                }
            });
        });
    }

    private static autheliaCheckClientsSecretHash(): SetupCheckResult {
        const log = AutheliaSetupChecker.log.child({ task_id: 'autheliaCliSecretHashCheck' })
        log.info('  --> Checking authelia clients secret hash...');
        const result = AutheliaSetupChecker.CLIENTS_HASHED_SECRETS
            .map(env => ConfigService.getEnv(env))
            .every(hash => !!hash); //TODO: implement real validation
        if (result) {
            log.info('  --> [OK] All authelia clients secrets hashes are present');
            return { name: 'clients-secrets', success: true, message: 'All authelia clients secrets hashes are present' };
        } else {
            log.warn('  --> [ERROR] Some authelia clients secrets hashes are missing');
            const missingClients = AutheliaSetupChecker.CLIENTS_HASHED_SECRETS.filter(env => !ConfigService.getEnv(env));
            log.warn('  --> [ERROR] Missing clients secrets hashes: ' + missingClients);
            return {
                name: 'clients-secrets',
                success: false,
                message: 'Some authelia clients secrets hashes are missing',
                failedChecks: missingClients
            };
        }
    }

    public async check(): Promise<SetupCheckResult> {

        AutheliaSetupChecker.log.info('STATUS - Checking authelia setup...')

        const results = await Promise.all([
            AutheliaSetupChecker.autheliaCheckClientsSecretHash(),
            AutheliaSetupChecker.autheliaConfigFilesValidation(),
            AutheliaSetupChecker.checkSecretFiles()
        ])
            .then(results => {
                const failedChecks = results.filter(r => !r.success);
                const success = failedChecks.length === 0;
                AutheliaSetupChecker.log.info('STATUS - Authelia setup is complete: ' + success);
                return {
                    name: this.name,
                    success,
                    message: success ? 'Authelia setup is complete' : 'Authelia setup is incomplete',
                    failedChecks
                };
            })
            .catch(reason => {
                AutheliaSetupChecker.log.error('[ERROR] STATUS - Checking authelia config: ' + reason);
                return { name: this.name, success: false, message: reason.toString() };
            });
        return results;
    }
}