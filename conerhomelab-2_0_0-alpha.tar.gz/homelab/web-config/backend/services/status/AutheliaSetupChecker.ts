import { exec } from "node:child_process";
import { existsSync } from "node:fs";
import path from "node:path";
import type { ServiceSetupChecker, SetupCheckResult } from "./status.service.ts";

export class AutheliaSetupChecker implements ServiceSetupChecker {
    public readonly name: string = 'authelia';

    private static CLIENTS_HASHED_SECRETS = [
        "AUTHELIA_VAULTWARDEN_SECRET_HASH",
        "AUTHELIA_GATUS_SECRET_HASH",
        "AUTHELIA_RUSTICAL_SECRET_HASH",
        "AUTHELIA_WEBCONFIG_SECRET_HASH",
        "AUTHELIA_HEADSCALE_SECRET_HASH"
    ];

    private static SECRET_FILES = [
        "JWT_SECRET",
        "SESSION_SECRET",
        "storage_encryption_key.txt",
        "OIDC_HMAC_SECRET",
        "oidc_jwks_key.pem"
    ];

    private static checkSecretFiles(): boolean {
        const installDir = process.env.INSTALL_DIR;
        if (!installDir) {
            console.error('  --> [ERROR] INSTALL_DIR is not defined');
            return false;
        }
        const secretsDir = path.join(installDir, 'authelia/secrets');
        try {
            console.log('  --> Checking authelia secrets...');
            const result = AutheliaSetupChecker.SECRET_FILES.every(file => existsSync(path.join(secretsDir, file)));
            if (result) {
                console.log('  --> [OK] All authelia secrets are present');
                return true;
            } else {
                const missingFiles = AutheliaSetupChecker.SECRET_FILES.filter(file => !existsSync(path.join(secretsDir, file)));
                console.log('  --> [ERROR] Some authelia secrets are missing:', missingFiles);
                return false;
            }
        } catch (error) {
            console.error('  --> [ERROR] Checking authelia secrets:', error);
            return false;
        }
    }

    private static autheliaConfigFilesValidation(): Promise<boolean> {
        console.log('  --> Checking authelia configuration...');
        return new Promise((resolve, reject) => {
            exec('docker compose run --no-deps --rm authelia authelia config validate --config /config/config.yml --config /config/config.oidc.yml', (error, stdout, stderr) => {
                if (error) {
                    console.error('  --> [ERROR] Authelia config is not valid');
                    console.error(stderr);
                    resolve(false);
                } else {
                    console.log('  --> [OK] Authelia config is valid');
                    resolve(true);
                }
            });
        });
    }

    private static autheliaCheckClientsSecretHash(): boolean {
        console.log('  --> Checking authelia clients secret hash...');
        const result = AutheliaSetupChecker.CLIENTS_HASHED_SECRETS.map(env => process.env[env]).every(hash => !!hash);
        if (result) {
            console.log('  --> [OK] All authelia clients secrets hashes are present');
            return true;
        } else {
            console.log('  --> [ERROR] Some authelia clients secrets hashes are missing');
            return false;
        }
    }

    public async check(): Promise<SetupCheckResult> {

        console.log('STATUS - Checking authelia setup...')

        const success = await Promise.all([
            AutheliaSetupChecker.autheliaCheckClientsSecretHash(),
            AutheliaSetupChecker.autheliaConfigFilesValidation(),
            AutheliaSetupChecker.checkSecretFiles()
        ])
            .then(results => {
                const success = results.every(r => r);
                console.log('STATUS - Authelia setup is complete:', success);
                return success;
            })
            .catch(reason => {
                console.error('[ERROR] STATUS - Checking authelia config:', reason);
                return false;
            });
        return { name: this.name, success, message: success ? 'Authelia setup is complete' : 'Authelia setup is incomplete' };
    }
}