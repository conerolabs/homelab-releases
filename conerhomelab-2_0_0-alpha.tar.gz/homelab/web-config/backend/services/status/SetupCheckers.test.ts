import test from "node:test";
import assert from "node:assert";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { AutheliaSetupChecker } from "./AutheliaSetupChecker.ts";
import { CaddySetupChecker } from "./CaddySetupChecker.ts";
import { PiholeSetupChecker } from "./PiholeSetupChecker.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ENV_PATH = path.join(__dirname, '../../../../.env');
process.loadEnvFile(ENV_PATH);

const skip = [
    'Authelia Setup Test',
    'Caddy Setup Test',
    'Pi-Hole Setup Test',
    // 'Unbound Setup Test',
    // 'Tailscale Setup Test'
]

test('Authelia Setup Test', async (t) => {
    if (skip.includes('Authelia Setup Test')) {
        t.skip();
        return;
    }
    const result = await new AutheliaSetupChecker().check();
    assert.strictEqual(result.success, true);
})

test('Caddy Setup Test', async (t) => {
    if (skip.includes('Caddy Setup Test')) {
        t.skip();
        return;
    }
    const result = await new CaddySetupChecker().check();
    assert.strictEqual(result.success, true);
})

test('Pi-Hole Setup Test', async (t) => {
    if (skip.includes('Pi-Hole Setup Test')) {
        t.skip();
        return;
    }
    const result = await new PiholeSetupChecker().check();
    assert.strictEqual(result.success, true);
})