import { Router } from 'express';
import { StatusController } from '../controllers/status.controller.ts';

export const statusRouter = Router();

statusRouter.get('/', StatusController.getStatus);
statusRouter.get('/admin', StatusController.getAdminStatus);
statusRouter.get('/deps', StatusController.getDepsStatus);
statusRouter.get('/services', StatusController.getServicesStatus);
statusRouter.get('/service/:name', StatusController.getServiceStatus);