import { Router } from 'express';
import { DepsController } from '../controllers/deps.controller.ts';

export const depsRouter = Router();

depsRouter.get('/install', DepsController.install);
depsRouter.get('/install/:name', DepsController.installSingle);
depsRouter.get('/uninstall/:name', DepsController.uninstall);
depsRouter.get('/status', DepsController.getStatus);
depsRouter.get('/status/:name', DepsController.getDepStatus);
depsRouter.get('/required/status', DepsController.getRequiredDepsStatus);
