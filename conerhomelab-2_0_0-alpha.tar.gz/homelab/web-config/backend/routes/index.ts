import { Router } from 'express';
import { auth } from '../oidc-utils.ts';
import { configRouter } from './config.routes.ts';
import { systemRouter } from './system.routes.ts';
import { servicesRouter } from './services.routes.ts';
import { depsRouter } from './deps.routes.ts';
import { ipRouter } from './ip.routes.ts';
import { ServicesController } from '../controllers/services.controller.ts';
import { userRouter } from './user.routes.ts';
import { statusRouter } from './status.router.ts';

const authMiddleware = auth(process.env.NODE_ENV === 'production');

export const apiRouter = Router();

apiRouter.use('/config', authMiddleware, configRouter);
apiRouter.get('/deploy', authMiddleware, ServicesController.deploy);
apiRouter.use('/system', authMiddleware, systemRouter);
apiRouter.use('/service', authMiddleware, servicesRouter);
apiRouter.use('/status', authMiddleware, statusRouter);
apiRouter.use('/deps', authMiddleware, depsRouter);
apiRouter.use('/user', userRouter);
apiRouter.use('/ip', ipRouter);
