import { Router } from 'express';
import { auth } from '../oidc-utils.ts';
import { configRouter } from './config.routes.ts';
import { systemRouter } from './system.routes.ts';
import { servicesRouter } from './services.routes.ts';
import { depsRouter } from './deps.routes.ts';
import { ipRouter } from './ip.routes.ts';
import { ServicesController } from '../controllers/services.controller.ts';
import { userRouter } from './user.routes.ts';
import { statusRouter } from './status.routes.ts';

export class ApiRouter {
    private static instance: ApiRouter | null = null;
    public readonly router: Router;

    private constructor(authRequired: boolean) {
        if (ApiRouter.instance !== null) return;
        const authMiddleware = auth(authRequired);
        this.router = Router();
        this.router.use('/config', authMiddleware, configRouter);
        this.router.get('/deploy', authMiddleware, ServicesController.deploy);
        this.router.use('/system', authMiddleware, systemRouter);
        this.router.use('/service', authMiddleware, servicesRouter);
        this.router.use('/status', authMiddleware, statusRouter);
        this.router.use('/deps', authMiddleware, depsRouter);
        this.router.use('/user', userRouter);
        this.router.use('/ip', ipRouter);
    }

    public static getInstance(authRequired: boolean): ApiRouter {
        if (ApiRouter.instance === null) {
            ApiRouter.instance = new ApiRouter(authRequired);
        }
        return ApiRouter.instance;
    }
}

