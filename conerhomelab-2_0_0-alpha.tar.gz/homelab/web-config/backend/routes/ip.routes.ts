import { Router } from 'express';
import { IpController } from '../controllers/ip.controller.ts';

export const ipRouter = Router();

ipRouter.get('/', IpController.getIp);
