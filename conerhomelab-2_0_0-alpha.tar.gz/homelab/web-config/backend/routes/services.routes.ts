import { Router } from 'express';
import { ServicesController } from '../controllers/services.controller.ts';

export const servicesRouter = Router();

servicesRouter.get('/:name/status', ServicesController.getServiceStatus);
servicesRouter.get('/:name/health', ServicesController.getServiceStatus);
servicesRouter.get('/:name/setup', ServicesController.setupService);
servicesRouter.get('/:name/:action', ServicesController.executeServiceAction);
