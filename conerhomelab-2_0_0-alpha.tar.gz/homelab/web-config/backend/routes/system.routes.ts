import { Router } from 'express';
import { SystemController } from '../controllers/system.controller.ts';

export const systemRouter = Router();

systemRouter.post('/sudo', SystemController.handleSudoPost);
systemRouter.get('/sudo', SystemController.handleSudoGet);
systemRouter.get('/network', SystemController.getNetworkInfo);
