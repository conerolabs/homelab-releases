import { Router } from 'express';
import { UsersController } from '../controllers/users.controller.ts';

export const userRouter = Router();

userRouter.post('/register', UsersController.register);
