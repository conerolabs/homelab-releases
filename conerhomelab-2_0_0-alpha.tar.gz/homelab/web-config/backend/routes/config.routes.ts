import { Router } from 'express';
import { ConfigController } from '../controllers/config.controller.ts';

export const configRouter = Router();

configRouter.get('/', ConfigController.getConfig);
configRouter.post('/', ConfigController.saveConfig);
configRouter.get('/reload', ConfigController.reloadConfig);
