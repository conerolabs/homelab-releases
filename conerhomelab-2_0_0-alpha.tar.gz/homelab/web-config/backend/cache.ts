export interface CacheOptions {
    /** Default TTL in milliseconds. Defaults to 0 (no expiration). */
    ttl?: number;
}

export interface SetCacheOptions {
    /** TTL in milliseconds for this specific entry. Overrides default TTL. */
    ttl?: number;
    /** If true, the entry is immediately considered expired. */
    expired?: boolean;
}

export interface CacheEntry<V> {
    value: V;
    lastUpdate: number;
    ttl: number;
    expired?: boolean;
}

export class Cache<K, V> {
    private entries = new Map<K, CacheEntry<V>>();
    private defaultTtl: number;
    private _lastUpdate = 0;

    constructor(options?: CacheOptions) {
        this.defaultTtl = options?.ttl ?? 0;
    }

    public get ttl(): number {
        return this.defaultTtl;
    }

    public set ttl(value: number) {
        this.defaultTtl = value;
    }

    public get lastUpdate(): number {
        return this._lastUpdate;
    }

    public get size(): number {
        return this.entries.size;
    }

    /**
     * Store a value in the cache with an optional custom TTL or options.
     * @param key Cache key
     * @param value Value to store
     * @param options TTL in milliseconds or SetCacheOptions
     */
    public set(key: K, value: V, options?: SetCacheOptions | number): void {
        const now = Date.now();
        let ttl = this.defaultTtl;
        let expired = false;

        if (typeof options === 'number') {
            ttl = options;
        } else if (options && typeof options === 'object') {
            if (options.ttl !== undefined) ttl = options.ttl;
            if (options.expired !== undefined) expired = options.expired;
        }

        this.entries.set(key, {
            value,
            lastUpdate: now,
            ttl,
            expired,
        });
        this._lastUpdate = now;
    }

    /**
     * Mark an entry as expired without removing it from the cache.
     */
    public expire(key: K): void {
        const entry = this.entries.get(key);
        if (entry) {
            entry.expired = true;
        }
    }

    /**
     * Retrieve the raw cache entry with metadata (value, lastUpdate, ttl, isExpired).
     */
    public getEntry(key: K): (CacheEntry<V> & { isExpired: boolean }) | undefined {
        const entry = this.entries.get(key);
        if (!entry) return undefined;
        return {
            ...entry,
            isExpired: this.isEntryExpired(entry),
        };
    }

    /**
     * Retrieve a value from the cache if it has not expired.
     * Returns undefined if key is missing or expired.
     */
    public get(key: K): V | undefined {
        const entry = this.entries.get(key);
        if (!entry || this.isEntryExpired(entry)) {
            return undefined;
        }
        return entry.value;
    }

    /**
     * Retrieve a value from the cache even if it has expired (peek without TTL filter).
     * Returns undefined if key is not found.
     */
    public peek(key: K): V | undefined {
        return this.entries.get(key)?.value;
    }

    /**
     * Checks if a key exists in cache and has expired (or does not exist).
     */
    public isExpired(key: K): boolean {
        const entry = this.entries.get(key);
        if (!entry) return true;
        return this.isEntryExpired(entry);
    }

    /**
     * Checks if the entire cache is expired based on default TTL from lastUpdate.
     */
    public isCacheExpired(): boolean {
        if (!this._lastUpdate || this.defaultTtl <= 0) return true;
        return Date.now() - this._lastUpdate > this.defaultTtl;
    }

    /**
     * Checks if a key exists in the cache.
     * @param key Cache key
     * @param allowExpired If true, returns true even if the entry is expired
     */
    public has(key: K, allowExpired = false): boolean {
        const entry = this.entries.get(key);
        if (!entry) return false;
        return allowExpired || !this.isEntryExpired(entry);
    }

    /**
     * Delete an entry from the cache.
     */
    public delete(key: K): boolean {
        return this.entries.delete(key);
    }

    /**
     * Clear all entries from the cache.
     */
    public clear(): void {
        this.entries.clear();
        this._lastUpdate = Date.now();
    }

    /**
     * Get all keys in the cache.
     * @param allowExpired If true (default), returns all keys regardless of expiration.
     */
    public keys(allowExpired = true): K[] {
        if (allowExpired) {
            return Array.from(this.entries.keys());
        }
        const activeKeys: K[] = [];
        for (const [key, entry] of this.entries.entries()) {
            if (!this.isEntryExpired(entry)) {
                activeKeys.push(key);
            }
        }
        return activeKeys;
    }

    /**
     * Get all values in the cache.
     * @param allowExpired If true (default), returns all values regardless of expiration.
     */
    public values(allowExpired = true): V[] {
        if (allowExpired) {
            return Array.from(this.entries.values()).map(e => e.value);
        }
        const activeValues: V[] = [];
        for (const entry of this.entries.values()) {
            if (!this.isEntryExpired(entry)) {
                activeValues.push(entry.value);
            }
        }
        return activeValues;
    }

    /**
     * Evict expired entries from the cache.
     * @returns Number of evicted entries.
     */
    public purgeExpired(): number {
        let purgedCount = 0;
        for (const [key, entry] of this.entries.entries()) {
            if (this.isEntryExpired(entry)) {
                this.entries.delete(key);
                purgedCount++;
            }
        }
        return purgedCount;
    }

    private isEntryExpired(entry: CacheEntry<V>): boolean {
        if (entry.expired || !entry.lastUpdate) return true;
        if (!entry.ttl || entry.ttl <= 0) return false;
        return Date.now() - entry.lastUpdate > entry.ttl;
    }
}
