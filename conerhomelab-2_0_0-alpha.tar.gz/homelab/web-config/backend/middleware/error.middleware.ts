import type { Request, Response, NextFunction } from 'express';

export function errorHandler(
    err: any,
    req: Request,
    res: Response,
    next: NextFunction
): void {
    console.error('GLOBAL ERROR:', err);

    const statusCode = err.status || err.statusCode || 500;
    const message = err.message || 'An unexpected error occurred';

    res.status(statusCode).json({
        error: message,
        details: err.details || null,
    });
}
