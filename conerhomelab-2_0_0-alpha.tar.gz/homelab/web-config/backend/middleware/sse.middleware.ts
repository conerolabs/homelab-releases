import type { Request, Response, NextFunction } from 'express';
import type { ChildProcessByStdio, ChildProcess } from 'child_process';
import type Stream from 'node:stream';

export type ConsoleSSEType = 'log' | 'stdout' | 'stderr' | 'done' | 'error';

export interface ConsoleSSEPayload {
    type: ConsoleSSEType | string;
    code?: number;
    text?: string;
    [key: string]: unknown;
}

export interface SSEResponse {
    /** Initialize SSE response headers (Content-Type: text/event-stream, etc.) */
    init(): void;
    /** Send a JSON-formatted SSE message in the shell.service format: data: {"type": "...", ...payload}\n\n */
    send(type: ConsoleSSEType | string, payload?: Record<string, unknown>): void;
    /** Send a custom object SSE message: data: {"key": "val"}\n\n */
    send(data: Record<string, unknown>): void;
    /** Stream an array of objects as SSE messages: data: {"key": "val"}\n\n */
    streamData(type: string, data: Record<string, unknown>[]): void;
    /** Send a standard named SSE event: event: <name>\ndata: <data>\n\n */
    sendEvent(event: string, data: unknown): void;
    /** Send an SSE comment (keep-alive ping): : <comment>\n\n */
    sendComment(comment?: string): void;
    /** Start sending periodic keep-alive comments to prevent connection timeouts */
    keepAlive(intervalMs?: number): () => void;
    /** Stream stdio/error/close events from a ChildProcess as SSE messages */
    streamChildProcess(
        child: ChildProcess | ChildProcessByStdio<Stream.Writable | null, Stream.Readable | null, Stream.Readable | null>,
        description?: string,
        /** Whether the stream should end when the child process closes. Defaults to true. */
        onClose?: (exitCode: number | null) => void
    ): void;
}

declare global {
    namespace Express {
        interface Response {
            sse?: SSEResponse;
        }
    }
}

/**
 * Creates an SSEResponse helper bound to the given Request and Response objects.
 */
export function createSSEResponse(req: Request, res: Response): SSEResponse {
    let keepAliveTimer: NodeJS.Timeout | null = null;

    const cleanup = () => {
        if (keepAliveTimer) {
            clearInterval(keepAliveTimer);
            keepAliveTimer = null;
        }
    };

    const endResponse = (exitCode: number | null) => {
        sse.send('done', { exitCode });
        res.end();
    };


    if (res) {
        res.on('finish', cleanup);
        res.on('close', cleanup);
    }

    const sse: SSEResponse = {
        init() {
            if (res.headersSent) return;
            res.writeHead(200, {
                'Content-Type': 'text/event-stream',
                'Cache-Control': 'no-cache, no-transform',
                'Connection': 'keep-alive',
                'X-Accel-Buffering': 'no',
            });
            if (typeof res.flushHeaders === 'function') {
                res.flushHeaders();
            }
        },

        send(typeOrPayload: string | Record<string, unknown>, payload: Record<string, unknown> = {}) {
            if (!res.headersSent) {
                sse.init();
            }

            let dataObj: Record<string, unknown>;
            if (typeof typeOrPayload === 'string') {
                dataObj = { type: typeOrPayload, ...payload };
            } else {
                dataObj = typeOrPayload;
            }

            res.write(`data: ${JSON.stringify(dataObj)}\n\n`);
            if (typeof (res as any).flush === 'function') {
                (res as any).flush();
            }
        },

        streamData(type: string, data: Record<string, unknown>[]) {
            data.map((d) => sse.send(type, d));
        },

        sendEvent(event: string, data: unknown) {
            if (!res.headersSent) {
                sse.init();
            }
            const dataStr = typeof data === 'string' ? data : JSON.stringify(data);
            res.write(`event: ${event}\ndata: ${dataStr}\n\n`);
            if (typeof (res as any).flush === 'function') {
                (res as any).flush();
            }
        },

        sendComment(comment: string = 'ping') {
            if (!res.headersSent) {
                sse.init();
            }
            res.write(`: ${comment}\n\n`);
            if (typeof (res as any).flush === 'function') {
                (res as any).flush();
            }
        },

        keepAlive(intervalMs: number = 15000) {
            cleanup();
            keepAliveTimer = setInterval(() => {
                if (!res.writableEnded) {
                    sse.sendComment('keep-alive');
                }
            }, intervalMs);
            return cleanup;
        },

        streamChildProcess(child, description = 'command', onClose: (exitCode: number | null) => void = endResponse) {
            if (!res.headersSent) {
                sse.init();
            }

            const kill = () => {
                if (!child.killed && child.exitCode === null) {
                    try {
                        child.kill('SIGTERM');
                    } catch {
                        // child may have already terminated
                    }
                }
            };

            if (req) {
                req.on('close', kill);
            }

            child.stdout?.on('data', (data: Buffer | string) => {
                sse.send('log', { text: data.toString() });
            });

            child.stderr?.on('data', (data: Buffer | string) => {
                sse.send('log', { text: data.toString() });
            });

            child.on('error', (err: Error) => {
                sse.send('error', { text: `Failed to execute ${description}: ${err.message}` });
            });

            child.on('close', (code: number | null) => {
                if (req) {
                    req.off('close', kill);
                }
                sse.send('done', { code })
                onClose(code);
            });
        },
    };

    return sse;
}

/**
 * Express middleware that attaches `res.sse` helper to the response object.
 * Set `autoInit: true` in options to immediately send SSE headers upon request.
 */
export function sseMiddleware(options?: { autoInit?: boolean }) {
    return (req: Request, res: Response, next: NextFunction): void => {
        res.sse = createSSEResponse(req, res);
        if (options?.autoInit) {
            res.sse.init();
        }
        next();
    };
}
