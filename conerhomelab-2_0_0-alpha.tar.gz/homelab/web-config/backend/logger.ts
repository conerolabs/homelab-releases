import pino from "pino";

const log: pino.Logger = initLogger();

function initLogger() {
    const colorizedStdOutTransport = pino.transport({
        target: 'pino-pretty',
        options: {
            colorize: true,
        }
    });
    const lokiTransport = process.env.NODE_ENV !== 'production' ? pino.transport({
        target: 'pino-loki',
        options: {
            host: 'http://localhost:3100',
            batching: true,
            interval: 3, // flush every 3 seconds
            labels: {
                env: process.env.NODE_ENV || 'development'
            }
        }
    }) : null;
    if (process.env.NODE_ENV === 'production') {
        return pino(
            { level: process.env.LOG_LEVEL || 'debug' },
            colorizedStdOutTransport
        );
    }
    else {
        const transport = pino.multistream([
            { stream: colorizedStdOutTransport, level: process.env.LOG_LEVEL || 'debug' },
            { stream: lokiTransport }
        ]);
        return pino({ level: process.env.LOG_LEVEL || 'debug' }, transport);
    }
}

export function getLogger(service: string) {
    return log.child({ service });
}
