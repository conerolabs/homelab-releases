import pino from "pino";
import pinoLoki from "pino-loki";
import pinoPretty from "pino-pretty"

export function getLogger(service: string) {
    const colorizedStdOutTransport = pino.transport({
        target: 'pino-pretty',
        options: {
            colorize: true,
        }
    });
    const lokiTransport = pino.transport({
        target: 'pino-loki',
        options: {
            host: 'http://localhost:3100',
            batching: true,
            interval: 3, // flush every 3 seconds
            labels: {
                service,
                env: process.env.NODE_ENV || 'development'
            }
        }
    })
    if (process.env.NODE_ENV === 'production') {
        return pino(
            { level: process.env.LOG_LEVEL || 'debug', name: service },
            colorizedStdOutTransport
        );
    }
    else {
        const transport = pino.multistream([
            { stream: colorizedStdOutTransport, level: process.env.LOG_LEVEL || 'debug' },
            { stream: lokiTransport }
        ]);
        return pino({ level: process.env.LOG_LEVEL || 'debug', name: service }, transport);
    }
}

export function getChildLogger(logger: pino.Logger, child: string) {
    return logger.child({ child });
}
