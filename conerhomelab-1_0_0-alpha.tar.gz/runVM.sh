#!/bin/bash
set -eo pipefail

VM_NAME="armbian"
SNAPSHOT_TYPE=${1:-latest}

VM_SNAPSHOT=$(virsh snapshot-list "$VM_NAME" | grep "$SNAPSHOT_TYPE" | awk '{print $1; exit}')

echo "Starting a $VM_NAME VM from snapshot: $VM_SNAPSHOT..."
if [[ $(virsh domstate "$VM_NAME") != "running" ]]; then
    echo "VM is not running, starting..."
    virsh start "$VM_NAME"
fi

# wait VM to boot up
echo "Waiting for VM to boot up and become available via ssh..."

VM_IP=$(virsh domifaddr "$VM_NAME" | grep 'ipv4' | awk '{print $NF}' | cut -d/ -f1 | grep 192.168)

# Wait for SSH to be available
while ! nc -z "$VM_IP" 22; do
    sleep 1
    echo -n "."
done

echo "VM is running, reverting to $SNAPSHOT_TYPE snapshot: $VM_SNAPSHOT..."
virsh snapshot-revert "$VM_NAME" "$VM_SNAPSHOT"


# wait VM to boot up
echo "Waiting for VM snapshot to boot up and become available via ssh..."
# Loop until SSH is available on port 22
# Get the IP address of the VM
VM_IP=$(virsh domifaddr "$VM_NAME" | grep 'ipv4' | awk '{print $NF}' | cut -d/ -f1)
echo "VM IP address: $VM_IP"

# Wait for SSH to be available
while ! nc -z "$VM_IP" 22; do
    sleep 1
done