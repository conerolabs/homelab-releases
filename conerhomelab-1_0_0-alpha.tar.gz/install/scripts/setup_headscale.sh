#!/bin/bash
HEADSCALE_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$HEADSCALE_SCRIPT_DIR/commons.sh"
source "$HOMELAB_SCRIPTS_DIR/print.sh"
source "$HOMELAB_SCRIPTS_DIR/oidc.sh"
# set -a automatically exports all variables defined in the sourced file, so they are available for envsubst and other commands that need them.
set -a; source "$HOMELAB_ENV_FILE"; set +a;
echo
echo -e "${BLUE}####################################################################${NC}"
echo -e "${BLUE}##                                                                ##${NC}"
echo -e "${BLUE}##                   Configurazione di Headscale                  ##${NC}"
echo -e "${BLUE}##                                                                ##${NC}"
echo -e "${BLUE}####################################################################${NC}"
echo

if ! command -v headscale > /dev/null 2>&1; then
    print_warning "Headscale non è installato. Esegui prima lo script deps-install-all.sh"
    exit 1
fi

echo
oidc_client_id headscale
echo
oidc_client_secret headscale systemd-creds
echo

echo -e "- Modifico il file di configurazione di Headscale... ${CYAN}/etc/headscale/config.yaml${NC}"
# Sets CREDENTIALS_DIRECTORY to the literal string '$CREDENTIALS_DIRECTORY'
# effectively neutralizing the substitution for this specific variable
CREDENTIALS_DIRECTORY='$CREDENTIALS_DIRECTORY'
export CREDENTIALS_DIRECTORY

# Initial configuration file generation with env vars substitution without custom dns (will be updated later with the actual Tailscale IP)
envsubst < "$INSTALL_DATA_DIR"/headscale/config.yaml | sudo tee /etc/headscale/config.yaml > /dev/null
echo

echo "- Configuro il systemd service per usare il secret file criptato..."
if diff -BEZq /etc/systemd/system/headscale.service.d/override.conf "$INSTALL_DATA_DIR/headscale/systemd_override.conf" > /dev/null 2>&1; then
    echo -e "  La configurazione del ${CYAN}systemd service${NC} nel file /etc/systemd/system/headscale.service.d/override.conf è già impostata correttamente"
else
    sudo mkdir -p /etc/systemd/system/headscale.service.d
    sudo cp "$INSTALL_DATA_DIR/headscale/systemd_override.conf" /etc/systemd/system/headscale.service.d/override.conf
    sudo systemctl daemon-reload
fi
echo

echo "- Controllo i container necessari..."
# Headscale si avvia solamente se riesce a connettersi ad Authelia, per questo è necessario che i container siano già in esecuzione
echo
docker compose up -d authelia caddy
sleep 1
echo
authelia_attempt=1
echo -n "- Attendo che Authelia sia disponibile..."
until curl -s "https://auth.$DOMAIN/api/health" | grep -q "OK"; do
    sleep 2
    ((authelia_attempt++))
    if [ $authelia_attempt -ge 10 ]; then
        echo -e "   ${RED}TIMEOUT${NC}"
        echo
        print_error "L'authentication server non è disponibile. Verifica che il container sia in esecuzione e che il dominio auth.$DOMAIN punti al nodo."
        exit 1
    fi
done
echo -e "   ${GREEN}OK${NC}"
echo

echo "- Riavvio il servizio di Headscale..."
echo
sudo systemctl restart headscale
sleep 1
# Verifica che il servizio sia attivo
sudo systemctl --no-pager status headscale
echo
headscale_attempt=1

echo -n "- Verifico la connessione con Headscale control plane..."
until curl -s "$HEADSCALE_SERVER_URL/health" | grep -q "pass"; do
    sleep 2
    ((headscale_attempt++))
    if [ $headscale_attempt -ge 10 ]; then
        echo -e "   ${RED}TIMEOUT${NC}"
        echo
        print_error "Non riesco a connettermi al control plane di Headscale. Verifica che il servizio sia attivo e che il login server URL $HEADSCALE_SERVER_URL sia corretto."
        echo
        exit 1
    fi
done
echo -e "   ${GREEN}OK${NC}"
echo
print_success "Headscale è configurato correttamente e il servizio è attivo."
echo