#!/bin/bash

# it could lead to an error... it could be different from homelab if not run inside the installation tmp directory
HOMELAB_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/../../homelab" &>/dev/null && pwd)
HOMELAB_SCRIPTS_DIR="${HOMELAB_DIR}/scripts"

HOMELAB_DB=$HOMELAB_DIR/homelab.db

INSTALL_DATA_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/../../install" &>/dev/null && pwd)
HOMELAB_ENV_FILE=$HOMELAB_DIR/.env

HOMELAB_COMPOSE_FILE=$HOMELAB_DIR/docker-compose.yml

