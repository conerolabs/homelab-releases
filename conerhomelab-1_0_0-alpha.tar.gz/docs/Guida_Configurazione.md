# Software e Configurazioni

## Preparazione del Sistema Operativo (Armbian)

### 1. Immagine Base

Scarica l'immagine [Armbian per ROCK 2A](https://www.armbian.com/rock-2a/) e flashala sulla MicroSD (Samsung/SanDisk Endurance) usando [Armbian Imager](https://github.com/armbian/imager/releases) o BalenaEtcher. Qui la [guida completa](https://docs.armbian.com/User-Guide_Getting-Started/) per iniziare con Armbian.
Immagine flashata: Armbian 25.11.1 -> updated to 25.11.2 stable 6.1.115-vendor-rk35xx (Debian trixie)

### 2. Primo Avvio

Collega la scheda via Ethernet, trova l'IP nel router e accedi via SSH (`ssh root@<IP_SCHEDA>`).  
<IP_SCHEDA> è l'indirizzo IP assegnato alla scheda dal router e la password iniziale è `1234`. Dopo il login ti verrà chiesto di cambiarla.
Assegnato l'IP statico nel router: `192.168.1.109`
Lo script `install.sh` automatizza tutte le operazioni elencate di seguito, se riscontri dei problemi esegui le operazioni manualmente.

Aggiorna:

```bash
apt update
apt upgrade
```

### 3. Ottimizzazione di Armbian

``` bash
    bash setup_armbian.sh
```

### 4. Installazione Software

Installiamo docker dal sito ufficiale e non dal repository armbian.
Installiamo come prima cosa il Docker Engine. Seguiremo la [guida ufficiale](https://docs.docker.com/engine/install/debian/) di Docker.

```bash
# Rimuoviamo prima eventuali pacchetti che possono confliggere:
sudo apt remove $(dpkg --get-selections docker.io docker-compose docker-doc podman-docker containerd runc | cut -f1)

# Add Docker's official GPG key:
sudo apt update
sudo apt install ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# Add the repository to Apt sources:
sudo tee /etc/apt/sources.list.d/docker.sources <<EOF
Types: deb
URIs: https://download.docker.com/linux/debian
Suites: $(. /etc/os-release && echo "$VERSION_CODENAME")
Components: stable
Signed-By: /etc/apt/keyrings/docker.asc
EOF

sudo apt update

sudo apt install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

Limita i log di docker in /etc/docker nel file daemon.json

```json
{
  "log-driver": "local",
  "log-opts": {
    "max-size": "5m",
    "max-file": "5",
    "compress": "true"
  }
}
```

apt install unbound (vedi [configurazione](https://docs.pi-hole.net/guides/dns/unbound/#configure-unbound))
curl -fsSL https://tailscale.com/install.sh | sh

### 5. Abilitazione ZRAM

  - **SIZE:** Impostalo al **50%** della RAM totale (quindi `1024M`). Questo non significa che "ruba" 1GB di RAM, ma che può gestire fino a 1GB di dati compressi.
  - **ALGORITHM:** Usa `zstd` (miglior rapporto compressione/velocità) o `lz4` (massima velocità, meno compressione). Per la Rock 2A, **zstd** è l'ideale.

## Configurazione DNS

Unbound ascolta sulla porta `5335`. Verificalo con:

```bash
    ss -tulpn | grep unbound
```

_(Dovresti vedere il servizio attivo su 127.0.0.1:5335)_

### Disable Stub DNS in Armbian

To disable the stub DNS resolver in Armbian, follow these steps:

1. **Create a drop-in configuration directory**:

    ```bash
        sudo mkdir -p /etc/systemd/resolved.conf.d/
    ```

2. **Create a configuration file to disable the stub listener**:

   ```bash
   sudo tee /etc/systemd/resolved.conf.d/disable-stub.conf << 'EOF'
   [Resolve]
   DNSStubListener=no
   EOF
   ```

3. **Repoint `/etc/resolv.conf` to the system-resolved file**:

   ```bash
   sudo ln -sf /run/systemd/resolve/resolv.conf /etc/resolv.conf
   ```

4. **Restart the systemd-resolved service**:

   ```bash
   sudo systemctl restart systemd-resolved
   ```

After completing these steps, the stub DNS listener on `127.0.0.53` will be disabled, and DNS resolution will be handled directly by the upstream DNS servers (e.g., your router or custom DNS settings). This approach avoids modifying the main config file, ensuring compatibility with package updates and unattended upgrades.

### Disable resolvconf.conf entry for unbound (Required for Debian Bullseye+ releases)

Segui la [guida](https://docs.pi-hole.net/guides/dns/unbound/#disable-resolvconfconf-entry-for-unbound-required-for-debian-bullseye-releases) di Pi-Hole

Per far sì che la Rock 2A usi se stessa (e quindi Pi-hole) come DNS in modo persistente, aggiorna /etc/resolv.conf:

Bash
echo "nameserver 127.0.0.1" | sudo tee /etc/resolv.conf

### Prevent DHCP from setting DNS servers automatically

Set UseDNS=false in the [DHCP] section of your .network file in `/etc/systemd/network/`

```Bash
[Match]
Name=end1

[Network]
DHCP=yes

[DHCP]
UseDNS=false
```

### Comunicazione Pi-hole -> Unbound

Nel `docker-compose.yml`, abbiamo usato `172.20.0.1#5335`.
`172.20.0.1` è l'IP dell'host visto dall'interno del bridge Docker.
Assicurati che Unbound accetti query da Docker modificando (se necessario) `/etc/unbound/unbound.conf.d/homelab.conf`:

``` txt
    access-control: 172.20.0.0/16 allow
```

Vedi il file di [configurazione](../install/unbound/homelab.conf) unbound.

## Configurazione Tailscale (Network Mesh)

1. **Autenticazione:**

    ```bash
        tailscale up --hostname=conerolabs-1
    ```

    _Segui il link per autenticarti nel tuo account._

2. **HTTPS su Tailscale:** Vai sulla [Admin Console di Tailscale](https://login.tailscale.com/admin/dns) e abilita **HTTPS** e **MagicDNS**. Prendi nota del tuo dominio (es. `iguana-justitia.ts.net`).

3. Imposta il global Nameserver nella sezione [Nameservers](https://login.tailscale.com/admin/dns) con l'ip Tailscale di questo nodo. Vedi la variabile `TAILSCALE_IP` nel file [.env](../.env)

---

## Configurazione del Caddyfile (Il Routing HTTPS)

Si è deciso di utilizzare il dominio personalizzato `conerolabs.com` in modo da poter creare certificati per tutti i sottodomini desiderati. Tailscale consente di creare certificati solamente per il dominio `ts.net` del nodo.  
Caddy utilizzerà dunque Let's Encrypt per generare i certificati e il plugin per Cloudflare (il gestore del dominio `conerolabs.com`) per poter modificare i record DNS necessari per rispondere alla challenge di Let's Encrypt.
Per comunicare con Cloudflare, Caddy ha bisogno del relativo token.
Per fare in modo che Caddy legga i DNS record appena aggiornati per la challenge utilizziamo direttamente i resolvers di Cloudflare `1.1.1.1` e `1.0.0.1`

### Generazione del token di Cloudflare

1. Login su cloudflare, vai su profilo (in alto a destra) -> api tokens (menù a sx) -> create token
  [Cloudflare API Tokens](https://dash.cloudflare.com/profile/api-tokens)
2. Usa il template `Edit zone DNS`.  
3. Sotto Permissions, assicurati che ci sia:

    - `Zone - DNS - Edit`
    - `Zone - Zone - Read`

4. Sotto Zone Resources, seleziona

    - Include - Specific zone - conerolabs.com

Compila il valore della variabile CLOUDFLARE_API_TOKEN nel file [.env](../.env)

---

## Configurazione di Authelia

[setup_authelia.sh](../setup_authelia.sh)  
[configuration.yml](../docker/authelia/config/configuration.yml)  
[user_database.yml](../docker/authelia/config/user_database.yml)  
[Authelia.md](Authelia.md)  
Per il reset password e notifiche, Authelia avrà bisogno di un server SMTP (puoi usare un account Gmail o simili).

---

## Deployment dello Stack Docker

Questi sono i servizi che andremo ad installare:

- [PiHole](https://docs.pi-hole.net/) DNS Filter and Cache
- [Caddy](https://caddyserver.com/docs/running#docker-compose) Reverse Proxy  
  Utilizzeremo l'immagine `caddy:builder` per compilare Caddy con il plugin Cloudflare.
- [Authelia]() Auth Server
- [Vaultwarden]() Password Manager
- [Homepage]() Dashboard
- [Gatus]() Monitoring
- [MySpeed]() Network Speed Test
- [Portainer]() Containers Management
- [RustiCal]() WebDAV Server

Crea una cartella dedicata per gestire i container tramite IaC (Infrastructure as Code):

```bash
mkdir -p ~/infra-stack/{caddy,authelia,vaultwarden,pihole,gatus,myspeed,homepage,portainer}
cd ~/infra-stack
nano docker-compose.yml
```

### File `docker-compose.yml`

[PiHole Docker](https://docs.pi-hole.net/docker/) - Attenzione all'[autenticazione](https://docs.pi-hole.net/api/auth/?h=auth)
[Nodo1 - docker-compose.yml](./Nodo1/containers/docker-compose-all.yml)

### Vaultwarden admin page: `ADMIN_TOKEN`

Segui le istruzioni [qui](https://github.com/dani-garcia/vaultwarden/wiki/Enabling-admin-page).

Vaultwarden ha una "Admin Page" nascosta (accessibile su `/admin`).
Questa pagina ti permette di gestire gli utenti, vedere le sessioni attive e forzare i backup del database senza dover agire via terminale.

[Interazione con Authelia]()

---

## Pi-hole come DNS di Tailscale

Dobbiamo dire a Tailscale di usare Pi-hole per risolvere i nomi della tua rete.

1. Nella console Tailscale (DNS settings), clicca su **Add Nameserver** -> **Custom**.
2. Inserisci l'**IP Tailscale** del tuo Nodo 1 (quello che inizia con `100.x.y.z`).
3. Abilita **Override Local DNS**.

Invece di mappare ogni servizio (`vault`, `dns`, `auth`), puoi dire a Pi-hole: _"Qualsiasi cosa finisca con `.conerolabs.tuodominio.ts.net`, mandale all'IP del Nodo 1"_.

Così facendo, quando il tuo notebook cerca il dominio, chiede a Tailscale -> Tailscale chiede a Pi-hole -> Pi-hole risponde con l'IP del Nodo 1 -> Caddy riceve la chiamata e la smista al container.

---

## Configurazione del Router

Per risolvere il problema dovuto al NAT Loopback (o Hairpin NAT): quando tenti di accedere al tuo dominio pubblico dall'interno della rete, il router intercetta la richiesta sulla porta 80 e la dirotta alla sua pagina di amministrazione locale invece di inoltrarla al server interno.

Ecco le soluzioni per risolvere il conflitto:

cambia la porta di gestione del router (es.  da 80 a 8080 o 8443).  In questo modo, digitando http://dominio.it la porta 80 sarà libera per il port forwarding, mentre accederai al router tramite http://192.168.1.1:8080.

## Best Practices di Post-Installazione

### Ottimizzazione MicroSD

Armbian gestisce già i log in RAM, ma assicuriamoci che il database di Pi-hole non scriva eccessivamente.

- Entra nella dashboard di Pi-hole [dns.conerolabs.com](https://dns.conerolabs.com) e imposta la **Privacy Mode** su "Anonymous Statistics" se non ti interessano i log storici delle query.

### Avvio dello Stack

```bash
    cd $INSTALL_DIR
    export FTLCONF_DNS_HOSTS=$(cat local-dns-table.list)
    docker compose up -d
```

## 5. Note Tecniche

### Monitoraggio

Puoi verificare lo stato del sistema in qualsiasi momento con i comandi consigliati nella sezione [Armbian](Armbian.md#5-comandi-utili)

### Gestione Backup

[[Backup Script]]

---
