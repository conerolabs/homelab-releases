# Homelab Development

## Virtual Machine

1. install qemu and virt-manager on ubuntu
2. download the image:
    https://dl.armbian.com/uefi-x86/archive/Armbian_26.2.1_Uefi-x86_noble_cloud_6.18.8_minimal.img.qcow2.xz
3. uncompress the image file

```bash
curl -LO https://dl.armbian.com/uefi-x86/archive/Armbian_26.2.1_Uefi-x86_trixie_cloud_6.18.8_minimal.img.qcow2.xz
xz -d Armbian_26.2.1_Uefi-x86_trixie_cloud_6.18.8_minimal.img.qcow2.xz   
```

4. start virt-manager and create a virtual machine with the .qcow2 file

5. avvia la vm

Enable and start the time synchronization service:

```bash
sudo timedatectl set-ntp true
```

Force an immediate NTP sync (if chrony or systemd-timesyncd is available):

```bash
sudo systemctl restart systemd-timesyncd
```

6. Per abilitare l'autenticazione ssh con chiavi:

per generare la chiave sul client:

```bash
ssh-keygen -t ed25519 -N "" -f $HOME/.ssh/armbian <<< y
```

poi copiare la chiave pubblica nel server:

```bash
ssh-copy-id -i $HOME/.ssh/armbian -o StrictHostKeyChecking=no andrea@[IP_ADDRESS]
```



## Release (.tar.gz file)

Use `tag-release` script to tag the release commit even if it is enough to push a tag starting with `v`.
The script will:
1. update the version in .env file (either 'major', 'minor' or 'patch')
2. push the .env file to the repository
3. create the tag
4. push the tag to the repository

Then, thanks to github actions (see [.github/workflows/sync-release.yml](.github/workflows/sync-release.yml)), the .tar.gz file is automatically created (using 'release.sh' script) and pushed to [homelab-releases](https://github.com/conerolabs/homelab-releases) public repository, available to be downloaded.

### Manual creation of the release file

You can create the release file manually using the 'release.sh' script or following commands below.

```bash
source install/.env
# Cleaning up old release archives
rm -f conerhomelab-*.tar.gz
# Creating release archive for version $HOMELAB_VERSION
git archive -o conerhomelab-"${HOMELAB_VERSION//./_}".tar.gz HEAD . ':!install/scripts/tests/' ':!release.sh' ':!tag-release.sh'
```

## Installation

Download install.sh from git repo.
Execute the script.

```bash
curl -fsSL https://raw.githubusercontent.com/conerolabs/homelab-releases/main/install.sh | bash
```

## PM2 - Production Process Manager for Node.js
[Quick start](https://pm2.keymetrics.io/docs/usage/quick-start/)

``` bash
npm install pm2 -g
pm2 completion install
# create systemd entries to run pm2 on hostreboot
eval "$(pm2 startup | tail -n 1)"
```

To start the app:

``` bash
pm2 start ecosystem.config.js --env production
# Save running process list to restart them after reboot
pm2 save
```



