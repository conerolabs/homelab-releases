import { execSync } from 'child_process';
import { getLogger } from '../logger.ts';

const GET_NIC_COMMAND = `ip -d -j link | jq -r '.[] | select(.operstate == "UP" or .operstate == "UNKNOWN") | select(.linkinfo?.info_kind == null and .link_type != "loopback").ifname'`

export type NetworkType = "public" | "lan" | "tailscale"
export class NetworkService {

    private static log = getLogger(NetworkService.name);

    public static async getIp(network: NetworkType): Promise<string> {
        try {
            const result = await new Promise<string>((resolve, reject) => {
                switch (network) {
                    case 'public': NetworkService.getPublicIp().then(resolve).catch(reject); break;
                    case 'lan':
                        const networkInterface = process.env.NETWORK_INTERFACE || NetworkService.getNic();
                        resolve(NetworkService.getLanIp(networkInterface));
                        break;
                    case 'tailscale': resolve(NetworkService.getTailscaleIp()); break;
                    default:
                        reject(new Error(`Invalid network parameter: "${network}"`));
                }
            });
            return result;
        } catch (error) {
            return '';
        }
    }

    private static async getPublicIp(ipService?: string, count: number = 1): Promise<string> {
        const ipServices: string[] = [
            'https://ipinfo.io/ip',
            'https://ifconfig.me/ip',
            'https://api.ipify.org'
        ]
        const ipServiceIndex = Math.floor(Math.random() * ipServices.length);
        let url = ipService || ipServices[ipServiceIndex];
        return fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }
                return response.text();
            })
            .then(text => text.trim())
            .catch(err => {
                if (count > ipServices.length) {
                    NetworkService.log.error(`Failed to fetch public IP with ${url}: ${err.message}`);
                    throw new Error(`Failed to fetch public IP with ${url}: ${err.message}`);
                }
                NetworkService.log.error(`Failed to fetch public IP with ${url}: ${err.message}`);
                return NetworkService.getPublicIp(ipServices[(ipServices.indexOf(url) + 1) % ipServices.length], ++count);
            });
    }

    private static getTailscaleIp() {
        const tailscaleCmd = `tailscale ip -4`;
        try {
            return execSync(tailscaleCmd, { encoding: 'utf-8' }).trim();
        } catch (error) {
            throw new Error(`Failed to get tailscale ip with command: ${tailscaleCmd} - ${error.stdout} - ${error.stderr}`);
        }
    }

    private static getLanIp(networkInterface: string): string {
        // Validate network interface name to prevent shell injection
        if (!/^[a-zA-Z0-9.-]+$/.test(networkInterface)) {
            throw (new Error(`Invalid NETWORK_INTERFACE configuration: "${networkInterface}"`));
        }
        const lanCmd = `ip -4 -o addr show ${networkInterface} | awk '{printf $4}' | sed 's/\\/.*//'`;
        try {
            return execSync(lanCmd, { encoding: 'utf-8' }).trim();
        } catch (error) {
            throw new Error(`Failed to get LAN ip with command: ${lanCmd} - ${error.stdout} - ${error.stderr}`);
        }
    }

    public static getNic(): string {
        try {
            return execSync(GET_NIC_COMMAND, { encoding: 'utf-8' }).trim();
        } catch (error) {
            throw new Error(`Failed to get network interface: ${error.stdout} - ${error.stderr}`);
        }
    }

}