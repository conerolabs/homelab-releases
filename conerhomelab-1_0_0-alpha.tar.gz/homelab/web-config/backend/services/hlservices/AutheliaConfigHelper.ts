import { ConfigService } from "../config.service.ts";
import type { ServiceConfigHelper } from "./services.service.ts";
import { parseAutheliaConfig } from '../../config-utils.ts';
import type { AutheliaHashOptions, AutheliaConfig } from '../../config-utils.ts';
import { mapFields, type TransformationMap } from '../../../commons/utils.ts';
import { decryptSystemdCredential, generateArgon2idHash, generateRsaKeyPair, PROFILES } from "../../../commons/hlCrypto.ts";
import type { HashOptions } from "argon2";
import { readFileSync, writeFileSync } from "fs";
import os from "node:os";
import type { SetupResult } from "../../../commons/dto.ts";
import { existsSync } from "node:fs";
import { getLogger } from "../../logger.ts";
import * as hlCrypto from "../../../commons/hlCrypto.ts";

type ClientSecret = {
    client: string;
    path: string;
    type: 'txt' | 'cred' | 'env';
    hashEnvVar: string;
}

type FileSecret = {
    name: string;
    path: string;
    type: 'txt' | 'rsa';
}


export class AutheliaConfigHelper implements ServiceConfigHelper {
    public readonly name: string = 'authelia';
    private static log = getLogger('AutheliaConfigHelper');
    private static HOMELAB_DIR: string = '';
    private static AUTHELIA_SECRETS_DIR: string = '';

    public static CLIENT_SECRETS: ClientSecret[] = [];
    public static AUTHELIA_SECRETS: FileSecret[] = [];
    public static CLIENTS: string[] = [
        'vaultwarden',
        'gatus',
        'rustical',
        'web-config',
        'headscale',
    ];

    public static init(): void {
        AutheliaConfigHelper.log.info('STARTUP - Initializing Authelia Config Helper...');
        AutheliaConfigHelper.HOMELAB_DIR = ConfigService.getEnv('INSTALL_DIR').replace(/^~/, os.homedir());
        AutheliaConfigHelper.log.info(`  --> setting HOMELAB_DIR = ${AutheliaConfigHelper.HOMELAB_DIR}`)
        AutheliaConfigHelper.AUTHELIA_SECRETS_DIR = `${AutheliaConfigHelper.HOMELAB_DIR}/authelia/secrets`;
        AutheliaConfigHelper.log.info(`  --> setting AUTHELIA_SECRETS_DIR = ${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}`)

        AutheliaConfigHelper.AUTHELIA_SECRETS = [
            {
                name: 'JWT_SECRET',
                path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/JWT_SECRET`,
                type: 'txt',
            },
            {
                name: 'SESSION_SECRET',
                path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/SESSION_SECRET`,
                type: 'txt',
            },
            {
                name: 'STORAGE_ENCRYPTION_KEY',
                path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/storage_encryption_key.txt`,
                type: 'txt',
            },
            {
                name: 'OIDC_HMAC_SECRET',
                path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/OIDC_HMAC_SECRET`,
                type: 'txt',
            },
            {
                name: 'OIDC_JWKS_KEY',
                path: `${AutheliaConfigHelper.AUTHELIA_SECRETS_DIR}/oidc_jwks_key.pem`,
                type: 'rsa',
            },
        ];

        AutheliaConfigHelper.CLIENT_SECRETS = [
            {
                client: 'vaultwarden',
                path: `${AutheliaConfigHelper.HOMELAB_DIR}/vaultwarden/secrets/oidc_client_secret.txt`,
                type: 'txt',
                hashEnvVar: 'AUTHELIA_VAULTWARDEN_SECRET_HASH',
            },
            {
                client: 'gatus',
                path: `${AutheliaConfigHelper.HOMELAB_DIR}/gatus/secrets/oidc_client_secret.txt`,
                type: 'txt',
                hashEnvVar: 'AUTHELIA_GATUS_SECRET_HASH',
            },
            {
                client: 'rustical',
                path: `${AutheliaConfigHelper.HOMELAB_DIR}/rustical/secrets/oidc_client_secret.txt`,
                type: 'txt',
                hashEnvVar: 'AUTHELIA_RUSTICAL_SECRET_HASH',
            },
            {
                client: 'web-config',
                path: `${AutheliaConfigHelper.HOMELAB_DIR}/web-config/secrets/oidc_client_secret.txt`,
                type: 'txt',
                hashEnvVar: 'AUTHELIA_WEBCONFIG_SECRET_HASH',
            },
            {
                client: 'headscale',
                path: `${AutheliaConfigHelper.HOMELAB_DIR}/headscale/secrets/oidc_client_secret.cred`,
                type: 'cred',
                hashEnvVar: 'AUTHELIA_HEADSCALE_SECRET_HASH',
            },
        ];
        AutheliaConfigHelper.log.info('STARTUP - Authelia Config Helper initialized');
    }

    /**
     * Sets up Authelia by hashing all client secrets and generating all authelia secrets.
     * It hashes client secrets from environment variables and generates missing secrets in the secrets directory.
     * Creation of admin user is not part of this setup as it is done through the web interface.
     * Note: Even if setup result is ok, Authelia could be misconfigured. Run AutheliaSetupChecker for a better overview.
     * @returns the setup result
     */
    public async setup(): Promise<SetupResult> {
        try {
            await Promise.all([
                async () => {
                    AutheliaConfigHelper.generateClientIds();
                    AutheliaConfigHelper.generateClientSecrets();
                    await AutheliaConfigHelper.hashAllClientSecrets()
                },
                AutheliaConfigHelper.generateAutheliaSecrets(),
            ]);
            AutheliaConfigHelper.log.info("SETUP - Authelia setup completed");
            const result = { name: AutheliaConfigHelper.name, success: true };
            return result;
        } catch (error) {
            AutheliaConfigHelper.log.error("SETUP - Error setting up Authelia: " + error);
            const result = { name: AutheliaConfigHelper.name, success: false, message: error.toString() };
            return result;
        } finally {
            ConfigService.saveConfig();
        }
    }

    private static generateClientIds(): void {
        AutheliaConfigHelper.log.info(`SETUP - Generating Authelia clients ids...`)
        for (const client of AutheliaConfigHelper.CLIENTS) {
            const clientIdEnvVar = client.toUpperCase().replaceAll('-', '') + '_OIDC_CLIENT_ID';
            let clientId = ConfigService.getEnv(clientIdEnvVar)
            if (clientId) {
                AutheliaConfigHelper.log.info(`  --> client id for ${client} already exists: ${clientId}`)
                continue;
            }
            clientId = client.toLowerCase().replaceAll('-', '') + '-' + hlCrypto.generateKey(8);
            ConfigService.setEnv(clientIdEnvVar, clientId);
            AutheliaConfigHelper.log.info(`  --> [OK] ${client} client id generated: ${clientId}`)
        }
    }

    private static resolveSecretEnv(secret: ClientSecret): string {
        return secret.client.toUpperCase().replaceAll('-', '') + '_OIDC_CLIENT_SECRET';
    }

    private static generateClientSecrets(): void {
        AutheliaConfigHelper.log.info(`SETUP - Generating Authelia clients secrets...`)
        for (const secret of AutheliaConfigHelper.CLIENT_SECRETS) {
            // TODO: check if secret already exists and generate it if not
            AutheliaConfigHelper.log.info(`  --> generating secret for ${secret.client}...`)
            AutheliaConfigHelper.generateClientSecret(secret);
        }
    }

    private static generateClientSecret(secret: ClientSecret): void {
        const secretExists = existsSync(secret.path);
        if (secretExists) {
            AutheliaConfigHelper.log.info(`  --> secret for ${secret.client} already exists at ${secret.path}`)
            return;
        }
        const secretValue = hlCrypto.generateKey(32);
        switch (secret.type) {
            case 'txt':
            case 'cred':
                writeFileSync(secret.path, secretValue, { mode: 0o600 });
                break;
            case 'env':
                ConfigService.setEnv(secret.hashEnvVar, secretValue);
                break;
        }
        AutheliaConfigHelper.log.info(`  --> [OK] ${secret.client} secret generated.`)
    }

    private static async hashAllClientSecrets(): Promise<void> {
        const log = AutheliaConfigHelper.log.child({ task_id: 'hashAllClientSecrets' })
        log.info(`SETUP - Hashing Authelia clients secrets...`)
        for (const clientSecret of AutheliaConfigHelper.CLIENT_SECRETS) {
            log.info(`  --> hashing ${clientSecret.client}'s secret...`)
            const hashedSecret = ConfigService.getEnv(clientSecret.hashEnvVar);
            if (!hashedSecret) {
                let secret = '';
                try {
                    switch (clientSecret.type) {
                        case 'txt':
                            secret = readFileSync(clientSecret.path).toString().trim();
                            break;
                        case 'cred':
                            secret = decryptSystemdCredential(clientSecret.path, 'oidc_client_secret');
                            break;
                        case 'env':
                            secret = ConfigService.getEnv(AutheliaConfigHelper.resolveSecretEnv(clientSecret));
                            break;
                    }
                } catch (error) {
                    log.error(`  --> Error reading client secret for ${clientSecret.client}: ` + error);
                    continue;
                }
                const hash = await AutheliaConfigHelper.generateAutheliaHash(secret);
                ConfigService.setEnv(clientSecret.hashEnvVar, hash);
                log.info(`  --> ${clientSecret.client}'s secret hash generated successfully`)
            }
            else {
                log.info(`  --> Client secret hash for ${clientSecret.client} already exists`);
            }
        }
    }

    private static generateAutheliaSecrets(size: number = 64) {
        try {
            AutheliaConfigHelper.AUTHELIA_SECRETS.map(s => {
                if (existsSync(s.path)) {
                    AutheliaConfigHelper.log.info(`SETUP - Authelia secret ${s.name} already exists`);
                    return;
                }
                if (s.type === 'txt') {
                    const secret = hlCrypto.generateKey(size);
                    writeFileSync(s.path, secret);
                }
                else if (s.type === 'rsa') {
                    const { privateKey } = generateRsaKeyPair();
                    writeFileSync(s.path, privateKey);
                }
            })
        }
        catch (error) {
            throw new Error("Error generating Authelia secret", { cause: error })
        }
    }

    private static hashOptionsTransformer: TransformationMap<AutheliaHashOptions, HashOptions> = new Map([
        ['variant', {
            field: 'type',
            transformer: (value: string | number) => ['argon2d', 'argon2i', 'argon2id'].indexOf(String(value).toLowerCase()) as HashOptions['type']
        }],
        ['iterations', { field: 'timeCost' }],
        ['memory', { field: 'memoryCost' }],
        ['parallelism', { field: 'parallelism' }],
        ['key_length', { field: 'hashLength' }],
    ]);

    private static loadAutheliaHashOptions(config?: AutheliaConfig): HashOptions {
        let hashOptions: HashOptions;
        AutheliaConfigHelper.log.debug("CONFIG - Loading Authelia hash options");
        try {
            const data = config ?? parseAutheliaConfig();
            const options: AutheliaHashOptions = data.authentication_backend.file.password.argon2;
            hashOptions = mapFields(options, AutheliaConfigHelper.hashOptionsTransformer);
        } catch (error) {
            AutheliaConfigHelper.log.debug("  --> WARNING - Error loading Authelia hash options: " + error);
            AutheliaConfigHelper.log.debug("  --> Using default Authelia profile");
            hashOptions = PROFILES['authelia'];
        }
        AutheliaConfigHelper.log.debug("  --> Authelia hash options: " + JSON.stringify(hashOptions, null, 2));
        return hashOptions;
    }

    public static async generateAutheliaHash(secret: string, config?: AutheliaConfig): Promise<string> {
        const hashOptions = AutheliaConfigHelper.loadAutheliaHashOptions(config);
        const hashedPassword = await generateArgon2idHash(secret, hashOptions);
        return hashedPassword;
    }
}