import type { SetupResult } from "../../../commons/dto.ts";
import type { ServiceConfigHelper } from "./services.service.ts";
import { ConfigService } from "../config.service.ts";
import { SystemService } from "../system.service.ts";
import { getLogger } from "../../logger.ts";
import { getLanIp } from "../../../commons/utils.ts";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { exec } from "node:child_process";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export class DnsRecord {
    ip: string;
    name: string;

    constructor(ip: string, name: string) {
        this.ip = ip;
        this.name = name;
    }

    public toString() {
        return `${this.ip} ${this.name}`
    }
}

type DnsTable = DnsRecord[]

export class PiholeConfigHelper implements ServiceConfigHelper {
    public readonly name: string = 'pihole';
    private static readonly log = getLogger('PiholeConfigHelper');

    private static readonly RESOLVED_CONF_DIR = '/etc/systemd/resolved.conf.d';
    private static readonly DISABLE_STUB_FILE = path.join(PiholeConfigHelper.RESOLVED_CONF_DIR, 'disable-stub.conf');
    private static readonly HOMELAB_RESOLVED_FILE = path.join(PiholeConfigHelper.RESOLVED_CONF_DIR, 'homelab.conf');
    private static readonly RESOLV_CONF_FILE = '/etc/resolv.conf';
    private static readonly RESOLV_CONF_TARGET = '/run/systemd/resolve/resolv.conf';
    private static readonly NETWORK_CONF_DIR = '/etc/systemd/network';

    /**
     * Executes a shell command with sudo privileges.
     */
    private static async runCommand(cmd: string): Promise<{ stdout: string; stderr: string }> {
        const sudoPassword = SystemService.getSudoPassword();
        const isRoot = typeof process.getuid === 'function' && process.getuid() === 0;

        const commandToExec = (!isRoot && sudoPassword)
            ? `echo "${sudoPassword}" | sudo -S ${cmd}`
            : (!isRoot ? `sudo ${cmd}` : cmd);

        return new Promise((resolve, reject) => {
            exec(commandToExec, { shell: '/bin/bash' }, (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`Command "${cmd}" failed: ${error.message} (stderr: ${stderr.trim()})`));
                } else {
                    resolve({ stdout: stdout.trim(), stderr: stderr.trim() });
                }
            });
        });
    }

    /**
     * Writes configuration files to privileged directories using sudo tee.
     */
    private static async writeFileWithSudo(filePath: string, content: string): Promise<void> {
        const dir = path.dirname(filePath);
        await PiholeConfigHelper.runCommand(`mkdir -p "${dir}" && tee "${filePath}" << 'EOF'\n${content}\nEOF`);
    }

    /**
     * Disables the systemd DNS Stub resolver and updates /etc/resolv.conf.
     */
    private static async disableDnsStubResolver(): Promise<void> {
        const log = PiholeConfigHelper.log.child({ task: 'disableDnsStubResolver' });

        if (existsSync(PiholeConfigHelper.DISABLE_STUB_FILE)) {
            const content = readFileSync(PiholeConfigHelper.DISABLE_STUB_FILE, 'utf-8');
            if (content.includes('DNSStubListener=no')) {
                log.info('- DNS Stub resolver already disabled');
                return;
            }
        }

        log.info('- Disabling DNS Stub resolver...');
        const stubConfig = `[Resolve]\nDNSStubListener=no`;
        await PiholeConfigHelper.writeFileWithSudo(PiholeConfigHelper.DISABLE_STUB_FILE, stubConfig);
        await PiholeConfigHelper.runCommand(`ln -sf "${PiholeConfigHelper.RESOLV_CONF_TARGET}" "${PiholeConfigHelper.RESOLV_CONF_FILE}"`);
        log.info('  --> [OK] DNS Stub resolver disabled and /etc/resolv.conf updated');
    }

    /**
     * Adds Pi-Hole and optional backup DNS to systemd-resolved.
     */
    private static async configureHomelabDnsResolver(): Promise<void> {
        const log = PiholeConfigHelper.log.child({ task: 'configureHomelabDnsResolver' });

        if (existsSync(PiholeConfigHelper.HOMELAB_RESOLVED_FILE)) {
            const content = readFileSync(PiholeConfigHelper.HOMELAB_RESOLVED_FILE, 'utf-8');
            if (content.includes('DNS=127.0.0.1')) {
                log.info('  Homelab DNS resolver already configured');
                return;
            }
        }

        log.info('- Adding Pi-Hole as DNS resolver...');
        const backupDns = (ConfigService.getEnv('BACKUP_DNS') || process.env.BACKUP_DNS || '').trim();
        const dnsLine = backupDns ? `DNS=127.0.0.1 ${backupDns}` : `DNS=127.0.0.1`;
        const homelabConfig = `[Resolve]\n${dnsLine}`;

        await PiholeConfigHelper.writeFileWithSudo(PiholeConfigHelper.HOMELAB_RESOLVED_FILE, homelabConfig);
        log.info('  --> [OK] Homelab DNS resolver configured');
    }

    /**
     * Restarts the systemd-resolved service.
     */
    private static async restartSystemdResolved(): Promise<void> {
        PiholeConfigHelper.log.info('- Restarting systemd-resolved...');
        await PiholeConfigHelper.runCommand('systemctl restart systemd-resolved');
        PiholeConfigHelper.log.info('  --> [OK] systemd-resolved restarted');
    }

    /**
     * Disables DNS assigned by Router DHCP on the network interface.
     */
    private static async disableDhcpDns(): Promise<void> {
        const log = PiholeConfigHelper.log.child({ task: 'disableDhcpDns' });
        log.info('- Disabling DNS assigned by Router DHCP...');

        const networkInterface = ConfigService.getEnv('NETWORK_INTERFACE') || process.env.NETWORK_INTERFACE || 'eth0';
        const networkFilePath = path.join(PiholeConfigHelper.NETWORK_CONF_DIR, `01-${networkInterface}.network`);

        if (existsSync(networkFilePath)) {
            const content = readFileSync(networkFilePath, 'utf-8');
            if (content.includes('DHCP=yes') && (content.includes('UseDNS=false') || content.includes('UseDNS=no'))) {
                log.info(`  Network interface ${networkInterface} already configured`);
                return;
            }
        }

        const networkConfig = `[Match]\nName=${networkInterface}\n\n[Network]\nDHCP=yes\n\n[DHCP]\nUseDNS=false`;
        await PiholeConfigHelper.writeFileWithSudo(networkFilePath, networkConfig);
        log.info(`  --> [OK] Written network configuration for ${networkInterface}`);

        log.info('- Restarting systemd-networkd...');
        await PiholeConfigHelper.runCommand('systemctl restart systemd-networkd');
        log.info('  --> [OK] systemd-networkd restarted');
    }

    /**
     * Disables dnsmasq service if active.
     */
    private static async disableDnsmasq(): Promise<void> {
        const log = PiholeConfigHelper.log.child({ task: 'disableDnsmasq' });

        const isDnsmasqActive = await new Promise<boolean>((resolve) => {
            exec('systemctl is-active dnsmasq', (error, stdout) => {
                resolve(stdout.trim() === 'active');
            });
        });

        if (isDnsmasqActive) {
            log.info('- Disabling dnsmasq...');
            try {
                await PiholeConfigHelper.runCommand('systemctl stop dnsmasq && systemctl disable dnsmasq');
                log.info('  --> [OK] dnsmasq stopped and disabled');
            } catch (err: any) {
                log.warn(`  --> Failed to stop/disable dnsmasq: ${err.message}`);
            }
        } else {
            log.info('  --> [OK] Service dnsmasq is already disabled');
        }
    }

    /**
     * Generates the local DNS table list file and executes local-dns-table.sh.
     */


    static configureLocalDnsTable(): DnsTable {
        const log = PiholeConfigHelper.log.child({ task_id: 'configureLocalDnsTable' });
        log.info('- Generating local DNS table for Pi-hole...');

        const homelabDir = (ConfigService.getEnv('INSTALL_DIR') || '').replace(/^~/, process.env.HOME || '') || path.resolve(__dirname, '../../..');

        const dnsTable = PiholeConfigHelper.createDnsTable();
        const listPath = path.join(homelabDir, 'local-dns-table.list');
        writeFileSync(listPath, PiholeConfigHelper.printDnsTable(dnsTable), 'utf-8');
        log.info(`  --> [OK] Local DNS table saved to ${listPath}`);
        return dnsTable;
    }

    static printDnsTable(dnsTable: DnsTable) {
        return dnsTable.map(record => record.toString()).join('\n')
    }

    private static createDnsTable(): DnsTable {
        const mode = ConfigService.getEnv('VPN_MODE') || 'novpn'; // tail, head, novpn
        const tailscaleIp = ConfigService.getEnv('TAILSCALE_IP');
        const lanIp = ConfigService.getEnv('LAN_IP') || getLanIp();
        const domain = ConfigService.getEnv('DOMAIN');
        const defaultDomain = "home.lab"
        if (!domain) {
            console.warn("No domain is defined. Configuring local dns table with default local domain: home.lab")
        }
        const dnsDomain = domain || defaultDomain;
        const ip = (tailscaleIp || lanIp).trim();

        const publicHosts = ['auth'];
        let hosts = ['calendar', 'dns', 'home', 'portainer', 'speedtest', 'status', 'vault', 'music', 'files'];
        const hostsLan = ['cron', 'config'];

        if (mode !== 'head') {
            hosts = [...publicHosts, ...hosts];
        }

        const dnsTable: DnsTable = [
            ...hosts.map(h => new DnsRecord(ip, `${h}.${dnsDomain}`)),
            ...hostsLan.map(h => new DnsRecord(lanIp, `${h}.${dnsDomain}`))
        ];

        return dnsTable;
    }

    /**
     * Executes all Pi-hole setup steps mirroring 03-setup_pihole.sh.
     */
    public async setup(): Promise<SetupResult> {
        PiholeConfigHelper.log.info('SETUP - Starting Pi-hole configuration...');
        try {
            await PiholeConfigHelper.disableDnsStubResolver();
            await PiholeConfigHelper.configureHomelabDnsResolver();
            await PiholeConfigHelper.restartSystemdResolved();
            await PiholeConfigHelper.disableDhcpDns();
            await PiholeConfigHelper.disableDnsmasq();
            await PiholeConfigHelper.configureLocalDnsTable();

            PiholeConfigHelper.log.info('SETUP - Pi-hole configuration completed successfully');
            return {
                name: PiholeConfigHelper.name,
                success: true,
                message: 'Pi-hole configuration completed successfully',
            };
        } catch (error: any) {
            PiholeConfigHelper.log.error('SETUP - Error configuring Pi-hole: ' + error);
            return {
                name: PiholeConfigHelper.name,
                success: false,
                message: error?.message || String(error),
            };
        }
    }
}