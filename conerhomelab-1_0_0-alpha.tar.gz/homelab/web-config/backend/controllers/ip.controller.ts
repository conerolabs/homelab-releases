import type { Request, Response, NextFunction } from 'express';
import { NetworkService } from '../services/ip.service.ts';

export class IpController {
    public static async getIp(req: Request, res: Response, next: NextFunction): Promise<void> {
        try {
            const network = req.query.network as string;
            if (!network) {
                res.status(400).json({ error: 'Network parameter is required' });
                return;
            }
            if (network !== "public" && network !== "lan" && network !== "tailscale") {
                res.status(400).json({ error: 'Invalid network parameter' });
                return;
            }

            const ip = await NetworkService.getIp(network);
            console.log(`${network.charAt(0).toUpperCase() + network.slice(1)} IP: ${ip}`);
            res.send(ip);
        } catch (err) {
            next(err);
        }
    }
}
