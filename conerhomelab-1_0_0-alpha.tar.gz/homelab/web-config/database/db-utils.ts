import { existsSync, type PathLike } from "node:fs";
import { configureEnv, deleteOldEnvs } from "./envDAO.ts";
import { parseEnv, parseDockerCompose, parseAutheliaUsers } from "../backend/config-utils.ts";
import { configureService } from "./serviceDAO.ts";
import { DatabaseSync } from "node:sqlite";
import { deleteAllUsers, insertUsers } from "./usersDAO.ts";
import type { UserModel } from "../commons/models.ts";

export function syncServices(compose: PathLike) {
    const services = parseDockerCompose(compose)
    Object.values(services).forEach(service => {
        service.version = `${service.name.replaceAll('-', '_').toUpperCase()}_VERSION`
        configureService(service.name, 'docker', service.docker_img ?? null, service.version ?? null, service.envs ?? []);
    });
    //TODO: remove services not in docker-compose
    //TODO: insert services not in db
}

export function syncEnvs(env?: PathLike) {
    const envs = parseEnv(env)
    Object.keys(envs).forEach(e => {
        configureEnv(envs[e]);
    });
    deleteOldEnvs(Object.keys(envs))
}

export function syncUsers(usersFilePath?: PathLike) {
    deleteAllUsers();

    if (!existsSync(usersFilePath)) {
        console.log(`  --> [WARN] Users file not found, skipping user sync`);
        console.log(`  --> [WARN] homelab currently has no user`)
        return;
    }
    console.log(`  --> Syncing users from ${usersFilePath}`);
    try {
        const autheliaUsers = parseAutheliaUsers(usersFilePath);
        const users: UserModel[] = Object.entries(autheliaUsers.users).map(([username, data]) => {
            return {
                username,
                email: data.email,
                password: data.password,
                display_name: data.displayname,
                groups: data.groups.join(',')
            }
        });
        insertUsers(users);
    } catch (error) {
        console.error(`  - syncing users: `, error);
        throw error;
    }
}

export function multipleUpdate(db: DatabaseSync, table: string, columns: string[], values: any[][], uniqueColumn: string) {
    if (values.length === 0) return;
    const placeholders = values.map(() => `(${[uniqueColumn, ...columns].map(() => '?').join(', ')})`).join(', ');
    const sql =
        `WITH updates(${uniqueColumn}, ${columns.join(', ')}) AS (
        VALUES ${placeholders}
    )
    UPDATE ${table}
    SET ${columns.map(col => `${col} = updates.${col}`).join(', ')}
    FROM updates
    WHERE ${table}.${uniqueColumn} = updates.${uniqueColumn}`;

    const flattenedValues = values.flat();
    // console.log(`Executing SQL: ${sql}`);
    const preparedStmt = db.prepare(sql);
    const result = preparedStmt.run(...flattenedValues);
    // console.log(`Executed SQL: ${preparedStmt.expandedSQL}`);
    console.log(`  Updated ${result.changes} rows in ${table}`);
}

export function multipleInsert(db: DatabaseSync, table: string, columns: string[], values: any[][]) {
    if (values.length === 0) return;
    const placeholders = values.map(() => `(${columns.map(() => '?').join(', ')})`).join(', ');
    const sql =
        `INSERT INTO ${table} (${columns.join(', ')})
        VALUES ${placeholders}`;

    const flattenedValues = values.flat();
    // console.log(`Executing SQL: ${sql}`);
    const preparedStmt = db.prepare(sql);
    const result = preparedStmt.run(...flattenedValues);
    // console.log(`Executed SQL: ${preparedStmt.expandedSQL}`);
}