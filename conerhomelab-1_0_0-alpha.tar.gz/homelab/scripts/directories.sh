#!/bin/bash
set +e
DIRECTORIES_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
HOMELAB_DIR=$(cd "$DIRECTORIES_SCRIPT_DIR/.." &>/dev/null && pwd)
HOMELAB_SCRIPTS_DIR=$(cd "$HOMELAB_DIR/scripts" &>/dev/null && pwd)
INSTALL_DATA_DIR=$(cd "$DIRECTORIES_SCRIPT_DIR/../../install" &>/dev/null && pwd)

source $DIRECTORIES_SCRIPT_DIR/print.sh
print_debug "Homelab directory: ${LIGHT_CYAN}$HOMELAB_DIR${NC}" "${BASH_SOURCE[0]##*/}"
print_debug "Homelab scripts directory: ${LIGHT_CYAN}$HOMELAB_SCRIPTS_DIR${NC}" "${BASH_SOURCE[0]##*/}"
print_debug "Utils script directory: ${LIGHT_CYAN}$DIRECTORIES_SCRIPT_DIR${NC}" "${BASH_SOURCE[0]##*/}"
print_debug "Installation data directory: ${LIGHT_CYAN}${INSTALL_DATA_DIR:-${LIGHT_RED}not found}${NC}" "${BASH_SOURCE[0]##*/}"
set -e