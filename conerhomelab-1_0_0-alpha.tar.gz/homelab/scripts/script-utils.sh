#!/bin/bash
set -Eeuo pipefail
# -u: Treat unbound variables as errors (triggers ERR trap)
# -e: Exit immediately on command failure
# -E: Inherit ERR trap in functions
# -o pipefail: Catch errors in pipelines


UTILS_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "${UTILS_SCRIPT_DIR}/print.sh"

FTLCONF_DNS_HOSTS=$(cat "$UTILS_SCRIPT_DIR/../local-dns-table.list")
export FTLCONF_DNS_HOSTS

function crun() {
  local command=$1
  docker compose -f "$HOMELAB_DIR/docker-compose.yml" run --no-deps --rm $command
}

# TODO: to test
function edit_yaml() {
    local FILE=$1
    local KEY=$2
    local VALUE=$3
    local ESCAPED_VALUE

    ESCAPED_VALUE="$(echo "$VALUE" | "$UTILS_SCRIPT_DIR"/sed_escape.sh -m replacement)"
    echo -e "${INFO} Aggiorno la chiave ${CYAN}$KEY${NC} nel file $FILE ..."
    sed "s/^\(${KEY}: \).*/\1${ESCAPED_VALUE}/" "$FILE" > "$FILE.tmp" && mv "$FILE.tmp" "$FILE"
}

# $1: array as string, $2: value to check
# TODO: to test
function contains() {
  local array=($1)
  local value="$2"
  for element in "${array[@]}"; do
    if [[ "$element" == "$value" ]]; then
      echo "true"
      return
    fi
  done
  echo "false"
}

function recreate_container() {
    local args=("$@")
    local DOCKER_COMPOSE_FILE=$1
    for CONTAINER_NAME in "${args[@]:1}"; do
        if [ "$(docker ps -q -f name="$CONTAINER_NAME")" ]; then
            echo "  $CONTAINER_NAME è in esecuzione. Ricreo il container per applicare le nuove configurazioni."
            docker compose -f "$DOCKER_COMPOSE_FILE" up -d --force-recreate "$CONTAINER_NAME"
        else
            echo "  $CONTAINER_NAME non è in esecuzione. Ricreo il container senza avviarlo."
            docker compose -f "$DOCKER_COMPOSE_FILE" up -d --force-recreate --no-start "$CONTAINER_NAME"
        fi
    done
}

function rainbow() {
  for code in {0..255}
    do echo -e "\e[38;5;${code}m"'\\e[38;5;'"$code"m"\e[0m"
  done
}