#!/usr/bin/env bash

LOCAL_DNS_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
source "$LOCAL_DNS_SCRIPT_DIR/directories.sh"
source "$HOMELAB_DIR/.env"

MODE="${1:-'private'}"

# Risolvi il default (bash lo fa nativamente)
IP="${TAILSCALE_IP:-$LAN_IP}"

# Costruisci la lista dinamica
PUBLIC_HOSTS="auth" # vpn no need for a record, it needs to be added only on public dns
HOSTS="calendar dns home portainer speedtest status vault music files"
HOSTS_LAN="cron config"

echo

if [ "$MODE" == "public" ]; then
  echo -e "Generating local DNS table for Homelab with ${CYAN}Headscale${NC} VPN mode"
else
  HOSTS="$PUBLIC_HOSTS $HOSTS"
  echo -e "Generating local DNS table for Homelab with ${CYAN}Tailscale${NC} VPN mode"
fi

echo

FTLCONF_DNS_HOSTS=""
for h in $HOSTS; do
  FTLCONF_DNS_HOSTS+="${IP} ${h}.${DOMAIN}\n"
done
for h in $HOSTS_LAN; do
  FTLCONF_DNS_HOSTS+="${LAN_IP} ${h}.${DOMAIN}\n"
done

echo -e "$FTLCONF_DNS_HOSTS" > "$HOMELAB_DIR"/local-dns-table.list
echo -e "$FTLCONF_DNS_HOSTS"

# Esporta e lancia
# export FTLCONF_DNS_HOSTS
# docker compose up -d   