# CADDY as Reverse Proxy

## Configurazione nel Caddyfile

[Caddyfile docs](https://caddyserver.com/docs/caddyfile)
[Caddyfile environment variables](https://caddyserver.com/docs/caddyfile/concepts#environment-variables)
[Homelab Caddyfile](../caddy/Caddyfile)

---

## Tailscale domains

Domains ending in `.ts.net` certificates will not be managed by Caddy. Instead, Caddy will automatically attempt to get these certificates at handshake-time from the locally-running [Tailscale](https://tailscale.com/)  instance. This requires that [HTTPS is enabled in your Tailscale account](https://tailscale.com/kb/1153/enabling-https/)  and the Caddy process must either be running as root, or you must configure `tailscaled` to give your Caddy user permission to fetch certificates.

 https://caddyserver.com/docs/automatic-https

## Autenticazione OIDC con Authelia

Con OIDC, non devi più usare `forward_auth` per Vaultwarden. La protezione non è più a livello di "rete" (Caddy), ma a livello di "applicazione" (Vaultwarden).
