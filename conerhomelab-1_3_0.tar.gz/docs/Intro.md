# NODO 1 - Radxa ROCK 2A

Per la configurazione iniziale clicca [qui](docs/Guida_Configurazione.md)

Questo nodo funge da **Gateway, DNS e Security Layer** per l'intero homelab.  
È progettato per l'alta disponibilità (24/7), il basso consumo energetico e l'accesso remoto sicuro tramite rete Mesh VPN.  
In questa architettura distribuita, il Nodo 1 gestisce l'identità e il traffico, delegando i servizi ad alto carico (Media/Archiviazione) al Nodo 2.
Abbiamo trasformato una [**Radxa ROCK 2A**](https://radxa.com/products/rock2/2a) (una SBC con risorse finite ma ben bilanciate) nel "cervello" centrale dell'intera infrastruttura.

![Radxa ROCK 2A Overview](https://radxa.com/rock2/2a/overview/rock2a-view3.webp)

## Specifiche Hardware

|**Componente**|**Modello Selezionato**|**Motivazione**|
|---|---|---|
|**SBC**|[**Radxa ROCK 2A (2GB RAM)**](https://radxa.com/products/rock2/2a)|Porta USB 3.0 per backup, Gigabit Ethernet, ottimo rapporto prezzo/prestazioni, basso footprint energetico.|
|**Storage**|MicroSD SanDisk Max Endurance 64GB|Progettata per resistere a scritture continue (log DNS/Docker).|
|**Case**|Compatibile Raspberry Pi 3 B|Form factor standard; dissipazione passiva preferita per silenziosità.|
|**Alimentazione**|USB-C 5V/3A (Quality Brand)|Stabilità elettrica fondamentale per evitare corruzione dati su SD.|

---

## 1. La scelta dell'Hardware e del File System

Essendo un nodo che deve restare acceso 24/7, l'affidabilità dello storage è una priorità.

### DietPi OS

Meno processi girano, meno punti di rottura ci sono. DietPi riduce all'osso l'occupazione della RAM e della CPU, lasciando quasi tutti i 2GB della Radxa a disposizione dei tuoi servizi. [DietPi](https://dietpi.com/)

### MicroSD High Endurance

Le schede SD comuni muoiono velocemente a causa dei log di sistema e delle scritture costanti dei database (come quello di Vaultwarden). Abbiamo scelto una **Lexar High Endurance da 64GB** non solo per lo spazio, ma perché raddoppia le ore di vita utile rispetto alla versione da 32GB e garantisce una velocità di scrittura costante (V30), fondamentale per evitare rallentamenti quando più servizi scrivono contemporaneamente.

### Networking Privato: Tailscale (Official Free Tier)

Mesh VPN con Tailscale. Sostituibile con `Headscale` ma la versione cloud gratuita di [Tailscale](https://tailscale.com/blog/how-tailscale-works) garantisce una maggiore affidabilità e manutenzione zero.
Il Nodo 1 fungerà anche da **Exit Node** (opzionale) per navigare sicuri su Wi-Fi pubblici.

## 2. L'Architettura "Ibrida" (Nativo + Docker)

Invece di "dockerizzare" tutto, si è optato per un mix strategico:

### Unbound e Tailscale, Cockpit Nativi

Abbiamo deciso di installare [Unbound](https://unbound.docs.nlnetlabs.nl/en/latest/) e [Tailscale](https://tailscale.com/blog/how-tailscale-works) direttamente sull'OS. Perché? Perché sono le fondamenta della rete. Se Docker dovesse avere un problema, la rete mesh (Tailscale) e la risoluzione DNS interna (Unbound) devono rimanere attive per permetterti di intervenire da remoto.
Cockpit on: https://{LOCAL_IP_192}:9890/

- **Il resto in Docker:** Vaultwarden, Pi-hole e gli altri servizi vivono in container per garantirti facilità di aggiornamento e portabilità. Se un domani vorrai cambiare hardware, basterà spostare la cartella dello stack e tutto tornerà online in pochi secondi.

Architettura dei Servizi (Docker Stack)

### Stack Docker (`docker-compose.yml`)

| Container | Funzione | Descrizione | RAM |
| :--- | :--- | :--- | :--- |
| **Caddy** | Reverse Proxy | Termina le connessioni HTTPS per i sottodomini `.conerolabs.com` e smista il traffico verso i servizi interni o verso gli altri nodi. | 100 MB |
| **Authelia** | Auth Server | Server di autenticazione | 175 MB |
| **Redis** | Cache | Cache per le sessioni di Authelia | 64 MB |
| **[PiHole](https://docs.pi-hole.net/)** | DNS Filter and Cache | DNS sinkhole, Blocco pubblicità a livello di rete. | 175 MB |
| **[Vaultwarden](https://www.vaultwarden.net/)** | Password Manager | Server Bitwarden self-hosted scritto in Rust con database SQLite mappato sulla cartella `/data` locale. | 128 MB |
| **Homepage** | Dashboard | "Single pane of glass" per l'accesso rapido ai servizi. | 150 MB |
| **Gatus** | Monitoraggio | Controlla lo stato dei servizi e dei Nodi 2 e 3 con notifiche. | 64 MB |
| **MySpeed** | Internet SpeedTest | Controlla la velocità della connessione internet. | 120 MB |
| **Portainer** | Containers Management UI | Gestisci i tuoi containers da interfaccia web | 100 MB |
| **Total** | | | **1070 MB** |

---

## 3. Gestione dei 2GB di RAM

Criteri usati per i limiti (2GB RAM Target)
I valori di RAM assegnati ai containers Docker, sono stati definiti in base a tre criteri ingegneristici: Footprint del Runtime, Picchi di Carico e Margine di Sicurezza.

### A. Analisi del Runtime (Linguaggi e Framework)

Go (Authelia, Caddy, Gatus): Sono binari compilati. Sono estremamente efficienti nella gestione della memoria. 100-150MB sono generosi; in idle ne usano spesso meno di 50MB.

Node.js (Homepage): Qui serve cautela. Node.js ha un garbage collector che tende a espandersi fino a quando non sente pressione sulla memoria. Ho impostato 150MB per evitare che il processo occupi RAM inutilmente solo perché "vede" spazio libero.

Rust (Vaultwarden): Essendo una reimplementazione in Rust di Bitwarden (che è in .NET), è incredibilmente leggero. 128MB bastano anche per gestire database di password voluminosi.

### B. Picchi di Carico vs Idle

Ho calcolato i limiti basandomi sul "worst-case scenario" simultaneo:

Pi-hole: Se ricevi migliaia di query DNS al secondo (es. un attacco o un loop di rete), la memoria occupata dal database FTL cresce. 200MB sono il "tetto massimo" per evitare che un picco DNS mandi in crash l'intera board.

Authelia: Durante la generazione di hash Argon2 per il login, la CPU e la RAM hanno dei picchi brevi.  
Per evitare saturazione della memoria (OOM) sui 2GB della Radxa durante l'autenticazione, Authelia è configurato con parametri "Low-Memory":

- **Memory Cost:** 32MB (32768 KB)
- **Iterations:** 3
- **Parallelism:** 2

### C. La Regola dell'80/20

In un sistema con 2GB:

~250MB per il Sistema Operativo (Armbian + Kernel + ZRAM overhead).  
~1070MB di Limiti Hard per Docker (la somma dei limits che ti ho dato).  
~650MB di Buffer libero per il caching del filesystem e per evitare lo swapping aggressivo.

In ingegneria dei sistemi, non dovresti mai saturare la RAM fisica oltre l'80% se vuoi mantenere latenze basse (fondamentale per il DNS).

### Monitoraggio

Una volta avviato lo stack, usa il comando nativo di Docker per vedere come si comportano i processi sotto stress:

```Bash
docker compose stats
```

Vedrai una colonna MEM USAGE / LIMIT. Se vedi un container che sta costantemente sopra il 90% del suo limite, dovrai alzare leggermente quel valore a discapito di un altro servizio meno critico.

---

### La ZRAM

In un sistema con soli **2GB di RAM**, la **ZRAM** non è solo un'opzione, è la tua rete di salvataggio. Su DietPi, la gestione della ZRAM è particolarmente efficiente e si sposa perfettamente con i limiti Docker che abbiamo impostato.

La ZRAM crea un dispositivo a blocchi compresso all'interno della RAM fisica. Quando il sistema inizia a sentire pressione sulla memoria, invece di fare lo "swap" dei dati sul disco (MicroSD/eMMC), che è lento e usurante, li **comprime** e li tiene in RAM.

In un server DNS/Dashboard come il tuo, i dati sono principalmente testo e log, il che permette rapporti di circa **3:1**.
È come se i 2GB diventassero virtualmente **3GB o più**, con una penalità di latenza sulla CPU (Cortex-A53) quasi impercettibile per i tuoi carichi di lavoro.

#### [Configurazione su DietPi](docs/Guida_Configurazione.md#5-abilitazione-zram)

---

### Interazione ZRAM e limiti Docker

Ecco la magia: Docker non sa che sotto c'è la ZRAM.

Quando un container (ad esempio **Homepage**) raggiunge il limite che abbiamo impostato (150MB) e tenta di allocarne altri, il kernel Linux inizierà a spostare le pagine di memoria "fredde" (non usate di frequente) nella ZRAM.

Questo evita che l'**OOM Killer** termini i tuoi container prematuramente durante un picco di traffico, perché il sistema troverà sempre quel "margine" di memoria compressa libera.

---

### Monitoraggio in tempo reale

Dal tuo terminale (magari via VS Code SSH), puoi vedere la ZRAM in azione con il comando:
`zramctl`

Vedrai una tabella simile a questa:

| NAME | ALGORITHM | DISKSIZE | DATA | COMPRESS | TOTAL |
| :--- | :--- | :--- | :--- | :--- | :--- |
| /dev/zram0 | zstd | 1G | 450M | 110M | 130M |

- **DATA:** La quantità di dati che il sistema crede di aver scritto (450MB).
- **TOTAL:** Lo spazio reale occupato nella tua RAM fisica dopo la compressione (**solo 130MB!**).

---

## 4. La Strategia "Zero Exposure" e il Tunnel Tailscale

Qui abbiamo applicato il principio di sicurezza **Zero Trust**.

- Non abbiamo aperto nessuna porta sul router. L'accesso avviene esclusivamente tramite **Tailscale**. Questo crea un tunnel cifrato punto-a-punto tra i nodi partecipanti alla rete.

- Abbiamo integrato **Caddy con Tailscale**. Caddy recupera i certificati SSL direttamente dal socket di Tailscale, permettendoti di avere il "lucchetto verde" (HTTPS) sui tuoi domini interni (es. `vault.conerolabs.iguana-justitia.ts.net`) senza mai interagire con il web pubblico.

## 4. Il layer di sicurezza: Authelia + Redis

Per proteggere i servizi critici, non ci siamo fidati delle singole password di ogni app. Abbiamo inserito **Authelia** come guardiano (Forward Auth).

Quando provi ad accedere alla dashboard o al password manager, Caddy interroga Authelia. Se non sei autenticato, verrai fermato da una pagina di login con **Multi-Factor Authentication (MFA)**.

![Authentication Sequence Diagram](https://www.authelia.com/overview/prologue/architecture/sequence-diagram_hu_56b2d123c0dc031e.webp)

È una soluzione professionale che centralizza l'identità: un solo utente (il tuo) protetto da un secondo fattore di sicurezza forte, che fa da scudo a tutto lo stack.

Per gestire le sessioni in Authelia utilizziamo **Redis** apportando i seguenti vantaggi rispetto ad una soluzione più semplice:

- Persistenza senza I/O pesante: Redis scrive gli snapshot su disco (dump.rdb) raramente, mentre le sessioni vengono lette e scritte in millisecondi in RAM. Questo salva la tua MicroSD dai continui aggiornamenti del database SQLite di Authelia.

- Scalabilità dei container: Se in futuro dovessi riavviare solo il container di Authelia per aggiornarlo, gli utenti non verrebbero disconnessi, perché la loro sessione è "viva" nel container Redis.

- Latenza: Caddy e Redis sono scritti rispettivamente in Go e C/ANSI; la latenza di autorizzazione su una board ARM come la Radxa sarà nell'ordine dei microsecondi.

## 5. Monitoraggio e Dashboard (Homepage + Gatus)

Un nodo senza visibilità è un nodo cieco.

### Gatus

Abbiamo aggiunto **Gatus** per monitorare non solo il Nodo 1, ma anche i futuri Nodi 2 e 3, con la capacità di inviarti notifiche se qualcosa cade.

#### Politica di Monitoraggio

La connessione a internet di Gatus viene monitorata ogni minuto per prevenire che vengano riportati finti malfunzionamenti riguardanti i servizi controllati.
In assenza di connettività tutti i controlli vengono saltati.

```yaml
connectivity:
  checker:
    target: 1.1.1.1:53
    interval: 60s
```

### Homepage

Abbiamo coronato il tutto con **Homepage**. Invece di ricordare porte e indirizzi IP, hai una "Control Room" elegante che interroga le API di Pi-hole e Docker per darti lo stato di salute del sistema a colpo d'occhio.

## 6. La Continuità Operativa (Il Backup)

Infine, abbiamo affrontato il tema del _Disaster Recovery_.

- Abbiamo sfruttato la porta **USB 3.0** della Radxa ROCK 2A per un disco esterno.
- Lo script che abbiamo progettato mette in pausa i container per assicurarsi che i database SQLite non siano in fase di scrittura (evitando corruzioni), copia i dati e poi li riavvia, mantenendo uno storico degli ultimi 4 backup settimanali.

---

## 7. Note Tecniche

### Manutenzione e Backup

- **Logs:** Armbian gestisce i log in RAM per preservare la MicroSD.
- **Backup:** Sfruttando la porta **USB 3.0** della ROCK 2A, è previsto il collegamento di un piccolo disco per il backup settimanale dei volumi Docker (`/var/lib/docker/volumes`).
- **Aggiornamenti:** Gestiti tramite `dietpi-update` per il sistema e `docker-compose pull` per i servizi.

### Workflow di Accesso Remoto

1. Il client Tailscale (sul tuo notebook Ubuntu) si connette alla rete mesh.
2. Accedi al Nodo 1 tramite il nome di dominio configurato su Caddy e sul DNS locale di PiHole (es: `vault.conerolabs.com`)
3. Caddy gestisce automaticamente i certificati TLS per garantire HTTPS su ogni servizio.
4. Prima di farti accedere al servizio Caddy interroga Authelia per l'autenticazione tranne per Vaultwarden che ha l'integrazione OIDC (OpenID Connect) nativa.

### La gerarchia della sicurezza in Homelab

Visualizza la sicurezza come due cerchi concentrici:

Cerchio Esterno (Tailscale + IdP Esterno): Usi ad esempio il tuo account GitHub con la sua 2FA (chiave fisica o app). Questo ti permette di "entrare" nel tunnel sicuro e vedere i tuoi server.

Cerchio Interno (Authelia): Una volta "dentro" la rete Tailscale, se provi ad aprire servizi critici (Vaultwarden, Portainer), ti viene chiesto un secondo login sul tuo Authelia.

Nota: Se un domani volessi centralizzare tutto, Tailscale supporta l'integrazione con IdP personalizzati (via OIDC), ma è una funzione del piano Enterprise. Per il piano Free, usare GitHub o Google come "chiave della porta principale" è la soluzione standard e più sicura.

---

## In Sintesi

Il Nodo 1 non è solo un server, è un **Gateway di Infrastruttura** resiliente, sicuro e monitorato. Ha il compito di gestire l'identità e il traffico, lasciando i nodi più potenti (come l'N100) liberi di occuparsi solo di dati e calcolo.
