#!/bin/bash
source install/.env
TAG="v$HOMELAB_VERSION"
echo "Tagging the release in git repository ... ($TAG)"
# switching to main branch to avoid tagging the release on a different branch
#git checkout main
git tag -d "$TAG" 2>/dev/null || true
git push origin --delete "$TAG" 2>/dev/null || true   
git tag -a "$TAG" -m "Release versione $HOMELAB_VERSION"
git push origin "$TAG"

# edit HOMELAB_VERSION in .env file
RELEASE_TYPE=$1

if [ "$RELEASE_TYPE" = "major" ]; then
    NEXT_VERSION=$(echo "$HOMELAB_VERSION" | awk -F. '{print $1+1"."0"."0}')
elif [ "$RELEASE_TYPE" = "minor" ]; then
    NEXT_VERSION=$(echo "$HOMELAB_VERSION" | awk -F. '{print $1"."$2+1"."0}')
else
    NEXT_VERSION=$(echo "$HOMELAB_VERSION" | awk -F. '{print $1"."$2"."$3+1}')
fi

echo "Incrementing version to $NEXT_VERSION for next development cycle..."
ESCAPED_NEXT_VERSION=${NEXT_VERSION//./\\.}
sed "s/^HOMELAB_VERSION=.*/HOMELAB_VERSION=$ESCAPED_NEXT_VERSION/" install/.env   > .env.tmp && mv .env.tmp install/.env
git commit -am "Increment version to $NEXT_VERSION for next development cycle"
git push origin main