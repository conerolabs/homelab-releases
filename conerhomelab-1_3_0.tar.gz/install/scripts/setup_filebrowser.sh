#!/bin/bash

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "${SCRIPT_DIR}"/script-utils.sh
source "$HOMELAB_DIR/.env"

echo
echo -e "${BLUE}#########################################################"
echo -e "##########   Configurazione di FILEBROWSER   ############"
echo -e "##########         -- File Browser --        ############"
echo -e "#########################################################${NC}"
echo
#! Interazione Utente
if [ -z "$FILEBROWSER_ADMIN" ]; then
    echo -e "${PENCIL} Utente admin per File Browser? (Deve esistere anche in Authelia):"
    read -p "" -r USERNAME
    echo -e "${PENCIL} Password (Non verrà utilizzata se si passa per Authelia, ma è richiesta):"
    read -s -p "" -r PASSWORD
    crun "filebrowser config init --auth.method=proxy --auth.header=Remote-User"
    crun "filebrowser users add $USERNAME $PASSWORD --perm.admin=true"
    edit_env "FILEBROWSER_ADMIN" "$USERNAME"
else
    echo -e "${INFO} Utente admin per File Browser già esistente."
fi
echo

if [ -z "$HOMEPAGE_FILEBROWSER_USER" ]; then
    echo "Creo l'utente per Homepage..."
    crun "filebrowser users add homepage $(openssl rand -base64 8) --perm.admin=false"
    echo
    edit_env "HOMEPAGE_FILEBROWSER_USER" homepage
else 
    echo -e "${INFO} Utente per Homepage già presente."
fi
echo

echo "Configuro la personalizzazione di File Browser..."
crun 'filebrowser config set --branding.files /branding'

echo
echo -e "${OK} Configurazione di File Browser completata."
echo
