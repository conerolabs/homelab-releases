#!/bin/bash

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "${SCRIPT_DIR}"/script-utils.sh
source "$HOMELAB_DIR/.env"

# Crea la cartella per i segreti se non esiste già
SECRETS_DIR="$HOMELAB_DIR/rustical/secrets"
SECRET_FILE="$SECRETS_DIR/oidc_client_secret.txt"
mkdir -p "$SECRETS_DIR"
chmod 700 "$SECRETS_DIR"
echo
echo -e "${BLUE}###############################################################"
echo "###########    Configurazione di RustiCal    ###############"
echo "#####        -- Calendar/Contacts Server --       ##########"
echo -e "###############################################################${NC}"
echo

echo "Generazione del client id per Authelia RustiCal client ..."
if [ -z "$RUSTICAL_SSO_CLIENT_ID" ]; then
    CLIENT_ID=$(openssl rand -hex 16)
    echo "  Client ID: $CLIENT_ID"
    echo -n "  "
    edit_env "RUSTICAL_SSO_CLIENT_ID" "$CLIENT_ID"
else
    echo "  Client ID già configurato: $RUSTICAL_SSO_CLIENT_ID"
fi
echo
# Authelia RustiCal client, poi faremo l'hash per Authelia)
echo "Generazione del segreto del client OIDC di RustiCal..."

# Secret file non ancora supportato da RustiCal, quindi lo leggiamo in un env var (non è ideale, ma è l'unica opzione al momento)
# if [ -f "$SECRET_FILE" ]; then
#     echo -e "  ${CYAN}sso_client_secret.txt${NC} esiste già in $SECRETS_DIR"
# else
#     openssl rand -base64 32 | tr -d '\n' > "$SECRET_FILE"
#     echo -e "  ${CYAN}sso_client_secret.txt${NC} generato in $SECRETS_DIR"
# fi
if [ -z "$RUSTICAL_SSO_CLIENT_SECRET" ]; then
    CLIENT_SECRET=$(openssl rand -base64 32 | tr -d '\n')
    echo "  Nuovo client secret generato correttamente."
    echo -n "  "
    edit_env "RUSTICAL_SSO_CLIENT_SECRET" "$CLIENT_SECRET"
else
    echo "  Client Secret esiste già. Non verrà rigenerato."
fi
echo
print_success "Configurazione di RustiCal completata."
echo