#!/usr/bin/env bash
set -euo pipefail
LOG=sed_escape_test.log
: > "$LOG"

run() {
  echo ">>> $*"
  rc=0
  out=$("$@" 2>&1) || rc=$?
  echo "exit:$rc"
  echo "$out"
  echo
}

run_stdin() {
  # $1 = description, $2 = stdin string, $3... = command and args
  echo ">>> $1"
  rc=0
  out=$(printf "%s" "$2" | ${@:3} 2>&1) || rc=$?
  echo "exit:$rc"
  echo "$out"
  echo
}

{
  which perl || true
  echo
  echo '--- pattern default ---'
  echo 'input: a/b & c'
  run ./sed_escape.sh 'a/b & c'

  echo '--- replacement mode ---'
  echo 'input: a/b & c'
  run ./sed_escape.sh -m replacement 'a/b & c'

  echo '--- custom delimiter | pattern ---'
  echo 'input: a|b & c'
  run ./sed_escape.sh -d '|' -m pattern 'a|b & c'

  echo '--- stdin replacement ---'
  echo 'input: a/b & c (stdin)'
  run_stdin 'stdin replacement (replacement mode)' 'a/b & c' ./sed_escape.sh -m replacement

  echo '--- pattern special chars ---'
  echo 'input: .*[test]^$'
  run ./sed_escape.sh '.*[test]^$'
} | tee "$LOG"

echo "Wrote $LOG"
