#!/bin/bash
set -euo pipefail
HOMELAB_DIR=$(cd "$(dirname "${BASH_SOURCE}")/../../homelab" &>/dev/null && pwd)
#echo "Homelab directory: $HOMELAB_DIR"
UTILS_SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
#echo "Script directory: $UTILS_SCRIPT_DIR"
INSTALL_DATA_DIR=$(cd "$(dirname "${BASH_SOURCE}")/.." &>/dev/null && pwd)
#echo "Installation data directory: $INSTALL_DATA_DIR"

# Italic
ITALIC='\e[3m'
NOT_ITALIC='\e[23m'
# Foreground
RED='\e[0;31m'
GREEN='\e[0;32m'
YELLOW='\e[1;33m'
BLUE='\e[0;34m'
MAGENTA='\e[0;35m'
CYAN='\e[0;36m'
WHITE='\e[1;37m'
# Background
BG_RED='\e[0;41m'
BG_GREEN='\e[0;42m'
# Reset
NC='\e[0m'
# Symbols
OK='\u2705'
WARN='\u26A0'
ERROR='\u274C'
PENCIL='\u270F'
INFO='\u2139'

crun() {
  local command=$1
  docker compose -f "$HOMELAB_DIR/docker-compose.yml" run --no-deps --rm $command
}

print_info() {
    echo -e "${INFO} ${CYAN}$1${NC}"
}

print_success() {
    echo -e "${OK} $1"
}

print_warning() {
    echo -e "${WARN} ${YELLOW}$1${NC}"
}

print_error() {
    echo -e "${ERROR} ${RED}$1${NC}"
}

# TODO: to test
erase_lines() {
  local n=${1:-1}
  for ((i=0; i<n; i++)); do
    echo -ne "\033[1A\033[2K"
  done
}   

function edit_env() {
    local ENV_VAR=$1
    local VALUE=$2
    local ESCAPED_VALUE

    ESCAPED_VALUE="$(echo "$VALUE" | "$UTILS_SCRIPT_DIR"/sed_escape.sh -m replacement)"
    echo -e "${INFO} Aggiorno la variabile ${CYAN}$ENV_VAR${NC} nel file .env ..."
    sed "s/^${ENV_VAR}=.*/${ENV_VAR}='$ESCAPED_VALUE'/" "$HOMELAB_DIR/.env"   > .env.tmp && mv .env.tmp "$HOMELAB_DIR/.env"
}

# TODO accept progress and print a bar!
function progress(){
    local duration=$1
    local label=${2:-"Processing"}
    local width=40
    local progress=0
    local step=1
    
    echo -ne "${label} ["
    for ((i=0; i<width; i++)); do echo -ne " "; done
    echo -ne "] 0%"

    for ((i=0; i<=width; i++)); do
        sleep "$(echo "scale=3; $duration / $width" | bc)"
        echo -ne "\r${label} ["
        for ((j=0; j<i; j++)); do echo -ne "#"; done
        for ((j=i; j<width; j++)); do echo -ne " "; done
        echo -ne "] $((i * 100 / width))%"
    done
    echo -e " ${OK}"
    
}

# $1: array as string, $2: value to check
# TODO: to test
function contains() {
  local array=($1)
  local value="$2"
  for element in "${array[@]}"; do
    if [[ "$element" == "$value" ]]; then
      echo "true"
      exit 0
    else
      echo "false"
    fi
  done
}