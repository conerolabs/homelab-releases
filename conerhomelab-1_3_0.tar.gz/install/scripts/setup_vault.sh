#!/bin/bash

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "${SCRIPT_DIR}"/script-utils.sh

# Crea la cartella per i segreti se non esiste già
SECRETS_DIR="$HOMELAB_DIR/vaultwarden/secrets"
mkdir -p "$SECRETS_DIR"
chmod 700 "$SECRETS_DIR"
echo
echo -e "${BLUE}###############################################################"
echo "###########    Configurazione di VAULTWARDEN    ###############"
echo "###########        -- Password Manager --       ###############"
echo -e "###############################################################${NC}"
echo

echo "Generazione del client id per Authelia Vaultwarden client ..."
if [ -e "$VAULTWARDEN_SSO_CLIENT_ID" ]; then
    CLIENT_ID=$(openssl rand -hex 32)
    echo "  Client ID: $CLIENT_ID"
    edit_env "VAULTWARDEN_SSO_CLIENT_ID" "$CLIENT_ID"
else
    echo "  Client ID già configurato: $VAULTWARDEN_SSO_CLIENT_ID"
fi

# Authelia Vaultwarden client, poi faremo l'hash per Authelia)
echo "Generazione del segreto del client OIDC di Vaultwarden..."
if [ -f "$SECRETS_DIR/sso_client_secret.txt" ]; then
    echo -e "  ${CYAN}sso_client_secret.txt${NC} esiste già in $SECRETS_DIR"
else
    openssl rand -base64 32 | tr -d '\n' > "$SECRETS_DIR/sso_client_secret.txt"
fi

#! Interazione Utente
if [ -e "$VAULTWARDEN_ADMIN_TOKEN" ]; then
    read -s -p "${PENCIL} Inserisci la password per il token di ADMIN: " -r PSW
    echo
    read -s -p "${PENCIL} Conferma la password:" -r PSW_CONFIRM
    echo
    if [ "$PSW" != "$PSW_CONFIRM" ]; then
        echo "${ERROR} Le password non corrispondono. Riprova."
        exit 1
    fi
    echo "Generazione dell'hash Argon2 per il token di ADMIN ..."
    HASH=$("$SCRIPT_DIR"/hashpsw.sh "$PSW" bitwarden | sed -n '2p')
    echo "Hash generato: $HASH"
    edit_env "VAULTWARDEN_ADMIN_TOKEN" "$HASH"
else
    echo "Password per il token di ADMIN già configurata."
fi
echo
echo -e "$OK Configurazione di Vaultwarden completata."
echo