#!/bin/bash

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$SCRIPT_DIR/script-utils.sh"
source "$HOMELAB_DIR/.env"

# Crea la cartella per i segreti
SECRETS_DIR="$HOMELAB_DIR/gatus/secrets"
mkdir -p "$SECRETS_DIR"
chmod 700 "$SECRETS_DIR"
echo
echo -e "${BLUE}#########################################################"
echo "######         Configurazione di GATUS         ##########"
echo "######   -- Uptime monitoring and alerting --  ##########"
echo -e "#########################################################${NC}"
echo

echo "Generazione del client id per Authelia ..."
if [ -e "$GATUS_OIDC_CLIENT_ID" ]; then
    CLIENT_ID=$(openssl rand -hex 32)
    edit_env "GATUS_OIDC_CLIENT_ID" "$CLIENT_ID"
    echo "  Client ID: $CLIENT_ID"
else
    echo -e "  Il ${CYAN}client ID${NC} esiste già: $GATUS_OIDC_CLIENT_ID"
fi

# Authelia Gatus client, poi faremo l'hash per Authelia)
echo "Generazione del segreto del client OIDC di Gatus ..."
if [ -f "$SECRETS_DIR/oidc_client_secret.txt" ]; then
    echo -e "  ${CYAN}oidc_client_secret.txt${NC} esiste già in $SECRETS_DIR"
else
    openssl rand -base64 32 | tr -d '\n' > "$SECRETS_DIR/oidc_client_secret.txt"
fi
echo
echo -e "${OK} Configurazione di Gatus completata."
echo