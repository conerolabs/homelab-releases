#!/bin/bash
# Dependencies installation
# - Docker
# - Unbound
# - Tailscale
# - Git

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source /etc/os-release # be careful with variables names
source "$SCRIPT_DIR/script-utils.sh"

function docker_install() {
    # Add Docker's official GPG key:
    sudo apt update
    sudo apt install ca-certificates curl
    sudo install -m 0755 -d /etc/apt/keyrings
    sudo curl -fsSL https://download.docker.com/linux/$ID/gpg -o /etc/apt/keyrings/docker.asc
    sudo chmod a+r /etc/apt/keyrings/docker.asc
    # Add the repository to Apt sources:
    sudo tee /etc/apt/sources.list.d/docker.sources <<EOF
Types: deb
URIs: https://download.docker.com/linux/$ID
Suites: "${UBUNTU_CODENAME:-$VERSION_CODENAME}"
Components: stable
Signed-By: /etc/apt/keyrings/docker.asc
EOF
    sudo apt update
    sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
}

echo "Checking pre-requisites ..."
# TODO: Eventually check also versions

if command -v docker > /dev/null; then
    echo -e "${OK} Docker è già installato"
    sudo systemctl start docker
else
    docker_install
fi
if dpkg -s python3-dotenv > /dev/null 2>&1; then
    echo -e "${OK} python3-dotenv è già installato"
else
    sudo apt install -y python3-dotenv
fi
if command -v unbound > /dev/null; then
    echo -e "${OK} Unbound è già installato"
    sudo systemctl start unbound
else
    sudo apt install -y unbound
fi
if command -v unbound-anchor > /dev/null; then
    echo -e "${OK} Il tool unbound-anchor di Unbound è già installato"
else
    sudo apt install -y unbound-anchor
fi
if command -v tailscale > /dev/null; then
    echo -e "${OK} Tailscale è già installato"
else
    curl -fsSL https://tailscale.com/install.sh | sh
fi
if command -v git > /dev/null; then
    echo -e "${OK} Git è già installato"
else
    sudo apt install -y git
fi