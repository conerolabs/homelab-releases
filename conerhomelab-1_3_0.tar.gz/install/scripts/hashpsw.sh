#!/bin/bash
# Argon2 password hashing examples

# Install dependencies if needed
# sudo apt install -y argon2 openssl

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
set -euo pipefail
# shellcheck source=/dev/null
source "$SCRIPT_DIR"/../.env

if [[ -z "$1" ]]; then
    echo "Password parameter missing."
    echo "Usage: $0 <password> <profile>"
    echo "Available profiles: bitwarden, owasp, authelia"
    exit 1
fi

if [[ -z "$2" ]]; then
    echo "Profile parameter missing."
    echo "Usage: $0 <password> [profile]"
    echo "Available profiles: bitwarden, owasp, authelia"
    exit 1
fi

PSW=$1
PROFILE=$2

case $PROFILE in
    bitwarden)
        echo "Using Bitwarden default settings:"
        echo -n "$PSW" | argon2 "$(openssl rand -base64 32)" -e -id -k 65540 -t 3 -p 4
        ;;
    owasp)
        echo "Using OWASP minimum recommended settings:"
        echo -n "$PSW" | argon2 "$(openssl rand -base64 32)" -e -id -k 19456 -t 2 -p 1
        ;;
    authelia)
        echo "Using Authelia recommended settings:"
        # Generiamo un salt casuale di 16 byte (come richiesto da Authelia)
        HASH=$(docker run --rm authelia/authelia:"${AUTHELIA_VERSION}" authelia crypto hash generate argon2 \
            --password "$PSW" \
            --variant argon2id \
            --iterations 3 \
            --memory 32768 \
            --parallelism 2 | grep -oP '\$argon2id\$.*')
        echo "$HASH"
        ;;
    *)
        echo "Unknown profile value. Please use 'bitwarden', 'owasp', or 'authelia'."
        exit 1
esac