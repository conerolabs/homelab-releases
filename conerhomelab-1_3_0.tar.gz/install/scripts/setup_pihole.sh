#!/bin/bash

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$SCRIPT_DIR/script-utils.sh"
source "$HOMELAB_DIR/.env"

echo
echo -e "${BLUE}#########################################################"
echo -e "#########     Configurazione di PI-HOLE       ###########"
echo -e "#########        -- DNS Ads Filter --         ###########"
echo "#########################################################${NC}"
echo

if [ -f /etc/systemd/resolved.conf.d/disable-stub.conf ]; then
    echo "- Dns Stub resolver già disabilitato"
else
    echo "- Disabling Dns Stub resolver ..."
    sudo mkdir -p /etc/systemd/resolved.conf.d/
    sudo tee /etc/systemd/resolved.conf.d/disable-stub.conf << EOF
[Resolve]
DNSStubListener=no
EOF
    sudo ln -sf /run/systemd/resolve/resolv.conf /etc/resolv.conf
fi

if [ -f /etc/systemd/resolved.conf.d/homelab.conf ]; then
    echo "  Homelab DNS resolver già configurato"
else
    echo "- Adding Pi-Hole as DNS resolver ..."
    sudo tee /etc/systemd/resolved.conf.d/homelab.conf << EOF
[Resolve]
DNS=127.0.0.1 ${BACKUP_DNS}
EOF
fi

sudo systemctl restart systemd-resolved

echo "- Disabilito il DNS assegnato dal DHCP del Router"
INTERFACE=$(ip -br addr show | grep '192.168' | cut -d ' ' -f 1)

# TODO: a better check would be to check also file content
if [ -f /etc/systemd/network/01-"$INTERFACE".network ]; then
    echo "  Interfaccia di rete $INTERFACE già configurata"
else
    tee /etc/systemd/network/01-"$INTERFACE".network << EOF
[Match]
Name=$INTERFACE

[Network]
DHCP=yes

[DHCP]
UseDNS=false
EOF
fi
sudo systemctl restart systemd-networkd

if sudo systemctl is-active --quiet dnsmasq; then
    echo "- Disabilito dnsmasq ..."
    sudo systemctl stop dnsmasq 2>/dev/null || true
    sudo systemctl disable dnsmasq 2>/dev/null || true
else
    echo "- Il servizio dnsmasq è già disabilitato"
fi

echo -e "${OK} Configurazione di PI-HOLE completata."