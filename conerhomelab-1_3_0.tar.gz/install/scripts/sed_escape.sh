#!/usr/bin/env bash
set -euo pipefail

usage() {
cat <<'USAGE'
Usage: sed_escape.sh [-d DELIM] [-m MODE] [STRING]

Escape special characters for use in sed.

Modes:
  pattern      Escape string for sed search pattern (default). Escapes regex metacharacters.
  replacement  Escape string for sed replacement part (escapes & and backslashes).

Options:
  -d DELIM     Delimiter character used in sed command (default '/')
  -h           Show this help

If STRING is omitted, read from stdin.

Examples:
  sed_escape.sh "a/b & c"           # pattern mode, default delimiter '/'
  sed_escape.sh -m replacement "a/b & c"
  echo 'a/b & c' | sed_escape.sh -d '|' -m pattern
USAGE
}

DELIM='/'
MODE='pattern'

while getopts "d:m:h" opt; do
  case $opt in
    d) DELIM="$OPTARG" ;;
    m) MODE="$OPTARG" ;;
    h) usage; exit 0 ;;
    *) usage; exit 1 ;;
  esac
done
shift $((OPTIND-1))

if [ $# -gt 0 ]; then
  INPUT="$*"
else
  INPUT=$(cat)
fi

# Use perl if available for a reliable implementation
if command -v perl >/dev/null 2>&1; then
  export PERL_DELIM="$DELIM"
  if [ "$MODE" = "pattern" ]; then
    printf '%s' "$INPUT" | perl -pe 'chomp; $_ = quotemeta($_); $d = $ENV{PERL_DELIM} // "/"; s/\Q$d\E/\\$d/g'
  elif [ "$MODE" = "replacement" ]; then
    printf '%s' "$INPUT" | perl -pe 'chomp; s/\\/\\\\/g; s/&/\\&/g; $d = $ENV{PERL_DELIM} // "/"; s/\Q$d\E/\\$d/g'
  else
    echo "Unknown mode: $MODE" >&2; usage; exit 1
  fi
else
  # Fallback using sed (less comprehensive but portable)
  if [ "$MODE" = "pattern" ]; then
    ESC=$(printf '%s' "$INPUT" | sed -e 's/\\/\\\\/g' -e "s/${DELIM}/\\${DELIM}/g" \
      -e 's/\./\\./g' -e 's/\*/\\*/g' -e 's/\[/\\[/g' -e 's/\]/\\]/g' \
      -e 's/(/\\(/g' -e 's/)/\\)/g' -e 's/{/\\{/g' -e 's/}/\\}/g' -e 's/|/\\|/g' \
      -e 's/+\\/\\+/g' -e 's/?/\\?/g' -e 's/\^/\\^/g' -e 's/\$/\\$/g')
    printf '%s' "$ESC"
  elif [ "$MODE" = "replacement" ]; then
    ESC=$(printf '%s' "$INPUT" | sed -e 's/\\/\\\\/g' -e "s/${DELIM}/\\${DELIM}/g" -e 's/&/\\&/g')
    printf '%s' "$ESC"
  else
    echo "Unknown mode: $MODE" >&2; usage; exit 1
  fi
fi
