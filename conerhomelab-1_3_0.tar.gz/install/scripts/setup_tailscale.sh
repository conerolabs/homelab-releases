#!/bin/bash
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE}")" &>/dev/null && pwd)
source "$SCRIPT_DIR/script-utils.sh"
source "$HOMELAB_DIR/.env"

TS_IP=$(tailscale ip -4)
# if it is a valid ip
if python3 -c "import ipaddress; ipaddress.IPv4Address('$TS_IP')" >/dev/null 2>&1; then
    sudo tailscale set --accept-dns=false
    edit_env HOST_IP "$TS_IP"
    echo "Tailscale IP: $TS_IP"

    sudo tailscale up --hostname "${SERVER_NAME}"
    echo "Tailscale HOSTNAME: ${SERVER_NAME}"
else
    echo "Effettua il login con Tailscale e poi rilancia lo script"
    sudo tailscale up --hostname "${SERVER_NAME}"
    exit 1
fi